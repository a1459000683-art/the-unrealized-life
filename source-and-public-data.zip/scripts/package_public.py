#!/usr/bin/env python3
"""Prepare a portable, allowlisted public bundle. Never builds or publishes a site.

Run after `node build.cjs`: python3 scripts/package_public.py
Use --output output/public-package-check for an isolated packaging rehearsal.
All checks finish before existing prepared upload files are replaced.
"""
from __future__ import annotations

import argparse
import gzip
import hashlib
import io
import json
import os
from pathlib import Path
import re
import sys
import tempfile
import zipfile

ROOT = Path(__file__).resolve().parents[1]
PUBLIC_URL = "https://a1459000683-art.github.io/the-unrealized-life/"
BACKUP_URL = "https://the-unrealized-life-2000.a1459000683.chatgpt.site"
HTML_FILES = ("index.html", "legacy.html", "legacy-v1.1.html", "connection-check.html")
UPLOAD_FILES = (*HTML_FILES, "README.md", "source-and-public-data.zip", ".nojekyll")
SAVE_FIXTURES = (
    "output/playwright/final-browser-save.json",
    "output/playwright/quota-save.json",
    "output/playwright/securityerror-save.json",
)
DOCS = (
    "docs/SOURCES.md", "docs/RULES.md", "docs/PIR-SOURCES.md",
    "docs/FFLATE_LICENSE.txt", "docs/novel/API.md",
    "docs/novel/FINANCIAL-INTEGRATION.md",
)
SCRIPTS = ("scripts/build_market.py", "scripts/audit_market.py", "scripts/package_public.py")
# These audit the original annual-report text, which is deliberately not redistributed.
OMITTED_TESTS = {
    "tests/independent-early-financials-audit.py": "Requires original annual-report full text; source links and numeric evidence are included instead.",
    "tests/audit-early-hrb.py": "Requires original report text and research-only parsed tables.",
}
FIXED_ZIP_TIME = (2026, 10, 2, 0, 0, 0)


class PackageError(Exception):
    pass


def digest(data):
    return hashlib.sha256(data).hexdigest()


def json_bytes(value):
    return (json.dumps(value, ensure_ascii=False, indent=2) + "\n").encode("utf-8")


def read_allowed(relative):
    path = ROOT / relative
    if path.is_symlink() or not path.is_file():
        raise PackageError("Missing or non-regular allowed file: " + relative)
    if ROOT not in path.resolve().parents:
        raise PackageError("File is outside source root: " + relative)
    # Bounded reads work reliably with file-provider backed workspace volumes.
    with path.open("rb") as handle:
        return b"".join(iter(lambda: handle.read(1024 * 1024), b""))


def selected_paths():
    selected = set((*HTML_FILES, "build.cjs", "build-legacy.cjs", "package.json", *DOCS, *SCRIPTS, *SAVE_FIXTURES))
    for folder, patterns in (
        ("src", ("*",)), ("data", ("*.json",)),
        ("data/raw", ("*.json",)), ("data/early-financials", ("*.json",)),
        ("tests", ("*.cjs", "*.json", "*.py")), ("tests/fixtures", ("*",)),
    ):
        for pattern in patterns:
            for path in (ROOT / folder).glob(pattern):
                if path.is_file() and not path.name.startswith("."):
                    selected.add(path.relative_to(ROOT).as_posix())
    return sorted(selected - OMITTED_TESTS.keys())


def parse_story(data):
    text = data.decode("utf-8")
    marker = "globalThis.NOVEL_STORY ="
    if marker not in text:
        raise PackageError("Cannot find static novel story assignment")
    story, end = json.JSONDecoder().raw_decode(text.split(marker, 1)[1].lstrip())
    if not isinstance(story, dict) or story.get("draft"):
        raise PackageError("Cannot package an authoring draft")
    return story


def check_built_files(files):
    """Fail closed rather than ship newer source beside stale generated HTML."""
    def escaped(raw):
        return re.sub(r"</script", lambda _: "<\\/script", raw.decode("utf-8"), flags=re.I)
    novel = files["index.html"].decode("utf-8")
    legacy = files["legacy.html"].decode("utf-8")
    for rel in ("src/finance.js", "src/game.js", "src/novel-story.js", "src/novel.js",
                "src/fflate.js", "src/novel-ui.js", "src/novel-bootstrap.js"):
        if escaped(files[rel]) not in novel:
            raise PackageError("Stale novel build; run node build.cjs first: " + rel)
    for rel in ("src/finance.js", "src/game.js", "src/story.js", "src/ui.js", "src/boot.js"):
        if escaped(files[rel]) not in legacy:
            raise PackageError("Stale legacy build; run node build.cjs first: " + rel)
    for rel, html in (("src/novel-style.css", novel), ("src/style.css", legacy)):
        if files[rel].decode("utf-8") not in html:
            raise PackageError("Stale embedded stylesheet: " + rel)
    match = re.search(r'<script\s+id="market-data"\s+type="application/json">(.*?)</script\s*>', novel, re.S | re.I)
    if not match:
        raise PackageError("Novel build has no embedded market dataset")
    if json.loads(match[1].replace("<\\/script", "</script")) != json.loads(files["data/market.json"]):
        raise PackageError("Embedded market data does not match public dataset")
    if digest(files["legacy-v1.1.html"]) != "b5c692d20fe293d9fedfa9a7590cd803edb536b03e1667bca2dd48c907e94907":
        raise PackageError("Frozen legacy-v1.1.html hash differs from the preserved release")


# Fast literal gates avoid expensive full-dataset regex passes. Expressions do
# not contain concrete local paths, account credentials, or file identifiers.
SENSITIVE_RULES = (
    ("local_home_path", b"/" + b"Users/", rb"/[U]sers/"),
    # A path component inside a public URL is not an absolute local home path.
    ("unix_home_path", b"/" + b"home/", rb"(?<![A-Za-z0-9/_:])/[h]ome/[^/\s\"']+/"),
    ("windows_home_path", b"Users", rb"[A-Za-z]:[\\/]{1,2}Users[\\/]"),
    ("temporary_local_path", b"/" + b"tmp/", rb"/[t]mp/"),
    ("mac_temporary_path", b"/var/" + b"folders/", rb"/var/[f]olders/"),
    ("library_file_id", b"libfile_", rb"libfile_[A-Za-z0-9]{12,}"),
    ("library_folder_id", b"libfld_", rb"libfld_[A-Za-z0-9]{12,}"),
    ("uploaded_file_id", b"file_", rb"\bfile_[a-fA-F0-9]{20,}"),
    ("private_attachment_url", b"sediment:", rb"sediment:[/]/"),
    ("github_token", b"ghp_", rb"ghp_[A-Za-z0-9]{20,}"),
    ("github_fine_grained_token", b"github_pat_", rb"github_pat_[A-Za-z0-9_]{30,}"),
    ("api_key_shape", b"sk-", rb"\bsk-[A-Za-z0-9_-]{20,}"),
    ("aws_access_key_shape", b"AKIA", rb"\bAKIA[A-Z0-9]{16}\b"),
    ("private_key", b"PRIVATE KEY", rb"-----BEGIN (?:RSA |EC |OPENSSH )?PRIVATE KEY-----"),
    ("credential_in_url", b"://", rb"https?://[^/\s\"'<>:]+:[^/\s\"'<>@]+@"),
    ("original_request_name", b"wall_street_" + b"life_game_prompt", rb"wall_street_life_game_[p]rompt"),
)


def scan_one(path, raw):
    hits = []
    for label, needle, pattern in SENSITIVE_RULES:
        if needle in raw and re.search(pattern, raw):
            hits.append(label)
    if path.endswith(".gz"):
        try:
            expanded = gzip.decompress(raw)
        except (OSError, EOFError) as exc:
            raise PackageError("Invalid compressed fixture: " + path) from exc
        if len(expanded) > 32 * 1024 * 1024:
            raise PackageError("Compressed fixture is unexpectedly large: " + path)
        hits.extend(scan_one(path[:-3], expanded))
    return sorted(set(hits))


def scan_files(files):
    hits = []
    for path, raw in sorted(files.items()):
        labels = scan_one(path, raw)
        if labels:
            hits.append({"file": path, "categories": labels})
    return hits


def stats_for(story, market):
    nodes = story["nodes"]
    return {
        "startDate": market["dates"][0], "endDate": market["dates"][-1],
        "starts": len(story["starts"]), "nodes": len(nodes),
        "choices": sum(len(n["choices"]) for n in nodes),
        "sceneGroups": story["groupCount"],
        "variants": sum(n.get("priority", 0) > 0 for n in nodes),
        "endings": len(story["endings"]), "chains": len(story["chains"]),
        "companies": len(market["companies"]), "marketDates": len(market["dates"]),
        "fullPathCompanies": sum(len(c["prices"]) == len(market["dates"]) for c in market["companies"]),
    }


def verified_coverage(files):
    """Publish only numeric summaries whose replay inputs match this bundle."""
    report_path = ROOT / "output/qa/novel-independent-witness-replay.json"
    previous_path = ROOT / "PUBLIC_PACKAGE.json"
    candidate = None
    if report_path.is_file():
        report = json.loads(read_allowed(report_path.relative_to(ROOT).as_posix()))
        if report.get("sourceStableDuringRun"):
            candidate = {"coverage": report.get("coverage", {}), "hashes": report.get("hashes", {})}
    elif previous_path.is_file():
        candidate = json.loads(read_allowed("PUBLIC_PACKAGE.json")).get("verifiedRouteCoverage")
    if not candidate:
        return None
    hashes, coverage = candidate.get("hashes", {}), candidate.get("coverage", {})
    required = ("src/finance.js", "src/game.js", "src/novel.js", "src/novel-story.js",
                "data/market.json", "tests/novel-story-routes.json", "tests/novel-independent-witness-replay.cjs")
    if any(name not in files or hashes.get(name) != digest(files[name]) for name in required):
        return None
    keys = ("routes", "decisions", "nodes", "variants", "endings", "choices", "totalChoices", "chains", "crossStageChains")
    if any(type(coverage.get(key)) is not int or coverage[key] < 0 for key in keys):
        return None
    return {"coverage": {key: coverage[key] for key in keys}, "hashes": {name: hashes[name] for name in required}}


def public_readme(stats, verified=None):
    coverage_note = "当前包没有附带与全部重播输入哈希相符的路线覆盖摘要；请运行随包测试自行核验。"
    if verified:
        c = verified["coverage"]
        if c["totalChoices"] != stats["choices"] or c["choices"] > c["totalChoices"]:
            raise PackageError("Verified replay choice counts do not match story")
        coverage_note = (f"与本包源码、数据及路线文件哈希一致的独立重播，实际执行{c['routes']}条路线、"
                         f"{c['decisions']}次选择，覆盖{c['nodes']}个节点、{c['variants']}个变体、"
                         f"{c['endings']}种结局和{c['chains']}条链。选项覆盖为 **{c['choices']}/{c['totalChoices']}**；"
                         f"其余{c['totalChoices'] - c['choices']}个选项未由这组路线逐一执行，不能称作全部选项已测。")
    return f"""# 未实现的人生

中文互动人生小说，从2000年、24岁开始，走到2020年。人物、雇主与私人经历均属虚构；市场历史独立于玩家选择。

- 公开入口：{PUBLIC_URL}
- 备用入口：{BACKUP_URL}

这些是项目公开入口；本打包程序不进行上传或网络验证，不能据此判断线上是否已更新到本包版本。

本包静态内容实读为 **{stats['starts']}种开局、{stats['nodes']}个节点、{stats['choices']}个选项、{stats['sceneGroups']}组场景、{stats['variants']}个条件变体、{stats['chains']}条跨年链、{stats['endings']}种结局**。这些是源码中的内容数量，不冒充独立实测可达数量；多数完整路线有约{stats['sceneGroups']}次选择，部分路线会提前结束。

{coverage_note}

## 打开与保存

直接用能执行JavaScript的浏览器打开 `index.html`，不需要安装npm包、账号、API或网络。游戏是完整离线单文件，剧情不是运行时生成；普通文件预览器不一定能运行。`legacy.html`保留旧玩法与旧存档身份，`legacy-v1.1.html`是原样冻结版本。小说与旧版存档不混用。

自动书签、手动书签及JSON导入导出可用。不同网址、设备与离线文件的存储空间不会自动同步；跨入口前先导出。浏览器限制file地址存储、隐私模式、权限或配额不足时，当前页临时进度不等于永久保存。多标签页冲突会提示，不能当作自动同步。

`connection-check.html`是轻量连接检查页。已有用户反馈手机可以顺利打开；这是单次设备打开反馈，不是实体手机完整通关验收，也不保证所有Safari/WebView版本或中国大陆网络可用。手机阅读布局和桌面手机视口测试有各自范围。连接问题可先打开检查页，也可下载离线文件；离线仍需浏览器支持JavaScript。

## 历史资料边界

{stats['fullPathCompanies']}家核心公司覆盖{stats['startDate']}至{stats['endDate']}的{stats['marketDates']}个真实采样日期，另有有限交易窗口的清算案例。缺失价格不可交易，不用合成或插值价格充当真实收益。早期财务按原始公开日开放，未知指标保留空值；不同产业现金和债务口径见来源文件。

股票采用还原的当时收盘价，分红和拆股另行入账；分红入账简化为除息日。基准使用含再投资的复权序列，不再重复计息。回撤只代表离散节点。未模拟所得税、资本利得税、通胀及完整经纪业务流程。客户组合、机构收入与个人资金分开核算；净资产增加不全是投资回报。

来源、逐节点追溯与限制见 `docs/SOURCES.md`。源码包提供公开行情/SEC数值JSON、短数字证据、来源链接与原件哈希，**不重复分发整篇年报**。匿名只是阅读设计，查看源码会看到真实公司身份。

## 源码与复核

解压 `source-and-public-data.zip` 后，源码直接位于压缩包根目录。游玩无需任何工具；重建需要本地Node.js，数据重建需要Python 3，均不需要npm安装：

```text
node build.cjs
node --test tests/*.test.cjs
node tests/novel-story-replay.cjs
node tests/novel-real-careers.cjs
node tests/novel-real-finance.cjs
python3 scripts/build_market.py
python3 scripts/audit_market.py
```

先在解压目录运行命令；`build.cjs`也会重建兼容旧版。数据重建不联网，使用随包数值证据。`MANIFEST.sha256`用于校验包内文件，`PUBLIC_PACKAGE.json`记录内容数量、纳入文件和省略项目。运行测试会产生新的本地报告，打包时未附带开发者本机QA日志。

`tests/fixtures`与三份 `output/playwright/*-save.json`是默认测试需要的虚构游戏存档/版本夹具，特意保留。需要完整原件的逐行Python审计和依赖本机浏览器会话的流程，不属于上述离线测试；详见 `docs/PUBLIC_PACKAGE.md`。

只准备上传目录可运行 `python3 scripts/package_public.py`。它不构建、不联网、不发布；现有HTML必须与源码和数据一致。准备结果是 `output/github-upload/` 的7个文件。压缩包带有fflate的MIT许可：`docs/FFLATE_LICENSE.txt`。
""".encode("utf-8")


def package_notes():
    return """# 公共包范围与可移植性

本包使用明确文件白名单。完整游戏源码、行情和SEC数值JSON、已核验的早期财务快照、源链接和哈希、构建脚本及默认Node测试均保留。它不包含需求附件、账号配置、上传凭据、开发者私人目录或本机QA日志。

## 省略项目

- `data/raw`下的年报TXT/HTML全文及`data/raw/early`研究原件不重复分发。原件可按快照中的来源链接自行取得；这不影响离线游戏、数值数据重建或默认Node测试。
- `tests/independent-early-financials-audit.py`和`tests/audit-early-hrb.py`依赖这些原件全文/研究中间表，公共包省略。已核验短数字证据和每项定位仍随早期财务JSON保留。
- 只保留 `scripts/build_market.py`、`scripts/audit_market.py` 和本打包器。首次抓取/解析原报告、作者本地发布和研究杂项脚本不属于离线重建链，故省略。
- 不复制根目录QA报告、浏览器截图、发布日志、原要求或开发进度。`tests`里的小型JSON见证/测试结果是测试资料，不能代替使用者自己运行当前版本。

## 默认测试之外的入口

`tests/novel-browser-faults.cjs`、`tests/novel-browser-final-career.cjs`是接收已有Playwright Page对象的浏览器测试函数，保留供开发者复用；单独执行Node不会自动建立浏览器会话，也不应把这种执行称作浏览器测试通过。真实浏览器测试需要自行准备环境，它不是离线游玩的依赖。

默认 `node --test tests/*.test.cjs` 不需要Playwright、账号、网络、Git历史或完整原年报。RC1/RC2压缩源码夹具保持原字节与哈希，三份旧版存档供结构和账本兼容性测试。`output/qa/.gitkeep`只创建测试输出目录，不包含开发者QA记录。

## 安全检查边界

打包器扫描公开文件、生成说明以及解压后的gzip测试夹具，检查本机用户目录、临时绝对路径、附件标识、常见密钥格式和带密码URL；只报告文件名和规则类别，不回显匹配内容。白名单、人工范围和模式扫描共同限制公开面，扫描没有命中不是对所有可能秘密格式的数学证明。

## 重新打包

先运行 `node build.cjs`，再运行 `python3 scripts/package_public.py`。程序先确认嵌入源码与数据一致、v1.1冻结哈希未变、所有文件扫描无命中，最后准备七个上传文件；不触发构建、浏览器、网络或部署。相同输入生成相同ZIP字节。可以使用 `--output output/public-package-check`隔离演练，或 `--check-only`只检查而不生成文件。
""".encode("utf-8")


def make_zip(files):
    buffer = io.BytesIO()
    with zipfile.ZipFile(buffer, "w", compression=zipfile.ZIP_DEFLATED, compresslevel=9) as archive:
        for name, content in sorted(files.items()):
            info = zipfile.ZipInfo(name, date_time=FIXED_ZIP_TIME)
            info.compress_type = zipfile.ZIP_DEFLATED
            info.external_attr = 0o100644 << 16
            archive.writestr(info, content, compress_type=zipfile.ZIP_DEFLATED, compresslevel=9)
    result = buffer.getvalue()
    with zipfile.ZipFile(io.BytesIO(result)) as archive:
        if archive.testzip() is not None or set(archive.namelist()) != set(files):
            raise PackageError("Archive integrity or file-set check failed")
    return result


def run(args):
    files = {path: read_allowed(path) for path in selected_paths()}
    check_built_files(files)
    story, market = parse_story(files["src/novel-story.js"]), json.loads(files["data/market.json"])
    stats = stats_for(story, market)
    verified = verified_coverage(files)
    files["README.md"] = public_readme(stats, verified)
    files["docs/PUBLIC_PACKAGE.md"] = package_notes()
    files["output/qa/.gitkeep"] = b""
    files[".nojekyll"] = b""
    files["PUBLIC_PACKAGE.json"] = json_bytes({
        "schemaVersion": 1, "purpose": "Offline source and public numeric evidence; not deployment proof",
        "content": stats, "storySha256": digest(files["src/novel-story.js"]),
        "indexSha256": digest(files["index.html"]), "marketSha256": digest(files["data/market.json"]),
        "verifiedRouteCoverage": verified,
        "omittedTests": OMITTED_TESTS, "retainedSaveFixtures": list(SAVE_FIXTURES),
        "sourceFiles": sorted(files),
    })
    files["MANIFEST.sha256"] = "".join(digest(raw) + "  " + name + "\n" for name, raw in sorted(files.items())).encode("ascii")
    hits = scan_files(files)
    report = {"ok": not hits, "sensitivePatternHit": bool(hits), "hits": hits,
              "scannedFiles": len(files), "gzipFixturesAlsoScanned": sum(p.endswith(".gz") for p in files),
              "content": stats, "storySha256": digest(files["src/novel-story.js"])}
    if hits:
        print(json.dumps(report, ensure_ascii=False))
        return 2
    if args.check_only:
        report["prepared"] = False
        print(json.dumps(report, ensure_ascii=False))
        return 0
    # Read-only checks above use a captured file set. Refuse a mixed build if its
    # inputs changed while preparing it; no write is performed before this check.
    for name in [p for p in files if p.startswith("src/")] + list(HTML_FILES) + ["data/market.json"]:
        if read_allowed(name) != files[name]:
            raise PackageError("Source changed while packaging; retry after it is frozen: " + name)
    archive = make_zip(files)
    output = Path(args.output)
    if not output.is_absolute():
        output = ROOT / output
    output = output.resolve()
    allowed_parent = (ROOT / "output").resolve()
    if allowed_parent not in output.parents:
        raise PackageError("Prepared output must be a child directory of output")
    if output.exists() and any(p.name not in UPLOAD_FILES for p in output.iterdir()):
        raise PackageError("Output has unrelated entries; choose a dedicated empty directory")
    output.parent.mkdir(parents=True, exist_ok=True)
    with tempfile.TemporaryDirectory(prefix="public-package-", dir=output.parent) as temporary:
        stage = Path(temporary)
        payload = {name: files[name] for name in (*HTML_FILES, "README.md", ".nojekyll")}
        payload["source-and-public-data.zip"] = archive
        for name, raw in payload.items():
            (stage / name).write_bytes(raw)
        output.mkdir(parents=True, exist_ok=True)
        for name in UPLOAD_FILES:
            os.replace(stage / name, output / name)
    report.update({"prepared": True, "output": output.relative_to(ROOT).as_posix(),
                   "files": [{"path": (output / name).relative_to(ROOT).as_posix(),
                              "bytes": (output / name).stat().st_size,
                              "sha256": digest(payload[name])} for name in UPLOAD_FILES],
                   "archiveFiles": len(files), "archiveSha256": digest(archive)})
    print(json.dumps(report, ensure_ascii=False))
    return 0


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--output", default="output/github-upload", help="Dedicated child of output (default: output/github-upload)")
    parser.add_argument("--check-only", action="store_true", help="Check build consistency and scan without preparing files")
    args = parser.parse_args()
    try:
        return run(args)
    except PackageError as exc:
        print(json.dumps({"ok": False, "error": str(exc)}, ensure_ascii=False), file=sys.stderr)
        return 1


if __name__ == "__main__":
    sys.exit(main())
