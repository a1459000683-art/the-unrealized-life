#!/usr/bin/env python3
"""Create the offline source/data delivery; omit private inputs and full reports."""
from pathlib import Path
import hashlib, shutil, zipfile, json
ROOT = Path(__file__).resolve().parents[1]
BASE = ROOT / 'release'
OUT = BASE / '未实现的人生'
OUT.mkdir(parents=True, exist_ok=True)
files = [ROOT / p for p in ('index.html','README.md','package.json','build.cjs')]
for folder, patterns in [('src',['*']),('data',['*.json']),('data/raw',['*.json']),('data/early-financials',['*.json']),('docs',['*.md','*.json']),('docs/early-financials',['*.md','*.json']),('scripts',['*.py']),('tests',['*.cjs','*.json','*.py'])]:
    for pattern in patterns:
        files.extend((ROOT/folder).glob(pattern))
for p in (ROOT/'output/qa').glob('*'):
    if p.name in {'unit-tests.txt','independent-regression.txt','career-paths-51.json','career-run-51.txt','career-paths-final-3.json','career-run-final-3.txt','public-headers.txt','publication.json','package-verification.json','browser-results.json','early-data-tests.txt','early-data-audit.json','career-paths-v1.1-6.json','career-run-v1.1-6.txt','github-pages-verification.json','github-public-audit.json','publication-v1.1.json','early-browser-results.json','package-verification-v1.1.json'}:
        files.append(p)
for p in (ROOT/'output/playwright').glob('*'):
    if p.suffix == '.png' or (p.suffix == '.json' and p.name != 'cli.config.json') or p.name == 'final-career-summary.txt':
        files.append(p)
files = sorted({p for p in files if p.is_file() and p.name != 'PROGRESS.md'})
relative = {str(p.relative_to(ROOT)) for p in files}
for p in OUT.rglob('*'):
    if p.is_file() and str(p.relative_to(OUT)) not in relative:
        p.unlink()
for p in files:
    dest=OUT/p.relative_to(ROOT)
    dest.parent.mkdir(parents=True,exist_ok=True)
    shutil.copyfile(p,dest)
manifest=''.join(hashlib.sha256((OUT/p).read_bytes()).hexdigest()+'  '+p+'\n' for p in sorted(relative))
(OUT/'MANIFEST.sha256').write_text(manifest,encoding='utf-8')
archive=BASE/'未实现的人生-完整源码与数据.zip'
with zipfile.ZipFile(archive,'w',compression=zipfile.ZIP_DEFLATED,compresslevel=9) as z:
    for p in sorted(OUT.rglob('*')):
        if not p.is_file():continue
        entry=zipfile.ZipInfo(str(p.relative_to(BASE)),date_time=(2026,10,2,0,0,0))
        entry.compress_type=zipfile.ZIP_DEFLATED
        entry.external_attr=0o100644<<16
        z.writestr(entry,p.read_bytes())
with zipfile.ZipFile(archive) as z:
    assert z.testzip() is None
print(json.dumps({'archive':str(archive),'files':len(files)+1,'bytes':archive.stat().st_size,'sha256':hashlib.sha256(archive.read_bytes()).hexdigest()},ensure_ascii=False))
