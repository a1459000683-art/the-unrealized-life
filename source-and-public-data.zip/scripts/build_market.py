# -*- coding: utf-8 -*-
"""Deterministic build from locally archived public sources. No network required."""
import json,datetime,math,pathlib,re,hashlib
ROOT=pathlib.Path(__file__).resolve().parents[1];RAW=ROOT/'data/raw'; OUT=ROOT/'data/market.json'
C=[
('HEI','湖岸航材','HEICO Corporation',46619,'工业','航空替换零件','把获适航认证的替换零件卖给航空公司及维修商，也经营地面支援设备。客户购买是为了降低维修成本并保持飞机可用。','认证和产品目录形成进入门槛；每项新零件开发仍需时间与费用。','客户集中、适航批准和航空业景气。'),
('GNTX','镜原精密','Gentex Corporation',355811,'工业','汽车电子镜','用电致变色技术制造自动防眩后视镜，销售给整车制造商；另有商用消防产品。','装车渗透率可以提高，但技术领先不等于整车厂会接受任何价格。','整车客户压价、车型销量与替代技术。'),
('JKHY','溪桥系统','Jack Henry & Associates',779152,'金融','银行核心软件','向中小银行销售账务处理软件、硬件及安装服务，并收取维护支持费用。','更换核心系统有迁移成本；但银行合并会减少潜在客户数量。','实施质量、客户银行整合和技术投入。'),
('AIR','天际维修','AAR Corp.',1750,'工业','航空维修分销','采购、销售和租赁飞机与发动机及备件，并提供大修、交换和库存管理服务。','把零件送到需要它的机库很有价值；库存和租赁资产却会占用大量资金。','航空需求、库存可售性、租赁资产余值与负债。'),
('BRO','杉谷经纪','Brown & Brown',79282,'金融','保险经纪','为客户安排财产及责任保险，主要收取佣金与服务费，不直接承担承保损失。','续保与收购能够扩大客户基础；保费下降也会压低按比例收取的佣金。','保费周期、客户留存和收购整合。'),
('RHI','格点人才','Robert Half',315213,'金融','专业人才服务','为企业提供临时及正式的会计、财务、行政和信息技术人才，按服务收费。','专业候选人网络有价值；经济下行时，雇主通常先收缩招聘。','就业周期、客户欠款与人员匹配效率。'),
('WDFC','蓝罐养护','WD-40 Company',105132,'消费','维护化学品','通过五金、汽车用品和工业渠道销售润滑、防锈及重型洗手清洁产品。','小额消耗品的品牌和渠道可以持续；大零售商集中却会加强议价压力。','零售商集中、原料成本与新品分销。'),
('FAST','北岭分销','Fastenal',815556,'工业','工业紧固件分销','把紧固件和工业耗材通过当地网点配送给工厂与施工客户。','近距离供货减少客户停工；开网点和备货会先消耗现金。','制造业开工、库存周转和网点费用。'),
('GPC','路标配件','Genuine Parts',40987,'消费','汽车售后及工业配件','通过分销网络供应汽车维修零件及工业备件，并经营其他分销业务。','维修需求与新车销售并非完全同步；广泛备货需要营运资金。','渠道竞争、库存占用与工业客户需求。'),
('THO','远行车厢','Thor Industries',730263,'消费','房车与小型巴士','制造和销售多种房车以及小中型巴士，主要通过经销渠道到达客户。','多品牌与产品价位覆盖不同消费者；房车仍属于可以延后的大额支出。','经销商库存、消费者信贷和可选消费周期。'),
('SCHL','纸灯出版','Scholastic',866729,'消费','儿童出版与学校渠道','通过学校书会、书展和零售渠道出版销售儿童书籍、教育材料及相关媒体产品。','直接抵达学校的渠道有价值；畅销书并不保证下一本同样畅销。','内容成败、退货、学校日历与库存。'),
('HRB','橡街税务','H&R Block',12659,'金融','报税与金融服务','为居民提供报税及电子申报服务，也经营按揭贷款和其他金融服务。','报税具有重复需求；附属贷款业务的风险不能由门店客流替代评估。','季节性、报税软件竞争与按揭业务信用风险。'),
('HOG','赤轮制造','Harley-Davidson',793952,'消费','重型摩托车及消费金融','销售重型摩托车、零件和相关用品，并向经销商及消费者提供融资。','品牌与骑行社群支持需求；融资条件和消费者收入同样影响销量。','消费周期、金融子公司融资与信用损失。'),
('EOG','荒原能源','EOG Resources',821189,'工业','油气勘探生产','勘探、开发、生产并销售天然气和原油，把资本投入地下资源及生产设施。','储量与低成本开采值得研究；商品售价和钻井投入可能同时不利。','油气价格、储量估算与资本开支。'),
('CBU','河湾银行','Community Bank System',723188,'金融','区域银行','通过地方银行网点吸收存款、发放贷款并提供金融服务。','稳定存款和熟悉地方客户有价值；利差与信贷质量需要一起看。','贷款损失、利率变化、流动性及区域经济。'),
('NUE','炉石钢业','Nucor',73309,'工业','电炉钢铁','主要以废钢为原料，用电炉和轧钢设备生产钢材，卖给服务中心、制造商与建筑客户。','生产效率可以改善竞争力；钢材售价、废钢和能源价格不受企业单独控制。','进口竞争、钢价与废钢价差、固定资产利用率。')]
def iso(ts):return datetime.datetime.fromtimestamp(ts,datetime.timezone.utc).date().isoformat()
def days(a,b):return (datetime.date.fromisoformat(b)-datetime.date.fromisoformat(a)).days
def read(s):return json.loads((RAW/(s+'.json')).read_text())
def chart(s):return read(s)['chart']['result'][0]
def rawrows(s):
 x=chart(s);splits=sorted([(iso(v['date']),v['numerator']/v['denominator']) for v in x.get('events',{}).get('splits',{}).values()]);q=x['indicators']['quote'][0]['close'];adj=x['indicators']['adjclose'][0]['adjclose'];rows={}
 for i,t in enumerate(x['timestamp']):
  if q[i] is None:continue
  d=iso(t);factor=math.prod(r for sd,r in splits if sd>d);rows[d]={'close':round(q[i]*factor,6),'splitAdjustedClose':q[i],'adjustedClose':adj[i]}
 return rows,splits,x
spy,_,_=rawrows('SPY');dates=['2000-01-03']
for y in range(2000,2021):
 for m in (6,12):dates.append(max(d for d in spy if d.startswith(f'{y}-{m:02}')))
dates += ['2001-09-28','2008-09-30','2019-07-31','2019-08-30','2020-01-06','2020-02-14','2020-02-18','2020-03-31','2020-10-09','2020-10-15']
dates=sorted(set(dates))
# All source dates are actual trading dates; no interpolated price.
assert all(d in spy for d in dates)
METRICS={'revenue':['RevenueFromContractWithCustomerExcludingAssessedTax','RevenueFromContractWithCustomerIncludingAssessedTax','Revenues','SalesRevenueNet','SalesRevenueGoodsNet','SalesRevenueServicesNet'], 'netIncome':['NetIncomeLoss','ProfitLoss'], 'ocf':['NetCashProvidedByUsedInOperatingActivities'], 'capex':['PaymentsToAcquirePropertyPlantAndEquipment'], 'eps':['EarningsPerShareDiluted','EarningsPerShareBasic'], 'shares':['WeightedAverageNumberOfDilutedSharesOutstanding','WeightedAverageNumberOfSharesOutstandingBasic']}
def annualfacts(s,cik):
 g=read(s+'-companyfacts')['facts']['us-gaap']; annual={}; candidates=[]
 for tag in METRICS['netIncome']:
  for v in g.get(tag,{}).get('units',{}).get('USD',[]):
   if v.get('form') in ['10-K','10-K/A'] and v.get('start') and 300<=days(v['start'],v['end'])<=400 and '2000-01-01'<=v['end']<='2020-12-31' and v['end']<=v.get('filed','0000')<='2020-12-31':candidates.append(v)
 # Preserve earliest actual filing for each period. Later revisions are separate data,
 # never silently pasted over facts the player saw earlier.
 for v in sorted(candidates,key=lambda a:(a['filed'],a['end'])):
  if v['end'] not in annual:annual[v['end']]=v
 result=[]
 for period,anchor in sorted(annual.items()):
  metrics={k:None for k in ['revenue','netIncome','ocf','capex','debt','eps','shares','cash']};meta={}
  def val(tags,annual=True):
   for tag in tags:
    for unit,vs in g.get(tag,{}).get('units',{}).items():
     matches=[v for v in vs if v.get('accn')==anchor['accn'] and v.get('end')==period and ((v.get('start') and 300<=days(v['start'],v['end'])<=400) if annual else not v.get('start'))]
     if matches:
      v=matches[0];return v['val'],{'tag':tag,'unit':unit,'start':v.get('start'),'end':v['end'],'accession':v['accn']}
   return None,None
  for key,tags in METRICS.items():metrics[key],m=val(tags);meta[key]=m
  metrics['cash'],meta['cash']=val(['CashAndCashEquivalentsAtCarryingValue'],False)
  # Debt is explicitly the reported long-term debt measure, NOT invented total debt.
  debt,dm=val(['LongTermDebtCurrent'],False);noncurrent,nm=val(['LongTermDebtNoncurrent'],False)
  if debt is not None and noncurrent is not None:
   metrics['debt']=debt+noncurrent;meta['debt']={'tags':[dm['tag'],nm['tag']],'scope':'长期债务当前部分 + 非流动部分；不含短期借款、存款及经营租赁'}
  else:
   metrics['debt'],meta['debt']=val(['LongTermDebt','LongTermDebtAndCapitalLeaseObligations'],False)
   if meta['debt']:meta['debt']['scope']='仅该申报长期债务标签，不能当作全部负债；短债/存款/租赁未合并'
  if s=='CBU':
   ni,nmeta=val(['InterestIncomeExpenseNet']);non,n2meta=val(['NoninterestIncome'])
   if ni is not None and non is not None:metrics['revenue']=ni+non;meta['revenue']={'tags':[nmeta['tag'],n2meta['tag']],'scope':'净利息收入 + 非利息收入；银行口径不与工业收入直接比较'}
  url=f'https://www.sec.gov/Archives/edgar/data/{cik}/{anchor["accn"].replace("-","")}/{anchor["accn"]}-index.html'
  result.append({'id':s+'-fy-'+period,'kind':'financial','period':period,'occurred':period,'published':anchor['filed'],'publicationDate':anchor['filed'],'availableFrom':(datetime.date.fromisoformat(anchor['filed'])+datetime.timedelta(days=1)).isoformat(),'publicationTiming':'未系统提取受理时分秒；保守至下一自然日才可用于决策','title':period+' 财年已申报数据','text':'下列数字只来自本次列明的原始SEC申报；金额单位为美元。自由现金流定义为经营现金流减资本开支。空白表示本数据包尚未核验，不能据此断言该企业没有该项目。','source':url,'metrics':metrics,'metricMeta':meta,'verification':'SEC XBRL原始申报，按filed日期过滤','filing':anchor['accn']})
 return result
# First annual report before start date, manually checked unit overrides. Some
# historical FDS contain erroneous multiplier/year headings (notably GNTX/WDFC).
INITIAL={
'HEI':('1998-10-31',95351000,10509000,None,None), 'GNTX':('1998-12-31',222292053,50307130,52144290,24596224),
'JKHY':('1999-06-30',184497000,31768000,37776000,38819000),'AIR':('1999-05-31',918036000,41671000,None,None),
'BRO':('1998-12-31',153791000,23053000,36313000,4510000),'RHI':('1998-12-31',1793041000,131580000,None,None),
'WDFC':('1999-08-31',146348000,22065000,25849000,1308000),'FAST':('1998-12-31',503100000,52953000,43316000,None),
'GPC':('1998-12-31',6614032000,355794000,None,None),'THO':('1999-07-31',805805904,30766195,None,None),
'SCHL':('1999-05-31',1154710000,36800000,None,None),'HRB':('1999-04-30',1644665000,215366000,None,None),
'HOG':('1998-12-31',2063956000,213500000,None,None),'EOG':('1998-12-31',769188000,56171000,None,None),
'CBU':('1998-12-31',None,15728000,None,None),'NUE':('1998-12-31',4151232283,263708596,None,None)}
cash_evidence_path=ROOT/'data/initial-cash.json'
cash_evidence=json.loads(cash_evidence_path.read_text()).get('records',{}) if cash_evidence_path.exists() else {}
companies=[]
for i,(s,alias,name,cik,sector,business,description,edge,risk) in enumerate(C):
 rows,splits,x=rawrows(s); source=f'https://query1.finance.yahoo.com/v8/finance/chart/{s}?period1=915148800&period2=1790899200&interval=1d&events=div%2Csplits'
 actions=[]
 for d,r in splits:
  if dates[0]<d<=dates[-1]:actions.append({'id':s+'-split-'+d,'date':d,'published':d,'type':'split','ratio':r,'source':source,'verification':'Yahoo公司行动记录','note':'按实际比例增减零股数量，成本总额不变'})
 for v in x.get('events',{}).get('dividends',{}).values():
  d=iso(v['date'])
  if s=='CBU' and d in ['2001-09-12','2015-05-13','2016-08-10']:continue # SEC confirms only one Q3 0.27 USD dividend; Yahoo duplicate is excluded.
  if dates[0]<d<=dates[-1]:
   factor=math.prod(r for sd,r in splits if sd>d)
   actions.append({'id':s+'-div-'+d,'date':d,'published':d,'type':'dividend','amount':round(v['amount']*factor,8),'source':source,'verification':'Yahoo除息记录，经后续拆股因子还原','dateBasis':'ex-dividend date','note':'玩法简化：除息日入账，非历史支付日；不再使用adjclose计股票盈亏'})
 if s=='CBU':
  for action in actions:
   if action['date']=='2001-09-17':
    action['amount']=0.27
    action['verification']='季度金额按SEC2001年报及Q3报核实；Sep17除息日沿用Yahoo，未独立核实'
    action['correction']='剔除Yahoo在2001-09-12休市日重复记录；本期没有9/12至9/17间交易节点'
    action['amountSource']='https://www.sec.gov/Archives/edgar/data/723188/000089155402001428/d50061_10k.txt'
 meta=read(s+'-initial-meta');init=INITIAL[s];metrics=dict(zip(['revenue','netIncome','ocf','capex'],init[1:]));metrics.update({'debt':None,'eps':None,'shares':None,'cash':None})
 cash_record=cash_evidence.get(s)
 if cash_record is not None:
  cash_value=cash_record.get('cash')
  if not isinstance(cash_value,(int,float)) or not math.isfinite(cash_value) or cash_value<0:
   raise ValueError('Invalid verified initial cash record: '+s)
  metrics['cash']=cash_value
 else:
  initial_text=(RAW/(s+'-initial.txt')).read_text(errors='replace'); first_fds=initial_text[initial_text.find('<ARTICLE>'):]; cash_match=re.search(r'<CASH>\s*([0-9,]+)',first_fds)
  if cash_match:
   multiplier=1000 if s in ['AIR','BRO','CBU','EOG','GPC','HOG','HRB','JKHY','RHI','SCHL'] else 1
   metrics['cash']=int(cash_match.group(1).replace(',',''))*multiplier
 facts=[{'id':s+'-initial','kind':'business','period':init[0],'occurred':init[0],'published':meta['filingDate'],'title':'开局前的业务底稿','text':description+' '+edge,'source':meta['url'],'metrics':metrics,'verification':'已阅读开局前SEC年报；初始营收净利核对原文，其他空缺未核验','metricMeta':{'note':'历史FDS乘数并不全部可靠：GNTX按原财务表美元值；JKHY/EOG按千美元；WDFC年度取正文1999而非末尾FDS笔误1998。JKHY初始经营现金流为持续经营口径。'}}]+annualfacts(s,cik)
 companies.append({'id':s,'alias':alias,'name':name,'ticker':s,'business':business,'sector':sector,'description':description,'edge':edge,'risk':risk,'listed':'2000-01-03','actualListingDate':None,'availableFrom':'2000-01-03','listedMeaning':'本游戏首个已验证可交易日；不是IPO日期','delisted':None,'prices':[{'date':d,'close':rows[d]['close'],'source':source} for d in dates], 'actions':sorted(actions,key=lambda a:(a['date'],0 if a['type']=='split' else 1)), 'facts':facts,'sources':[{'id':s+'-prices','url':source,'type':'market','local':'data/raw/'+s+'.json','retrieved':'2026-10-02','verification':'原始JSON已下载；精确交易日采样，未插值'},{'id':s+'-initial-report','url':meta['url'],'type':'filing','published':meta['filingDate'],'local':'data/raw/'+s+'-initial.txt'},{'id':s+'-facts','url':f'https://data.sec.gov/api/xbrl/companyfacts/CIK{cik:010d}.json','type':'financial','local':'data/raw/'+s+'-companyfacts.json','retrieved':'2026-10-02'}], 'researchEvidence':[{'published':meta['filingDate'],'kind':'support','text':edge,'status':'基于当时业务结构的研究推论，并非未来结果'},{'published':meta['filingDate'],'kind':'challenge','text':risk,'status':'研究风险问题，不表示风险已实际发生'},{'published':meta['filingDate'],'kind':'management','text':description,'status':'按初始年报业务章节匿名转述；不逐字引用'}], 'financialGap':'2000—2008年间未系统核验的中间财务字段不补造；显示最近已公开快照及其原报告期。2009年前的财务年比较不可由后来的XBRL倒填。'})
base=spy[dates[0]]['adjustedClose']
market={'version':'1.0.0','basisType':'raw_close','basis':{'type':'raw_close','label':'原始每股收盘价 + 独立现金分红与拆股；离散真实交易日','currency':'USD','priceMethod':'Yahoo close为拆股调整价；乘该日之后至抓取日全部拆股比例还原当时每股价格。公司行动逐日执行，不使用股票adjclose计盈亏。','dividendMethod':'分红金额亦乘除息日之后的拆股比率还原；玩法统一于除息日入账，实际支付日未核验。','benchmark':'SPY adjusted close归一化100，含分红再投资及基金净值内费用；不另加分红，未扣游戏主动交易费用。','sampling':'半年末及明确列出的危机/清算检查点；图表与最大回撤为这些离散节点口径，并非真实日内或每日最大回撤。','tradeRule':'仅在本公司有精确price.date的决策点成交。缺值不得插值或以上一个收盘价作为新成交价。','precision':'价格还原后保留6位小数，分红8位，份额允许零股；不模拟撮合/税务。','financialUnits':'美元；年度流量与期末存量分开，debt具体范围见metricMeta；空白仅表示未核验。','retrieved':'2026-10-02'},'dates':dates,'benchmark':[{'date':d,'value':round(spy[d]['adjustedClose']/base*100,8)} for d in dates],'dataCorrections':[{'company':'CBU','excludedYahooDividendDates':['2001-09-12','2015-05-13','2016-08-10'],'reason':'SEC原始季度/年报确认重复或额外错误条目，详data/cbu-dividend-correction.json；原始响应不修改','evidence':'data/cbu-dividend-correction.json'}],'benchmarkSource':'https://query1.finance.yahoo.com/v8/finance/chart/SPY?period1=915148800&period2=1790899200&interval=1d&events=div%2Csplits','companies':companies}
pir=ROOT/'data/pir-case.json'
if pir.exists():
 p=json.loads(pir.read_text());p.update({'id':'PIR','alias':'旧港家居','name':'Pier 1 Imports','ticker':'PIR / PIRRQ','business':'进口家居零售','sector':'消费','description':'通过家居门店销售家具与装饰用品，试图调整门店和线上渠道。','edge':'仍有品牌、门店和库存，能否把库存变回现金比折扣幅度更重要。','risk':'门店租赁、销售下滑、现金消耗与债务重组风险。','listed':'2019-07-31','listedMeaning':'历史上市更早；本包仅于2019-07-31之后精确核验的点开放交易。'})
 p['prices']=[v for v in p.get('prices',[]) if v['date']>='2019-07-31'];p['facts']=p.get('facts',[])+annualfacts('PIR',278130);p['actions']=[a for a in p.get('actions',[]) if a['date']>='2019-07-31'];companies.append(p)
for company in companies:
 for j,fact in enumerate(company['facts']):
  fact.setdefault('id',company['id']+'-event-'+str(j))
 company['facts'].sort(key=lambda f:(f.get('published',''),f.get('period',''),f['id']))
OUT.write_text(json.dumps(market,ensure_ascii=False,indent=2))
print('Wrote',OUT,'companies',len(companies),'dates',len(dates),'facts',sum(len(c['facts']) for c in companies),'actions',sum(len(c['actions']) for c in companies))
