import urllib.request,json,concurrent.futures,pathlib,re
ROOT=pathlib.Path(__file__).resolve().parents[1]; RAW=ROOT/'data/raw'; RAW.mkdir(exist_ok=True)
C={'HEI':46619,'GNTX':355811,'JKHY':779152,'AIR':1750,'BRO':79282,'RHI':315213,'WDFC':105132,'FAST':815556,'GPC':40987,'THO':730263,'SCHL':866729,'HRB':12659,'HOG':793952,'EOG':821189,'CBU':723188,'NUE':73309}
def get(url):return urllib.request.urlopen(urllib.request.Request(url,headers={'User-Agent':'UnrealizedLife public-history research (offline educational game) research@example.com'}),timeout=45).read()
def fetch(a):
 s,c=a
 try:
  p=RAW/(s+'-submissions.json')
  if not p.exists():p.write_bytes(get(f'https://data.sec.gov/submissions/CIK{c:010d}.json'))
  j=json.loads(p.read_bytes()); fs=[j['filings']['recent']]
  for h in j['filings']['files']:
   if h['filingFrom']<'2000-01-03':
    p=RAW/h['name'];p.write_bytes(get('https://data.sec.gov/submissions/'+h['name']));fs.append(json.loads(p.read_bytes()))
  records=[]
  for f in fs:
   for i,t in enumerate(f['form']):
    if t in ['10-K','10-K405','10-K/A'] and f['filingDate'][i]<'2000-01-03':records.append({k:v[i] for k,v in f.items() if isinstance(v,list)})
  records.sort(key=lambda x:x['filingDate']);r=next(x for x in reversed(records) if x['form']!='10-K/A')
  acc=r['accessionNumber']; doc=r.get('primaryDocument','')
  # Legacy pre-2001 SEC submissions use the accession text endpoint.
  url=f'https://www.sec.gov/Archives/edgar/data/{c}/{acc}.txt'
  try:b=get(url)
  except Exception:
   url=f'https://www.sec.gov/Archives/edgar/data/{c}/{acc.replace("-","")}/{doc}';b=get(url)
  (RAW/(s+'-initial.txt')).write_bytes(b)
  r['url']=url;(RAW/(s+'-initial-meta.json')).write_text(json.dumps(r,indent=2))
  print(s,r['filingDate'],len(b),flush=True)
 except Exception as e:print(s,'ERROR',str(e),flush=True)
with concurrent.futures.ThreadPoolExecutor(max_workers=3) as e:list(e.map(fetch,C.items()))
