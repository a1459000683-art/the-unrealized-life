# -*- coding: utf-8 -*-
"""Independent source-to-package checks; python3 scripts/audit_market.py."""
import json,pathlib,datetime,math,hashlib
R=pathlib.Path(__file__).resolve().parents[1];m=json.loads((R/'data/market.json').read_text()); checks=[]
def check(name,cond,details=''):
 checks.append({'name':name,'passed':bool(cond),'details':details})
def date(ts):return datetime.datetime.fromtimestamp(ts,datetime.timezone.utc).date().isoformat()
check('17个真实公司，16个完整主线行情',len(m['companies'])==17 and all(len(c['prices'])==53 for c in m['companies'][:16]))
check('至少8种不同生意',len({c['business'] for c in m['companies']})>=8)
check('53节点严格递增且覆盖20年',m['dates']==sorted(set(m['dates'])) and m['dates'][0]=='2000-01-03' and m['dates'][-1]=='2020-12-31')
check('基准日期完全一致', [x['date'] for x in m['benchmark']]==m['dates'])
excluded={'CBU':{'2001-09-12','2015-05-13','2016-08-10'}}
for c in m['companies'][:16]:
 s=c['id'];raw=json.loads((R/f'data/raw/{s}.json').read_text())['chart']['result'][0];q=raw['indicators']['quote'][0]['close'];splits=[(date(v['date']),v['numerator']/v['denominator']) for v in raw.get('events',{}).get('splits',{}).values()];prices={date(t):q[i] for i,t in enumerate(raw['timestamp'])}
 ok=all(p['date'] in prices and math.isclose(p['close'],prices[p['date']]*math.prod(r for d,r in splits if d>p['date']),rel_tol=0,abs_tol=5.01e-7) for p in c['prices'])
 check(s+'全部53报价可回溯原始JSON及拆股乘数',ok)
 expected=sum(m['dates'][0]<date(v['date'])<=m['dates'][-1] and date(v['date']) not in excluded.get(s,set()) for v in raw.get('events',{}).get('dividends',{}).values())+sum(m['dates'][0]<d<=m['dates'][-1] for d,_ in splits)
 check(s+'公司行动数量与原始源及明确更正一致',len(c['actions'])==expected,f"game={len(c['actions'])}; expected={expected}")
 check(s+'事实不早于所属期间，来源齐全',all(f['published']>=f['period'] and f['source'].startswith('https://') for f in c['facts']))
 check(s+'财务指标无NaN/Infinity',all(v is None or isinstance(v,(int,float)) and math.isfinite(v) for f in c['facts'] for v in f.get('metrics',{}).values()))
pir=m['companies'][-1]
check('PIR有限窗口无虚构中间价',[(p['date'],p['close']) for p in pir['prices']]==[('2019-07-31',3.85),('2019-08-30',4.38),('2020-01-06',5.18)])
check('PIR真实取消日期与后来的申报日期分开',any(a['date']=='2020-10-09' and a['published']=='2020-10-15' and a['type']=='cancel' for a in pir['actions']))
cbu=next(c for c in m['companies'] if c['id']=='CBU')
for year,total in [('2001',1.08),('2015',1.22),('2016',1.26)]:
 actual=sum(a['amount'] for a in cbu['actions'] if a['type']=='dividend' and a['date'].startswith(year))
 check('CBU '+year+'股息与SEC年报一致',math.isclose(actual,total,abs_tol=1e-9),str(actual))
check('股票正价格，缺失不以0冒充',all(p['close']>0 and math.isfinite(p['close']) for c in m['companies'] for p in c['prices']))
check('公司行动ID唯一',len({a['id'] for c in m['companies'] for a in c['actions']})==sum(len(c['actions']) for c in m['companies']))
check('财务披露可用日保守延至次日',all(f.get('availableFrom','9999')>f['published'] for c in m['companies'] for f in c['facts'] if f.get('kind')=='financial'))
manifest=[]
for p in sorted((R/'data/raw').glob('*')):
 if p.is_file():manifest.append({'path':str(p.relative_to(R)),'bytes':p.stat().st_size,'sha256':hashlib.sha256(p.read_bytes()).hexdigest()})
report={'executed':'2026-10-02','command':'python3 scripts/audit_market.py','passed':sum(x['passed'] for x in checks),'failed':sum(not x['passed'] for x in checks),'checks':checks,'packageStats':{'companies':len(m['companies']),'businesses':len({c['business'] for c in m['companies']}),'dates':len(m['dates']),'prices':sum(len(c['prices']) for c in m['companies']),'facts':sum(len(c['facts']) for c in m['companies']),'actions':sum(len(c['actions']) for c in m['companies'])},'scope':'仅数据源、转换及日期审计；不是整个游戏或浏览器测试。'}
(R/'docs/data-audit.json').write_text(json.dumps(report,ensure_ascii=False,indent=2));(R/'data/SOURCE-MANIFEST.json').write_text(json.dumps(manifest,ensure_ascii=False,indent=2))
print(json.dumps({k:report[k] for k in ['passed','failed','packageStats']},ensure_ascii=False))
assert report['failed']==0
