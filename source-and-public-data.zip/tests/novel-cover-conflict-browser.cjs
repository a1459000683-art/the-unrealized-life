/* Real same-context browser tabs and actual storage events, without synthetic
 * event dispatch. Run with playwright-cli run-code against a local candidate. */
async (page) => {
  const sourceUrl=page.url(),browser=page.context().browser(),reports=[];
  if(!sourceUrl.startsWith('file:'))throw Error('Open the local candidate HTML first.');
  const autoKey='unrealized-life-novel:v1:auto';
  for(const scenario of ['update-home','delete-home','clear-home','update-new-life']){
    const context=await browser.newContext({viewport:{width:390,height:844},isMobile:true,hasTouch:true,acceptDownloads:true}),checks=[],errors=[];
    const check=(v,label)=>{checks.push({label,passed:!!v});if(!v)throw Error(scenario+': '+label);};
    const open=async()=>{const p=await context.newPage();p.on('pageerror',e=>errors.push(String(e)));await p.goto(sourceUrl);await p.waitForFunction(()=>window.__novelMounted===true);return p;};
    const disk=p=>p.evaluate(k=>localStorage.getItem(k),autoKey);
    const exportLife=async p=>{await p.getByRole('button',{name:'存档',exact:true}).click();const pending=p.waitForEvent('download');await p.getByRole('button',{name:'导出当前人生',exact:true}).click();const file=await pending;check(await file.failure()===null,'Current life downloads successfully');const chunks=[],stream=await file.createReadStream();for await(const c of stream)chunks.push(c);const raw=Buffer.concat(chunks).toString();await p.getByRole('button',{name:'关闭弹窗',exact:true}).click();return raw;};
    try{
      const current=await open();
      if(scenario==='update-new-life'){
        // Obtain an ending using the public engine with natural choices only;
        // import the legal result through the actual UI to exercise new-life.
        const ending=await current.evaluate(async()=>{const n=new Novel('buffer',2000);for(let i=0;i<200;i++){const v=n.view();if(v.phase==='ending')return n.exportSave();const result=v.phase==='result'?await n.next():await n.choose(v.node.choices.find(c=>c.available!==false).id,v.node.id,v.revision);if(!result.ok)throw Error(result.error);}throw Error('Natural route did not finish');});
        await current.getByRole('button',{name:'存档',exact:true}).click();await current.locator('#novel-import').setInputFiles({name:'natural-ending.json',mimeType:'application/json',buffer:Buffer.from(ending)});await current.getByRole('button',{name:'确认读取',exact:true}).click();
        check(await current.locator('[data-action="new-life"]').count()===1,'Natural ending exposes the real new-life entry');
      }else await current.getByRole('button',{name:/给自己留点余地/}).click();
      const original=await exportLife(current),originalDisk=await disk(current);
      const other=await open();await other.getByRole('button',{name:'继续阅读',exact:true}).click();
      await current.evaluate(()=>{window.__coverEvents=[];addEventListener('storage',e=>window.__coverEvents.push({key:e.key,newValue:e.newValue}));});
      if(scenario==='delete-home')await other.evaluate(k=>localStorage.removeItem(k),autoKey);
      else if(scenario==='clear-home')await other.evaluate(()=>localStorage.clear());
      else if(scenario==='update-new-life'){
        await other.getByRole('button',{name:'开始另一段人生',exact:true}).click();await other.getByRole('button',{name:'回到封面',exact:true}).click();await other.getByRole('button',{name:/先把日子撑住/}).click();await other.getByRole('button',{name:'开始新人生',exact:true}).click();
      }else await other.locator('[data-action="choose"]').first().click();
      await current.waitForFunction(()=>window.__coverEvents.length>0);
      const externalDisk=await disk(other),events=await current.evaluate(()=>window.__coverEvents);
      check(externalDisk!==originalDisk,'The other tab really changed or removed automatic storage');
      check(events.some(e=>scenario==='clear-home'?e.key===null:e.key===autoKey),'A real corresponding storage event reached the unchanged current tab');
      await current.getByRole('button',{name:scenario==='update-new-life'?'开始另一段人生':'打开封面',exact:true}).click();
      if(scenario!=='update-new-life')check((await current.locator('.confirm-copy').innerText()).includes('本页仍可继续阅读'),'Home confirmation promises to preserve current reading');
      await current.getByRole('button',{name:'回到封面',exact:true}).click();
      check(await disk(other)===externalDisk,'Returning to cover leaves the other tab disk unchanged');
      await current.getByRole('button',{name:'继续阅读',exact:true}).click();
      check(await disk(other)===externalDisk,'Resuming does not overwrite the other tab disk');
      const resumed=await exportLife(current);
      check(resumed===original,'The exact original current life survives cover, resume and export');
      check(await disk(other)===externalDisk,'Export preserves the other tab disk bytes');
      if(scenario==='update-home'){
        const expected=await exportLife(other);await current.getByRole('button',{name:'存档',exact:true}).click();await current.getByRole('button',{name:'读取设备上的自动书签',exact:true}).click();await current.getByRole('button',{name:'读取设备版本',exact:true}).click();
        check(await exportLife(current)===expected,'Only explicit reading of the device version replaces the current life');
      }
      check(errors.length===0,'No uncaught browser errors');reports.push({scenario,checks,events:events.map(e=>({key:e.key,removed:e.newValue===null})),originalPhase:JSON.parse(original).state.phase});
    }finally{await context.close();}
  }
  return {reports,assertions:reports.reduce((sum,r)=>sum+r.checks.length,0)};
}
