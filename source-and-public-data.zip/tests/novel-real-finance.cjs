'use strict';
// Financial witnesses using only legal choices from the final authored novel.
// No fabricated scene, injected holding, direct state edit or time jump.
// Run explicitly after NOVEL_STORY.draft is removed:
//   node tests/novel-real-finance.cjs
const fs=require('node:fs'),path=require('node:path'),vm=require('node:vm'),crypto=require('node:crypto'),assert=require('node:assert/strict');
const ROOT=path.resolve(__dirname,'..'),OUT=path.join(ROOT,'output/qa/novel-real-finance.json');
const files=['src/finance.js','src/game.js','src/novel.js','src/novel-story.js','data/market.json','tests/novel-real-finance.cjs'];
const text=Object.fromEntries(files.map(p=>[p,fs.readFileSync(path.join(ROOT,p),'utf8')]));
const hash=x=>crypto.createHash('sha256').update(x).digest('hex');
const sourceHashes=Object.fromEntries(files.map(p=>[p,hash(text[p])]));
function load(){const ctx=vm.createContext({console,MARKET:JSON.parse(text['data/market.json']),STORY:{characters:['lin','mara','june','elias','mei','sam','nora','darius'].map(id=>({id,name:id})),events:[],endings:[]}});for(const p of ['src/finance.js','src/game.js','src/novel-story.js','src/novel.js'])vm.runInContext(text[p],ctx,{filename:p});return ctx;}
const ctx=load(),story=ctx.NOVEL_STORY,market=ctx.MARKET;
assert.equal(story.draft,undefined,'Final authored story is not available; this is not a completed finance witness.');
const content=ctx.Novel.validateContent();assert.equal(content.ok,true,content.error);assert.ok(content.nodes>=90);assert.ok(content.groups>=60&&content.groups<=85);
const authorNodes=new Map(story.nodes.map(n=>[n.id,n]));
const close=(actual,expected,tol=1e-7)=>assert.ok(Math.abs(actual-expected)<=tol*Math.max(1,Math.abs(expected)),`${actual} != ${expected}`);
function scoreChoice(ch,n,route){
 const e=ch.effects||{},st=ch.strategy,account=st?.account||'client',p=st?.companyId?n.core.state[account].positions[st.companyId]:null;
 if(ch.ending)return-1e9;
 if(e.career&&['unemployed','outside'].includes(e.career))return-1e8;
 let score=(e.health||0)*3-(e.stress||0)*3+(e.trust||0)*2+(e.discipline||0)*2+(e.research||0)+(e.communication||0)+(e.authority||0)*2;
 score+=Object.values(e.relations||{}).reduce((a,x)=>a+x,0)*.2;
 if(st?.type==='invest'){const priorReduction=route==='partial-then-cancellation'&&st.companyId==='PIR'&&n.state.choiceLog.some(l=>{const prev=authorNodes.get(l.nodeId).choices.find(c=>c.id===l.choiceId).strategy;return prev?.type==='reduce'&&prev.companyId==='PIR';});if(priorReduction)return-10000;score+=st.companyId==='PIR'?2000:account==='client'?1000:600;}
 if(st?.type==='reduce'||st?.type==='exit'){
  if(!p?.quantity)return-10000;
  if(st.companyId==='PIR'&&route==='retain-to-cancellation')return-10000;
  if(st.type==='reduce'&&(st.targetPercent??0)>0)score+=route==='partial-then-cancellation'?2500:1400;
  else score-=800;
 }
 // Prefer a true hold when the loss-case holding already exists; never acquire
 // foreknowledge from future prices or change the historical quote series.
 if(st?.type==='hold'&&route==='retain-to-cancellation')score+=10;
 return score;
}
function run(route){
 const n=new ctx.Novel('buffer',8675309),choices=[],events=[],declined=[],research=[],approvals=[],partialSales=[],actualLosses=[];let completed=0;
 while(n.view().phase!=='ending'){
  const before=n.view(),node=authorNodes.get(before.node.id),available=before.node.choices.filter(c=>c.available);
  assert.ok(available.length,`No legal choice at ${node.id}`);
  const selected=available.map(v=>({v,ch:node.choices.find(c=>c.id===v.choiceId)})).sort((a,b)=>scoreChoice(b.ch,n,route)-scoreChoice(a.ch,n,route))[0];
  const old={client:JSON.parse(JSON.stringify(n.core.state.client)),personal:JSON.parse(JSON.stringify(n.core.state.personal))};
  const oldResearch=JSON.parse(JSON.stringify(n.core.state.research));
  const chosen=n.choose(selected.v.id,before.node.id,before.revision);assert.equal(chosen.ok,true,`${node.id}/${selected.ch.id}: ${chosen.error}`);
  const r=chosen.result,st=selected.ch.strategy;
  for(const which of ['client','personal']){
   for(const row of n.core.state[which].ledger.slice(old[which].ledger.length)){
    if(row.type==='buy'){
     const comp=market.companies.find(c=>c.id===row.companyId),quote=comp.prices.find(p=>p.date===row.date);assert.ok(quote,'a real exact-date quote backs every purchase');close(row.price,quote.close);
     assert.ok(n.core.state.research[row.companyId]?.length,'an authored investment actually did dossier work');assert.ok(n.core.state.theses[row.companyId],'actual pre-trade thesis exists');
     if(which==='client'){assert.ok(r.notices.some(x=>x.includes('允许的单一标的上限')),'result records actual committee limit');approvals.push({nodeId:node.id,date:row.date,companyId:row.companyId,notices:r.notices.filter(x=>x.includes('上限')||x.includes('委员会'))});}
    }
    if(['buy','sell','dividend','split','cancel','cash_merger','expense'].includes(row.type)&&(row.type==='expense'||row.quantity>0||row.quantityBefore>0))events.push({nodeId:node.id,choiceId:selected.ch.id,account:which,...JSON.parse(JSON.stringify(row))});
    if(row.type==='sell'&&row.quantityAfter>0){const beforePosition=old[which].positions[row.companyId];partialSales.push({nodeId:node.id,account:which,companyId:row.companyId,date:row.date,quantity:row.quantity,quantityRemaining:row.quantityAfter,costRemoved:row.costRemoved,realized:row.realized,authoredStrategy:st?.companyId===row.companyId&&(st.account||'client')===which&&row.date===before.date?st.type:null});if(beforePosition&&st?.type==='reduce')close(row.costRemoved,beforePosition.cost*row.quantity/beforePosition.quantity);}
    if(row.type==='cancel'&&row.quantityBefore>0){assert.equal(row.amount,0);assert.equal(row.quantityAfter,0);actualLosses.push({nodeId:node.id,account:which,companyId:row.companyId,date:row.date,quantity:row.quantityBefore,realized:row.realized});}
   }
   const validation=ctx.Finance.validateAccount(n.core.state[which],n.core.state.date);assert.equal(validation.ok,true,validation.error);close(ctx.Finance.stats(n.core.state[which],{},n.core.state.date).reconciliationError,0);
  }
  for(const [id,topics]of Object.entries(n.core.state.research))for(const topic of topics)if(!(oldResearch[id]||[]).includes(topic))research.push({nodeId:node.id,date:before.date,companyId:id,topic});
  if(st&&['invest','reduce','exit'].includes(st.type)){
   const which=st.account||'client',type=st.type==='invest'?'buy':'sell',actual=n.core.state[which].ledger.slice(old[which].ledger.length).filter(x=>x.companyId===st.companyId&&x.type===type&&x.date===before.date);
   if(!actual.length){assert.ok(r.notices.some(x=>/未产生|没有成交|没有可用于|没有新增/.test(x)),`No execution must be explained: ${node.id}/${selected.ch.id}`);declined.push({nodeId:node.id,choiceId:selected.ch.id,strategy:st,result:r.text,notices:r.notices});}
  }
  choices.push({nodeId:node.id,choiceId:selected.ch.id,date:before.date,settledDate:r.toDate,label:selected.ch.label,strategy:st||null,availableChoices:available.map(c=>c.choiceId)});
  const amounts=JSON.stringify([n.core.state.client,n.core.state.personal,n.core.state.firm]);assert.equal(n.next().ok,true);assert.equal(JSON.stringify([n.core.state.client,n.core.state.personal,n.core.state.firm]),amounts,'reading next cannot settle again');
  completed++;assert.ok(completed<=85);
 }
 assert.ok(completed>=60);assert.equal(n.core.state.date,'2020-12-31');assert.equal(n.core.state.review.length,52);assert.equal(ctx.Novel.validateSave(n.exportSave()).ok,true);
 close(n.core.state.firm.cash,n.core.state.firm.ledger.reduce((a,x)=>a+x.amount,0));
 return{route,start:'buffer',seed:8675309,decisions:completed,date:n.core.state.date,ending:n.view().ending.id,research,approvals,choices,events,partialSales,actualLosses,declined,summary:n.view().summary,accountStats:{client:ctx.Finance.stats(n.core.state.client,{},n.core.state.date),personal:ctx.Finance.stats(n.core.state.personal,{},n.core.state.date)},positions:{client:n.core.state.client.positions,personal:n.core.state.personal.positions}};
}
const routes=[run('retain-to-cancellation'),run('partial-then-cancellation')];
const all=routes.flatMap(r=>r.events),partials=routes.flatMap(r=>r.partialSales).filter(p=>p.authoredStrategy==='reduce'),losses=routes.flatMap(r=>r.actualLosses);
const residualRoute=routes.find(r=>r.route==='partial-then-cancellation'),residualSale=residualRoute.partialSales.find(s=>s.companyId==='PIR'&&s.authoredStrategy==='reduce'),residualCancel=residualRoute.actualLosses.find(s=>s.companyId==='PIR');
const residualPreserved=!!residualSale&&!!residualCancel&&residualSale.quantityRemaining===residualCancel.quantity&&!residualRoute.events.some(e=>e.companyId==='PIR'&&e.type==='buy'&&e.date>residualSale.date);
const checks={partialResidualPreservedUntilCancellation:residualPreserved,unexecutedStrategyExplained:routes.every(r=>r.declined.every(d=>d.notices.some(x=>/未产生|没有成交|没有可用于|没有新增/.test(x)))),authoredResearch:routes.some(r=>r.research.length>0),actualClientApproval:routes.some(r=>r.approvals.length>0),actualBuy:all.some(e=>e.type==='buy'),authoredPartialSale:partials.length>0,heldDividend:all.some(e=>e.type==='dividend'&&e.quantityBefore>0&&e.amount>0),heldSplit:all.some(e=>e.type==='split'&&e.quantityBefore>0),pirCancellation:losses.some(e=>e.companyId==='PIR'&&e.date==='2020-10-15'&&e.realized<0),meaningfulLoss:losses.some(e=>e.companyId==='PIR'&&e.realized<=-1000)};
for(const p of files)assert.equal(hash(fs.readFileSync(path.join(ROOT,p),'utf8')),sourceHashes[p],`Source changed during witnesses: ${p}`);
const report={schemaVersion:1,generatedAt:new Date().toISOString(),status:Object.values(checks).every(Boolean)?'passed':'failed',sourceHashes,method:'Only new Novel plus actual authored available choice tokens; no direct state writes, injected holdings, skipped dates, fabricated scenes or market changes. Policies read current state and authored strategies, not future prices.',checks,routes};
fs.mkdirSync(path.dirname(OUT),{recursive:true});fs.writeFileSync(OUT,JSON.stringify(report,null,2)+'\n');
console.log(JSON.stringify({status:report.status,checks,routes:routes.map(r=>({route:r.route,decisions:r.decisions,ending:r.ending,events:r.events.length,research:r.research.length,approvals:r.approvals.length,authoredPartials:r.partialSales.filter(p=>p.authoredStrategy==='reduce').length,losses:r.actualLosses})),output:'output/qa/novel-real-finance.json'},null,2));
assert.equal(report.status,'passed','Missing natural financial witness; inspect report, do not count it as implemented.');
