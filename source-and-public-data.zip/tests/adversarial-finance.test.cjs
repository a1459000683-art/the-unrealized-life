'use strict';
const {test} = require('node:test');
const assert = require('node:assert/strict');
// FINANCE_UNDER_TEST allows proving that the new cases fail on the pinned baseline.
const F = require(process.env.FINANCE_UNDER_TEST || '../src/finance.js');
const day = '2000-01-01';
const account = (cash = 10000) => F.createAccount(cash, day);
const buy = (a, quantity, price = 1, id = 'A', feeRate = 0) => F.buy(a, {id, quantity, price, feeRate, date:a.date});
const sell = (a, quantity, price = 1, id = 'A', feeRate = 0) => F.sell(a, {id, quantity, price, feeRate, date:a.date});
const ok = result => assert.equal(result.ok, true, JSON.stringify(result));
const near = (actual, expected, tolerance = 2e-7) => assert.ok(Math.abs(actual - expected) <= tolerance, `${actual} != ${expected}`);
const clone = x => JSON.parse(JSON.stringify(x));
const refused = (a, f, code) => { const before=JSON.stringify(a); const r=f(); assert.equal(r.ok,false,JSON.stringify(r)); if(code)assert.equal(r.code,code); assert.equal(JSON.stringify(a),before,'failed operation changed account'); };
const valid = a => assert.deepEqual(F.validateAccount(clone(a),a.date),{ok:true});
const finiteTree = x => {if(typeof x==='number')assert.ok(Number.isFinite(x));else if(x&&typeof x==='object')Object.values(x).forEach(finiteTree);};

test('sub-ULP buys cannot create stock without debiting cash',()=>{
 const a=account(1e14);for(let i=0;i<100;i++)refused(a,()=>buy(a,.005),'precision_limit');assert.equal(a.cash,1e14);assert.deepEqual(a.positions,{});
});
test('sub-ULP sells cannot pay cash while preserving all shares',()=>{
 const a=account(1e14);ok(buy(a,1e14));for(let i=0;i<100;i++)refused(a,()=>sell(a,.005),'precision_limit');assert.equal(a.cash,0);assert.equal(a.positions.A.quantity,1e14);valid(a);
});
test('partially rounded deltas are refused even when they change the large balance',()=>{
 const a=account(1e14);refused(a,()=>buy(a,.02),'precision_limit');
});
test('tiny high-price fractional shares remain legitimate',()=>{
 const a=account(10);ok(buy(a,1e-10,1e10));ok(sell(a,1e-10,2e10));near(a.cash,11);valid(a);
});
test('mandatory tiny-share cash distributions are paid even below order precision',()=>{
 const a=account(10);ok(buy(a,1e-10,1e10));ok(F.action(a,{id:'tiny-d',companyId:'A',date:a.date,type:'dividend',amount:1}));assert.equal(a.totals.dividends,1e-10);assert.equal(a.ledger.at(-1).amount,1e-10);valid(a);
});
test('legitimate tiny stored cash is not silently rounded away',()=>{
 const a=account(1e-11);ok(buy(a,1,1e-12));near(a.cash,9e-12,1e-25);assert.equal(a.ledger.at(-1).cashAfter,a.cash);ok(F.flow(a,0,a.date));near(a.cash,9e-12,1e-25);
});
for(const type of ['cancel','cash_merger']){
 test(`${type} remains permanent after a full sale and after JSON restore`,()=>{
  const a=account();ok(buy(a,10));ok(sell(a,10));const event={id:'retire',companyId:'A',date:a.date,type,amount:3};ok(F.action(a,event));assert.equal(a.positions.A.cancelled,true);valid(a);
  const b=clone(a);refused(b,()=>buy(b,1),'cancelled_equity');assert.equal(F.action(b,event).duplicate,true);assert.equal(JSON.stringify(a),JSON.stringify(b));
 });
 test(`${type} permanently retires an identity never held`,()=>{
  const a=account();ok(F.action(a,{id:'retire',companyId:'A',date:a.date,type,amount:3}));refused(a,()=>buy(a,1),'cancelled_equity');valid(a);
 });
}
test('legacy or altered false cancellation flag cannot revive the old identity',()=>{
 const a=account();ok(buy(a,10));ok(F.action(a,{id:'retire',companyId:'A',date:a.date,type:'cancel'}));const b=clone(a);b.positions.A.cancelled=false;valid(b);refused(b,()=>buy(b,1),'cancelled_equity');
});
test('post-cancellation purchases in a self-consistent old ledger are rejected',()=>{
 const a=account();ok(F.action(a,{id:'retire',companyId:'A',date:a.date,type:'cancel'}));
 // Construct exactly the legacy hole: an action before any ownership, followed
 // by an ordinary purchase. Its arithmetic is consistent; its identity is not.
 const b=account();ok(buy(b,1));const action=clone(a.ledger[1]);b.ledger.splice(1,0,action);b.ledger.forEach((r,i)=>r.seq=i+1);b.appliedActions=clone(a.appliedActions);assert.equal(F.validateAccount(b).ok,false);
});
test('extreme reverse splits cannot save Infinity prices or underflow shares',()=>{
 for(const ratio of [Number.MIN_VALUE,1e-300,1e-20]){const a=account();ok(buy(a,1,100));refused(a,()=>F.action(a,{id:'split',companyId:'A',date:a.date,type:'split',ratio}),'numeric_limit');valid(a);}
});
test('overflowing split shares and invalid action inputs are atomic',()=>{
 const a=account(1e15);ok(buy(a,1e15));for(const ratio of [NaN,Infinity,-1,0,1e10,2])refused(a,()=>F.action(a,{id:'split',companyId:'A',date:a.date,type:'split',ratio}));
 for(const amount of [-1,NaN,Infinity,1e16])refused(a,()=>F.action(a,{id:'div',companyId:'A',date:a.date,type:'dividend',amount}));
});
test('new funding checks portfolio NAV rather than only cash',()=>{
 const a=account(1e15);ok(buy(a,1,1e15));refused(a,()=>F.flow(a,1e15,a.date),'numeric_limit');valid(a);
});
test('dividend checks portfolio NAV before changing cash or recording its ID',()=>{
 const a=account(1e15);ok(buy(a,1,1e15));refused(a,()=>F.action(a,{id:'large-div',companyId:'A',date:a.date,type:'dividend',amount:1e14}),'numeric_limit');valid(a);
});
test('turnover cannot silently exceed persisted aggregate limits',()=>{
 const a=account(1e15);ok(buy(a,1,1e15));ok(sell(a,1,1e15));refused(a,()=>buy(a,1,1e15),'numeric_limit');valid(a);
});
test('sell proceeds have a cumulative guard separate from current cash',()=>{
 const a=account(5e14);ok(buy(a,1,5e14));ok(sell(a,1,8e14));ok(F.flow(a,-3e14,a.date));ok(buy(a,1,5e14));refused(a,()=>sell(a,1,8e14),'numeric_limit');valid(a);
});
test('expense totals cannot overflow after replenishment',()=>{
 const a=account(1e15);ok(F.expense(a,1e15,a.date));ok(F.flow(a,1,a.date));refused(a,()=>F.expense(a,1,a.date),'numeric_limit');valid(a);
});
test('cash flows and charges below a large balance precision reject atomically',()=>{
 const a=account(1e14);for(const n of [.005,-.005])refused(a,()=>F.flow(a,n,a.date),'precision_limit');refused(a,()=>F.expense(a,.005,a.date),'precision_limit');
});
test('bad numeric types, extreme values and authorization reject both sides',()=>{
 const a=account();ok(buy(a,100));
 for(const fn of [F.buy,F.sell])for(const quantity of [-1,NaN,Infinity,1e16,'1',null,Number.MIN_VALUE])refused(a,()=>fn(a,{id:'A',date:a.date,price:1,quantity}));
 for(const fn of [F.buy,F.sell])for(const overrides of [{authorized:false},{tradable:false},{status:'unlisted'},{status:'suspended'},{status:'cancelled'},{feeRate:NaN},{feeRate:Infinity},{price:-1}])refused(a,()=>fn(a,{id:'A',date:a.date,price:1,quantity:1,...overrides}));valid(a);
});
test('repeated same-price round trips lose exactly the stated two-sided fee',()=>{
 const a=account();for(let i=0;i<500;i++){ok(buy(a,1,25,'A',.001));ok(sell(a,1,25,'A',.001));}near(a.cash,9975);near(a.totals.realized,-25);near(a.totals.fees,25);assert.equal(a.positions.A.quantity,0);valid(a);
});
test('redemption after split and ex-dividend mark leaves linked return unchanged',()=>{
 const a=account(1000);ok(buy(a,100,10));ok(F.mark(a,'2001-01-01',{A:12}));ok(F.action(a,{id:'s',companyId:'A',date:a.date,type:'split',ratio:2}));ok(F.action(a,{id:'d',companyId:'A',date:a.date,type:'dividend',amount:1}));ok(F.mark(a,a.date,{A:5}));near(F.stats(a).twr,.2);near(F.positionStats(a,'A',5).twr,.2);
 ok(sell(a,100,5));ok(F.flow(a,-700,a.date,'赎回'));near(F.stats(a).twr,.2);ok(F.mark(a,'2002-01-01',{A:10}));near(F.stats(a).twr,1.4);valid(a);
});
test('complete redemption and later resubscription preserve the existing return chain',()=>{
 const a=account(1000);ok(buy(a,100,10));ok(sell(a,100,12));ok(F.flow(a,-1200,a.date));near(F.stats(a).twr,.2);ok(F.flow(a,500,'2001-01-01'));ok(buy(a,50,10));ok(F.mark(a,'2002-01-01',{A:11}));near(F.stats(a).twr,.32);valid(a);
});
test('tax-like expense is a cost and repeated action IDs stay account-local after restore',()=>{
 const a=account(),b=account();const event={id:'annual-d',companyId:'A',date:day,type:'dividend',amount:1};for(const x of[a,b]){ok(buy(x,100,10));ok(F.action(x,event));ok(F.mark(x,day,{A:9}));ok(F.expense(x,15,day,'股息税测试费用'));}
 const c=clone(a);const before=JSON.stringify(c);assert.equal(F.action(c,event).duplicate,true);assert.equal(JSON.stringify(c),before);near(F.stats(c).profit,-15);assert.equal(b.totals.dividends,100);valid(c);valid(b);
});

// Independent, seeded accounting oracle. Unlike the existing random test this
// maintains a separate cash/cost/action model, exercises whole-account restores,
// and compares absolute dollar differences (not a large relative tolerance).
for(const initialSeed of [1,719,90210,0xdeadbeef])test(`independent 400-step ledger oracle, seed ${initialSeed}`,()=>{
 let a=account(100000),seed=initialSeed>>>0;const rnd=()=>{seed=(Math.imul(seed,1664525)+1013904223)>>>0;return seed/2**32;};
 const ref={cash:100000,contributions:100000,realized:0,dividends:0,fees:0,expenses:0,positions:{}},prices={A:20,B:35,C:50};
 for(let i=0;i<400;i++){
  const date=new Date(Date.UTC(2000,0,i+1)).toISOString().slice(0,10),id=['A','B','C'][Math.floor(rnd()*3)];prices[id]=Math.round((10+rnd()*80)*100)/100;ok(F.mark(a,date,prices));
  const op=Math.floor(rnd()*7),p=ref.positions[id];
  if(op===0){const q=1+Math.floor(rnd()*10),gross=q*prices[id],fee=gross*.001;if(ref.cash>=gross+fee){ok(buy(a,q,prices[id],id,.001));const r=ref.positions[id]||(ref.positions[id]={quantity:0,cost:0});r.quantity+=q;r.cost+=gross+fee;ref.cash-=gross+fee;ref.fees+=fee;}}
  else if(op===1&&p?.quantity>0){const q=p.quantity*(rnd()<.3?1:.25),gross=q*prices[id],fee=gross*.001,removed=p.cost*q/p.quantity;ok(sell(a,q,prices[id],id,.001));p.quantity-=q;p.cost=p.quantity===0?0:p.cost-removed;ref.cash+=gross-fee;ref.realized+=gross-fee-removed;ref.fees+=fee;}
  else if(op===2){const amount=rnd()<.5?137:-Math.min(ref.cash,79);ok(F.flow(a,amount,date));ref.cash+=amount;ref.contributions+=amount;}
  else if(op===3){const fee=Math.min(ref.cash,3.25);ok(F.expense(a,fee,date));ref.cash-=fee;ref.expenses+=fee;ref.fees+=fee;}
  else if(op===4){const event={id:`d${i}`,companyId:id,date,type:'dividend',amount:.25},payment=(p?.quantity||0)*.25;ok(F.action(a,event));ref.cash+=payment;ref.dividends+=payment;prices[id]-=.25;ok(F.mark(a,date,prices));const before=JSON.stringify(a);assert.equal(F.action(a,event).duplicate,true);assert.equal(JSON.stringify(a),before);}
  else if(op===5&&p?.quantity>0){const ratio=rnd()<.5?2:.5;ok(F.action(a,{id:`s${i}`,companyId:id,date,type:'split',ratio}));p.quantity*=ratio;prices[id]/=ratio;ok(F.mark(a,date,prices));}
  else if(op===6){a=clone(a);valid(a);}
  const market=Object.entries(ref.positions).reduce((v,[k,r])=>v+r.quantity*prices[k],0),cost=Object.values(ref.positions).reduce((v,r)=>v+r.cost,0);
  near(a.cash,ref.cash);near(a.totals.realized,ref.realized);near(a.totals.dividends,ref.dividends);near(a.totals.fees,ref.fees);near(ref.cash+market-ref.contributions,ref.realized+market-cost+ref.dividends-ref.expenses);
  for(const [k,r]of Object.entries(ref.positions)){near(a.positions[k].quantity,r.quantity,1e-9);near(a.positions[k].cost,r.cost);}
  if(i%25===0){valid(a);finiteTree(a);}
 }
 valid(a);const result=F.stats(a);ok(result);near(result.reconciliationError,0);finiteTree(result);
});

// Real JSON emitted by pinned finance.js SHA-256 339a5fd5cf0f022c7b51750df73014a243db7cf1999371f0506744f14f4dea51.
test("baseline micro save remains readable without rewriting the historical ledger",()=>{
 const legacy={"version":1,"currency":"USD","date":"2000-01-01","startDate":"2000-01-01","cash":9999.999999999,"positions":{"A":{"id":"A","quantity":1e-10,"cost":1e-9,"realized":0,"dividends":0,"fees":0,"totalInvested":1e-9,"totalProceeds":0,"firstBuyDate":"2000-01-01","lastBuyDate":"2000-01-01","closedDate":null,"cancelled":false,"cashFlows":[{"date":"2000-01-01","amount":-1e-9,"type":"buy"}],"history":[{"date":"2000-01-01","unitValue":1,"marketValue":0,"kind":"start"},{"date":"2000-01-01","marketValue":1e-9,"unitValue":1,"kind":"buy"}],"performanceFactor":1,"lastValue":1e-9}},"ledger":[{"seq":1,"type":"external_flow","date":"2000-01-01","amount":10000,"reason":"初始资金","cashAfter":10000},{"seq":2,"type":"buy","date":"2000-01-01","companyId":"A","quantity":1e-10,"price":10,"gross":1e-9,"fee":0,"amount":-1e-9,"costAfter":1e-9,"quantityAfter":1e-10,"cashAfter":9999.999999999}],"externalFlows":[{"date":"2000-01-01","amount":10000,"reason":"初始资金"}],"history":[{"date":"2000-01-01","nav":10000,"unitValue":1,"twr":0,"kind":"initial","stale":[]},{"date":"2000-01-01","nav":10000,"unitValue":1,"twr":0,"kind":"buy","stale":[]}],"prices":{"A":10},"quoteDates":{"A":"2000-01-01"},"appliedActions":{},"twrFactor":1,"lastNav":10000,"totals":{"realized":0,"dividends":0,"fees":0,"expenses":0},"priceBasis":"raw","sampling":"完整可核验报价的决策日最终净值；排除含陈旧估值的节点，同日后续结算覆盖；不是日内最大回撤"};
 const before=JSON.stringify(legacy);valid(legacy);assert.equal(JSON.stringify(legacy),before);ok(buy(legacy,1,10));valid(legacy);
});

// Real JSON emitted by pinned finance.js SHA-256 339a5fd5cf0f022c7b51750df73014a243db7cf1999371f0506744f14f4dea51.
test("baseline retired save remains readable without rewriting the historical ledger",()=>{
 const legacy={"version":1,"currency":"USD","date":"2000-01-01","startDate":"2000-01-01","cash":10000,"positions":{"A":{"id":"A","quantity":0,"cost":0,"realized":0,"dividends":0,"fees":0,"totalInvested":100,"totalProceeds":100,"firstBuyDate":"2000-01-01","lastBuyDate":"2000-01-01","closedDate":"2000-01-01","cancelled":false,"cashFlows":[{"date":"2000-01-01","amount":-100,"type":"buy"},{"date":"2000-01-01","amount":100,"type":"sell"}],"history":[{"date":"2000-01-01","unitValue":1,"marketValue":0,"kind":"start"},{"date":"2000-01-01","marketValue":0,"unitValue":1,"kind":"sell"}],"performanceFactor":1,"lastValue":0,"pendingDistribution":0}},"ledger":[{"seq":1,"type":"external_flow","date":"2000-01-01","amount":10000,"reason":"初始资金","cashAfter":10000},{"seq":2,"type":"buy","date":"2000-01-01","companyId":"A","quantity":10,"price":10,"gross":100,"fee":0,"amount":-100,"costAfter":100,"quantityAfter":10,"cashAfter":9900},{"seq":3,"type":"sell","date":"2000-01-01","companyId":"A","quantity":10,"price":10,"gross":100,"fee":0,"amount":100,"costRemoved":100,"realized":0,"quantityAfter":0,"costAfter":0,"cashAfter":10000},{"seq":4,"type":"cancel","actionId":"retire","date":"2000-01-01","companyId":"A","quantityBefore":0,"quantityAfter":0,"perShare":null,"ratio":null,"amount":0,"realized":0,"costAfter":0,"cashAfter":10000}],"externalFlows":[{"date":"2000-01-01","amount":10000,"reason":"初始资金"}],"history":[{"date":"2000-01-01","nav":10000,"unitValue":1,"twr":0,"kind":"initial","stale":[]},{"date":"2000-01-01","nav":10000,"unitValue":1,"twr":0,"kind":"cancel","stale":[]}],"prices":{"A":10},"quoteDates":{"A":"2000-01-01"},"appliedActions":{"retire":{"date":"2000-01-01","type":"cancel","companyId":"A"}},"twrFactor":1,"lastNav":10000,"totals":{"realized":0,"dividends":0,"fees":0,"expenses":0},"priceBasis":"raw","sampling":"完整可核验报价的决策日最终净值；排除含陈旧估值的节点，同日后续结算覆盖；不是日内最大回撤"};
 const before=JSON.stringify(legacy);valid(legacy);assert.equal(JSON.stringify(legacy),before);refused(legacy,()=>buy(legacy,1),'cancelled_equity');
});

const market = require('../data/market.json');
for(const company of market.companies)test(`pinned ${company.id} timeline: every disclosed action, duplicate replay and final save remain valid`,()=>{
 const first=company.prices[0];if(!first)return;const a=F.createAccount(1000000,first.date);ok(buy(a,100,first.close,company.id,.001));
 let shares=100,cash=1000000-100*first.close*1.001;
 const actions=(company.actions||[]).filter(e=>!e.informational&&!e.appliedInSeries).map(e=>({...e,date:e.published&&e.published>e.date?e.published:e.date,companyId:company.id})).filter(e=>e.date>first.date);
 const timeline=[...company.prices.slice(1).map(p=>({...p,kind:'quote'})),...actions.map(e=>({...e,kind:'action'}))].sort((a,b)=>a.date.localeCompare(b.date)||(a.kind==='action'?-1:1));
 for(const e of timeline){
  if(e.kind==='quote')ok(F.mark(a,e.date,{[company.id]:e.close}));
  else {ok(F.action(a,e));if(e.type==='split')shares*=e.ratio;else if(e.type==='dividend')cash+=shares*e.amount;else if(e.type==='cash_merger'){cash+=shares*e.amount;shares=0;}else if(e.type==='cancel')shares=0;
   const saved=JSON.stringify(a);assert.equal(F.action(a,e).duplicate,true);assert.equal(JSON.stringify(a),saved);}
 }
 near(a.cash,cash);near(a.positions[company.id].quantity,shares);valid(a);near(F.stats(a).reconciliationError,0);
});
