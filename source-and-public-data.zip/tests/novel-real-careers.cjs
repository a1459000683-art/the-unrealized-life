'use strict';
// Independent authored-content smoke careers: real market, real story, only
// Novel constructor/choose/next/export/fromSave. No state injection or skip.
// Run explicitly after the story is final: node tests/novel-real-careers.cjs
const fs=require('node:fs'),path=require('node:path'),vm=require('node:vm'),assert=require('node:assert/strict'),crypto=require('node:crypto');
const ROOT=path.resolve(__dirname,'..');
const read=p=>fs.readFileSync(path.join(ROOT,p),'utf8');
const hash=p=>crypto.createHash('sha256').update(fs.readFileSync(path.join(ROOT,p))).digest('hex');
const evidenceFiles=['src/finance.js','src/game.js','src/novel.js','src/novel-story.js','data/market.json','tests/novel-real-careers.cjs'];
const hashesBefore=Object.fromEntries(evidenceFiles.map(p=>[p,hash(p)]));
const storyCtx=vm.createContext({});vm.runInContext(read('src/novel-story.js'),storyCtx);
const story=JSON.parse(JSON.stringify(storyCtx.NOVEL_STORY));
assert.equal(story.draft,undefined,'Refusing to count authoring draft as a complete real novel');
const market=JSON.parse(read('data/market.json')),marketBefore=JSON.stringify(market);
const ctx=vm.createContext({console,MARKET:market,NOVEL_STORY:story,STORY:{characters:story.characters,events:[],endings:[]}});
for(const file of ['finance','game','novel'])vm.runInContext(read('src/'+file+'.js'),ctx,{filename:file+'.js'});
const groups=new Set(story.nodes.map(n=>n.dateIndex+':'+(n.slot||0))).size;
const nodeMap=Object.fromEntries(story.nodes.map(n=>[n.id,n]));
let assertions=0;const check=(condition,msg)=>{assertions++;assert.ok(condition,msg);};
const near=(a,b,msg)=>check(Math.abs(a-b)<=1e-6*Math.max(1,Math.abs(b)),msg+': '+a+' vs '+b);
function score(ch,mode){const e=ch.effects||{},st=ch.strategy||{},relation=Object.values(e.relations||{}).reduce((a,b)=>a+b,0);if(mode==='cash')return (st.type==='repay'?35:0)+(st.type==='hold'?12:0)-(st.type==='invest'?15:0)+(e.health||0)*2-(e.stress||0)+(e.personalCash||0)/1000-(e.debt||0)/1000;if(mode==='investment')return (st.type==='invest'?80:st.type==='reduce'?50:st.type==='exit'?45:0)+(e.researchCompany?.length||0)*12+(e.research||0)*2+(e.discipline||0)+(e.health||0)*.1;return relation*3+(e.health||0)*3-(e.stress||0)*2+(e.freedom||0)+(e.career==='outside'?20:0);}
const specs=[{start:'debt',seed:1001,mode:'cash'},{start:'buffer',seed:2002,mode:'investment'},{start:'network',seed:3003,mode:'relationships'}];
const paths=[];
for(const spec of specs){let n=new ctx.Novel(spec.start,spec.seed);const steps=[],dates=new Set(),careers=new Set();let rejected=0,roundTrips=0;
 while(n.view().phase!=='ending'){
  const v=n.view();check(v.phase==='choice','legal scene');check(v.date===market.dates[v.node.dateIndex],'scene aligned to real market date');dates.add(v.date);careers.add(n.core.state.career);
  const authored=nodeMap[v.node.id];const available=v.node.choices.filter(ch=>ch.available).map(ch=>({shown:ch,authored:authored.choices.find(x=>x.id===ch.choiceId)})).sort((a,b)=>score(b.authored,spec.mode)-score(a.authored,spec.mode));
  check(available.length>0,'at least one legal choice at '+v.node.id);
  // Explicitly take an authored partial exit at an actual PIR quotation date,
  // then retain the residual through its later disclosed cancellation. These
  // are legal visible choices, not injected holdings or future-priced orders.
  const required=spec.mode==='investment'?({n43_0:'b',n45_0:'c'})[v.node.id]:null;
  const selected=required?available.find(x=>x.authored.id===required):available[0];check(!!selected,'targeted authored strategy is legally available');const beforeCount=n.state.choiceCount;
  const result=n.choose(selected.shown.id,v.node.id,v.revision);check(result.ok,result.error);check(n.state.choiceCount===beforeCount+1,'one choice consumed');
  const settled=n.exportSave();check(!n.choose(selected.shown.id).ok,'same command rejected');rejected++;check(n.exportSave()===settled,'duplicate command has no effects');
  for(const key of ['client','personal']){const st=ctx.Finance.stats(n.core.state[key],{},n.core.state.date);near(st.reconciliationError,0,key+' cash reconciles');check(Number.isFinite(st.nav)&&st.nav>=0,key+' finite nonnegative NAV');}
  near(n.core.state.firm.cash,n.core.state.firm.ledger.reduce((sum,row)=>sum+row.amount,0),'firm cash reconciles');
  const money=JSON.stringify({client:n.core.state.client,personal:n.core.state.personal,firm:n.core.state.firm,debt:n.core.state.debt,debtLedger:n.core.state.debtLedger});
  steps.push({nodeId:v.node.id,choiceId:selected.authored.id,date:v.date,settledDate:n.core.state.date,strategy:selected.authored.strategy?.type||null});
  if(n.state.choiceCount%7===0||result.result.terminal){const valid=ctx.Novel.validateSave(n.exportSave());check(valid.ok,valid.error);n=ctx.Novel.fromSave(n.exportSave());roundTrips++;}
  check(n.next().ok,'navigate result');check(JSON.stringify({client:n.core.state.client,personal:n.core.state.personal,firm:n.core.state.firm,debt:n.core.state.debt,debtLedger:n.core.state.debtLedger})===money,'next is financially pure');
  const immediatelyAfterNext=n.exportSave();check(ctx.Novel.validateSave(immediatelyAfterNext).ok,'immediate post-next autosave is valid before another choice');check(ctx.Novel.fromSave(immediatelyAfterNext).exportSave()===immediatelyAfterNext,'immediate post-next restore is idempotent');
  check(steps.length<=groups,'no looping/skipped terminal');
 }
 const v=n.view(),s=n.core.state;check(v.ending.kind==='death'||s.date===market.dates.at(-1),'correct terminal date');check(v.ending.kind==='death'||steps.length===groups,'complete ordinary career');check(ctx.Novel.validateSave(n.exportSave()).ok,'valid final import');
 const frozen=n.exportSave();check(!n.next().ok&&!n.choose('old').ok,'ending frozen');check(n.exportSave()===frozen,'terminal cannot settle again');
 check(JSON.stringify(market)===marketBefore,'choices never modify market data');
 const ledgerRowsByType={},affectedActions={};for(const account of ['client','personal']){ledgerRowsByType[account]=s[account].ledger.reduce((out,row)=>(out[row.type]=(out[row.type]||0)+1,out),{});affectedActions[account]={paidDividends:s[account].ledger.filter(r=>r.type==='dividend'&&r.amount>0).length,heldSplits:s[account].ledger.filter(r=>r.type==='split'&&r.quantityBefore>0).length,cancelledHeldStock:s[account].ledger.filter(r=>r.type==='cancel'&&r.quantityBefore>0).length};}
 if(spec.mode==='investment'){const sales=s.personal.ledger.filter(r=>r.type==='sell'&&r.companyId==='PIR');check(sales.length>0,'real authored path executes a partial PIR sale');const canceled=s.personal.ledger.find(r=>r.type==='cancel'&&r.companyId==='PIR');check(!!canceled,'actual disclosed cancellation was processed');check(s.personal.positions.PIR&&s.personal.positions.PIR.cancelled,'residual old shares remain cancelled');}
 paths.push({...spec,choices:steps.length,datesVisited:dates.size,finalDate:s.date,age:s.age,ending:v.ending.id,endingKind:v.ending.kind,careers:[...careers],rejectedDuplicateCommands:rejected,validRoundTrips:roundTrips,clientNav:s.client.lastNav,personalNetWorth:s.personal.lastNav-s.debt,ledgerRowsByType,affectedActions,steps});
 console.log(spec.start+': '+steps.length+' choices, '+s.date+', ending '+v.ending.id);
}
const hashes=Object.fromEntries(evidenceFiles.map(p=>[p,hash(p)]));check(JSON.stringify(hashesBefore)===JSON.stringify(hashes),'all source/data/test files stable during execution');
const report={generatedAt:new Date().toISOString(),command:'node tests/novel-real-careers.cjs',scope:'3 deterministic natural authored-content careers; no state injection; not all branches or all endings',sourceStableDuringRun:true,assertions,paths,hashesBefore,hashes};
fs.mkdirSync(path.join(ROOT,'output/qa'),{recursive:true});fs.writeFileSync(path.join(ROOT,'output/qa/novel-independent-real-careers.json'),JSON.stringify(report,null,2)+'\n');console.log(assertions+' assertions passed; report output/qa/novel-independent-real-careers.json');
