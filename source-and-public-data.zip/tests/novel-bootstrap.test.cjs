const test=require('node:test'),assert=require('node:assert/strict'),vm=require('node:vm'),fs=require('node:fs');
const source=fs.readFileSync(require('node:path').join(__dirname,'../src/novel-bootstrap.js'),'utf8');
function boot(){
 const message={textContent:''},status={hidden:false,querySelector:()=>message};
 const handlers={},timers=[],attributes={};
 const ctx=vm.createContext({document:{getElementById:()=>status,documentElement:{setAttribute:(k,v)=>attributes[k]=v}},setTimeout:fn=>timers.push(fn),addEventListener:(type,fn)=>handlers[type]=fn});
 vm.runInContext('window=this; Array.prototype.at=undefined; Object.fromEntries=undefined;',ctx);
 vm.runInContext(source,ctx);return{ctx,message,status,handlers,timers,attributes};
}
test('novel startup supplies .at and fromEntries without exposing prototype setters',()=>{
 const {ctx}=boot();
 assert.equal(vm.runInContext('[7,8,9].at(-1)',ctx),9);
 assert.equal(vm.runInContext('[7,8,9].at(0)',ctx),7);
 assert.equal(vm.runInContext("Object.fromEntries([['x',3]]).x",ctx),3);
 assert.equal(vm.runInContext("Object.fromEntries(new Map([['form',4]]).entries()).form",ctx),4);
 assert.equal(vm.runInContext("Object.getPrototypeOf(Object.fromEntries([['__proto__',{polluted:true}]]))===Object.prototype",ctx),true);
});
test('novel startup shows parsing errors and keeps a visible recovery message',()=>{
 const {handlers,message,status,timers}=boot();
 handlers.error({message:'Unexpected token'});
 timers.forEach(fn=>fn());
 assert.match(message.textContent,/Unexpected token/);assert.equal(status.hidden,false);
});
test('novel startup readiness hides loading and prevents later timeout overwriting the game',()=>{
 const {ctx,status,timers,attributes,message}=boot();
 vm.runInContext('NOVEL_BOOT_READY()',ctx);timers.forEach(fn=>fn());
 assert.equal(status.hidden,true);assert.equal(attributes['data-game-ready'],'true');assert.equal(message.textContent,'');
});
