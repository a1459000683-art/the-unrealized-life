'use strict';
// Real authored-life witnesses. No state/price/condition mutation is permitted.
const fs=require('node:fs'),path=require('node:path'),vm=require('node:vm'),crypto=require('node:crypto'),assert=require('node:assert/strict');
const ROOT=path.resolve(__dirname,'..');
const hash=p=>crypto.createHash('sha256').update(fs.readFileSync(path.join(ROOT,p))).digest('hex');
const witness=JSON.parse(fs.readFileSync(path.join(__dirname,'novel-story-routes.json'),'utf8'));
const hashes=Object.fromEntries(['src/novel-story.js','src/novel.js','src/game.js','src/finance.js','data/market.json'].map(p=>[p,hash(p)]));
assert.equal(hashes['src/novel-story.js'],witness.storySha256,'Witness content hash changed; review and regenerate intentionally');
const ctx=vm.createContext({console,MARKET:JSON.parse(fs.readFileSync(path.join(ROOT,'data/market.json'),'utf8'))});
for(const file of ['finance','story','game','novel-story','novel'])vm.runInContext(fs.readFileSync(path.join(ROOT,'src',file+'.js'),'utf8'),ctx,{filename:file+'.js'});
ctx.STORY={characters:ctx.STORY.characters,events:[],endings:[]};
assert.equal(ctx.Novel.validateContent().ok,true);
let checks=0;const ok=(x,message)=>{assert.ok(x,message);checks++;};const report={schemaVersion:1,createdAt:new Date().toISOString(),method:'Public Novel constructor -> choose(revision-bound token) -> next only. No final-state injection; historical Finance/Game engines unmodified.',hashes,routes:[],coverage:{}};
const nodeMap=Object.fromEntries(ctx.NOVEL_STORY.nodes.map(n=>[n.id,n])),seen=new Set(),endings=new Set(),choicesSeen=new Set();
const output=path.join(ROOT,'output/qa/novel-story-reachability.json');fs.mkdirSync(path.dirname(output),{recursive:true});
for(const route of witness.routes){
 const n=new ctx.Novel(route.start,route.seed);let priorDate='',transactions=[],earned=[],timelines=[];
 for(const step of route.steps){
  const v=n.view();ok(v.phase==='choice',route.id+' expects choice phase');ok(v.date>=priorDate,'monotonic date');priorDate=v.date;
  ok(v.node.id===step.nodeId,route.id+' expected node '+step.nodeId+' got '+v.node.id);ok(v.node.dateIndex===step.dateIndex&&v.node.slot===step.slot,'group/date match');
  const ch=v.node.choices.find(c=>c.choiceId===step.choiceId);ok(ch?.available,'authored choice is actually available');
  const r=n.choose(ch.id);ok(r.ok,route.id+' '+step.nodeId+': '+r.error);ok(r.result.fromDate===v.date,'result preserves decision date');
  for(const flag of nodeMap[step.nodeId].choices.find(c=>c.id===step.choiceId).effects?.flags||[])earned.push({flag,nodeId:step.nodeId,choiceId:step.choiceId,date:v.date,dateIndex:step.dateIndex});
  timelines.push({date:v.date,nodeId:step.nodeId,health:n.core.state.stats.health,stress:n.core.state.stats.stress,career:n.core.state.career});
  transactions.push(...r.result.transactions.map(t=>({...t,afterNode:step.nodeId})));
  ok(n.next().ok,'result navigation succeeds');seen.add(step.nodeId);choicesSeen.add(step.nodeId+':'+step.choiceId);
 }
 const v=n.view(),s=n.core.state,a=n.audit();ok(v.phase==='ending','route reaches real ending');ok(v.ending.id===route.expectedEnding,'expected ending');ok(n.state.choiceCount===route.expectedChoiceCount,'choice count');ok(v.age===44,'age44');
 ok(Math.abs(a.clientStats.reconciliationError)<.01,'client account conservation');ok(Math.abs(a.personalStats.reconciliationError)<.01,'personal account conservation');
 const save=n.exportSave();ok(ctx.Novel.validateSave(save).ok,'final save valid');const resumed=ctx.Novel.fromSave(save);ok(resumed.view().ending.id===v.ending.id,'roundtrip preserves ending');ok(resumed.exportSave()===save,'roundtrip does not duplicate settlement');
 endings.add(v.ending.id);
 report.routes.push({id:route.id,start:route.start,seed:route.seed,ending:v.ending.id,title:v.ending.title,date:v.date,age:v.age,choiceCount:n.state.choiceCount,metrics:{wealth:s.personal.lastNav-s.debt,personalTwr:s.personal.twrFactor-1,clientTwr:s.client.twrFactor-1,health:s.stats.health,stress:s.stats.stress,freedom:s.stats.freedom,trust:s.stats.trust,career:s.career,relations:s.relations},flags:s.flags,earned,timelines,transactions,reconciliation:{client:a.clientStats.reconciliationError,personal:a.personalStats.reconciliationError},saveRoundtrip:true});
 report.checks=checks;fs.writeFileSync(output,JSON.stringify(report,null,2)+'\n');console.log(route.id+' -> '+v.ending.id+' ('+n.state.choiceCount+' choices)');
}
const variants=ctx.NOVEL_STORY.nodes.filter(n=>n.requires&&Object.keys(n.requires).length);const chainWitnesses=ctx.NOVEL_STORY.chains.map(chain=>{
 const witness=report.routes.find(r=>chain.flags.every(f=>r.flags.includes(f)));ok(!!witness,'complete causal chain '+chain.id);
 const events=chain.flags.map(flag=>witness.earned.find(e=>e.flag===flag));ok(events.every(Boolean),'every flag earned through a recorded authored choice');
 const first=events.map(e=>e.date).sort()[0],last=events.map(e=>e.date).sort().at(-1),years=(Date.parse(last)-Date.parse(first))/864e5/365.25;ok(years>=2,'chain spans >=2 years');
 const stages=[...new Set(events.map(e=>e.dateIndex<=15?'2000–2006':e.dateIndex<=30?'2007–2013':'2014–2020'))];
 return{id:chain.id,title:chain.title,routeId:witness.id,years,stages,events};
});
report.coverage={totalNodes:ctx.NOVEL_STORY.nodes.length,visitedNodes:seen.size,missingNodes:ctx.NOVEL_STORY.nodes.filter(n=>!seen.has(n.id)).map(n=>n.id),totalVariants:variants.length,visitedVariants:variants.filter(n=>seen.has(n.id)).length,totalEndings:ctx.NOVEL_STORY.endings.length,reachedEndings:endings.size,endingIds:[...endings],totalChoices:ctx.NOVEL_STORY.nodes.reduce((s,n)=>s+n.choices.length,0),visitedChoices:choicesSeen.size,totalRoutes:report.routes.length,totalDecisions:report.routes.reduce((s,r)=>s+r.choiceCount,0),chains:chainWitnesses,crossStageChains:chainWitnesses.filter(c=>c.stages.length>=2).length};
ok(seen.size===100,'all100 nodes reached');ok(endings.size===10,'all10 endings reached');ok(report.coverage.visitedVariants===23,'all23 variants reached');ok(report.coverage.crossStageChains>=6,'at least6 cross-stage chains');
report.checks=checks;report.status='passed';fs.writeFileSync(output,JSON.stringify(report,null,2)+'\n');console.log(JSON.stringify({status:report.status,checks,coverage:{...report.coverage,chains:report.coverage.chains.map(c=>({id:c.id,routeId:c.routeId,years:c.years,stages:c.stages}))}},null,2));
