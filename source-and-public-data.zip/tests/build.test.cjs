const test=require('node:test'),assert=require('node:assert/strict'),fs=require('node:fs'),vm=require('node:vm'),path=require('node:path');
const html=fs.readFileSync(path.resolve(__dirname,'../index.html'),'utf8');
test('standalone HTML has one complete syntactically valid inline game script',()=>{
 const scripts=[...html.matchAll(/<script\b[^>]*>([\s\S]*?)<\/script\s*>/gi)];
 assert.equal(scripts.length,1);assert.equal((html.match(/<\/script\s*>/gi)||[]).length,1);
 assert.doesNotThrow(()=>new vm.Script(scripts[0][1],{filename:'built-index-inline.js'}));
 assert.match(scripts[0][1],/\$'\+forfeited/); // literal dollar-plus-quote survives replacement.
});
test('standalone build contains Chinese game and no external runtime resources',()=>{
 assert.match(html,/<title>未实现的人生/);assert.match(html,/二十四岁，入职的早晨/);
 assert.doesNotMatch(html,/<script[^>]+src=/i);
 const links=[...html.matchAll(/<link\b[^>]*>/gi)];for(const [tag]of links){const href=/\bhref=["']([^"']*)/i.exec(tag)?.[1];assert.ok(!href||href.startsWith('data:'),`external runtime link: ${href}`);}
 assert.doesNotMatch(html,/@import\s|@font-face\s*\{/i);
});
