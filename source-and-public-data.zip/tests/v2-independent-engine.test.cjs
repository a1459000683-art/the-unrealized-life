'use strict';
// RC1 independent QA. Uses the actual authored story and fixed historical
// market. Every career below uses exposed choice tokens only; no state writes,
// injected holdings, synthetic scenes, price look-ahead or skipped dates.
const test=require('node:test'),assert=require('node:assert/strict');
const fs=require('node:fs'),path=require('node:path'),vm=require('node:vm'),crypto=require('node:crypto');
const ROOT=path.resolve(__dirname,'..');
const sources=Object.fromEntries(['finance','game','novel-story','novel'].map(f=>[f,fs.readFileSync(path.join(ROOT,'src',f+'.js'),'utf8')]));
const rawMarket=fs.readFileSync(path.join(ROOT,'data/market.json'),'utf8');
const hash=s=>crypto.createHash('sha256').update(s).digest('hex');
const baseHashes={...Object.fromEntries(Object.entries(sources).map(([k,v])=>[k,hash(v)])),market:hash(rawMarket)};
const reports=[];
function runtime(){const ctx=vm.createContext({console,MARKET:JSON.parse(rawMarket)});vm.runInContext(sources['novel-story'],ctx);ctx.STORY={characters:ctx.NOVEL_STORY.characters,events:[],endings:[]};for(const f of ['finance','game','novel'])vm.runInContext(sources[f],ctx,{filename:f+'.js'});return ctx;}
const close=(a,b,msg)=>assert.ok(Math.abs(a-b)<=1e-6,`${msg}: ${a} != ${b}`);
const copy=x=>JSON.parse(JSON.stringify(x));
// This independent book does not call Finance.stats or Finance.validateAccount.
// It derives cash, shares, average cost and realized P/L from actual rows.
function reconcile(account,market,which){
 let cash=0,dividends=0,fees=0,realized=0;const positions={},seen=new Set();
 for(const row of account.ledger){
  const p=row.companyId?(positions[row.companyId]||=( {quantity:0,cost:0,realized:0,dividends:0} )):null;
  assert.equal(typeof row.amount,'number');assert.ok(Number.isFinite(row.amount));
  cash+=row.amount;close(cash,row.cashAfter,which+' cash after '+row.seq);
  if(row.type==='buy'||row.type==='sell'){
   const company=market.companies.find(c=>c.id===row.companyId),quote=company.prices.find(q=>q.date===row.date);
   assert.ok(quote,'trade requires an exact historical quote');close(row.price,quote.close,'historical price');
   close(row.gross,row.quantity*quote.close,'trade gross');close(row.fee,row.gross*.001,'trade fee');fees+=row.fee;
   if(row.type==='buy'){p.quantity+=row.quantity;p.cost-=row.amount;close(row.amount,-row.gross-row.fee,'buy cash');}
   else{const removed=p.cost*row.quantity/p.quantity;close(row.costRemoved,removed,'proportional removed cost');p.cost-=removed;p.quantity-=row.quantity;realized+=row.amount-removed;p.realized+=row.amount-removed;close(row.amount,row.gross-row.fee,'sell cash');}
  }else if(row.type==='split'){p.quantity*=row.ratio;assert.equal(row.amount,0);}
  else if(row.type==='dividend'){close(row.amount,p.quantity*row.perShare,'cash dividend');dividends+=row.amount;p.dividends+=row.amount;}
  else if(row.type==='cancel'||row.type==='cash_merger'){close(row.amount,row.type==='cancel'?0:p.quantity*row.perShare,'retired identity settlement');realized+=row.amount-p.cost;p.realized+=row.amount-p.cost;p.quantity=0;p.cost=0;}
  else if(row.type==='expense'){assert.ok(row.amount<=0,'expense must remove money');fees-=row.amount;}
  else assert.equal(row.type,'external_flow','known ledger row');
  if(row.actionId){assert.equal(seen.has(row.actionId),false,'company action must occur only once per account');seen.add(row.actionId);}
 }
 close(cash,account.cash,which+' final cash');close(dividends,account.totals.dividends,which+' dividends');close(fees,account.totals.fees,which+' fees');close(realized,account.totals.realized,which+' realized');
 for(const[id,p]of Object.entries(account.positions)){const expected=positions[id];assert.ok(expected);for(const k of ['quantity','cost','realized','dividends'])close(p[k],expected[k],which+' '+id+' '+k);}
 let nav=cash;for(const[id,p]of Object.entries(account.positions))nav+=p.quantity*account.prices[id];close(nav,account.lastNav,which+' NAV from marked shares');
}
for(const[start,seed]of [['debt',613],['buffer',871],['network',1001]])test('RC1 natural '+start+' route: independent accounting, duplicate replay, restoration and frozen ending',()=>{
 const ctx=runtime(),originalMarket=JSON.stringify(ctx.MARKET);let n=new ctx.Novel(start,seed),rng=seed,restores=0,blocked=0;const steps=[],bought=new Set();
 const random=()=>((rng=(Math.imul(rng,1664525)+1013904223)>>>0)/4294967296);
 while(n.state.phase!=='ending'){
  const v=n.view(),available=v.node.choices.filter(c=>c.available);assert.ok(available.length,'at least one legal authored choice');
  const selected=available[Math.floor(random()*available.length)],before=n.exportSave();
  for(const input of [-1,NaN,Infinity,Number.MAX_VALUE,0.0000000000000000001,null,{},'a',v.node.choices[0].id+'/expired']){assert.equal(n.choose(input).ok,false);assert.equal(n.exportSave(),before);blocked++;}
  const result=n.choose(selected.id,v.node.id,v.revision);assert.equal(result.ok,true,result.error);const settled=n.exportSave();
  for(let i=0;i<3;i++){assert.equal(n.choose(selected.id).ok,false);assert.equal(n.exportSave(),settled);blocked++;}
  for(const which of ['client','personal']){reconcile(n.core.state[which],ctx.MARKET,which);for(const row of n.core.state[which].ledger)if(row.type==='buy')bought.add(row.companyId);}
  close(n.core.state.firm.cash,n.core.state.firm.ledger.reduce((v,r)=>v+r.amount,0),'firm cash');close(n.core.state.debt,n.core.state.debtLedger.reduce((v,r)=>v+r.amount,0),'debt principal');
  steps.push({nodeId:v.node.id,choiceId:selected.choiceId,label:selected.label,date:v.date,settledDate:n.core.state.date});
  if(steps.length%11===0||result.result.terminal){assert.equal(ctx.Novel.validateSave(settled).ok,true);const other=ctx.Novel.fromSave(settled);assert.equal(other.exportSave(),settled);n=other;restores++;}
  const money=JSON.stringify([n.core.state.client,n.core.state.personal,n.core.state.firm,n.core.state.debt]);assert.equal(n.next().ok,true);assert.equal(JSON.stringify([n.core.state.client,n.core.state.personal,n.core.state.firm,n.core.state.debt]),money,'navigation cannot settle');
  const moved=n.exportSave();assert.equal(n.next().ok,false);assert.equal(n.choose(selected.id).ok,false);assert.equal(n.exportSave(),moved);blocked+=2;
  assert.ok(steps.length<=85);assert.equal(JSON.stringify(ctx.MARKET),originalMarket,'market cannot depend on player activity');
 }
 assert.equal(n.state.ending.kind,'life');assert.equal(n.core.state.date,'2020-12-31');assert.equal(steps.length,77);assert.equal(n.core.state.review.length,52);
 assert.equal(ctx.Novel.validateSave(n.exportSave()).ok,true);const frozen=n.exportSave();for(let i=0;i<10;i++){assert.equal(n.next().ok,false);assert.equal(n.choose('anything').ok,false);assert.equal(n.exportSave(),frozen);}
 const restored=ctx.Novel.fromSave(frozen);assert.equal(restored.exportSave(),frozen);assert.equal(restored.choose('anything').ok,false);
 const report={start,seed,steps:steps.length,ending:n.state.ending.id,date:n.core.state.date,restores,blocked,bought:[...bought],clientNav:n.core.state.client.lastNav,personalNetWorth:n.core.state.personal.lastNav-n.core.state.debt,path:steps};reports.push(report);console.log('RC1_NATURAL_ROUTE '+JSON.stringify({...report,path:undefined}));
});
test('RC1 imported files reject non-finite, negative, excessive and inconsistent money before changing the live game',()=>{
 const ctx=runtime(),n=new ctx.Novel('buffer',987),saved=n.exportSave();
 for(const[account,key,value]of [['personal','cash',-1],['client','cash',NaN],['client','cash',Infinity],['personal','cash',1e16],['client','lastNav',1e14],['personal','twrFactor',-1]]){const bad=JSON.parse(saved);bad.core.state[account][key]=value;assert.equal(ctx.Novel.validateSave(bad).ok,false,account+'.'+key+'='+value);assert.throws(()=>ctx.Novel.fromSave(bad));assert.equal(n.exportSave(),saved);}
 for(const value of [NaN,Infinity,-1,1e13]){const bad=JSON.parse(saved);bad.core.state.debt=value;assert.equal(ctx.Novel.validateSave(bad).ok,false);}
});
test('RC1 result imports require an explicit null or valid ending, so the next page remains saveable',()=>{
 const ctx=runtime(),n=new ctx.Novel('buffer',123),v=n.view();assert.equal(n.choose(v.node.choices.find(c=>c.available).id).ok,true);
 const saved=n.exportSave();assert.equal(JSON.parse(saved).state.pendingEnding,null);assert.equal(ctx.Novel.validateSave(saved).ok,true);
 for(const value of [undefined,false,0,'',[],{},'ordinary_days']){
  const bad=JSON.parse(saved);if(value===undefined)delete bad.state.pendingEnding;else bad.state.pendingEnding=value;
  assert.equal(ctx.Novel.validateSave(JSON.stringify(bad)).ok,false,'reject pendingEnding '+String(value));
  assert.throws(()=>ctx.Novel.fromSave(JSON.stringify(bad)));assert.equal(n.exportSave(),saved);
 }
 const restored=ctx.Novel.fromSave(saved);assert.equal(restored.next().ok,true);assert.equal(ctx.Novel.validateSave(restored.exportSave()).ok,true);
 assert.equal(ctx.Novel.fromSave(restored.exportSave()).exportSave(),restored.exportSave());
});
test.after(()=>{const dir=path.join(ROOT,'output/qa');fs.mkdirSync(dir,{recursive:true});fs.writeFileSync(path.join(dir,'v2-independent-engine.json'),JSON.stringify({testedAt:new Date().toISOString(),baselineHtmlSha256:'dbed342ee82e3c42f3016b0cbb76c7f7ac8ff60fe8713d151d8b633cf77b9676',sourceHashes:baseHashes,method:'Actual authored choices with deterministic random selection; independent cash/share/cost/realized ledger; no direct state writes for natural routes. JSON corruption only in the separately named input rejection test.',routes:reports},null,2)+'\n');});
