'use strict';
// Wrapper-specific accounting and contract tests. The small story fixture is
// explicitly synthetic; market prices/actions are the checked production data.
// Authored narrative reachability is tested separately by the story/audit suite.
const test=require('node:test'),assert=require('node:assert/strict');
const fs=require('node:fs'),path=require('node:path'),vm=require('node:vm');
const ROOT=path.resolve(__dirname,'..');
const market=JSON.parse(fs.readFileSync(path.join(ROOT,'data/market.json'),'utf8'));
const copy=x=>JSON.parse(JSON.stringify(x));
const close=(a,b,tol=1e-8)=>assert.ok(Math.abs(a-b)<=tol*Math.max(1,Math.abs(b)),`${a} != ${b}`);
const people=['lin','mara','june','elias','mei','sam','nora','darius'].map(id=>({id,name:'人物 '+id,role:'当期角色'}));
function choice(id='wait',extra={}){return{id,label:'测试选择 '+id,detail:'独立测试的受控叙事，不能计入正式手写内容',effects:{},result:{title:'测试结果',text:'这只是验证引擎的结果。'},...extra};}
function fixture({start='buffer',slots=24,edit,first,realMarket=market}={}){
 const nodes=[];for(let i=0;i<realMarket.dates.length;i++)for(let slot=0;slot<1+(i<slots?1:0);slot++)nodes.push({id:`n${i}s${slot}`,dateIndex:i,slot,chapter:'check',title:'验证场景 '+i+' / '+slot,text:'验证完整财务路径，不替代正式剧情。',choices:[choice('wait',i===0&&slot===0?first:{}),choice('other')]});
 const story={version:1,characters:people,chapters:[{id:'check',title:'受控测试章节'}],nodes,endings:[{id:'ordinary',title:'测试人生走完',text:'完整日期已经结算。'}]};if(edit)edit(story);
 const ctx=vm.createContext({console,MARKET:copy(realMarket),STORY:{characters:people,events:[],endings:[]},NOVEL_STORY:story});
 for(const file of ['finance','game','novel'])vm.runInContext(fs.readFileSync(path.join(ROOT,'src',file+'.js'),'utf8'),ctx,{filename:file+'.js'});
 return{n:new ctx.Novel(start,2048),Novel:ctx.Novel,Game:ctx.Game,F:ctx.Finance,ctx,story};
}
function choose(n,id='wait'){const v=n.view(),ch=v.node.choices.find(x=>x.choiceId===id);assert.ok(ch,'choice exists');const r=n.choose(ch.id,v.node.id,v.revision);assert.equal(r.ok,true,r.error);return r.result;}
function next(n){const r=n.next();assert.equal(r.ok,true,r.error);}
const investments={effects:{researchCompany:[{companyId:'HEI',topic:'cashflow'}]},strategy:{type:'invest',companyId:'HEI',targetPercent:100}};

test('Novel view is a detached light projection and keeps all three distinct starts',()=>{
 for(const [start,cash,debt]of [['debt',14000,65000],['buffer',90000,8000],['network',32000,8000]]){
  const {n}=fixture({start});n.core.view=()=>{throw Error('expensive Game.view called from narrative');};
  const v=n.view();assert.equal(v.age,24);assert.equal(v.date,'2000-01-03');assert.equal(v.summary.personalNav,cash);assert.equal(v.summary.debt,debt);assert.equal(v.summary.clientNav,1000000);
  v.summary.clientNav=0;v.node.choices[0].label='mutated';assert.equal(n.view().summary.clientNav,1000000);assert.notEqual(n.view().node.choices[0].label,'mutated');
 }
 const {ctx}=fixture();vm.runInContext(fs.readFileSync(path.join(ROOT,'src/story.js'),'utf8'),ctx);
 const withLegacyContent=new ctx.Novel();choose(withLegacyContent);next(withLegacyContent);choose(withLegacyContent);
 assert.equal(withLegacyContent.core.state.eventId,null);assert.equal(withLegacyContent.core.state.seen.length,0);assert.equal(ctx.Novel.validateSave(withLegacyContent.exportSave()).ok,true);
});
test('Novel actual historical purchase is researched, authorized, capped and fee-balanced',()=>{
 const {n,F}=fixture({first:investments}),personal=JSON.stringify(n.core.state.personal),before=n.core.state.client.cash;
 const result=choose(n),s=n.core.state,p=s.client.positions.HEI,price=market.companies.find(c=>c.id==='HEI').prices[0].close;
 assert.equal(s.approved.HEI,8);assert.equal(s.research.HEI[0],'cashflow');assert.ok(s.theses.HEI);assert.equal(s.actionPoints,2);
 close(p.quantity*price/s.client.lastNav,.08);close(before-s.client.cash,p.cost);close(p.cost,p.quantity*price*1.001);
 assert.equal(JSON.stringify(s.personal),personal);assert.ok(result.notices.some(t=>t.includes('申请目标 100%')&&t.includes('上限 8%')));
 assert.equal(result.transactions.find(t=>t.type==='buy').company,market.companies.find(c=>c.id==='HEI').alias);
 assert.equal(result.transactions.some(t=>t.company==='HEI'||t.companyId),false);close(F.stats(s.client,{},s.date).reconciliationError,0);
});
test('Novel refuses unresearched or blocked investments atomically',()=>{
 for(const {first,setup}of [{first:{effects:{personalCash:1000},strategy:investments.strategy}},
  {first:investments,setup:n=>n.core.state.restricted.push('HEI')},
  {first:investments,setup:n=>n.core._setCareer('unemployed')}]){
  const {n}=fixture({first});setup?.(n);const before=n.exportSave(),v=n.view(),r=n.choose(v.node.choices[0].id);assert.equal(r.ok,false);assert.equal(n.exportSave(),before);assert.equal(v.node.choices[0].available,false);
 }
});
test('Novel actual research time gates cross-sector same-day choices',()=>{
 const {n}=fixture({first:{effects:{researchCompany:[{companyId:'HEI',topic:'cashflow'}]}},edit:s=>{s.nodes[1].choices[0]=choice('wait',{effects:{researchCompany:[{companyId:'BRO',topic:'cashflow'},{companyId:'RHI',topic:'debt'}]}});}});
 choose(n);next(n);assert.equal(n.core.state.actionPoints,2);assert.equal(n.view().node.choices[0].available,false);assert.ok(n.view().node.choices[0].reason.includes('时间不足'));
 const saved=n.exportSave();assert.equal(n.choose(n.view().node.choices[0].id).ok,false);assert.equal(n.exportSave(),saved);
});
test('Novel period TWR excludes the redemption and personal cash grant',()=>{
 const {n}=fixture({slots:0,first:{effects:{personalCash:125000}}});n.core.state.redemptionDue=200000;
 const initial=n.core.state.client.lastNav,result=choose(n),years=(Date.parse(market.dates[1])-Date.parse(market.dates[0]))/864e5/365.25;
 close(result.performance.client.twr,-.01*years);close(result.performance.personal.twr,0);
 assert.ok(Math.abs((n.core.state.client.lastNav/initial-1)-result.performance.client.twr)>.19);
 assert.ok(result.notices.some(x=>x.includes('剔除客户申赎')));assert.ok(result.notices.some(x=>x.includes('不等于投资赚亏')));
});
test('Novel repaying principal changes cash and debt, not personal investment return or net worth',()=>{
 const {n}=fixture({start:'debt',first:{strategy:{type:'repay',targetPercent:50}}}),wealth=n.view().summary.personalNetWorth,cash=n.core.state.personal.cash,debt=n.core.state.debt;
 const result=choose(n);close(n.core.state.personal.cash,cash/2);close(n.core.state.debt,debt-cash/2);close(n.view().summary.personalNetWorth,wealth);close(result.performance.personal.twr,0);
});
test('Novel causal branch selection uses earned flags and relations without skipping its group',()=>{
 const {n}=fixture({first:{effects:{flags:['kept_word'],relations:{mei:12}}},edit:s=>s.nodes.push({...copy(s.nodes[1]),id:'remembered',priority:10,title:'多年承诺的分支',requires:{flagsAll:['kept_word'],min:{'relations.mei':50}}})});
 choose(n);next(n);assert.equal(n.view().node.id,'remembered');assert.equal(n.view().progress.groupIndex,1);assert.equal(n.view().date,'2000-01-03');
 const {n:other}=fixture({edit:s=>s.nodes.push({...copy(s.nodes[1]),id:'remembered',priority:10,requires:{flagsAll:['kept_word'],min:{'relations.mei':50}}})});choose(other);next(other);assert.equal(other.view().node.id,'n0s1');
});
test('Novel unemployment continues the calendar, living costs and eventual rehire',()=>{
 const {n,Novel}=fixture({slots:0,first:{effects:{career:'unemployed'}},edit:s=>{s.nodes[1].choices[0]=choice('wait',{effects:{career:'senior',flags:['rebuilt']}});}});
 choose(n);assert.equal(n.core.state.salaryTotal,0);assert.ok(n.core.state.livingTotal>0);assert.ok(n.core.state.unemployedMonths>0);assert.equal(n.core.state.date,market.dates[1]);next(n);
 choose(n);assert.ok(n.core.state.salaryTotal>0);assert.equal(n.core.state.career,'senior');assert.equal(Novel.validateSave(n.exportSave()).ok,true);
});
test('Novel result validation rejects altered prose, amounts, performance and unknown condition keys',()=>{
 const {n,Novel,story}=fixture();choose(n);
 for(const mutate of [r=>r.state.result.text='伪造结果',r=>r.state.result.changes=[{label:'值',before:1,after:2,delta:2}],r=>r.state.result.performance.client.twr='100',r=>r.state.result.transactions=[{type:'sell',account:'personal',date:'1999-01-01',company:null}],r=>r.core.state.sector='financial']){const raw=JSON.parse(n.exportSave());mutate(raw);assert.equal(Novel.validateSave(raw).ok,false);}
 const broken=copy(story);broken.nodes[0].requires={min:{unkownWealth:1}};assert.equal(Novel.validateContent(broken).ok,false);
});
test('Novel automatic final selection cannot infer death from health or old pressure flags',()=>{
 const {n,Novel}=fixture({first:{effects:{health:-80,stress:80,flags:['old_pressure']}},edit:s=>{s.nodes=[s.nodes[0]];s.endings.unshift({id:'quiet_terminal',kind:'death',priority:100,title:'只准显式触发',text:'不得由低健康推断。',requires:{flagsAll:['old_pressure']}});}});
 choose(n);next(n);assert.equal(n.core.state.date,'2020-12-31');assert.equal(n.core.state.stats.health,0);assert.equal(n.view().ending.id,'ordinary');assert.equal(Novel.validateSave(n.exportSave()).ok,true);
});
for(const start of ['debt','buffer','network'])test('Novel real history '+start+': 77 choices, 53 dates, splits/distributions and three-account reconciliation',()=>{
 const {n:initial,Novel,F}=fixture({start,first:investments});let n=initial,buyQuantity;
 while(n.view().phase!=='ending'){
  const result=choose(n);if(n.state.choiceCount===1)buyQuantity=n.core.state.client.positions.HEI.quantity;
  const count=n.state.choiceCount;if(count%17===0){const valid=Novel.validateSave(n.exportSave());assert.equal(valid.ok,true,valid.error);n=Novel.fromSave(n.exportSave());}
  const settled=JSON.stringify({client:n.core.state.client,personal:n.core.state.personal,firm:n.core.state.firm});next(n);assert.equal(JSON.stringify({client:n.core.state.client,personal:n.core.state.personal,firm:n.core.state.firm}),settled);
  assert.ok(n.state.choiceCount<=77);assert.ok(result.notices.every(x=>typeof x==='string'));
 }
 const s=n.core.state,hei=market.companies.find(c=>c.id==='HEI'),ratio=hei.actions.filter(a=>a.type==='split'&&a.date>market.dates[0]&&a.date<=s.date).reduce((x,a)=>x*a.ratio,1);
 assert.equal(n.state.choiceCount,77);assert.equal(s.stage,52);assert.equal(s.date,'2020-12-31');assert.equal(s.age,44);assert.equal(s.review.length,52);close(s.client.positions.HEI.quantity,buyQuantity*ratio);assert.ok(s.client.positions.HEI.dividends>0);
 for(const which of ['client','personal']){assert.equal(F.validateAccount(s[which],s.date).ok,true);const st=F.stats(s[which],{},s.date);close(st.reconciliationError,0);assert.ok(Number.isFinite(st.twr));const ids=s[which].ledger.filter(x=>x.actionId).map(x=>x.actionId);assert.equal(new Set(ids).size,ids.length);}
 close(s.firm.cash,s.firm.ledger.reduce((x,r)=>x+r.amount,0));assert.ok(s.salaryTotal>0);assert.equal(Novel.validateSave(n.exportSave()).ok,true);assert.equal(n.view().ending.reveal.length,market.companies.filter(c=>!c.listed||c.listed<=s.date).length);assert.ok(n.view().ending.reveal.length>=16);
 const frozen=n.exportSave();assert.equal(n.choose('wait').ok,false);assert.equal(n.next().ok,false);assert.equal(n.exportSave(),frozen);
});
