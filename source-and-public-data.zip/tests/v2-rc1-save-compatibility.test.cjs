'use strict';
// Generate genuine RC1 saves through authored choices, then restore them with
// the current engine. No injected flags/careers or dependency on Git at runtime.
const test = require('node:test');
const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');
const vm = require('node:vm');
const crypto = require('node:crypto');
const zlib = require('node:zlib');
const ROOT = path.resolve(__dirname, '..');
const read = p => fs.readFileSync(path.join(ROOT, p), 'utf8');
const hash = s => crypto.createHash('sha256').update(s).digest('hex');
const fixtureBytes = fs.readFileSync(path.join(__dirname, 'fixtures/v2-rc1-sources.json.gz'));
const fixture = JSON.parse(zlib.gunzipSync(fixtureBytes));
const rc2Bytes = fs.readFileSync(path.join(__dirname, 'fixtures/v2-rc2-sources.json.gz'));
const rc2Fixture = JSON.parse(zlib.gunzipSync(rc2Bytes));
const RC1 = 'c93fc2d0ad44223e1a1272197016cd4fb9def789';
const SOURCE_HASHES = {
  'src/novel.js': '9ddddade7068af8979d0aa441ff0a26248b184c2cece851109f37da7c2163952',
  'src/novel-story.js': 'bed93448358fac189591484ff22d4319d4c4b4f828854d6959e9671488ac07b1'
};
const marketRaw = read('data/market.json');
const currentSources = Object.fromEntries(['finance', 'game', 'novel', 'novel-story']
  .map(name => [name, read('src/' + name + '.js')]));
function runtime(old) {
  const baseline = old === 'rc2' ? rc2Fixture : fixture;
  const ctx = vm.createContext({console, MARKET: JSON.parse(marketRaw)});
  vm.runInContext(old ? baseline.files['src/novel-story.js'].source : currentSources['novel-story'], ctx);
  ctx.STORY = {characters: ctx.NOVEL_STORY.characters, events: [], endings: []};
  for (const name of ['finance', 'game', 'novel']) {
    const source = old && name === 'novel' ? baseline.files['src/novel.js'].source : currentSources[name];
    vm.runInContext(source, ctx, {filename: (old ? 'rc1/' : 'current/') + name + '.js'});
  }
  return ctx;
}
const old = runtime(true), rc2 = runtime('rc2'), current = runtime(false);
const copy = x => JSON.parse(JSON.stringify(x));
const textRules = current.NOVEL_STORY.saveCompatibility.resultText;
const textSaves = new Map(), branchSaves = new Map();
const ruleKey = r => r.nodeId + '/' + r.choiceId + '/' + hash(r.from);
const coverage = {choice: 0, result: 0, ending: 0, immediateNext: 0};
function sameRealmObject(raw) {
  current.__compatRaw = raw;
  try { return vm.runInContext('JSON.parse(__compatRaw)', current); }
  finally { delete current.__compatRaw; }
}
function expectedDestination(id, career) {
  if (id === 'n24_0' && ['outside', 'unemployed'].includes(career)) return 'v24_external';
  if (id === 'n32_0' && career === 'independent') return 'v32_independent';
  if (id === 'n32_0' && ['outside', 'unemployed'].includes(career)) return 'v32_external';
  return id;
}
function expectedState(save) {
  const s = copy(save.state);
  if (s.phase === 'result') {
    const rule = textRules.find(r => r.nodeId === s.nodeId && r.choiceId === s.result.choiceId && r.from === s.result.text);
    if (rule) s.result.text = rule.to;
  }
  if (s.phase === 'choice' || s.phase === 'result' && s.pendingEnding === null) {
    const key = s.phase === 'choice' ? 'nodeId' : 'nextNodeId';
    const destination = expectedDestination(s[key], save.core.state.career);
    if (destination !== s[key]) {
      s[key] = destination;
      if (s.choiceLog.length) s.choiceLog.at(-1).nextNodeId = destination;
    }
  }
  for (const key of ['pendingEnding', 'ending']) {
    if (!s[key]) continue;
    const rule = current.NOVEL_STORY.saveCompatibility.endingText.find(r => r.endingId === s[key].id && r.from === s[key].text);
    if (rule) s[key].text = rule.to;
  }
  return s;
}
function immediatelyRestorable(novel, label) {
  const exported = novel.exportSave();
  const checked = current.Novel.validateSave(exported);
  assert.equal(checked.ok, true, label + ': ' + checked.error);
  assert.equal(current.Novel.fromSave(exported).exportSave(), exported, label + ': idempotent immediate restore');
  return exported;
}
function restoreNatural(raw, label, baseline = old) {
  const before = JSON.parse(raw), coreBytes = JSON.stringify(before.core), wanted = expectedState(before);
  assert.equal(baseline.Novel.validateSave(raw).ok, true, label + ': save was genuinely accepted by RC1');
  const caller = sameRealmObject(raw), callerBytes = JSON.stringify(caller);
  const validation = current.Novel.validateSave(caller);
  assert.equal(validation.ok, true, label + ': object boundary: ' + validation.error);
  assert.equal(JSON.stringify(caller), callerBytes, label + ': validate must not rewrite caller object');
  const objectLoaded = current.Novel.fromSave(caller);
  assert.equal(JSON.stringify(caller), callerBytes, label + ': restore must not rewrite caller object');
  const loaded = current.Novel.fromSave(raw);
  assert.equal(objectLoaded.exportSave(), loaded.exportSave(), label + ': string/object boundaries agree');
  assert.equal(JSON.stringify(JSON.parse(loaded.exportSave()).core), coreBytes, label + ': financial core bytes unchanged');
  assert.equal(JSON.stringify(loaded.state), JSON.stringify(wanted), label + ': only explicit prose/destination normalization');
  immediatelyRestorable(loaded, label + ' immediately after import');
  coverage[before.state.phase]++;
  if (before.state.phase === 'result') {
    const rule = textRules.find(r => r.nodeId === before.state.nodeId && r.choiceId === before.state.result.choiceId && r.from === before.state.result.text);
    if (rule) textSaves.set(ruleKey(rule), raw);
    assert.equal(loaded.next().ok, true, label + ': next is usable after restore');
    // This check deliberately occurs before any choose() can repair a field.
    immediatelyRestorable(loaded, label + ' immediately after next');
    coverage.immediateNext++;
  }
  const s = before.state, sceneId = s.phase === 'choice' ? s.nodeId : s.phase === 'result' ? s.nextNodeId : null;
  if (sceneId && expectedDestination(sceneId, before.core.state.career) !== sceneId) {
    branchSaves.set(sceneId + '/' + before.core.state.career + '/' + s.phase, raw);
  }
}
function naturalRoute(name, plan, stopAfter, baseline = old) {
  const novel = new baseline.Novel('buffer', 2000);
  let steps = 0;
  while (novel.state.phase !== 'ending') {
    const v = novel.view();
    restoreNatural(novel.exportSave(), name + ' choice ' + v.node.id, baseline);
    const wanted = plan[v.node.id] || 'c';
    const choice = v.node.choices.find(c => c.choiceId === wanted && c.available);
    assert.ok(choice, name + ': exact natural option ' + v.node.id + '/' + wanted + ' is available');
    const result = novel.choose(choice.id, v.node.id, v.revision);
    assert.equal(result.ok, true, name + ': ' + result.error);
    restoreNatural(novel.exportSave(), name + ' result ' + v.node.id + '/' + wanted, baseline);
    assert.ok(++steps <= 77, name + ': no skipped or repeated scene groups');
    if (v.node.id === stopAfter) return {steps, stoppedAt: v.node.id};
    assert.equal(novel.next().ok, true, name + ': RC1 next succeeds');
  }
  restoreNatural(novel.exportSave(), name + ' ending', baseline);
  assert.equal(steps, 77, name + ': all natural choices completed');
  assert.equal(novel.core.state.date, '2020-12-31');
  return {steps, ending: novel.state.ending.id};
}

test('the compressed real RC1 and RC2 source fixtures are pinned and self-contained', () => {
  assert.equal(fixture.format, 'unrealized-life-rc1-source-fixture');
  assert.equal(fixture.version, 1);
  assert.equal(fixture.revision, RC1);
  assert.equal(hash(fixtureBytes), 'da9ca8cbe300f5887baaeac5e8ba579c9bdc049f2c0f18f0fd3a01a4f58369cc');
  assert.deepEqual(Object.keys(fixture.files).sort(), Object.keys(SOURCE_HASHES).sort());
  for (const [file, expected] of Object.entries(SOURCE_HASHES)) {
    assert.equal(fixture.files[file].sha256, expected);
    assert.equal(hash(fixture.files[file].source), expected, file);
  }
  // These two reused engines are byte-identical to c93fc2d. A future engine
  // change must preserve the old sources in the fixture before changing these
  // assertions, so the claimed RC1 generator cannot silently become a hybrid.
  assert.equal(hash(currentSources.finance), '6f0956adff1d68cd3ec596a782fecb486e6c9a76c113ba934ab98e7da40a0c17', 'finance.js is the original RC1 engine');
  assert.equal(hash(currentSources.game), 'f3f14d6333c53a35a857511fa654e9748fd014fd183f9b62bb7800597e4d03be', 'game.js is the original RC1 engine');
  assert.equal(rc2Fixture.format, 'unrealized-life-rc2-source-fixture');
  assert.equal(rc2Fixture.version, 1);
  assert.equal(hash(rc2Bytes), '665ca0a4b436def119cc82162638fffca281189eb0ae3497c88e86c36aaae227');
  const rc2Hashes = {...SOURCE_HASHES, 'src/novel-story.js': '97c17bee50beea0154fd1a2ffe6d6297e9e7c3d6a8c96ebb28718352d157d8c1'};
  assert.deepEqual(Object.keys(rc2Fixture.files).sort(), Object.keys(rc2Hashes).sort());
  for (const [file, expected] of Object.entries(rc2Hashes)) {
    assert.equal(rc2Fixture.files[file].sha256, expected);
    assert.equal(hash(rc2Fixture.files[file].source), expected, file + ': actual RC2 source');
  }
  assert.equal(textRules.length, 16, 'exactly the reviewed legacy result texts from RC1 and RC2');
  assert.equal(new Set(Array.from(textRules, ruleKey)).size, 16, 'no ambiguous duplicate source texts');
  for (const rule of textRules) {
    const actual = [old, rc2].map(ctx => ctx.NOVEL_STORY.nodes.find(n => n.id === rule.nodeId).choices.find(c => c.id === rule.choiceId).result.text);
    assert.ok(actual.includes(rule.from), rule.nodeId + '/' + rule.choiceId + ': from is actual archived prose');
    const target = current.NOVEL_STORY.nodes.find(n => n.id === rule.nodeId).choices.find(c => c.id === rule.choiceId);
    assert.equal(rule.to, target.result.text, 'exact current destination prose');
  }
});

test('complete natural RC1 route: seven revised result texts survive both save phases', t => {
  t.diagnostic(JSON.stringify(naturalRoute('seven-prose', {
    n28_1:'b', n30_0:'b', n35_1:'a', n39_1:'a', n51_0:'a'
  })));
});

test('complete natural RC1 route: promise/postponement texts and outside scene destinations survive', t => {
  t.diagnostic(JSON.stringify(naturalRoute('promise-postponement', {
    n02_1:'a', n14_0:'a', v27:'a', v28:'b'
  })));
});

test('natural RC1 unemployment survives through both new career-specific destinations', t => {
  t.diagnostic(JSON.stringify(naturalRoute('unemployed', {
    n20_1:'a', n24_0:'c', n28_1:'a', n32_0:'c'
  }, 'n32_0')));
});

test('natural RC1 independent career reaches the new 2014 scene destination', t => {
  t.diagnostic(JSON.stringify(naturalRoute('independent', {
    n14_0:'a', v28:'a', v31:'a', n32_0:'c'
  }, 'n32_0')));
});

test('complete natural RC1 route: prior repayment and zero-sale result corrections survive', t => {
  t.diagnostic(JSON.stringify(naturalRoute('repayment-and-zero-sale', {
    n00_1:'b', n02_0:'b', n11_1:'b', n38_0:'b', n43_0:'b'
  })));
});

test('natural RC2 route: intervening unemployment prose survives without a generic text allowance', t => {
  t.diagnostic(JSON.stringify(naturalRoute('rc2-intervening-prose', {
    n14_0:'a', v28:'b'
  }, 'v28', rc2)));
});

test('all sixteen exact old texts and every career/phase mapping were reached naturally', t => {
  assert.deepEqual([...textSaves.keys()].sort(), Array.from(textRules, ruleKey).sort());
  const expected = [];
  for (const [scene, careers] of [['n24_0', ['outside','unemployed']], ['n32_0', ['outside','unemployed','independent']]]) {
    for (const career of careers) for (const phase of ['choice','result']) expected.push(scene + '/' + career + '/' + phase);
  }
  assert.deepEqual([...branchSaves.keys()].sort(), expected.sort());
  for (const [key, raw] of branchSaves) {
    const loaded = current.Novel.fromSave(raw);
    if (loaded.state.phase === 'result') {
      assert.equal(loaded.next().ok, true);
      immediatelyRestorable(loaded, key + ': destination after next');
    }
    const v = loaded.view();
    assert.equal(v.node.id, expectedDestination(key.split('/')[0], loaded.core.state.career));
    const choices = v.node.choices.filter(c => c.available);
    assert.ok(choices.length, key + ': migrated scene has usable choices');
    for (const choice of choices) {
      const probe = current.Novel.fromSave(loaded.exportSave());
      const before = probe.core.state.career;
      const result = probe.choose(choice.id, v.node.id, v.revision);
      assert.equal(result.ok, true, key + '/' + choice.choiceId + ': ' + result.error);
      immediatelyRestorable(probe, key + '/' + choice.choiceId + ' immediately after choose');
      if (key.includes('/independent/')) assert.equal(probe.core.state.career, before, 'independent scene cannot implicitly restore employment');
    }
  }
  assert.equal(coverage.immediateNext, coverage.result);
  t.diagnostic(JSON.stringify({naturalSavePhases:coverage, oldResultTexts:textSaves.size, careerPhaseMappings:branchSaves.size}));
});

test('clones of natural saves reject non-whitelisted text and mismatched node/choice identities', () => {
  let rejected = 0;
  function reject(raw, label) {
    const caller = sameRealmObject(raw), before = JSON.stringify(caller);
    assert.equal(current.Novel.validateSave(raw).ok, false, label + ': string input must be rejected');
    assert.equal(current.Novel.validateSave(caller).ok, false, label + ': object input must be rejected');
    assert.throws(() => current.Novel.fromSave(raw), undefined, label + ': not loadable');
    assert.equal(JSON.stringify(caller), before, label + ': rejected caller not mutated');
    rejected++;
  }
  for (const rule of textRules) {
    const natural = textSaves.get(ruleKey(rule));
    assert.ok(natural, 'negative tests derive from a witnessed natural save');
    for (const change of [
      s => {s.state.result.text += '伪造附加结果';},
      s => {s.state.result.nodeId = 'n00_0';},
      s => {s.state.result.choiceId = s.state.result.choiceId === 'a' ? 'b' : 'a';}
    ]) {
      const corrupt = JSON.parse(natural); change(corrupt);
      reject(JSON.stringify(corrupt), rule.nodeId + '/' + rule.choiceId);
    }
    const other = textRules.find(r => r.nodeId !== rule.nodeId);
    const wrongScene = JSON.parse(natural); wrongScene.state.result.text = other.from;
    reject(JSON.stringify(wrongScene), rule.nodeId + ': another scene legacy prose');
  }
  assert.equal(rejected, 64, 'damaged saves are separate from natural-route coverage');
});

test('a natural RC1 loss ending preserves pending and completed phases with one exact ending-text correction', t => {
  const fixture = JSON.parse(read('tests/fixtures/v2-drawdown-natural-route.json'));
  assert.equal(fixture.sourceStorySha256, '97c17bee50beea0154fd1a2ffe6d6297e9e7c3d6a8c96ebb28718352d157d8c1');
  const rules = current.NOVEL_STORY.saveCompatibility.endingText;
  assert.equal(rules.length, 1);
  const rule = rules[0];
  assert.equal(rule.endingId, 'drawdown_years');
  assert.equal(rule.from, old.NOVEL_STORY.endings.find(e => e.id === rule.endingId).text);
  assert.equal(rule.to, current.NOVEL_STORY.endings.find(e => e.id === rule.endingId).text);
  const route = fixture.route, n = new old.Novel(route.start, route.seed);
  let count = 0;
  for (const step of route.steps) {
    const v = n.view();
    assert.equal(v.node.dateIndex, step.dateIndex);
    assert.equal(v.node.slot, step.slot);
    const choice = v.node.choices.find(c => c.choiceId === step.choiceId && c.available);
    assert.ok(choice, 'actual RC1 option ' + v.node.id + '/' + step.choiceId + ' is available');
    const result = n.choose(choice.id, v.node.id, v.revision);
    assert.equal(result.ok, true, result.error);
    count++;
    if (result.result.terminal) {
      assert.equal(n.state.pendingEnding.id, 'drawdown_years');
      restoreNatural(n.exportSave(), 'natural drawdown pending ending');
      for (const phase of ['result', 'ending']) {
        if (phase === 'ending') assert.equal(n.next().ok, true);
        const saved = n.exportSave();
        restoreNatural(saved, 'natural drawdown ' + phase);
        for (const key of ['text', 'title', 'date', 'age', 'kind']) {
          const corrupt = JSON.parse(saved), ending = phase === 'result' ? corrupt.state.pendingEnding : corrupt.state.ending;
          ending[key] = key === 'age' ? ending[key] + 1 : ending[key] + 'forged';
          assert.equal(current.Novel.validateSave(JSON.stringify(corrupt)).ok, false, phase + ': strict ending ' + key);
        }
      }
    } else assert.equal(n.next().ok, true);
  }
  assert.equal(count, 77);
  assert.equal(n.state.phase, 'ending');
  assert.equal(n.core.state.date, '2020-12-31');
  t.diagnostic(JSON.stringify({actualChoices: count, ending: n.state.ending.id, personalNetWorth: n.core.state.personal.lastNav - n.core.state.debt}));
});

test.after(() => {
  assert.equal(JSON.stringify(old.MARKET), JSON.stringify(JSON.parse(marketRaw)), 'RC1 natural choices do not mutate historical market');
  assert.equal(JSON.stringify(rc2.MARKET), JSON.stringify(JSON.parse(marketRaw)), 'RC2 natural choices do not mutate historical market');
  assert.equal(JSON.stringify(current.MARKET), JSON.stringify(JSON.parse(marketRaw)), 'migration and new choices do not mutate historical market');
});
