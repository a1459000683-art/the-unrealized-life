'use strict';
// Independent QA regressions use the authored story and real market. No state injection.
const fs = require('node:fs');
const path = require('node:path');
const vm = require('node:vm');
const crypto = require('node:crypto');
const test = require('node:test');
const assert = require('node:assert/strict');
const ROOT = path.resolve(__dirname, '..');
const read = p => fs.readFileSync(path.join(ROOT, p), 'utf8');
const marketRaw = read('data/market.json');
const ctx = vm.createContext({console, MARKET: JSON.parse(marketRaw)});
vm.runInContext(read('src/novel-story.js'), ctx);
ctx.STORY = {characters: ctx.NOVEL_STORY.characters, events: [], endings: []};
for (const name of ['finance', 'game', 'novel']) vm.runInContext(read('src/' + name + '.js'), ctx);
const evidence = [];
function route(name, plan = {}, stopAt, defaultChoice = 'c') {
  const novel = new ctx.Novel('buffer', 2000), steps = [];
  while (novel.view().phase !== 'ending') {
    const view = novel.view(), wanted = plan[view.node.id] || defaultChoice;
    const selected = view.node.choices.find(c => c.choiceId === wanted && c.available);
    assert.ok(selected, name + ': intended choice available at ' + view.node.id);
    const careerBefore = novel.core.state.career;
    const flagsBefore = [...novel.core.state.flags];
    const result = novel.choose(selected.id);
    assert.equal(result.ok, true, result.error);
    steps.push({nodeId: view.node.id, date: view.date, choiceId: selected.choiceId,
      label: selected.label, careerBefore, careerAfter: novel.core.state.career,
      flagsBefore, scene: view.node.text, result: result.result.text});
    const validation = ctx.Novel.validateSave(novel.exportSave());
    assert.equal(validation.ok, true, validation.error);
    assert.equal(novel.next().ok, true);
    // Audit the exact P1 window: a subsequent choose() must not be allowed to
    // repair an invalid field before the post-navigation save is examined.
    const afterNext = novel.exportSave();
    const immediatelyValid = ctx.Novel.validateSave(afterNext);
    assert.equal(immediatelyValid.ok, true, immediatelyValid.error);
    assert.equal(ctx.Novel.fromSave(afterNext).exportSave(), afterNext);
    if (view.node.id === stopAt) break;
    assert.ok(steps.length <= 77, 'bounded scene sequence');
  }
  const end = novel.view();
  evidence.push({name, plan, defaultChoice, steps, finalPhase: end.phase,
    finalDate: end.date, finalCareer: novel.core.state.career, ending: end.ending?.id || null});
  return {novel, steps, at: id => steps.find(s => s.nodeId === id)};
}

test('all scene groups retain a fallback and 2–4 choices after career-specific alternatives', () => {
  const valid = ctx.Novel.validateContent();
  assert.equal(valid.ok, true, valid.error);
  assert.equal(valid.groups, 77);
  assert.equal(valid.nodes, 100);
});

test('leaving finance stays outside through a declined old-company invitation', () => {
  const r = route('outside-continuity', {n00_0:'b', n22_1:'b', v24_external:'b', n28_1:'a', v32_external:'b'});
  assert.equal(r.at('n20_1').careerAfter, 'outside');
  assert.equal(r.at('n22_1').careerAfter, 'outside');
  assert.equal(r.at('v24_external').careerBefore, 'outside');
  assert.equal(r.at('v24_external').careerAfter, 'outside');
  assert.equal(r.at('v32_external').careerAfter, 'outside');
  assert.ok(r.steps.filter(s => s.date >= '2008-12-31' && s.nodeId !== 'n20_0').every(s => s.careerAfter === 'outside'));
  assert.equal(r.novel.view().date, '2020-12-31');
  assert.equal(r.steps.length, 77);
});

test('outside player can explicitly choose a new industry job without implicit continuation', () => {
  const r = route('explicit-reentry', {n00_0:'b', n22_1:'b', v24_external:'a'}, 'v24_external');
  const step = r.at('v24_external');
  assert.equal(step.careerBefore, 'outside');
  assert.match(step.label, /重返机构/);
  assert.match(step.result, /重新入职/);
  assert.equal(step.careerAfter, 'head');
});

test('unemployment remains unemployment when both new-job invitations are declined', () => {
  const r = route('unemployed-continuity', {n20_1:'a', v24_external:'b', n28_1:'a', v32_external:'b'}, 'v32_external');
  assert.equal(r.at('v22').careerAfter, 'unemployed');
  assert.equal(r.at('v24_external').careerAfter, 'unemployed');
  assert.equal(r.at('v32_external').careerAfter, 'unemployed');
});

for (const option of ['a','b','c']) test('independent career remains independent after 2014 choice ' + option, () => {
  const r = route('independent-' + option, {n14_0:'a', v28:'a', v31:'a', v32_independent:option,
    v39:'a', n42_0:'c', n43_0:'a', n45_0:'c'});
  assert.equal(r.at('v28').careerAfter, 'independent');
  assert.equal(r.at('v32_independent').careerBefore, 'independent');
  assert.equal(r.at('v32_independent').careerAfter, 'independent');
  assert.ok(r.at('v39'), 'authored later independent branch is naturally reached');
  assert.equal(r.at('v39').careerAfter, 'independent');
  assert.ok(r.steps.filter(s => s.date >= '2013-01-01').every(s => s.careerAfter === 'independent'));
  assert.equal(r.steps.length, 77);
  assert.equal(r.novel.view().date, '2020-12-31');
  for (const id of ['n30_0','n31_1','n35_1']) {
    const s = r.at(id);
    assert.doesNotMatch(s.scene + s.result, /向主管|与主管|主管愿意|玛拉要求/);
  }
});

test('declining every teaching invitation does not invent permanent teaching work', () => {
  const r = route('no-teaching', {});
  const s = r.at('n32_1');
  assert.equal(s.flagsBefore.some(f => /^class_|^school_/.test(f)), false);
  assert.match(s.result, /不加入常驻名单/);
  assert.doesNotMatch(s.result, /从常驻名单上拿掉/);
  assert.doesNotMatch(r.at('n51_0').result, /未完成的部分|钥匙|接手/);
});

test('independent ending remains naturally reachable through a complete ordinary choice sequence', () => {
  const r = route('independent-ending', {}, undefined, 'a');
  assert.equal(r.steps.length, 77);
  assert.equal(r.at('v28').careerAfter, 'independent');
  assert.equal(r.at('v32_independent').careerAfter, 'independent');
  assert.equal(r.at('v39').careerAfter, 'independent');
  assert.equal(r.novel.view().ending.id, 'independent_home');
  assert.equal(r.novel.core.state.career, 'independent');
});

test('a 2000 promise returns as an old memory in 2012 rather than the same pending appointment', () => {
  const r = route('early-promise', {n02_1:'a'}, 'v27');
  assert.equal(r.at('n02_1').date, '2000-12-29');
  const later = r.at('v27');
  assert.equal(later.date, '2012-06-29');
  assert.match(later.scene, /那一次约定已经过去/);
  assert.match(later.scene, /眼下的安排/);
  assert.doesNotMatch(later.scene, /也感到它正在变形/);
});

test('retirement and ongoing-teacher branches remain available through their actual earlier choices', () => {
  const retirement = route('retirement-preserved', {n00_0:'a'}, 'v24');
  assert.ok(retirement.at('v24'), 'compatible retirement branch keeps priority over external job offer');
  const teacher = route('teaching-return-preserved', {n10_1:'a', n23_1:'a'}, 'v32');
  assert.ok(teacher.at('v32'));
});

test.after(() => {
  assert.equal(JSON.stringify(ctx.MARKET), JSON.stringify(JSON.parse(marketRaw)), 'story routes do not mutate market data');
  const output = path.join(ROOT, 'output/qa/v2-independent-narrative-regression.json');
  fs.mkdirSync(path.dirname(output), {recursive:true});
  fs.writeFileSync(output, JSON.stringify({scope:'Natural authored-story choices only; no state injection or browser claims',
    storySha256:crypto.createHash('sha256').update(read('src/novel-story.js')).digest('hex'),
    marketSha256:crypto.createHash('sha256').update(marketRaw).digest('hex'), routes:evidence}, null, 2) + '\n');
});
