async (page) => {
  const sourceUrl = page.url();
  if (!sourceUrl.startsWith('file:')) throw new Error('This offline fault run requires the final file:// index.html already open in the original page.');
  const browser = page.context().browser();
  if (!browser) throw new Error('The existing page has no browser connection.');
  const prefix = 'unrealized-life-novel:v1:';
  const autoKey = prefix + 'auto';
  const results = [];
  const contexts = [];
  const exportPath = name => decodeURIComponent(new URL('output/playwright/' + name, sourceUrl).pathname);
  const options = { viewport: { width: 390, height: 844 }, isMobile: true, hasTouch: true, deviceScaleFactor: 2, acceptDownloads: true };

  async function runCase(name, execute) {
    const context = await browser.newContext(options);
    contexts.push(context);
    const assertions = [], consoleErrors = [], pageErrors = [], downloads = [];
    const check = (condition, label, actual) => {
      assertions.push({ label, passed: Boolean(condition), actual: actual === undefined ? null : actual });
      if (!condition) throw new Error(label);
    };
    const watch = (p, label) => {
      p.setDefaultTimeout(15000);
      p.on('console', message => { if (message.type() === 'error') consoleErrors.push({ page: label, text: message.text(), injected: /QA_INJECT_(?:SECURITY|QUOTA)_STORAGE/.test(message.text()) }); });
      p.on('pageerror', error => pageErrors.push({ page: label, text: String(error), injected: /QA_INJECT_(?:SECURITY|QUOTA)_STORAGE/.test(String(error)) }));
      return p;
    };
    const open = async label => {
      const p = watch(await context.newPage(), label);
      await p.goto(sourceUrl, { waitUntil: 'domcontentloaded', timeout: 45000 });
      await p.waitForFunction(() => window.__novelMounted === true, null, { timeout: 30000 });
      return p;
    };
    const start = async p => {
      await p.locator('[data-action="start"][data-start="buffer"]').click();
      await p.locator('[data-action="choose"]:not([disabled])').first().waitFor({ state: 'visible' });
    };
    const pick = async (p, index = 0, turnPage = true) => {
      const button = p.locator('[data-action="choose"]:not([disabled])').nth(index);
      const token = await button.getAttribute('data-choice');
      await button.click();
      await p.locator('[data-action="next"]').waitFor({ state: 'visible' });
      if (turnPage) {
        await p.locator('[data-action="next"]').click();
        await p.locator('[data-action="choose"]:not([disabled])').first().waitFor({ state: 'visible' });
      }
      return token;
    };
    const saves = async p => {
      const opened = await p.locator('#novel-dialog').evaluate(d => d.hasAttribute('open'));
      if (opened) await p.keyboard.press('Escape');
      await p.locator('[data-action="saves"]').click();
      await p.locator('#novel-dialog[open]').waitFor({ state: 'visible' });
      await p.locator('#novel-dialog-content [data-action="export"]').waitFor({ state: 'visible' });
    };
    const disk = p => p.evaluate(key => localStorage.getItem(key), autoKey);
    const exportCurrent = async (p, filename) => {
      await saves(p);
      const promise = p.waitForEvent('download');
      await p.locator('#novel-dialog-content [data-action="export"]').click();
      const download = await promise;
      const destination = exportPath(filename);
      await download.saveAs(destination);
      check((await download.failure()) === null, 'Real browser download completed', filename);
      const stream = await download.createReadStream();
      if (!stream) throw new Error('The browser download has no readable stream: ' + filename);
      const chunks = [];
      for await (const chunk of stream) chunks.push(Buffer.from(chunk));
      const raw = Buffer.concat(chunks).toString('utf8');
      const save = JSON.parse(raw);
      const valid = await p.evaluate(text => window.Novel.validateSave(text), raw);
      check(valid.ok === true, 'Downloaded file passes the actual Novel save validator', valid.ok ? filename : valid.error);
      const record = { filename, path: destination, bytes: Buffer.byteLength(raw), choiceCount: save.state.choiceCount, phase: save.state.phase, date: save.core.state.date, lastChoice: save.state.choiceLog.length ? save.state.choiceLog[save.state.choiceLog.length - 1].choiceId : null };
      downloads.push(record);
      return { raw, save, record };
    };
    let status = 'passed', failure = null, detail = null;
    try {
      detail = await execute({ context, check, open, start, pick, saves, disk, exportCurrent });
      check(pageErrors.filter(x => !x.injected).length === 0, 'No unexpected uncaught page errors', pageErrors);
      check(consoleErrors.filter(x => !x.injected).length === 0, 'No unexpected console errors', consoleErrors);
    } catch (error) {
      status = 'failed'; failure = String(error && error.message || error);
    } finally {
      await context.close();
      contexts.splice(contexts.indexOf(context), 1);
    }
    results.push({ name, status, failure, assertions, detail, downloads, consoleErrors, pageErrors });
  }

  try {
    await runCase('missing APIs plus SecurityError storage getter', async h => {
      await h.context.addInitScript(() => {
        delete Array.prototype.at;
        delete Object.fromEntries;
        if (window.HTMLDialogElement) {
          delete HTMLDialogElement.prototype.showModal;
          delete HTMLDialogElement.prototype.close;
        }
        window.__qaRemovedApis = { at: typeof Array.prototype.at === 'undefined', fromEntries: typeof Object.fromEntries === 'undefined', showModal: !window.HTMLDialogElement || typeof HTMLDialogElement.prototype.showModal === 'undefined', close: !window.HTMLDialogElement || typeof HTMLDialogElement.prototype.close === 'undefined' };
        Object.defineProperty(window, 'localStorage', { configurable: true, get() { throw new DOMException('QA_INJECT_SECURITY_STORAGE', 'SecurityError'); } });
      });
      const p = await h.open('security');
      const removed = await p.evaluate(() => window.__qaRemovedApis);
      h.check(Object.values(removed).every(Boolean), 'All four API deletions occurred before application scripts', removed);
      await h.start(p); await h.pick(p, 0, true);
      await h.saves(p);
      const warning = await p.locator('#novel-dialog-content').innerText();
      h.check(warning.includes('未能可靠读写本地存储') && warning.includes('导出当前人生'), 'Storage denial has a visible recovery explanation', warning.slice(0, 220));
      const exported = await h.exportCurrent(p, 'novel-fault-security-save.json');
      h.check(exported.save.state.choiceCount === 1 && exported.save.state.phase === 'choice', 'Latest memory game was downloaded after choose and next', exported.record);
      const picking = p.waitForEvent('filechooser');
      await p.locator('#novel-dialog-content [data-action="import"]').click();
      const chooser = await picking;
      h.check(Boolean(chooser), 'Fallback dialog import button opens the actual native file chooser');
      await chooser.setFiles({name:'fallback-broken-save.json',mimeType:'application/json',buffer:Buffer.from('{broken')});
      await p.waitForFunction(() => document.getElementById('novel-toast').textContent.includes('导入未完成'));
      h.check((await p.locator('#novel-toast').innerText()).includes('这不是有效的 JSON 存档'), 'Actual fallback file selection reaches the import validator');
      await p.keyboard.press('Escape');
      await p.locator('#novel-dialog').waitFor({ state: 'hidden' });
      const closed = await p.locator('#novel-dialog').evaluate(d => ({ open: d.hasAttribute('open'), display: getComputedStyle(d).display, height: d.getBoundingClientRect().height }));
      h.check(!closed.open && closed.display === 'none' && closed.height === 0, 'Escape hides the dialog even without native dialog methods', closed);
      const repaired = await p.evaluate(() => ({ at: typeof Array.prototype.at, fromEntries: typeof Object.fromEntries }));
      h.check(repaired.at === 'function' && repaired.fromEntries === 'function', 'Early compatibility bootstrap restored the required APIs', repaired);
      return { removed, repaired, dialogAfterEscape: closed };
    });

    await runCase('QuotaExceeded after a successful auto save', async h => {
      const p = await h.open('quota'); await h.start(p); await h.pick(p, 0, true);
      const baseline = await h.disk(p);
      h.check(typeof baseline === 'string' && baseline.length > 0, 'A real automatic save exists before the fault', { bytes: baseline && baseline.length });
      await p.evaluate(storagePrefix => {
        const original = Storage.prototype.setItem;
        window.__qaQuotaAttempts = 0;
        Storage.prototype.setItem = function (key, value) {
          if (String(key).startsWith(storagePrefix)) { window.__qaQuotaAttempts++; throw new DOMException('QA_INJECT_QUOTA_STORAGE', 'QuotaExceededError'); }
          return original.call(this, key, value);
        };
      }, prefix);
      await h.pick(p, 0, true); await h.pick(p, 0, true);
      const after = await h.disk(p), attempts = await p.evaluate(() => window.__qaQuotaAttempts);
      h.check(attempts >= 2, 'Two later choices exercised the injected quota failure', attempts);
      h.check(after === baseline, 'Original disk bytes remain unchanged after failed writes', { unchanged: after === baseline, bytes: after && after.length });
      await h.saves(p);
      const warning = await p.locator('#novel-dialog-content').innerText();
      h.check(warning.includes('未能可靠读写本地存储'), 'Quota failure is visible in the save UI', warning.slice(0, 200));
      const exported = await h.exportCurrent(p, 'novel-fault-quota-save.json');
      h.check(exported.save.state.choiceCount === 3 && exported.save.state.phase === 'choice', 'Export contains both newer in-memory decisions, not the old disk version', exported.record);
      h.check((await h.disk(p)) === baseline, 'Exporting memory does not overwrite the original disk save');
      return { quotaAttempts: attempts, originalDiskPreserved: true, diskBaselineChoices: 1, exportedChoices: exported.save.state.choiceCount };
    });

    await runCase('two actual tabs preserve a newer CAS disk version', async h => {
      const first = await h.open('CAS-first'); await h.start(first);
      const baseline = await h.disk(first);
      const second = await h.open('CAS-second');
      await second.locator('[data-action="resume"]').click();
      await second.locator('[data-action="choose"]:not([disabled])').first().waitFor({ state: 'visible' });
      h.check((await h.disk(second)) === baseline, 'Normal second-tab resume preserves identical disk bytes');
      await h.saves(second);
      const beforeConflict = await second.locator('#novel-dialog-content').innerText();
      h.check(!beforeConflict.includes('另一标签页更改了存档'), 'Compressed-save resume does not invent a CAS conflict before any competing update');
      await second.keyboard.press('Escape');
      const firstToken = await h.pick(first, 0, false), committed = await h.disk(first);
      h.check(committed !== baseline, 'First tab successfully commits a newer decision');
      const secondToken = await h.pick(second, 1, false);
      h.check(firstToken !== secondToken, 'Stale tab chose a genuinely different option', { firstToken, secondToken });
      h.check((await h.disk(first)) === committed && (await h.disk(second)) === committed, 'Stale second-tab decision cannot overwrite the first tab on disk');
      await h.saves(second);
      const conflict = await second.locator('#novel-dialog-content').innerText();
      h.check(conflict.includes('另一标签页更改了存档') && conflict.includes('没有自动覆盖'), 'CAS conflict and preservation policy are visible to the player', conflict.slice(0, 380));
      const firstExport = await h.exportCurrent(first, 'novel-fault-cas-primary-save.json');
      const staleExport = await h.exportCurrent(second, 'novel-fault-cas-stale-save.json');
      const a = firstExport.save.state.choiceLog[0], b = staleExport.save.state.choiceLog[0];
      h.check(firstExport.save.state.choiceCount === 1 && staleExport.save.state.choiceCount === 1 && a.choiceId !== b.choiceId && a.nodeId === b.nodeId, 'Both conflicting lives remain independently exportable', { first: a.choiceId, stale: b.choiceId, node: a.nodeId });
      h.check(firstExport.save.state.seed === staleExport.save.state.seed, 'The competing tabs came from the same actual saved life');
      h.check((await h.disk(first)) === committed, 'Dialog inspection and both exports leave the winning disk bytes intact');
      return { sameBaseline: true, firstOption: a.choiceId, staleOption: b.choiceId, newerDiskPreserved: true };
    });

    await runCase('old-format and malformed JSON imports preserve the current life', async h => {
      const p = await h.open('imports'); await h.start(p); await h.pick(p, 0, true);
      const baseline = await h.disk(p);
      const before = await h.exportCurrent(p, 'novel-fault-import-before-save.json');
      const legacy = JSON.stringify(before.save.core);
      const oldValidation = await p.evaluate(raw => window.Game.validateSave(raw), legacy);
      h.check(oldValidation.ok === true, 'Legacy-format payload is a valid old Game save, not merely random JSON', oldValidation.ok);
      const payloads = [
        { name: 'old-game-save.json', raw: legacy, expected: '请选择本小说版本的存档' },
        { name: 'broken-novel-save.json', raw: '{"game":"unrealized-life-novel","schemaVersion":1,"state":', expected: '这不是有效的 JSON 存档' }
      ];
      const rejections = [];
      for (const payload of payloads) {
        const picking = p.waitForEvent('filechooser');
        await p.locator('#novel-dialog-content [data-action="import"]').click();
        const chooser = await picking;
        await chooser.setFiles({ name: payload.name, mimeType: 'application/json', buffer: Buffer.from(payload.raw, 'utf8') });
        await p.waitForFunction(expected => { const el = document.getElementById('novel-toast'); return el && el.textContent.includes(expected); }, payload.expected);
        const message = await p.locator('#novel-toast').innerText();
        h.check(message.includes('导入未完成') && message.includes(payload.expected), 'Rejected import produces the correct visible explanation', { file: payload.name, message });
        h.check((await h.disk(p)) === baseline, 'Rejected import leaves the current automatic save byte-for-byte intact', payload.name);
        h.check(await p.locator('#novel-dialog-content [data-action="confirm"]').count() === 0, 'Invalid import never reaches a replacement confirmation', payload.name);
        rejections.push({ file: payload.name, message });
      }
      const after = await h.exportCurrent(p, 'novel-fault-import-after-save.json');
      h.check(after.raw === before.raw, 'Both rejected imports leave the current in-memory life exactly unchanged', { bytesBefore: before.record.bytes, bytesAfter: after.record.bytes });
      h.check((await h.disk(p)) === baseline, 'Final export also preserves the original disk record');
      return { rejections, currentMemoryUnchanged: true, originalDiskUnchanged: true };
    });
  } finally {
    for (const context of contexts) { try { await context.close(); } catch (_) {} }
  }
  const report = { sourceUrl, viewport: options.viewport, originalPageUnchanged: page.url() === sourceUrl, cases: results };
  if (!report.originalPageUnchanged) throw new Error('Original page URL changed unexpectedly: ' + JSON.stringify(report));
  if (results.some(result => result.status !== 'passed')) throw new Error('Browser fault acceptance failed: ' + JSON.stringify(report));
  return report;
}
