'use strict';
// Data quality and time-boundary tests. Controlled date assignments below test
// projection only; they are not claimed as naturally played careers.
const {test}=require('node:test'),assert=require('node:assert/strict'),fs=require('node:fs'),path=require('node:path'),vm=require('node:vm'),crypto=require('node:crypto');
const ROOT=path.resolve(__dirname,'..'),market=JSON.parse(fs.readFileSync(path.join(ROOT,'data/market.json'),'utf8'));
const symbols=['HEI','GNTX','JKHY','AIR','BRO','RHI','WDFC','FAST','GPC','THO','SCHL','HRB','HOG','EOG','CBU','NUE'];
const stable=v=>Array.isArray(v)?v.map(stable):v&&typeof v==='object'?Object.fromEntries(Object.keys(v).sort().map(k=>[k,stable(v[k])])):v;
const hash=v=>crypto.createHash('sha256').update(JSON.stringify(stable(v))).digest('hex');
function load(m=market){const c=vm.createContext({console,MARKET:JSON.parse(JSON.stringify(m))});for(const f of ['src/finance.js','src/story.js','src/game.js'])vm.runInContext(fs.readFileSync(path.join(ROOT,f),'utf8'),c);return c;}
const previous=d=>new Date(Date.parse(d)-864e5).toISOString().slice(0,10);
test('financial supplement never changes historical trading dates, prices, actions or benchmark',()=>{
 const b=JSON.parse(fs.readFileSync(path.join(ROOT,'data/history-invariants-v1.json'),'utf8'));
 assert.equal(hash(market.dates),b.datesSha256);assert.equal(hash(market.benchmark),b.benchmarkSha256);
 for(const c of market.companies){assert.equal(hash(c.prices),b.companies[c.id].pricesSha256,c.id+' prices');assert.equal(hash(c.actions),b.companies[c.id].actionsSha256,c.id+' actions');assert.equal(c.listed,b.companies[c.id].listed);assert.equal(c.delisted??null,b.companies[c.id].delisted);}
});
for(const symbol of symbols){
 test(symbol+': contemporaneous early filings, numerical evidence and current-date projection',()=>{
  const s=JSON.parse(fs.readFileSync(path.join(ROOT,'data/early-financials',symbol+'.json'),'utf8'));
  assert.equal(s.symbol,symbol);assert.ok(s.facts.length>=9,'nine or more annual-era records required');
  const c=market.companies.find(x=>x.id===symbol),ctx=load(),g=new ctx.Game('buffer','industrial',123);
  g.state.research[symbol]=['cashflow','debt','customers','valuation','challenge'];
  const years=new Set(s.facts.map(f=>f.published.slice(0,4)));
  for(let y=2000;y<=2008;y++)assert.ok(years.has(String(y)),symbol+' no contemporaneous visible filing in '+y);
  const sourceUrls=new Set(s.sources.map(x=>x.url));
  assert.equal(new Set(s.facts.map(f=>f.id)).size,s.facts.length);
  for(const f of s.facts){
   assert.equal(f.kind,'financial');for(const year of ((f.title+' '+f.text).match(/(?<!\d)(?:19|20)\d{2}(?!\d)/g)||[]))assert.ok(year<=f.published.slice(0,4),f.id+' later-year wording '+year);assert.ok(f.period<=f.published);assert.ok(f.availableFrom>f.published);assert.ok(sourceUrls.has(f.source));assert.ok(c.facts.some(x=>x.id===f.id),'not integrated '+f.id);
   for(const key of ['revenue','netIncome','ocf','capex','debt','cash','eps','shares']){
    assert.ok(Object.hasOwn(f.metrics,key),f.id+' missing metric key '+key);
    const v=f.metrics[key];assert.ok(v===null||Number.isFinite(v));if(v!==null)assert.ok(f.metricMeta?.[key]&&Object.keys(f.metricMeta[key]).length,f.id+' evidence missing for '+key);
   }
   if(f.metrics.capex!==null)assert.ok(f.metrics.capex>=0,'capex is positive cash outflow');
   g.state.date=previous(f.availableFrom);assert.equal(g.company(symbol).facts.some(x=>x.id===f.id),false,'filing visible before availability '+f.id);
   g.state.date=f.availableFrom<c.listed?c.listed:f.availableFrom;assert.equal(g.company(symbol).facts.some(x=>x.id===f.id),true,'filing missing after availability '+f.id);
   for(const displayed of g.company(symbol).facts)assert.ok((displayed.availableFrom||displayed.published)<=g.state.date);
  }
  for(const src of s.sources){assert.match(src.url,/^https:\/\//);assert.match(src.sha256,/^[a-f0-9]{64}$/);assert.ok(src.filed||src.published);}
  assert.equal(s.listingAtStart.asOf,'2000-01-03');assert.equal(s.listingAtStart.listed,true);assert.ok(s.listingAtStart.source);assert.ok(s.listingAtStart.published<='2000-01-03');
 });
}
test('EPS estimates adjust from disclosed share basis, and do not double-count already reflected splits',()=>{
 const m=JSON.parse(JSON.stringify(market)),c=m.companies[0];
 c.facts=[{id:'controlled-eps',kind:'financial',period:'2000-12-31',published:'2001-02-01',availableFrom:'2001-02-02',metrics:{eps:2},metricMeta:{eps:{shareBasisDate:'2001-03-01'}}}];
 c.actions=[{id:'controlled-split',type:'split',date:'2001-03-01',published:'2001-03-01',ratio:2}];
 const ctx=load(m),g=new ctx.Game('buffer');g.state.research[c.id]=['valuation'];
 g.state.date='2001-02-28';assert.equal(g.company(c.id).valuation.neutral,null,'future share basis is not current-date value');
 g.state.date='2001-06-29';assert.equal(g.company(c.id).valuation.neutral,36,'EPS already uses split shares');
 c.facts[0].metricMeta.eps.shareBasisDate='2001-02-01';
 const oldBasis=load(m),b=new oldBasis.Game('buffer');b.state.date='2001-06-29';b.state.research[c.id]=['valuation'];assert.equal(b.company(c.id).valuation.neutral,18,'old share basis must be divided by split');
});
test('restatement is visible only after its own publication, retaining the original earlier observation',()=>{
 const m=JSON.parse(JSON.stringify(market)),c=m.companies[0];c.facts=[{id:'original',kind:'financial',period:'2000-12-31',published:'2001-03-01',availableFrom:'2001-03-02',metrics:{revenue:100,netIncome:10}},{id:'amended',kind:'financial',period:'2000-12-31',published:'2002-04-01',availableFrom:'2002-04-02',metrics:{revenue:90,netIncome:5}}];
 const ctx=load(m),g=new ctx.Game('buffer');g.state.research[c.id]=['cashflow'];g.state.date='2001-12-31';assert.equal(g.company(c.id).metrics.netIncome,10);assert.equal(g.company(c.id).facts.length,1);g.state.date='2002-04-02';assert.equal(g.company(c.id).metrics.netIncome,5);assert.equal(g.company(c.id).facts.length,2);
});
test('delivered version-1 browser saves load unchanged after financial data enrichment',()=>{
 const ctx=load();for(const name of ['final-browser-save.json','quota-save.json','securityerror-save.json']){
  const raw=fs.readFileSync(path.join(ROOT,'output/playwright',name),'utf8'),parsed=JSON.parse(raw);assert.equal(ctx.Game.validateSave(raw).ok,true,name);const g=ctx.Game.fromSave(raw);assert.deepEqual(JSON.parse(g.exportSave()).state,parsed.state,name+' state changed at import');assert.equal(g.view().clientStats.reconciliationError,0);
 }
});
test('free cash flow and raw evidence obey the current research permissions',()=>{
 const m=JSON.parse(JSON.stringify(market)),c=m.companies[0];c.facts=[{id:'cashflow-evidence',kind:'financial',period:'1999-12-31',published:'2000-03-01',availableFrom:'2000-03-02',metrics:{revenue:100,netIncome:20,ocf:-10,capex:5,cash:77,debt:88,eps:2,shares:10},metricMeta:{eps:{rawValue:2,shareBasisDate:'2000-03-01',source:'private identity locator'},cash:{rawValue:77},debt:{rawValue:88}},filing:'identifying-accession',sourceId:'identifying-name'}];
 const ctx=load(m),g=new ctx.Game('buffer');g.state.date='2000-06-30';g.state.research[c.id]=['customers'];let v=g.company(c.id);assert.equal(v.metrics.ocf,null);assert.equal(v.metrics.fcf,null);assert.equal(JSON.stringify(v.facts).includes('rawValue'),false);assert.equal(JSON.stringify(v.facts).includes('identifying-'),false);
 g.state.research[c.id].push('cashflow');v=g.company(c.id);assert.equal(v.metrics.fcf,-15);assert.equal(v.metrics.cash,null);assert.equal(v.metrics.debt,null);
 c.facts[0].metrics.capex=null;const missing=load(m),b=new missing.Game('buffer');b.state.date='2000-06-30';b.state.research[c.id]=['cashflow'];assert.equal(b.company(c.id).metrics.fcf,null,'unverified capex must not become zero');
});
