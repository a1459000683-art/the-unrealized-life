/* Independent historical integration simulation.
 * All career changes use public Game commands/eligible story choices.
 * No direct editing of money, flags, career, prices, or terminal state.
 * Scenario identifiers are visible to the tester only; UI remains anonymous.
 */
const fs=require('node:fs'),path=require('node:path'),vm=require('node:vm'),assert=require('node:assert/strict');
const ROOT=path.resolve(__dirname,'..');
function load(){const c=vm.createContext({console});c.MARKET=JSON.parse(fs.readFileSync(path.join(ROOT,'data/market.json'),'utf8'));for(const p of ['src/finance.js','src/story.js','src/game.js'])vm.runInContext(fs.readFileSync(path.join(ROOT,p),'utf8'),c,{filename:p});return c;}
const C=load();let assertions=0;const check=(value,message)=>{assert.ok(value,message);assertions++;};
const profiles={
 cash:{start:'buffer',sector:'industrial',weights:{discipline:5,research:4,trust:3,reputation:3,communication:3,health:2,stress:-1,freedom:1},relations:1},
 risk:{start:'debt',sector:'consumer',weights:{authority:6,trust:4,research:3,personalCash:.00015,freedom:-1,stress:1},relations:0},
 life:{start:'network',sector:'services',weights:{health:4,stress:-4,freedom:6,reputation:1,communication:2},relations:4}
};
const startNames=['buffer','debt','network'];
function randomSource(seed){let value=seed>>>0;return()=>{value^=value<<13;value^=value>>>17;value^=value<<5;return(value>>>0)/4294967296;};}
function run(name,seed,random=false){const p=profiles[name]||profiles.cash;const g=new C.Game(random?startNames[seed%3]:p.start,p.sector,seed);const rng=randomSource(seed+1);let last=g.state.date,loops=0,partialSale=false,unemployed=false,rebuilt=false,realAction=false,majorLoss=false,minPositionReturn=0;const visited=[],events=[],checks=[];let assetActionCounts={};
 function choose(){const e=g.event();if(!e||g.state.resolved)return;const options=e.choices.filter(c=>c.available&&(!c.cost?.actionPoints||c.cost.actionPoints<=g.state.actionPoints));check(options.length>0,`${name}/${seed}: event ${e.id} has no available choice`);let option;
  if(random)option=options[Math.floor(rng()*options.length)];
  else {const ranked=options.map(c=>{let score=0;for(const[k,w]of Object.entries(p.weights))score+=(c.effects?.[k]||0)*w;score+=Object.values(c.effects?.relations||{}).reduce((s,v)=>s+v,0)*p.relations;if(name==='life'&&c.effects?.career==='unemployed'&&!unemployed)score+=1000;if(name==='life'&&c.effects?.career==='outside'&&unemployed)score+=100;if(name==='risk'&&c.effects?.career==='independent')score+=100;return[c,score];}).sort((a,b)=>b[1]-a[1]);option=ranked[0][0];}
  const result=g.choose(option.id);check(result.ok,`${name}: choose ${e.id}/${option.id}: ${result.error}`);events.push({date:g.state.date,id:e.id,choice:option.id,chain:e.chain||null});
 }
 function prepare(id){if(!g.company(id)?.tradable)return false;if(!g.state.research[id]?.length){const r=g.researchCompany(id,'cashflow');if(!r.ok)return false;}const t=g.setThesis(id,{why:'按当期公开现金流与客户资料建立小额观察仓',risk:'周期、估值和资金需求可能超过预期',horizon:'跨多个决策阶段，保留按证据调整的余地',invalidation:'公开现金流或债务证据持续偏离事前判断'});if(!t.ok)return false;g.propose(id);return true;}
 function buy(id,which,fraction){if(!prepare(id))return;const v=g.view();const stats=which==='client'?v.clientStats:v.personalStats;const company=g.company(id);const held=g.state[which].positions[id]?.quantity||0;const target=Math.min(g.state[which].cash*.95,Math.max(0,stats.nav*fraction-held*company.price));const q=target/company.price;if(q>0)g.trade(which,id,'buy',q);}
 while(!g.state.ending&&loops++<100){check(g.state.date>=last,'date monotonicity');last=g.state.date;choose();
  if(g.state.career==='unemployed'){unemployed=true;if(name==='life'&&g.state.unemployedMonths>=6){g.spend('job');if(g.state.career!=='unemployed')rebuilt=true;}}
  if(!random){
   if(name==='cash'&&g.state.stage<10){buy('HEI','client',.04);buy('GNTX','client',.04);}
   if(name==='risk'&&g.state.date<'2007-01-01'){buy('HOG','personal',.38);buy('THO','client',.075);}
   if(name==='risk'&&g.state.date==='2019-07-31')buy('PIR','personal',.35);
   if(!partialSale&&g.state.date>='2003-01-01'){const entry=Object.entries(g.state.client.positions).find(([,v])=>v.quantity>0);if(entry&&g.company(entry[0]).tradable){check(g.trade('client',entry[0],'sell',entry[1].quantity/2).ok,'partial sale executes');partialSale=true;}}
   if(name==='life'&&g.state.actionPoints>0)g.spend('contact',C.STORY.characters[0].id);
   if(g.state.actionPoints>0)g.spend('rest');
  } else if(g.state.actionPoints>0&&rng()<.5)g.spend('rest');
  const v=g.view();for(const which of ['client','personal']){const st=which==='client'?v.clientStats:v.personalStats;check(st.ok&&Number.isFinite(st.nav)&&Number.isFinite(st.twr),`${name} ${which} finite stats`);check(Math.abs(st.reconciliationError)<Math.max(.02,st.nav*1e-9),`${name} ${which} accounting conserved ${st.reconciliationError}`);check(g.state[which].cash>=-1e-7,'no unexplained leverage');for(const[id,h]of Object.entries(g.state[which].positions)){if(h.totalInvested>0){const ps=C.Finance.positionStats(g.state[which],id,g.price(id)||0,g.state.date);if(ps.totalReturn!==null){minPositionReturn=Math.min(minPositionReturn,ps.totalReturn);if(ps.totalReturn<=-.4)majorLoss=true;}}}for(const row of g.state[which].ledger){if(['dividend','split','cancel','cash_merger'].includes(row.type)&&row.quantityBefore>0){realAction=true;assetActionCounts[row.type]=(assetActionCounts[row.type]||new Set()).add(row.actionId);}}}
  check(new Set(g.state.seen).size===g.state.seen.length,'events never repeat');for(const co of v.companies){check(co.prices.every(x=>x.date<=g.state.date),'no future visible price');check(co.facts.every(x=>(x.availableFrom||x.published)<=g.state.date),'no future visible fact');}
  if(g.state.stage%10===0){const restored=C.Game.fromSave(g.exportSave());check(restored.exportSave()===g.exportSave(),'save/import retains complete state');}
  visited.push({date:g.state.date,career:g.state.career,clientNav:v.clientStats.nav,personalNav:v.personalStats.nav,debt:g.state.debt,event:g.state.eventId,choices:g.state.choices});
  const a=g.advance();check(a.ok,`advance: ${a.error}`);
 }
 check(!!g.state.ending,`${name}: reaches ending`);check(g.state.date==='2020-12-31','complete 2000–2020');
 const terminal=g.exportSave();check(!g.advance().ok,'terminal advance blocked');check(g.exportSave()===terminal,'terminal state unchanged');
 return {name,seed,start:g.state.start,ending:g.state.ending.id,choices:g.state.choices,decisionDates:visited.length,unemployed,rebuilt,partialSale,realAction,majorLoss,minPositionReturn,actions:Object.fromEntries(Object.entries(assetActionCounts).map(([k,v])=>[k,v.size])),recalls:g.state.memory.filter(x=>x.delayed||x.origin||x.chain).map(x=>({date:x.date,title:x.title,origin:x.origin,chain:x.chain})),events,visited};
}
const count=Number(process.argv[2]||48);const paths=['cash','risk','life'].map((p,i)=>run(p,2000+i));for(let seed=1;seed<=count;seed++)paths.push(run(['cash','risk','life'][seed%3],seed,true));
const endingCounts={},eventSet=new Set();for(const p of paths){endingCounts[p.ending]=(endingCounts[p.ending]||0)+1;p.events.forEach(x=>eventSet.add(x.id));}
const report={date:new Date().toISOString(),method:'正常开局→可用选项与Game公共动作；不注入职业/财富/flags/终局；真实市场独立固定。',assertions,pathCount:paths.length,endingCounts,eventsReached:[...eventSet].sort(),availableEvents:C.STORY.events.length,declaredEndings:C.STORY.endings.map(x=>x.id),paths};
fs.mkdirSync(path.join(ROOT,'output/qa'),{recursive:true});fs.writeFileSync(path.join(ROOT,process.argv[3]||`output/qa/career-paths-${paths.length}.json`),JSON.stringify(report,null,2));
console.log(JSON.stringify({assertions,pathCount:paths.length,endingCounts,eventsReached:eventSet.size,availableEvents:C.STORY.events.length,core:paths.slice(0,3).map(({visited,events,recalls,...p})=>({...p,recallCount:recalls.length}))},null,2));
