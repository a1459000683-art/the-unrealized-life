/* Independent integration acceptance tests.
 * Controlled market fixtures test engine invariants; they are not historical
 * evidence and must never be counted as the real-company action acceptance.
 * Run: node --test tests/integration.test.cjs
 */
const test = require('node:test');
const assert = require('node:assert/strict');
const fs = require('node:fs');
const vm = require('node:vm');
const path = require('node:path');
const ROOT = path.resolve(__dirname, '..');

function fixture(start='buffer') {
  const context = vm.createContext({console});
  const dates = ['2000-01-03', '2000-06-30', '2000-12-29'];
  context.MARKET = {
    dates, basis: 'controlled raw fixture, never historical results', basisType: 'raw',
    benchmark: dates.map(date => ({date, value: 100})),
    companies: [{id:'sample', ticker:'HEI', name:'Test Company', alias:'测试公司',
      listed:'1990-01-01', prices:dates.map(date => ({date, close:100})),
      facts:[{published:'1999-12-01',layer:1,public:true,text:'已公开'},
             {published:'2001-01-01',layer:2,text:'未来秘密'}], actions:[], sources:[]},
      {id:'later', ticker:'GNTX', name:'Later Company', alias:'迟来公司', listed:'2001-01-01',
       prices:[{date:'2001-01-01',close:20}],facts:[],actions:[],sources:[]}]
  };
  context.STORY = {characters:['a','b','c','d','e','f','g','h'].map(id=>({id,name:id})),
    events:[{id:'e0',date:dates[0],stage:0,title:'测试事件',text:'独立集成测试',kind:'base',characters:[],requires:{},choices:[{id:'wait',label:'等待',effects:{}}]},
      {id:'e_future',date:'2000-12-29',stage:1,title:'未来事件',text:'现在不可见',kind:'base',characters:[],requires:{},choices:[{id:'wait',label:'等待',effects:{}}]}],
    endings:[{id:'ordinary',title:'结束',text:'测试结束',requires:{}}]};
  for (const f of ['src/finance.js','src/game.js']) vm.runInContext(fs.readFileSync(path.join(ROOT,f),'utf8'),context,{filename:f});
  return {g:new context.Game(start), Game:context.Game, Finance:context.Finance, market:context.MARKET, story:context.STORY};
}
function authorize(g) {
  assert.equal(g.researchCompany('sample','cashflow').ok,true);
  assert.equal(g.setThesis('sample',{why:'公共资料',risk:'客户风险',horizon:'三年',invalidation:'现金流恶化'}).ok,true);
  assert.equal(g.propose('sample').ok,true);
}
function roundtrip(Game,g,mutate) {
  const raw=JSON.parse(g.exportSave());mutate(raw.state);return Game.validateSave(raw);
}

test('institutional order cannot execute before authorization',()=>{
  const {g}=fixture();const before=g.state.client.cash;
  assert.equal(g.trade('client','sample','buy',1).ok,false);
  assert.equal(g.state.client.cash,before);assert.equal(Object.keys(g.state.client.positions).length,0);
});
test('company projection hides future public facts and pre-listing trade',()=>{
  const {g}=fixture();assert.equal(g.company('sample').facts.some(x=>x.text==='未来秘密'),false);
  assert.equal(g.company('later').tradable,false);assert.equal(g.company('sample').name,null);
});
test('same save and same commands are reproducible without duplicate settlement',()=>{
  const {g,Game}=fixture();g.choose('wait');authorize(g);
  const clone=Game.fromSave(g.exportSave());g.advance();clone.advance();
  assert.equal(g.exportSave(),clone.exportSave());
});
test('partial sale keeps position, costs, client/personal ledger separation',()=>{
  const {g}=fixture();authorize(g);const cash=g.state.personal.cash;
  assert.equal(g.trade('client','sample','buy',10).ok,true);
  assert.equal(g.trade('client','sample','sell',4).ok,true);
  assert.equal(g.state.client.positions.sample.quantity,6);
  assert.ok(Math.abs(g.state.client.positions.sample.cost-600.6)<1e-6);
  assert.equal(g.state.personal.cash,cash);assert.ok(Math.abs(g.view().clientStats.reconciliationError)<1e-6);
});
test('selling epsilon quantity after a full exit is rejected without NaN contamination',()=>{
  const {g}=fixture();authorize(g);g.trade('client','sample','buy',1);g.trade('client','sample','sell',1);
  const before=JSON.stringify(g.state.client);const result=g.trade('client','sample','sell',1e-10);
  assert.equal(result.ok,false);assert.equal(JSON.stringify(g.state.client),before);
  const stats=g.view().clientStats;assert.ok(Number.isFinite(stats.realized));assert.equal(stats.reconciliationError,0);
});
test('same committee proposal is idempotent and cannot farm internal trust',()=>{
  const {g}=fixture();authorize(g);const trust=g.state.stats.trust;
  for(let i=0;i<40;i++)g.propose('sample');
  assert.equal(g.state.stats.trust,trust);
});
test('leaving employer revokes discretionary client sales as well as buys',()=>{
  const {g}=fixture();authorize(g);g.trade('client','sample','buy',10);g._setCareer('unemployed');
  const before=JSON.stringify(g.state.client);
  assert.equal(g.trade('client','sample','sell',1).ok,false);assert.equal(JSON.stringify(g.state.client),before);
});
test('mandatory cash sourcing cannot fabricate a sale from a stale untradeable quote',()=>{
  const {g,market}=fixture();authorize(g);g.trade('client','sample','buy',10);
  market.companies[0].prices=[{date:'2000-01-03',close:100}];g.state.date='2000-06-30';g.state.stage=1;
  assert.equal(g.company('sample').tradable,false);
  const qty=g.state.client.positions.sample.quantity;g._cash(g.state.client,g.state.client.cash+100,g.state.date);
  assert.equal(g.state.client.positions.sample.quantity,qty);
});
test('missing values and stale quotes remain missing/stale instead of zero/fresh',()=>{
  const {g,market}=fixture();authorize(g);g.trade('client','sample','buy',1);
  market.companies[0].prices=[{date:'2000-01-03',close:100}];g.state.date='2000-06-30';g.state.stage=1;g._mark();
  assert.notEqual(g.state.client.quoteDates.sample,g.state.date);
  assert.equal(g.view().clientStats.stale.includes('sample'),true);
  assert.equal(Object.hasOwn(g.state.client.prices,'later'),false);
});
test('import rejects missing financial substructures before replacing game',()=>{
  const {g,Game}=fixture();
  for(const key of ['externalFlows','history','ledger','totals','prices','quoteDates','appliedActions']){
    assert.equal(roundtrip(Game,g,s=>{delete s.client[key];}).ok,false,`missing client.${key}`);
  }
});
test('import rejects wrong typed finance state and out-of-range money',()=>{
  const {g,Game}=fixture();
  for(const [key,value]of [['externalFlows',{}],['totals',[]],['cash',1e99]]){
    assert.equal(roundtrip(Game,g,s=>{s.client[key]=value;}).ok,false,`invalid client.${key}`);
  }
});
test('import rejects future event, incorrect age, and future account time',()=>{
  const {g,Game}=fixture();
  assert.equal(roundtrip(Game,g,s=>{s.eventId='e_future';}).ok,false);
  assert.equal(roundtrip(Game,g,s=>{s.age=90;}).ok,false);
  assert.equal(roundtrip(Game,g,s=>{s.client.date='2001-01-01';}).ok,false);
});
test('import validates exact stat keys rather than only arbitrary key count',()=>{
  const {g,Game}=fixture();
  assert.equal(roundtrip(Game,g,s=>{delete s.stats.health;s.stats.invented=50;}).ok,false);
});
test('import rejects non-object research maps and incomplete firm accounting',()=>{
  const {g,Game}=fixture();
  for(const key of ['research','theses','approved']){
    assert.equal(roundtrip(Game,g,s=>{s[key]='not-a-map';}).ok,false,`invalid ${key}`);
  }
  for(const key of ['managementFees','salaries','bonuses']){
    assert.equal(roundtrip(Game,g,s=>{delete s.firm[key];}).ok,false,`missing firm.${key}`);
  }
});
test('import rejects malformed pending effects and invalid ISO dates',()=>{
  const {g,Game}=fixture();g.choose('wait');
  assert.equal(roundtrip(Game,g,s=>{s.pending=[{origin:'e0',dueDate:'2000-02-31',effects:{}}];}).ok,false);
  assert.equal(roundtrip(Game,g,s=>{s.pending=[{origin:'e0',dueDate:'2000-06-30',effects:{relations:{a:'broken'}}}];}).ok,false);
});
test('institution receives only actual collected management fee',()=>{
  const {g,Finance,market}=fixture();
  Finance.buy(g.state.client,{id:'sample',date:g.state.date,price:100,quantity:10000,authorized:true});
  market.companies[0].delisted='2000-02-01';
  g.choose('wait');const initialFirm=g.state.firm.managementFees;const initialFees=g.state.client.totals.expenses||0;
  g.advance();
  assert.equal(g.state.firm.managementFees-initialFirm,(g.state.client.totals.expenses||0)-initialFees);
});
test('research topics unlock specific evidence, and EPS valuation states its assumptions',()=>{
  const {g,market}=fixture();market.companies[0].facts=[{id:'f1',kind:'business',published:'1999-12-31',period:'1999-09-30',metrics:{revenue:100,netIncome:10,ocf:11,capex:3,debt:50,eps:2}}];
  assert.equal(g.company('sample').metrics.ocf,null);assert.equal(g.company('sample').metrics.debt,null);
  g.researchCompany('sample','cashflow');assert.equal(g.company('sample').metrics.ocf,11);assert.equal(g.company('sample').metrics.debt,null);assert.equal(g.company('sample').valuation.neutral,null);
  g.researchCompany('sample','valuation');assert.equal(g.company('sample').valuation.conservative,24);assert.equal(g.company('sample').valuation.neutral,36);assert.equal(g.company('sample').valuation.optimistic,48);assert.match(g.company('sample').valuation.assumptions,/假设/);
  g.researchCompany('sample','debt');assert.equal(g.company('sample').metrics.debt,50);
});
test('total equity risk budget binds separately from the per-company limit',()=>{
  const {g,market}=fixture();const base=market.companies[0];
  for(let n=1;n<=8;n++){const copy=JSON.parse(JSON.stringify(base));copy.id='security'+n;copy.ticker='HEI';market.companies.push(copy);}
  // Many valid approved securities are a controlled precondition, not a claim
  // that one story action can grant those approvals.
  for(const c of market.companies.filter(c=>c.id!=='later'))g.state.approved[c.id]=10;
  let denied=false;for(const c of market.companies.filter(c=>c.id!=='later')){
    const result=g.trade('client',c.id,'buy',950);
    if(!result.ok){assert.match(result.error,/风险预算/);denied=true;break;}
  }
  assert.ok(denied);assert.ok(g.view().clientStats.marketValue/g.view().clientStats.nav*100<=g.permissions().riskBudget);
});
test('deferred award is a separate claim and leaving forfeits only unvested amount',()=>{
  const {g,market,story}=fixture('network');authorize(g);g.trade('client','sample','buy',10);
  market.companies[0].prices[1].close=200;g.choose('wait');g.advance();
  assert.ok(g.state.deferred.length>0);const award=g.state.deferred[0].amount;assert.ok(award>0);assert.equal(g.state.deferred[0].status,'pending');
  const before=g.state.personal.cash;story.events.push({id:'leave',date:g.state.date,stage:0,kind:'conditional',title:'离职测试',text:'受控事件',choices:[{id:'leave-now',label:'离职',effects:{career:'unemployed'}}]});
  g.state.eventId='leave';g.state.resolved=false;g.choose('leave-now');
  assert.equal(g.state.deferred[0].status,'forfeited');assert.equal(g.state.deferredForfeited,award);assert.equal(g.state.personal.cash,before);
});
test('old-file counterfactual uses real actions and never changes actual cash',()=>{
  const {g,market}=fixture();authorize(g);g.trade('client','sample','buy',10);g.trade('client','sample','sell',4);
  market.companies[0].prices[1].close=50;market.companies[0].actions=[{id:'s1',type:'split',ratio:2,date:'2000-03-01',published:'2000-03-01'},{id:'d2',type:'dividend',amount:10,date:'2000-04-01',published:'2000-04-01'}];
  g.choose('wait');g.advance();const before=g.exportSave();const rows=g.oldFiles();
  assert.equal(rows.length,1);assert.equal(rows[0].hypothetical,480);assert.ok(Math.abs(rows[0].actualProceeds-399.6)<1e-8);assert.equal(g.exportSave(),before);
});
test('corporate distribution does not create a fake drawdown before same-day ex-price',()=>{
  const {Finance:F}=fixture();const a=F.createAccount(1000,'2000-01-03');
  F.buy(a,{date:'2000-01-03',id:'sample',price:100,quantity:10,authorized:true});
  F.action(a,{date:'2001-01-03',id:'d1',companyId:'sample',type:'dividend',amount:10});
  F.mark(a,'2001-01-03',{sample:90});const s=F.stats(a);
  assert.equal(s.nav,1000);assert.equal(s.twr,0);assert.ok(Math.abs(s.maxDrawdown)<1e-10);
});
test('terminal state rejects all discretionary money changes',()=>{
  const {g}=fixture();g.choose('wait');g.advance();g.advance();g.choose('wait');g.advance();
  assert.ok(g.state.ending);const before=g.exportSave();
  assert.equal(g.trade('personal','sample','buy',1).ok,false);assert.equal(g.spend('repay',1).ok,false);assert.equal(g.advance().ok,false);
  assert.equal(g.exportSave(),before);
});
