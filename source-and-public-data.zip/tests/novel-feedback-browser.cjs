/* Run through playwright-cli run-code --filename against an already-open
 * local index/preview. Two independent mobile contexts; no product writes.
 * Checks pixels' stacking order, native picker/download, and quota messaging. */
async (page) => {
  const sourceUrl=page.url(), browser=page.context().browser(), reports=[];
  if(!sourceUrl.startsWith('file:'))throw Error('Open the local candidate HTML first.');
  for(const fallback of [false,true]){
    const context=await browser.newContext({viewport:{width:390,height:844},isMobile:true,hasTouch:true,deviceScaleFactor:2,acceptDownloads:true});
    const checks=[],errors=[];
    const check=(condition,message)=>{checks.push({message,passed:!!condition});if(!condition)throw Error(message);};
    try{
      if(fallback)await context.addInitScript(()=>{delete HTMLDialogElement.prototype.showModal;delete HTMLDialogElement.prototype.close;});
      const p=await context.newPage();p.on('pageerror',e=>errors.push(String(e)));
      await p.goto(sourceUrl);await p.waitForFunction(()=>window.__novelMounted===true);
      await p.getByRole('button',{name:/给自己留点余地/}).click();
      await p.getByRole('button',{name:'存档',exact:true}).click();
      const chooserPromise=p.waitForEvent('filechooser');
      await p.getByRole('button',{name:'导入存档文件',exact:true}).click();
      const chooser=await chooserPromise;await chooser.setFiles({name:'invalid.json',mimeType:'application/json',buffer:Buffer.from('{broken')});
      await p.waitForFunction(()=>document.getElementById('novel-dialog-feedback').textContent.includes('导入未完成'));
      await p.evaluate(()=>new Promise(resolve=>requestAnimationFrame(()=>requestAnimationFrame(resolve))));
      const feedback=await p.evaluate(()=>{
        const e=document.getElementById('novel-dialog-feedback'),d=document.getElementById('novel-dialog'),r=e.getBoundingClientRect();
        const title=document.getElementById('novel-dialog-title'),close=d.querySelector('[data-action="close"]'),tr=title.getBoundingClientRect(),cr=close.getBoundingClientRect();
        return {text:e.textContent,hidden:e.hidden,role:e.getAttribute('role'),live:e.getAttribute('aria-live'),rect:r.toJSON(),inDialog:d.contains(e),nativeModal:d.matches(':modal'),visible:r.top>=0&&r.bottom<=innerHeight&&r.width>0&&r.height>0,topmost:e.contains(document.elementFromPoint(r.x+r.width/2,r.y+r.height/2)),globalSuppressed:document.getElementById('novel-toast').getAttribute('aria-hidden')==='true',titleRect:tr.toJSON(),closeRect:cr.toJSON(),titleVisible:tr.top>=0&&tr.bottom<=innerHeight&&title.contains(document.elementFromPoint(tr.x+tr.width/2,tr.y+tr.height/2)),closeVisible:cr.top>=0&&cr.bottom<=innerHeight&&close.contains(document.elementFromPoint(cr.x+cr.width/2,cr.y+cr.height/2))};
      });
      check(feedback.visible&&feedback.topmost&&feedback.inDialog&&!feedback.hidden,'Invalid import feedback is actually exposed above the modal body at mobile size');
      check(feedback.role==='status'&&feedback.live==='polite'&&feedback.globalSuppressed,'One accessible status region carries modal feedback');
      check(feedback.nativeModal!==fallback,'Expected native/fallback dialog exercised');
      check(feedback.titleVisible&&feedback.closeVisible&&feedback.closeRect.width>=44&&feedback.closeRect.height>=44,'Scrolled modal keeps title visible and its full 44px close control touchable after feedback expands');
      await p.screenshot({path:'output/playwright/ux-feedback-'+(fallback?'fallback':'native')+'.png'});
      check(await p.locator('#novel-dialog-feedback').getAttribute('tabindex')===null,'Feedback does not add a Tab stop');
      await p.getByRole('button',{name:'关闭弹窗',exact:true}).click();
      check(await p.locator('#novel-toast').evaluate(e=>e.classList.contains('is-visible')&&!e.hasAttribute('aria-hidden')&&e.textContent.includes('导入未完成')),'Closing modal carries unexpired feedback back to the page');
      await p.getByRole('button',{name:'存档',exact:true}).click();
      check(await p.locator('#novel-dialog-feedback').evaluate(e=>!e.hidden&&e.textContent.includes('导入未完成')),'Reopening modal retains unexpired feedback');
      const downloading=p.waitForEvent('download');await p.getByRole('button',{name:'导出当前人生',exact:true}).click();const download=await downloading;
      check(await download.failure()===null,'Actual download still completes from open modal');
      const stream=await download.createReadStream(),chunks=[];for await(const chunk of stream)chunks.push(chunk);const raw=Buffer.concat(chunks);
      check(await p.evaluate(s=>Novel.validateSave(s).ok,raw.toString()),'Downloaded save remains valid');
      check((await p.locator('#novel-dialog-feedback').innerText()).includes('已准备存档文件'),'Download confirmation appears inside modal');
      await p.locator('#novel-import').setInputFiles({name:'valid.json',mimeType:'application/json',buffer:raw});
      check(await p.locator('#novel-dialog-feedback').evaluate(e=>!e.hidden&&e.textContent.includes('已准备存档文件')),'Dialog content replacement retains unexpired feedback');
      await p.getByRole('button',{name:'确认读取',exact:true}).click();
      check(await p.locator('#novel-dialog').evaluate(d=>!d.hasAttribute('open')),'Confirmed import closes the dialog');
      check(await p.locator('[data-action="choose"]').count()===3,'Confirmed import restores the story choices');
      await p.evaluate(()=>{const original=Storage.prototype.setItem;Storage.prototype.setItem=function(k,v){if(k==='unrealized-life-novel:v1:slot1')throw new DOMException('QA_INJECT_MANUAL_QUOTA','QuotaExceededError');return original.call(this,k,v);};});
      await p.getByRole('button',{name:'存档',exact:true}).click();
      await p.locator('[data-action="save"][data-slot="slot1"]').click();
      check((await p.locator('#novel-dialog-feedback').innerText()).includes('QA_INJECT_MANUAL_QUOTA'),'Manual-only persistence failure exercised');
      await p.getByRole('button',{name:'关闭弹窗',exact:true}).click();
      await p.getByRole('button',{name:'打开封面',exact:true}).click();
      check((await p.locator('.confirm-copy').innerText()).includes('已经自动保存'),'Manual slot failure does not falsely invalidate the successful automatic save');
      await p.getByRole('button',{name:'再想一下',exact:true}).click();
      await p.evaluate(()=>{window.__uxDiskBefore=localStorage.getItem('unrealized-life-novel:v1:auto');const original=Storage.prototype.setItem;Storage.prototype.setItem=function(k,v){if(String(k).startsWith('unrealized-life-novel:'))throw new DOMException('QA_INJECT_QUOTA','QuotaExceededError');return original.call(this,k,v);};});
      await p.locator('[data-action="choose"]').first().click();
      check(await p.locator('#novel-toast').getAttribute('aria-hidden')===null,'Outside-modal errors return to the ordinary accessible toast');
      await p.getByRole('button',{name:'打开封面',exact:true}).click();
      const home=await p.locator('#novel-dialog-content').innerText();
      check(home.includes('本页临时保留')&&!home.includes('已经自动保存'),'Home confirmation reports temporary progress after persistence failure');
      check(await p.evaluate(()=>localStorage.getItem('unrealized-life-novel:v1:auto')===window.__uxDiskBefore),'Quota failure preserves original disk bytes');
      check(errors.length===0,'No uncaught browser errors');
      reports.push({mode:fallback?'fallback':'native',checks,feedback});
    }finally{await context.close();}
  }
  return {reports,assertions:reports.reduce((sum,r)=>sum+r.checks.length,0)};
}
