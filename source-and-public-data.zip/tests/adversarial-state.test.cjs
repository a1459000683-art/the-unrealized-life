'use strict';
// Adversarial gameplay against the actual retained market/story snapshot.
// These are engine runs, not a claim of physical-phone or visual UX coverage.
const {test}=require('node:test');
const assert=require('node:assert/strict');
const fs=require('node:fs');
const path=require('node:path');
const vm=require('node:vm');
const crypto=require('node:crypto');
const root=path.resolve(__dirname,'..');
const source=Object.fromEntries(['finance','story','game'].map(x=>[x,fs.readFileSync(path.join(root,'src',x+'.js'),'utf8')]));
const marketText=fs.readFileSync(path.join(root,'data/market.json'),'utf8');
function fixture(start='buffer',sector='industrial',seed=2000){
 const context=vm.createContext({console});
 context.MARKET=JSON.parse(marketText);
 for(const name of ['finance','story','game'])vm.runInContext(source[name],context,{filename:name+'.js'});
 return {context,g:new context.Game(start,sector,seed),Game:context.Game,Finance:context.Finance,market:context.MARKET,story:context.STORY};
}
const thesis={why:'公开资料支持经营判断',risk:'需求下降与现金流恶化',horizon:'三年',invalidation:'出现连续经营亏损'};
const snapshot=g=>g.exportSave();
const edited=(g,edit)=>{const raw=JSON.parse(snapshot(g));edit(raw.state);return JSON.stringify(raw);};
function respond(g,select=()=>0){if(!g.state.resolved){const event=g.event();const choice=select(event,g);assert.equal(g.choose(choice).ok,true,event.id+' / '+choice);}}
function until(g,date){let guard=0;while(g.state.date<date){assert.ok(guard++<60);respond(g);assert.equal(g.advance().ok,true);}}
function check(g,Game){
 for(const account of ['client','personal']){
  const result=g._stats(account);assert.equal(result.ok,true);assert.ok(Number.isFinite(result.nav)&&result.nav>=-0.001);
  assert.ok(Math.abs(result.reconciliationError)<Math.max(0.01,result.nav*1e-9),account+' reconciliation '+result.reconciliationError);
 }
 const result=Game.validateSave(snapshot(g));assert.equal(result.ok,true,result.error);
 assert.equal(snapshot(Game.fromSave(snapshot(g))),snapshot(g),'valid save round-trip must preserve complete state');
}
function maxBuy(g,account,id){
 const c=g.company(id);if(!c?.tradable)return false;
 if(!g.state.theses[id])assert.equal(g.setThesis(id,thesis).ok,true);
 if(account==='client'){
  if(!g.state.research[id])g.researchCompany(id,'cashflow');
  if(!g.propose(id).ok)return false;
 }
 let lo=0,hi=g.state[account].cash/c.price;
 for(let n=0;n<42;n++){const q=(lo+hi)/2;if(g.previewTrade(account,id,'buy',q).ok)lo=q;else hi=q;}
 if(lo<0.00001)return false;return g.trade(account,id,'buy',lo*.999).ok;
}

test('failed cash flows cannot erase debt or partially settle a story/month',()=>{
 for(const action of ['repay','choice','advance']){
  const {g,Game,Finance,context}=fixture('debt');if(action==='advance')respond(g);
  const before=snapshot(g),original=Finance.flow;
  context.Finance={...Finance,flow:()=>({ok:false,error:'injected settlement rejection',code:'precision_limit'})};
  const result=action==='repay'?g.spend('repay',100):action==='choice'?g.choose('c00_1'):g.advance();
  assert.equal(result.ok,false,action);assert.equal(snapshot(g),before,action+' must roll back all effects');
  context.Finance=Finance;check(g,Game);
  const control=Game.fromSave(before);
  const run=x=>action==='repay'?x.spend('repay',100):action==='choice'?x.choose('c00_1'):x.advance();
  assert.equal(run(g).ok,true);assert.equal(run(control).ok,true);assert.equal(snapshot(g),snapshot(control));
 }
});

test('post-trade/repayment valuation rejection restores cash, debt, positions and records',()=>{
 for(const action of ['trade','repay']){
  const {g,Game,Finance,context}=fixture();g.setThesis('HEI',thesis);const before=snapshot(g);
  context.Finance={...Finance,mark:()=>({ok:false,error:'injected valuation rejection',code:'numeric_limit'})};
  const run=x=>action==='trade'?x.trade('personal','HEI','buy',1):x.spend('repay',100);
  assert.equal(run(g).ok,false);assert.equal(snapshot(g),before,action+' must not leave partial money changes');
  context.Finance=Finance;assert.equal(run(g).ok,true);check(g,Game);
 }
});

test('accepted extreme v1 account rejects unrepresentable repayment and rolls back partial advancement',()=>{
 const {g,Game,Finance}=fixture();g.state.personal=Finance.createAccount(1e14,g.state.date);respond(g);check(g,Game);
 const before=snapshot(g);const repayment=g.spend('repay',0.005);
 assert.equal(repayment.ok,false);assert.equal(snapshot(g),before,'rejected debit must not reduce debt');
 const advance=g.advance();assert.equal(advance.ok,false);assert.match(advance.error,/进度保持原样/);assert.equal(snapshot(g),before,'fees/date/actions must roll back when salary cannot be credited');
});

test('prototype names are not sectors, careers or contact choices',()=>{
 const {g,Game}=fixture();for(const key of ['constructor','__proto__','toString']){
  assert.throws(()=>new Game('buffer',key));const before=snapshot(g);
  assert.equal(g.spend('contact',key).ok,false);assert.equal(g.spend('transfer',key).ok,false);assert.equal(snapshot(g),before);
 }
});

test('micro-trade churn cannot manufacture discipline or authority',()=>{
 const {g}=fixture();assert.equal(g.setThesis('HEI',thesis).ok,true);
 const discipline=g.state.stats.discipline,authority=g.state.authority,initial=g.state.personal.cash;
 for(let n=0;n<30;n++){assert.equal(g.trade('personal','HEI','buy',0.01).ok,true);assert.equal(g.trade('personal','HEI','sell',0.01).ok,true);}
 assert.equal(g.state.stats.discipline,discipline);assert.equal(g.state.authority,authority);
 assert.ok(g.state.personal.cash<initial,'round trips must pay actual fees');
});

test('import rejects rendering and settlement hazards before replacing a slot',()=>{
 const {g,Game}=fixture();const before=snapshot(g);
 const attacks=[
  ['prototype sector',s=>{s.sector='constructor';}],
  ['prototype career',s=>{s.career='constructor';s.careerHistory.at(-1).career='constructor';}],
  ['missing benchmark history',s=>{delete s.benchmarkHistory;}],
  ['bad benchmark date',s=>{s.benchmarkHistory=[{date:'tomorrow',value:1}];}],
  ['bad redemption string',s=>{s.redemptionDue='broken';}],
  ['negative redemption',s=>{s.redemptionDue=-1;}],
  ['fractional time',s=>{s.actionPoints=0.5;}],
  ['overflow seed',s=>{s.seed=2**32;}],
  ['extra relation',s=>{s.relations.invented=1;}],
  ['invalid exit company',s=>{s.memory.push({date:s.date,title:'exit',text:'x',companyId:'missing',account:'personal',exitQuantity:1,exitPrice:1,exitProceeds:1,exitDate:s.date});}],
  ['missing exit proceeds',s=>{s.memory.push({date:s.date,title:'exit',text:'x',companyId:'HEI',account:'personal',exitQuantity:1,exitPrice:1,exitDate:s.date});}],
  ['false resolved event',s=>{s.resolved=true;}],
  ['invalid end record',s=>{s.ending={id:'open_ledger',date:s.date,title:'x',text:'x'};}]
 ];
 for(const [name,edit]of attacks){assert.equal(Game.validateSave(edited(g,edit)).ok,false,name);assert.throws(()=>Game.fromSave(edited(g,edit)),undefined,name);assert.equal(snapshot(g),before);}
});

test('delayed effects import rejects malformed flags, roles, relations and text',()=>{
 const {g,Game}=fixture();assert.equal(g.choose('b00_2').ok,true);assert.equal(g.state.pending.length,1);
 const attacks=[p=>{p.effects.removeFlags=5;},p=>{p.effects.flags={a:1};},p=>{p.effects.career=[];},p=>{p.effects.relations={missing:5};},p=>{p.text={nested:'x'};},p=>{p.flag={nested:'x'};},p=>{delete p.originTitle;}];
 for(const edit of attacks)assert.equal(Game.validateSave(edited(g,s=>edit(s.pending[0]))).ok,false);
});

test('rehiring immediately clears current unemployment and replaces a pending unemployment scene',()=>{
 for(const rehireBeforeScene of [true,false]){
  const {g,Game}=fixture();until(g,'2008-07-01');assert.equal(g.choose(1).ok,true);assert.equal(g.state.career,'unemployed');
  if(!rehireBeforeScene){while(g.state.date<'2009')assert.equal(g.advance().ok,true);assert.equal(g.event().id,'c18');}
  assert.equal(g.spend('job').ok,true);assert.equal(g.state.career,'senior');assert.equal(g.state.flags.includes('unemployed_now'),false);
  if(rehireBeforeScene)while(g.state.date<'2009')assert.equal(g.advance().ok,true);
  assert.notEqual(g.event()?.id,'c18');check(g,Game);
  const legacy=edited(g,s=>{s.flags.push('unemployed_now');});
  const loaded=Game.fromSave(legacy);assert.equal(loaded.state.flags.includes('unemployed_now'),false,'old v1 career marker is safely normalized');
 }
});

test('import rejects an event from the wrong period and mutually exclusive histories',()=>{
 const {g,Game}=fixture();until(g,'2002');
 assert.equal(Game.validateSave(edited(g,s=>{s.eventId='c00';s.resolved=false;})).ok,false);
 assert.equal(Game.validateSave(edited(g,s=>{s.seen.push('c00');s.choices++;})).ok,false);
});

test('repeated decisions and save/load cannot settle a delayed promise twice',()=>{
 const {g,Game}=fixture();assert.equal(g.choose('b00_2').ok,true);
 const chosen=snapshot(g);assert.equal(g.choose('b00_2').ok,false);assert.equal(snapshot(g),chosen);
 until(g,'2004-12-31');respond(g);const loaded=Game.fromSave(snapshot(g));
 while(g.state.date<'2006'){respond(g);respond(loaded);assert.equal(g.advance().ok,true);assert.equal(loaded.advance().ok,true);assert.equal(snapshot(g),snapshot(loaded));}
 assert.equal(g.state.memory.filter(m=>m.delayed&&m.origin==='b00').length,1);
 assert.equal(g.state.pending.filter(p=>p.origin==='b00').length,0);
 check(g,Game);
});

test('independent save slots never share nested ledgers, promises, research or memories',()=>{
 const {g,Game}=fixture();g.choose('b00_2');const saved=snapshot(g),first=Game.fromSave(saved),second=Game.fromSave(saved);
 first.setThesis('HEI',thesis);first.trade('personal','HEI','buy',1);first.researchCompany('HEI');first.spend('contact','nora');first.advance();
 assert.equal(snapshot(g),saved);assert.equal(snapshot(second),saved);assert.equal(first.state.personal.positions.HEI.quantity,1);
 check(first,Game);check(second,Game);
});

test('view, research, reload and seed variation never regenerate historical market prices',()=>{
 const a=fixture('buffer','industrial',1),b=fixture('buffer','industrial',4294967295);
 const hash=()=>crypto.createHash('sha256').update(JSON.stringify(a.market)).digest('hex');const before=hash();
 for(let n=0;n<7;n++){
  for(const c of a.market.companies)assert.equal(a.g.company(c.id).price,b.g.company(c.id).price);
  a.g.view();a.g.view();a.g.researchCompany('HEI',['cashflow','debt','valuation'][n%3]);a.g= a.Game.fromSave(snapshot(a.g));
  respond(a.g);respond(b.g);a.g.advance();b.g.advance();
 }
 assert.equal(hash(),before);
});

const summaries=[];
for(const route of ['cautious-cash','concentrated-volatility','life-career-change'])test('complete 2000–2020 route: '+route,()=>{
 const {g,Game}=fixture(route==='life-career-change'?'debt':'buffer',route==='concentrated-volatility'?'consumer':'industrial',73013);
 let decisions=0,advances=0,buys=0,sells=0,blocked=0,roundtrips=0;
 while(!g.state.ending){
  if(!g.state.resolved){
   const event=g.event();let choice=0;
   if(route==='life-career-change'){
    const picks={c00:2,b00:1,b17:1,c17:1,c18:1,b18:1,b24:2,c24:2,c31:0,b35:2,c35:2,c10:0,c32:0};
    choice=picks[event.id]??event.choices.findIndex(c=>c.available&&((c.effects?.health||0)>0||(c.effects?.freedom||0)>0));if(choice<0)choice=0;
   }else if(route==='concentrated-volatility'){
    const picks={b17:0,c17:0,b24:1,c24:0,b35:0,c35:1};
    choice=picks[event.id]??0;
   }
   respond(g,()=>choice);decisions++;
   const saved=snapshot(g);assert.equal(g.choose(choice).ok,false);assert.equal(snapshot(g),saved);
  }
  if(route==='concentrated-volatility'){
   const id='THO';
   if(g.state.stage%6===4){for(const account of ['client','personal']){const p=g.state[account].positions[id];if(p?.quantity>0){const r=g.trade(account,id,'sell',p.quantity*.25);if(r.ok)sells++;else blocked++;}}}
   for(const account of ['client','personal'])if(maxBuy(g,account,id))buys++;else blocked++;
  }
  if(route==='life-career-change'&&g.state.debt>0&&g.state.personal.cash>g.state.debt+25000)assert.equal(g.spend('repay',g.state.debt).ok,true);
  // Distinct, ordinary player time allocations; no test-only state edits.
  while(g.state.actionPoints>0){const r=route==='concentrated-volatility'&&g.state.actionPoints>1?g.spend('contact','june'):g.spend('rest');assert.equal(r.ok,true);}
  check(g,Game);roundtrips++;
  if(route==='life-career-change'&&['outside','unemployed'].includes(g.state.career)){
   const before=snapshot(g);assert.equal(g.trade('client','HEI','buy',1).ok,false);assert.equal(g.trade('client','HEI','sell',1).ok,false);assert.equal(snapshot(g),before);
  }
  assert.ok(advances++<60);assert.equal(g.advance().ok,true);
 }
 check(g,Game);
 const end=snapshot(g);
 for(const action of [()=>g.choose(0),()=>g.advance(),()=>g.researchCompany('HEI'),()=>g.setThesis('HEI',thesis),()=>g.propose('HEI'),()=>g.trade('personal','HEI','buy',1),()=>g.trade('client','HEI','sell',1),()=>g.spend('rest'),()=>g.spend('repay',1)])assert.equal(action().ok,false);
 assert.equal(snapshot(g),end);
 assert.equal(g.state.date,'2020-12-31');assert.equal(decisions,42);assert.equal(advances,53);assert.equal(g.state.review.length,52);
 if(route==='cautious-cash')assert.equal(Object.keys(g.state.client.positions).length,0);
 if(route==='concentrated-volatility'){assert.ok(buys>20);assert.ok(sells>5);}
 if(route==='life-career-change'){assert.equal(g.state.career,'outside');assert.ok(g.state.flags.includes('job_lost'));assert.ok(g.state.flags.includes('outside_confirmed'));}
 const summary={route,date:g.state.date,decisions,advances,roundtrips,buys,sells,blocked,ending:g.state.ending.id,career:g.state.career,clientNav:g._stats('client').nav,personalNetWorth:g._stats('personal').nav-g.state.debt,clientTwr:g._stats('client').twr};summaries.push(summary);console.log('ROUTE_EVIDENCE '+JSON.stringify(summary));
});

test('seeded adversarial command sequences keep ledger conservation and denied-action atomicity',()=>{
 const {g,Game}=fixture('network','consumer',9138);let rng=57299,steps=0,denied=0,successfulTrades=0;
 const next=()=>{rng=(Math.imul(rng,1664525)+1013904223)>>>0;return rng>>>8;};
 while(!g.state.ending){
  for(let n=0;n<10;n++){
   const company=['THO','HEI','PIR'][next()%3],account=next()%2?'client':'personal',op=next()%8;
   const quantity=[-1,0,NaN,Infinity,1e30,1e-15,1,10.125][next()%8];
   const before=snapshot(g);let result;
   if(op===0)result=g.trade(account,company,'buy',quantity);
   else if(op===1)result=g.trade(account,company,'sell',quantity);
   else if(op===2)result=g.setThesis(company,thesis);
   else if(op===3)result=g.researchCompany(company,['cashflow','debt','valuation','bad'][next()%4]);
   else if(op===4)result=g.propose(company);
   else if(op===5)result=g.spend('repay',quantity);
   else if(op===6)result=g.spend('rest');
   else result=g.trade('firm',company,'buy',1);
   if(result.ok&&(op===0||op===1))successfulTrades++;
   if(!result.ok){denied++;assert.equal(snapshot(g),before,'denied operation '+op+' mutated state');}
   steps++;
   for(const account of ['client','personal'])assert.ok(Math.abs(g._stats(account).reconciliationError)<.01);
  }
  respond(g);check(g,Game);assert.equal(g.advance().ok,true);
 }
 assert.equal(steps,530);assert.ok(denied>100&&denied<steps-50);assert.ok(successfulTrades>0);console.log('RANDOM_COMMAND_EVIDENCE '+JSON.stringify({seed:57299,steps,denied,successfulTrades,date:g.state.date}));
});
