'use strict';
// Independent integration audit against the retained source responses. This
// checks dataset construction and ledger arithmetic, not independent exchange
// certification of the upstream vendor's historical records.
const {test,after}=require('node:test');
const assert=require('node:assert/strict');
const fs=require('node:fs');
const path=require('node:path');
const crypto=require('node:crypto');
const Finance=require('../src/finance.js');
const MARKET=JSON.parse(fs.readFileSync(path.join(__dirname,'../data/market.json'),'utf8'));
const report={basis:MARKET.basis,verifiedAgainst:'retained Yahoo chart source JSON; published PIR SEC cancellation record',checks:[],holdings:[],reinvestment:[]};
const near=(a,b,tol=1e-7)=>assert.ok(Math.abs(a-b)<=tol*Math.max(1,Math.abs(b)),`${a} != ${b}`);
const dateOf=t=>new Date(t*1000).toISOString().slice(0,10);
const readRaw=ticker=>JSON.parse(fs.readFileSync(path.join(__dirname,'../data/raw',ticker+'.json'),'utf8')).chart.result[0];
const correction=JSON.parse(fs.readFileSync(path.join(__dirname,'../data/cbu-dividend-correction.json'),'utf8'));
const cbuEvidence=JSON.parse(fs.readFileSync(path.join(__dirname,'../data/cbu-numeric-evidence.json'),'utf8'));
const excludedDates=c=>MARKET.dataCorrections?.find(x=>x.company===c.id)?.excludedYahooDividendDates||[];
const correctedActions=(c,raw)=>raw.actions.filter(a=>!(a.type==='dividend'&&excludedDates(c).includes(a.date)));
function normalize(raw){
 const splits=Object.values(raw.events?.splits||{}).map(s=>({date:dateOf(s.date),ratio:s.numerator/s.denominator})).sort((a,b)=>a.date.localeCompare(b.date));
 const factor=date=>splits.filter(s=>s.date>date).reduce((r,s)=>r*s.ratio,1);
 const rows=raw.timestamp.map((t,i)=>({date:dateOf(t),close:raw.indicators.quote[0].close[i],adj:raw.indicators.adjclose?.[0].adjclose[i]})).filter(r=>Number.isFinite(r.close));
 const closeByDate=new Map(rows.map(r=>[r.date,r.close*factor(r.date)]));
 const adjByDate=new Map(rows.map(r=>[r.date,r.adj]));
 const actions=[...splits.map(s=>({...s,type:'split'})),...Object.values(raw.events?.dividends||{}).map(d=>({date:dateOf(d.date),amount:d.amount*factor(dateOf(d.date)),type:'dividend'}))].sort((a,b)=>a.date.localeCompare(b.date)||(a.type==='split'?-1:1));
 return{factor,rows,closeByDate,adjByDate,actions};
}
const full=MARKET.companies.filter(c=>c.id!=='PIR');
function verifyCbuPortableEvidence(){
 const hashes={
  'CBU-2001-10K':'f851272ae65c218a9ff541710a41bb6db7668f2fd6a73295ab065659d73399f8',
  'CBU-2001-Q3':'f2920545537d04867149a110ec95a9e7bf45f7bd3261890d1155a5e12fd25835',
  'CBU-2015-10K':'4ac4ad33dc9bfff7efe119c100d3769493ed488fff217564c9ea3647c6a13a7d',
  'CBU-2016-10K':'6f7e62a28ba3c33349ebff022abd8dde4973345d3e43bd1a19053cb0b7a065bc'
 };
 assert.equal(cbuEvidence.schemaVersion,1);assert.equal(cbuEvidence.symbol,'CBU');assert.equal(cbuEvidence.sources.length,4);
 for(const s of cbuEvidence.sources){
  assert.equal(s.sourceSha256,hashes[s.id],'source hash identity changed');
  assert.match(s.sourceUrl,/^https:\/\/www\.sec\.gov\/Archives\/edgar\/data\/723188\//);
  assert.ok(Number.isInteger(s.sourceBytes)&&s.sourceBytes>0);assert.ok(s.locator&&Object.keys(s.locator).length);
  const original=path.join(__dirname,'..',s.localPath),present=fs.existsSync(original);
  if(present){const bytes=fs.readFileSync(original);assert.equal(bytes.length,s.sourceBytes);assert.equal(crypto.createHash('sha256').update(bytes).digest('hex'),s.sourceSha256);}
  report.checks.push({id:s.id,source:s.sourceUrl,sourceSha256:s.sourceSha256,numericalEvidence:'data/cbu-numeric-evidence.json',fullTextVerification:present?'original_bytes_sha256_verified':'original_text_not_distributed; numerical_extract_and_pinned_source_hash_checked',limitation:present?null:'Absent original bytes cannot be rehashed in this distribution; annual/quarterly numerical checks remain mandatory.'});
 }
 const annual=cbuEvidence.sources.find(s=>s.id==='CBU-2001-10K').values;
 const quarterly=cbuEvidence.sources.find(s=>s.id==='CBU-2001-Q3').values;
 assert.deepEqual(annual.quarterlyDpsQ1ToQ4,[0.27,0.27,0.27,0.27]);near(annual.annualDps,1.08);
 near(annual.quarterlyDpsQ1ToQ4.reduce((s,n)=>s+n,0),annual.annualDps);
 near(quarterly.quarterDps,annual.quarterlyDpsQ1ToQ4[2]);near(quarterly.nineMonthDps,0.81);
 assert.deepEqual(annual.quarterlyDpsQ1ToQ4,correction.verified.quarterlyAmounts2001);
 near(annual.annualDps,correction.verified.fullYearDividendPerThenOutstandingShare);
}
test('complete source-backed stock universe spans at least 15 years and 16 companies',()=>{
 assert.ok(MARKET.companies.length>=16);assert.ok(full.length>=15);
 assert.ok((Date.parse(MARKET.dates.at(-1))-Date.parse(MARKET.dates[0]))/864e5>=15*365);
 assert.equal(MARKET.basisType,'raw_close');
});
for(const c of full){
 test(c.id+': raw quote restoration, action completeness and 21-year cash-dividend holdings reconcile',()=>{
  const raw=normalize(readRaw(c.ticker));const from=c.prices[0].date,to=c.prices.at(-1).date;
  for(const row of c.prices){assert.ok(raw.closeByDate.has(row.date),'unverified price date '+row.date);near(row.close,raw.closeByDate.get(row.date),5e-7);}
  const expectedActions=correctedActions(c,raw).filter(a=>a.date>from&&a.date<=to);
  const actual=c.actions.filter(a=>a.date>from&&a.date<=to&&!a.informational&&!a.appliedInSeries);
  assert.equal(actual.length,expectedActions.length,'not all source corporate actions are represented');
  for(let i=0;i<actual.length;i++){
   assert.equal(actual[i].date,expectedActions[i].date);assert.equal(actual[i].type,expectedActions[i].type);
   if(actual[i].type==='split')near(actual[i].ratio,expectedActions[i].ratio);
   else near(actual[i].amount,expectedActions[i].amount,1e-7);
  }
  const initialShares=100,initial=initialShares*c.prices[0].close,a=Finance.createAccount(initial,from);
  assert.equal(Finance.buy(a,{id:c.id,date:from,price:c.prices[0].close,quantity:initialShares}).ok,true);
  let shares=initialShares,dividends=0,sourceIndex=0;
  for(const point of c.prices.slice(1)){
   while(sourceIndex<actual.length&&actual[sourceIndex].date<=point.date){const e=actual[sourceIndex++];assert.equal(Finance.action(a,{...e,companyId:c.id}).ok,true);}
   assert.equal(Finance.mark(a,point.date,{[c.id]:point.close}).ok,true);
  }
  for(const e of expectedActions){if(e.type==='split')shares*=e.ratio;else dividends+=shares*e.amount;}
  near(a.positions[c.id].quantity,shares,1e-7);near(a.cash,dividends,2e-7);
  const value=shares*c.prices.at(-1).close+dividends,s=Finance.stats(a,{[c.id]:c.prices.at(-1).close},to);
  near(s.nav,value);near(s.profit,value-initial);near(s.reconciliationError,0,1e-7);near(s.twr,value/initial-1,1e-7);
  report.holdings.push({id:c.id,from,to,initialCash:initial,initialShares,endingShares:shares,cashDividends:dividends,endingValue:s.nav,cumulativeReturn:s.twr,actions:actual.length,checkedQuotes:c.prices.length,maxDrawdown:s.maxDrawdown});
 });
 test(c.id+(c.id==='CBU'?': SEC-corrected dividends replace documented source errors; polluted adjusted close is not a reference':': source daily dividend-reinvestment path stays close to source adjusted-close ratio'),()=>{
  const n=normalize(readRaw(c.ticker)),from=c.prices[0].date,to=c.prices.at(-1).date;
  const rawFirst=n.closeByDate.get(from),rawLast=n.closeByDate.get(to);
  let shares=1000/rawFirst,cash=0;
  const actions=correctedActions(c,n).filter(a=>a.date>from&&a.date<=to);
  for(const e of actions){
   if(e.type==='split')shares*=e.ratio;
   else{cash+=shares*e.amount;const px=n.closeByDate.get(e.date);assert.ok(px>0,'dividend ex-date quote missing');shares+=cash/px;cash=0;}
  }
  const reinvestedRatio=(shares*rawLast+cash)/1000,adjustedRatio=n.adjByDate.get(to)/n.adjByDate.get(from);
  const relativeDifference=reinvestedRatio/adjustedRatio-1;
  if(c.id==='CBU'){
   verifyCbuPortableEvidence();
   assert.deepEqual(excludedDates(c),['2001-09-12','2015-05-13','2016-08-10']);
   const facts=JSON.parse(fs.readFileSync(path.join(__dirname,'../data/raw/CBU-companyfacts.json'),'utf8')).facts['us-gaap'].CommonStockDividendsPerShareDeclared.units['USD/shares'];
   for(const y of correction.additionalAnnualCorrections){
    const firstFiled=facts.filter(f=>f.start===y.year+'-01-01'&&f.end===y.year+'-12-31'&&f.form==='10-K').sort((a,b)=>a.filed.localeCompare(b.filed))[0];
    assert.ok(firstFiled);near(firstFiled.val,y.verifiedAnnualDividendPerShare);assert.equal(firstFiled.accn,y.accession);
    const total=actions.filter(a=>a.type==='dividend'&&a.date.startsWith(String(y.year))).reduce((s,a)=>s+a.amount,0);
    const evidence=cbuEvidence.sources.find(s=>s.values.year===y.year);
    assert.ok(evidence);assert.equal(evidence.sourceUrl,y.source);assert.equal(evidence.locator.accession,y.accession);
    near(total,firstFiled.val);near(evidence.values.annualDps,firstFiled.val);
    assert.deepEqual(evidence.values.quarterlyDpsQ1ToQ4,y.verifiedQuarterlyAmounts);
    near(evidence.values.quarterlyDpsQ1ToQ4.reduce((s,n)=>s+n,0),firstFiled.val);
   }
   const annual2001=actions.filter(a=>a.type==='dividend'&&a.date.startsWith('2001')).reduce((s,a)=>s+a.amount,0);
   near(annual2001,cbuEvidence.sources.find(s=>s.id==='CBU-2001-10K').values.annualDps);assert.equal(correction.verified.exactExDatePrimaryVerified,false);
   report.reinvestment.push({id:c.id,reinvestedAtExCloseRatio:reinvestedRatio,rejectedVendorAdjustedCloseRatio:adjustedRatio,relativeDifference,referenceRejected:true,note:'Three vendor dividend rows conflict with SEC annual/quarterly amounts and are excluded. The polluted vendor adjusted-close ratio is reported only as a discrepancy, not a financial target. The retained 2001-09-17 ex-date remains vendor evidence; verified quarterly cash amount is $0.27 per then-outstanding share.'});
  }else{
   report.reinvestment.push({id:c.id,reinvestedAtExCloseRatio:reinvestedRatio,vendorAdjustedCloseRatio:adjustedRatio,relativeDifference,note:'Ex-date close reinvestment and vendor backward dividend adjustment are related but not mathematically identical conventions.'});
   assert.ok(Math.abs(relativeDifference)<0.005,`${c.id} reinvestment/adjclose divergence ${(relativeDifference*100).toFixed(4)}% exceeds 0.5% audit threshold`);
  }
 });
}
test('SPY total-return benchmark equals its retained adjusted-close source and receives no duplicate cash distributions',()=>{
 const n=normalize(readRaw('SPY')),first=n.adjByDate.get(MARKET.benchmark[0].date);
 for(const p of MARKET.benchmark)near(p.value,n.adjByDate.get(p.date)/first*100,1e-8);
 report.checks.push({id:'SPY',matchedRows:MARKET.benchmark.length,basis:'Adjusted close normalized to 100; no separately credited distributions'});
});
test('PIR old-equity cancellation preserves prior realized sale cash and unrelated money',()=>{
 const c=MARKET.companies.find(c=>c.id==='PIR'),first=c.prices[0],last=c.prices.at(-1);
 const a=Finance.createAccount(10000,first.date);Finance.buy(a,{id:c.id,date:first.date,price:first.close,quantity:100});
 Finance.sell(a,{id:c.id,date:last.date,price:last.close,quantity:25});const cash=a.cash;
 const cancellation=c.actions.find(x=>x.type==='cancel');assert.ok(cancellation);
 const settlementDate=cancellation.published>cancellation.date?cancellation.published:cancellation.date;
 Finance.action(a,{...cancellation,date:settlementDate,companyId:c.id});
 assert.equal(a.positions[c.id].quantity,0);near(a.cash,cash);near(a.positions[c.id].realized,25*last.close-100*first.close);
 const snapshot=JSON.stringify(a);assert.equal(Finance.action(a,{...cancellation,date:settlementDate,companyId:c.id}).duplicate,true);assert.equal(JSON.stringify(a),snapshot);
 report.checks.push({id:'PIR',firstKnownPrice:first.date,lastKnownPrice:last.date,effectiveCancellation:cancellation.date,disclosed:cancellation.published,settlementDate,remainingOldShares:0,cashPreserved:cash});
});
after(()=>{
 report.executedAt=new Date().toISOString();
 report.limits=['The retained vendor response is not an independent primary exchange feed.','Cash-dividend portfolios intentionally do not equal dividend-reinvestment benchmarks.','Reinvestment comparison accepts 0.5% relative convention difference and reports the actual difference. CBU vendor adjusted-close is excluded as a target because its dividend inputs contain three SEC-verified errors.','CBU 2001-Q3 amount is verified with SEC sources; its exact ex-date remains vendor evidence, with no player trading between the disputed dates.','CBU original filings are not required in redistributed source packages: mandatory numerical evidence and pinned source hashes are retained; present original bytes are SHA-256 checked, while absent bytes are explicitly reported as unavailable for rehashing.','PIR trades only at three independently evidenced quote dates; no interpolated prices.'];
 fs.writeFileSync(path.join(__dirname,'market-finance-results.json'),JSON.stringify(report,null,2)+'\n');
});
