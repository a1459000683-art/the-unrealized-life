'use strict';
// Independent novel-wrapper tests. Controlled fixtures below are NOT authored
// novel reachability witnesses and are NOT historical price evidence.
// Never writes old reports or modifies legacy production files.
const test=require('node:test'),assert=require('node:assert/strict');
const fs=require('node:fs'),path=require('node:path'),vm=require('node:vm');
const ROOT=path.resolve(__dirname,'..');
const HISTORICAL=JSON.parse(fs.readFileSync(path.join(ROOT,'data/market.json'),'utf8'));
const IDS=['lin','mara','june','elias','mei','sam','nora','darius'];
const near=(actual,expected,tolerance=1e-7)=>assert.ok(Math.abs(actual-expected)<=tolerance*Math.max(1,Math.abs(expected)),`${actual} != ${expected}`);
const copy=x=>JSON.parse(JSON.stringify(x));
function option(id='a',effects={},strategy){return{id,label:'测试选择 '+id,detail:'受控验收，不是正式剧情',effects,...(strategy?{strategy}:{}),result:{title:'已选择',text:'受控结果。'}};}
function fixture({sameDateSecond=false,firstEffects={},firstStrategy,secondStrategy,actions=[],prices,editStory,editMarket,start='buffer'}={}){
 const dates=HISTORICAL.dates.slice(),characters=IDS.map(id=>({id,name:id}));
 const market={dates,basis:'controlled fixture only',basisType:'raw_close',benchmark:dates.map(date=>({date,value:100})),companies:[{id:'HEI',ticker:'HEI',name:'Do not reveal future identity',alias:'受控匿名企业',sector:'工业',business:'受控现金流业务',listed:dates[0],prices:dates.map((date,i)=>({date,close:prices?.[i]??100})),facts:[{id:'old',kind:'financial',period:'1999-10-31',published:'1999-12-31',availableFrom:dates[0],metrics:{revenue:100,netIncome:10,ocf:11,capex:3,cash:9,debt:2,eps:1,shares:10},metricMeta:{eps:{shareBasisDate:dates[0]}}},{id:'future',kind:'financial',period:'2001-12-31',published:'2002-03-01',availableFrom:'2002-03-02',text:'INDEPENDENT_FUTURE_SENTINEL',metrics:{revenue:999999,netIncome:888888}}],actions:copy(actions),sources:[]}]};
 if(editMarket)editMarket(market);
 const story={version:1,characters,chapters:[{id:'test',title:'受控章节'}],nodes:dates.map((date,i)=>({id:'node-'+i,dateIndex:i,slot:0,chapter:'test',title:'受控场景 '+i,text:'此场景只用于结算和状态测试，不计入正式内容覆盖。',choices:[option('a',i?{}:firstEffects,i?undefined:firstStrategy),option('b')]})),endings:[{id:'ordinary',title:'受控终局',text:'受控测试完成。',requires:{}}]};
 if(sameDateSecond)story.nodes.splice(1,0,{id:'node-0-second',dateIndex:0,slot:1,chapter:'test',title:'同日第二幕',text:'日期不能因为同一天的第二幕而重复结算。',choices:[option('a',{},secondStrategy),option('b')]});
 if(editStory)editStory(story);
 const context=vm.createContext({console,MARKET:market,STORY:{characters,events:[],endings:[]},NOVEL_STORY:story});
 for(const file of ['src/finance.js','src/game.js','src/novel.js'])vm.runInContext(fs.readFileSync(path.join(ROOT,file),'utf8'),context,{filename:file});
 return{n:new context.Novel(start,2000),Novel:context.Novel,Finance:context.Finance,market,story,context};
}
function firstToken(n,index=0){const v=n.view();assert.ok(v.node,'current choice node exists');return v.node.choices[index].id;}
function choose(n,index=0){const r=n.choose(firstToken(n,index));assert.equal(r.ok,true,r.error);return r;}
function move(n){const r=n.next();assert.equal(r.ok,true,r.error);return r;}
const money=n=>JSON.stringify({client:n.core.state.client,personal:n.core.state.personal,firm:n.core.state.firm,debt:n.core.state.debt,debtLedger:n.core.state.debtLedger,salaryTotal:n.core.state.salaryTotal,bonusTotal:n.core.state.bonusTotal});

test('novel independent: same consumed choice cannot farm cash or select its old sibling',()=>{
 const {n}=fixture({sameDateSecond:true,firstEffects:{personalCash:123}}),v=n.view(),a=v.node.choices[0].id,b=v.node.choices[1].id,before=n.core.state.personal.cash;
 assert.equal(n.choose(a).ok,true);near(n.core.state.personal.cash,before+123);
 const done=n.exportSave();for(let i=0;i<100;i++)assert.equal(n.choose(i%2?a:b).ok,false);
 assert.equal(n.exportSave(),done);assert.equal(n.view().phase,'result');
});
test('novel independent: prior-node token remains invalid after next even when local option IDs repeat',()=>{
 const {n}=fixture({sameDateSecond:true}),old=firstToken(n);choose(n);move(n);const before=n.exportSave();
 assert.equal(n.view().node.id,'node-0-second');assert.notEqual(firstToken(n),old);assert.equal(n.choose(old).ok,false);assert.equal(n.exportSave(),before);
 assert.equal(n.choose('a').ok,false,'bare authored ID cannot bypass scene and revision binding');assert.equal(n.exportSave(),before);
});
test('novel independent: same-day slot and next navigation do not pay salary, fees or company actions twice',()=>{
 const {n}=fixture({sameDateSecond:true}),before=money(n);choose(n);assert.equal(money(n),before);const settled=money(n);move(n);assert.equal(money(n),settled);
 const navigated=n.exportSave();assert.equal(n.next().ok,false);assert.equal(n.exportSave(),navigated);
 choose(n);const settledLater=money(n);assert.notEqual(settledLater,before);move(n);assert.equal(money(n),settledLater);
});
test('novel independent: first historical interval independently reconciles all three cash accounts',()=>{
 const {n,market}=fixture(),p0=n.core.state.personal.cash,f0=n.core.state.firm.cash,c0=n.core.state.client.cash;
 const years=(Date.parse(market.dates[1])-Date.parse(market.dates[0]))/864e5/365.25;
 choose(n);near(n.core.state.client.cash,c0-c0*.01*years);near(n.core.state.firm.cash,f0+c0*.01*years-60000*years);
 near(n.core.state.personal.cash,p0+(60000-36000-8000*.055)*years);near(n.core.state.salaryTotal,60000*years);
});
test('novel independent: rejected scene or revision input is atomic',()=>{
 const {n}=fixture(),v=n.view(),before=n.exportSave();
 for(const args of [['not-an-option'],[v.node.choices[0].id,'wrong-node',v.revision],[v.node.choices[0].id,v.node.id,v.revision+10],['a','wrong-node',v.revision]]){
  assert.equal(n.choose(...args).ok,false);assert.equal(n.exportSave(),before);
 }
});
test('novel independent: downstream settlement failure rolls back earlier personal cash effect',()=>{
 const {n}=fixture({firstEffects:{personalCash:999}}),before=n.exportSave(),advance=n.core.advance;
 n.core.advance=()=>({ok:false,error:'independent injected settlement failure'});
 const result=n.choose(firstToken(n));assert.equal(result.ok,false);assert.equal(n.exportSave(),before);n.core.advance=advance;
 choose(n);assert.equal(n.view().phase,'result');
});
test('novel independent: reads, exports, summaries, audits and repeated restoration do not settle',()=>{
 const {n,Novel}=fixture({sameDateSecond:true,firstEffects:{personalCash:57}});choose(n);const saved=n.exportSave();
 for(let i=0;i<12;i++){n.view();n.audit();n.summary();assert.equal(n.exportSave(),saved);}
 const a=Novel.fromSave(saved),b=Novel.fromSave(a.exportSave());assert.equal(a.exportSave(),saved);assert.equal(b.exportSave(),saved);move(a);move(b);assert.equal(a.exportSave(),b.exportSave());
});
test('novel independent: novel schema strictly rejects legacy envelope, bare core and wrong game/version',()=>{
 const {n,Novel}=fixture(),before=n.exportSave();
 assert.equal(Novel.STORAGE_PREFIX,'unrealized-life-novel:v1:');
 for(const raw of [n.core.exportSave(),n.core.state,JSON.parse(n.exportSave()).state,{...JSON.parse(n.exportSave()),game:'unrealized-life'},{...JSON.parse(n.exportSave()),schemaVersion:2},'not-json']){
  assert.equal(Novel.validateSave(raw).ok,false);assert.throws(()=>Novel.fromSave(raw));assert.equal(n.exportSave(),before);
 }
});
test('novel independent: project and account audit cannot expose future facts',()=>{
 const {n}=fixture({sameDateSecond:true});n.core.state.research.HEI=['cashflow','debt','valuation','challenge'];
 assert.equal(JSON.stringify(n.view()).includes('INDEPENDENT_FUTURE_SENTINEL'),false);assert.equal(JSON.stringify(n.audit()).includes('INDEPENDENT_FUTURE_SENTINEL'),false);
 const before=n.exportSave();for(let i=0;i<5;i++){n.view();n.audit();}assert.equal(n.exportSave(),before);
});
test('novel independent: valid complete controlled career survives every result/scene round trip',()=>{
 const {n:initial,Novel,market}=fixture({sameDateSecond:true});let n=initial,decisions=0;const visited=[];
 while(n.view().phase!=='ending'&&decisions<60){
  const v=n.view();assert.ok(v.node);visited.push(v.node.id);choose(n);decisions++;
  assert.equal(Novel.validateSave(n.exportSave()).ok,true);n=Novel.fromSave(n.exportSave());const settled=money(n);move(n);assert.equal(money(n),settled);
  assert.equal(Novel.validateSave(n.exportSave()).ok,true);n=Novel.fromSave(n.exportSave());
 }
 assert.equal(n.view().phase,'ending');assert.equal(decisions,market.dates.length+1);assert.equal(new Set(visited).size,visited.length);assert.equal(n.core.state.date,market.dates.at(-1));
 const done=n.exportSave();assert.equal(n.next().ok,false);assert.equal(n.choose('a').ok,false);assert.equal(n.exportSave(),done);
});
test('novel independent: authored invest then reduce actually preserves part of position and proportional cost',()=>{
 const {n}=fixture({sameDateSecond:true,firstEffects:{researchCompany:[{companyId:'HEI',topic:'cashflow'}]},firstStrategy:{type:'invest',companyId:'HEI',account:'personal',targetPercent:10},secondStrategy:{type:'reduce',companyId:'HEI',account:'personal',targetPercent:5}});
 choose(n);const p=copy(n.core.state.personal.positions.HEI);assert.ok(p.quantity>0);assert.equal(Object.keys(n.core.state.client.positions).length,0);move(n);choose(n);
 const current=n.core.state.personal.positions.HEI;assert.ok(current.quantity>0&&current.quantity<p.quantity);near(current.cost,p.cost*current.quantity/p.quantity);
 const buys=n.core.state.personal.ledger.filter(r=>r.type==='buy'),sells=n.core.state.personal.ledger.filter(r=>r.type==='sell');assert.equal(buys.length,1);assert.equal(sells.length,1);near(sells[0].quantity,p.quantity-current.quantity);
 near(sells[0].amount,sells[0].gross-sells[0].fee);assert.equal(n.core.state.client.positions.HEI,undefined);
});
test('novel independent: repayments use personal cash only and cannot exceed debt',()=>{
 const {n}=fixture({sameDateSecond:true,firstStrategy:{type:'repay',targetPercent:100}}),beforeClient=JSON.stringify(n.core.state.client),beforeFirm=JSON.stringify(n.core.state.firm),cash=n.core.state.personal.cash,debt=n.core.state.debt;
 choose(n);near(n.core.state.personal.cash,cash-debt);assert.equal(n.core.state.debt,0);assert.equal(JSON.stringify(n.core.state.client),beforeClient);assert.equal(JSON.stringify(n.core.state.firm),beforeFirm);
});
test('novel independent: a missing exact quote cannot execute authored investment',()=>{
 const {n}=fixture({firstEffects:{researchCompany:[{companyId:'HEI',topic:'cashflow'}]},firstStrategy:{type:'invest',companyId:'HEI',account:'personal',targetPercent:10},editMarket:m=>{m.companies[0].prices=m.companies[0].prices.slice(1);}}),before=n.exportSave(),v=n.view();
 assert.equal(v.node.choices[0].available,false);assert.equal(n.choose(v.node.choices[0].id).ok,false);assert.equal(n.exportSave(),before);
});
test('novel independent: split and dividend inherited through choose settle once on preexisting shares',()=>{
 const {n,market}=fixture({sameDateSecond:true,firstEffects:{researchCompany:[{companyId:'HEI',topic:'cashflow'}]},firstStrategy:{type:'invest',companyId:'HEI',account:'personal',targetPercent:10},actions:[{id:'split-evidence',companyId:'HEI',type:'split',date:'2000-03-01',published:'2000-03-01',ratio:2},{id:'div-evidence',companyId:'HEI',type:'dividend',date:'2000-04-01',published:'2000-04-01',amount:3}],prices:[100,...HISTORICAL.dates.slice(1).map(()=>50)]});
 choose(n);const q=n.core.state.personal.positions.HEI.quantity;move(n);choose(n);
 near(n.core.state.personal.positions.HEI.quantity,q*2);near(n.core.state.personal.totals.dividends,q*2*3);
 const relevant=n.core.state.personal.ledger.filter(r=>r.type==='split'||r.type==='dividend');assert.equal(relevant.length,2);const settled=money(n);move(n);assert.equal(money(n),settled);
 assert.equal(n.core.state.date,market.dates[1]);
});
test('novel independent: malformed result rows are rejected before imported UI can consume them',()=>{
 const {n,Novel}=fixture();choose(n);const saved=JSON.parse(n.exportSave());
 assert.equal(Novel.validateSave(JSON.stringify(saved)).ok,true,'valid control must pass through the same file-import boundary');
 for(const [key,value]of [['changes',[null]],['changes',[{label:'伪金额',before:'broken',after:10,delta:10}]],['notices',[{}]],['transactions',[null]]]){
  const bad=copy(saved);bad.state.result[key]=value;assert.equal(Novel.validateSave(JSON.stringify(bad)).ok,false,`result.${key} must reject malformed rows`);
 }
});
test('novel independent: import cannot turn an ordinary early choice into an unearned death',()=>{
 const {n,Novel}=fixture({editStory:s=>s.endings.unshift({id:'life_ended',kind:'death',title:'受控死亡',text:'需要长期前因。',requires:{flagsAll:['five_prior_warnings']}})});choose(n);
 const bad=JSON.parse(n.exportSave()),s=bad.state,date=bad.core.state.date,age=bad.core.state.age;
 s.result.terminal=true;s.nextNodeId=null;s.nextGroupIndex=null;s.pendingEnding={id:'life_ended',kind:'life',title:'受控死亡',text:'需要长期前因。',date,age};
 const log=s.choiceLog.at(-1);log.endingId='life_ended';log.nextNodeId=null;log.nextGroupIndex=null;
 assert.equal(Novel.validateSave(JSON.stringify(bad)).ok,false,'must use authored ending kind and actual choice ending/requirements');
});
test('novel independent: 2020-10-09 terminal branch never advances into later disclosed PIR cancellation',()=>{
 const pir=copy(HISTORICAL.companies.find(c=>c.id==='PIR')),firstIndex=HISTORICAL.dates.indexOf(pir.prices[0].date),deathIndex=HISTORICAL.dates.indexOf('2020-10-09');
 const {n,Novel}=fixture({editMarket:m=>m.companies.push(pir),editStory:s=>{
  s.endings.unshift({id:'life_ended',kind:'death',title:'受控终止',text:'此受控节点仅检验金融终止日期。',requires:{flagsAll:['prior_warning']}});
  s.nodes[0].choices[0].effects={flags:['prior_warning']};
  s.nodes[firstIndex].choices[0].effects={researchCompany:[{companyId:'PIR',topic:'cashflow'}]};s.nodes[firstIndex].choices[0].strategy={type:'invest',companyId:'PIR',account:'personal',targetPercent:10};
  s.nodes[deathIndex].choices[0].ending='life_ended';
 }});
 for(let i=0;i<=deathIndex;i++){choose(n);move(n);}
 assert.equal(n.view().phase,'ending');assert.equal(n.core.state.date,'2020-10-09');assert.ok(n.core.state.personal.positions.PIR.quantity>0);assert.equal(n.core.state.personal.ledger.some(r=>r.type==='cancel'&&r.companyId==='PIR'),false);
 assert.ok(n.audit().personalStats.stale.includes('PIR'));assert.equal(Novel.validateSave(n.exportSave()).ok,true);
 const before=n.exportSave(),restored=Novel.fromSave(before);assert.equal(restored.choose('a').ok,false);assert.equal(restored.next().ok,false);assert.equal(restored.exportSave(),before);
});
test('novel independent: late-date save cannot invent a terminal result without an authored terminal choice',()=>{
 const {n,Novel}=fixture({editStory:s=>s.endings.unshift({id:'life_ended',kind:'death',title:'受控死亡',text:'需要长期前因。',requires:{flagsAll:['five_prior_warnings']}})});
 while(n.core.state.date<'2020-01-01'){choose(n);move(n);}
 choose(n);const saved=JSON.parse(n.exportSave());assert.equal(Novel.validateSave(JSON.stringify(saved)).ok,true);
 const s=saved.state,cs=saved.core.state;s.result.terminal=true;s.nextNodeId=null;s.nextGroupIndex=null;s.pendingEnding={id:'life_ended',kind:'death',title:'受控死亡',text:'需要长期前因。',date:cs.date,age:cs.age};
 const log=s.choiceLog.at(-1);log.endingId='life_ended';log.nextNodeId=null;log.nextGroupIndex=null;
 assert.equal(Novel.validateSave(JSON.stringify(saved)).ok,false,'an ordinary late choice cannot acquire an unearned authored death through import');
});
test('novel independent: historical choice settlement must be the real canonical destination date',()=>{
 const {n,Novel}=fixture();for(let i=0;i<3;i++){choose(n);move(n);}const good=JSON.parse(n.exportSave());assert.equal(Novel.validateSave(JSON.stringify(good)).ok,true);
 for(const invalidDate of ['2000-02-31','2000-01-04']){const bad=copy(good);bad.state.choiceLog[0].settledDate=invalidDate;assert.equal(Novel.validateSave(JSON.stringify(bad)).ok,false,'not an actual settled market destination: '+invalidDate);}
});
test('novel independent: financial fact is gated by availableFrom even when its published day is earlier',()=>{
 const marker='STRICT_AVAILABILITY_BOUNDARY', {n,market}=fixture({editMarket:m=>m.companies[0].facts.push({id:'boundary',kind:'financial',period:'1999-12-31',published:m.dates[0],availableFrom:m.dates[1],title:marker,text:marker,metrics:{revenue:123,netIncome:12,ocf:14,capex:3,cash:10,debt:1}})});
 n.core.state.research.HEI=['cashflow','debt','valuation','challenge'];const frozenMarket=JSON.stringify(market);
 assert.equal(JSON.stringify(n.audit()).includes(marker),false);choose(n);assert.equal(n.core.state.date,market.dates[1]);
 assert.equal(JSON.stringify(n.audit()).includes(marker),true);assert.equal(JSON.stringify(market),frozenMarket,'read/advance must never write a player-dependent history into market data');
});
