async (page) => {
  const sourceUrl=page.url(), browser=page.context().browser();
  const context=await browser.newContext({viewport:{width:390,height:844},isMobile:true,hasTouch:true,deviceScaleFactor:2,acceptDownloads:true});
  const p=await context.newPage(),errors=[],requests=[],trace=[];
  p.on('pageerror',e=>errors.push(String(e)));p.on('request',r=>requests.push(r.url()));
  p.setDefaultTimeout(15000);await context.setOffline(true);
  const state=()=>p.evaluate(()=>{const value=localStorage.getItem('unrealized-life-novel:v1:auto'),prefix='unrealized-life-novel:gzip-base64:v1:';return JSON.parse(value.startsWith(prefix)?fflate.strFromU8(fflate.gunzipSync(Uint8Array.from(atob(value.slice(prefix.length)),c=>c.charCodeAt(0)))):value);});
  const check=(condition,message)=>{if(!condition)throw Error(message);};
  try{
    await p.goto(sourceUrl);await p.locator('[data-action="start"][data-start="buffer"]').tap();
    const rejected=[];
    for(let i=0;i<90;i++){
      const before=await state();if(before.state.phase==='ending')break;
      check(before.state.phase==='choice','Expected a choice before each actual tap');
      const choices=await p.locator('[data-action="choose"]').evaluateAll(els=>els.map(e=>({id:e.dataset.choice,disabled:e.disabled,label:e.innerText,height:e.getBoundingClientRect().height})));
      check(choices.length>=2&&choices.length<=4,'2–4 choices on each page');
      check(choices.every(x=>x.height>=44),'Touch target must be at least 44 CSS pixels');
      const available=choices.filter(c=>!c.disabled),choice=available.find(c=>c.id==='c')||available[available.length-1];
      await p.locator('[data-action="choose"][data-choice="'+choice.id+'"]').tap();
      const after=await state(),visible=await p.locator('#novel-main').innerText();
      check(after.state.choiceCount===before.state.choiceCount+1,'Exactly one actual choice committed');
      check(!/时间加权|剔除资金进出|申请目标\s*\d|单一标的上限|使用了本阶段\s*\d+\s*次时间/.test(visible),'Professional accounting must stay collapsed in main story');
      check(await p.evaluate(()=>document.documentElement.scrollWidth<=innerWidth),'No horizontal overflow');
      trace.push({date:before.core.state.date,node:before.state.nodeId,choice:choice.id,label:choice.label,career:after.core.state.career,result:visible});
      if(i===0){
        const baseline=await p.evaluate(()=>localStorage.getItem('unrealized-life-novel:v1:auto'));
        await p.locator('[data-action="saves"]').tap();
        for(const value of ['missing',false,0,'']){
          const bad=JSON.parse(JSON.stringify(after));if(value==='missing')delete bad.state.pendingEnding;else bad.state.pendingEnding=value;
          await p.locator('#novel-import').setInputFiles({name:'pending-ending-'+String(value)+'.json',mimeType:'application/json',buffer:Buffer.from(JSON.stringify(bad))});
          await p.waitForFunction(()=>document.getElementById('novel-toast').textContent.includes('导入未完成'));
          check(await p.locator('#novel-dialog-content [data-action="confirm"]').count()===0,'Malformed ending navigation must never reach replacement confirmation');
          check(await p.evaluate(raw=>localStorage.getItem('unrealized-life-novel:v1:auto')===raw,baseline),'Rejected malformed import preserves exact disk bytes');
          rejected.push(String(value));
        }
        await p.getByRole('button',{name:'关闭弹窗',exact:true}).tap();
      }
      if(i===12||i===45){const raw=await p.evaluate(()=>localStorage.getItem('unrealized-life-novel:v1:auto'));await p.reload();await p.locator('[data-action="resume"]').tap();check(await p.evaluate(x=>localStorage.getItem('unrealized-life-novel:v1:auto')===x,raw),'Result-page refresh preserves exact compressed state');}
      if(i===20)await p.screenshot({path:'output/playwright/novel-integrated-mobile-result.png',scale:'css'});
      await p.locator('[data-action="next"]').tap();
      const immediate=await state();check(await p.evaluate(s=>Novel.validateSave(s).ok,immediate),'Immediately after next the actual saved state remains readable');
    }
    const final=await state();check(final.state.phase==='ending'&&final.state.choiceCount===77&&final.core.state.date==='2020-12-31','Full 77-choice life ends in December 2020');
    check(errors.length===0,'No uncaught page error');check(requests.every(url=>url.startsWith('file:')),'Offline play requests no remote resource');
    await p.screenshot({path:'output/playwright/novel-integrated-mobile-ending.png',scale:'css'});
    await p.locator('[data-action="saves"]').tap();
    const downloading=p.waitForEvent('download');await p.getByRole('button',{name:'导出当前人生',exact:true}).tap();const download=await downloading;await download.saveAs('output/playwright/novel-integrated-full-career-save.json');check(await download.failure()===null,'Final actual browser JSON downloaded');
    return{sourceUrl,offline:true,viewport:{width:390,height:844},engine:browser.browserType().name(),choices:final.state.choiceCount,date:final.core.state.date,ending:final.state.ending.id,career:final.core.state.career,malformedImportsRejected:rejected,resultReloads:2,immediateSaveChecks:trace.length,requests,errors,trace};
  }catch(error){
    const diagnostic=await p.evaluate(()=>{let raw=null,validation=null;try{const value=localStorage.getItem('unrealized-life-novel:v1:auto'),prefix='unrealized-life-novel:gzip-base64:v1:';raw=value&&(value.startsWith(prefix)?fflate.strFromU8(fflate.gunzipSync(Uint8Array.from(atob(value.slice(prefix.length)),c=>c.charCodeAt(0)))):value);if(raw){const v=Novel.validateSave(raw);validation={ok:v.ok,error:v.error};}}catch(e){validation={error:String(e)}}const saved=raw&&JSON.parse(raw);return{url:location.href,ready:window.__novelMounted,body:document.body.innerText.slice(0,3000),validation,state:saved&&{phase:saved.state.phase,choiceCount:saved.state.choiceCount,nodeId:saved.state.nodeId,career:saved.core.state.career}};});
    await p.screenshot({path:'output/playwright/novel-final-career-failure.png',scale:'css'});
    throw Error(JSON.stringify({error:String(error),steps:trace.length,diagnostic}));
  }finally{await context.close();}
}
