/* Narrative reachability uses the delivered Game and historical dataset.
 * Only constructor, eligible choices, rest and advance are called.
 * No flags, career, money, dates, relations or terminal state are injected.
 */
'use strict';
const fs=require('node:fs'),path=require('node:path'),vm=require('node:vm'),assert=require('node:assert/strict');
const root=path.resolve(__dirname,'..');
const env=vm.createContext({console});
env.MARKET=JSON.parse(fs.readFileSync(path.join(root,'data/market.json'),'utf8'));
for(const file of ['src/finance.js','src/story.js','src/game.js'])vm.runInContext(fs.readFileSync(path.join(root,file),'utf8'),env,{filename:file});
let assertions=0;function ok(value,message){assert.ok(value,message);assertions++;}
const story=env.STORY;
ok(story.events.length>=80,'80 independent event nodes');
ok(story.characters.length>=8,'8 principal characters');
ok(story.chains.length>=12,'12 causal chains');
ok(story.endings.length>=8,'8 endings');
ok(new Set(story.events.map(e=>e.id)).size===story.events.length,'unique event IDs');
ok(new Set(story.events.map(e=>e.text)).size===story.events.length,'independent, nonduplicated event prose');
for(let i=0;i<42;i++){
 const es=story.events.filter(e=>e.stage===i);
 ok(es.length===2&&es.some(e=>e.kind==='base')&&es.some(e=>e.kind==='conditional'),'one base and one conditional in phase '+i);
}
for(const e of story.events){
 const len=Array.from(e.text).length;
 ok(e.key?len>=250&&len<=450:len>=100&&len<=220,'authored text length '+e.id+' '+len);
 ok(e.choices.length>=2&&e.choices.every(c=>c.id&&c.effects),'meaningful structured choices '+e.id);
 ok(e.characters.every(id=>story.characters.some(c=>c.id===id)),'known participating characters '+e.id);
}
function rng(seed){let n=seed>>>0;return()=>{n=(Math.imul(n,1664525)+1013904223)>>>0;return n/4294967296;};}
function play(seed,start,overrides={},guide){
 const random=rng(seed),g=new env.Game(start,'industrial',seed),steps=[];
 let count=0,previous=g.state.date;const phases=new Set();
 while(!g.state.ending&&count++<100){
  const e=g.event();ok(g.state.date>=previous,'monotonic date');previous=g.state.date;
  if(e&&!g.state.resolved){
   ok(g.eligible(e.requires),'event qualified '+e.id);
   ok(!phases.has(e.stage),'mutually exclusive half-year event '+e.stage);phases.add(e.stage);
   if(e.recall)ok(g.state.flags.includes(e.recall.flag),'no invented callback '+e.id);
   let choice=guide?e.choices.find(c=>c.id===guide[steps.length]?.choice):e.choices[overrides[e.id]??0];
   ok(!!choice&&choice.available,'legal choice '+e.id);
   const result=g.choose(choice.id);ok(result.ok,'choice commits '+e.id);
   steps.push({date:g.state.date,stage:e.stage,event:e.id,choice:choice.id,label:choice.label});
  }
  // A normal repeatable rest action maintains health; it changes no story flags.
  if(g.state.actionPoints>0)ok(g.spend('rest').ok,'legal rest action');
  ok(g.advance().ok,'advance succeeds');
 }
 ok(!!g.state.ending,'natural terminal state');
 ok(g.state.date==='2020-12-31','complete 2000–2020 lifetime');
 ok(g.state.choices===42,'42 important choices, without checkpoint duplicates');
 ok(g.state.age===44,'consistent final age 44');
 ok(new Set(g.state.seen).size===g.state.seen.length,'no repeated event');
 const choiceText=steps.map(x=>x.choice).join('|');
 return {seed,start,sector:'industrial',ending:g.state.ending.id,choices:g.state.choices,finalDate:g.state.date,age:g.state.age,career:g.state.career,stats:JSON.parse(JSON.stringify(g.state.stats)),flags:[...g.state.flags],events:[...g.state.seen],delayed:g.state.memory.filter(x=>x.delayed).map(x=>({date:x.date,origin:x.origin,title:x.title,text:x.text})),steps,choiceText};
}
const paths=[],endingWitness={},eventWitness={},chainWitness={},endingCounts={};
const plans=[
 {name:'institution_solitude',start:'network',overrides:{b27:2,b35:0}},
 {name:'independent_practice',start:'buffer',overrides:{b24:1}},
 {name:'outside_profession',start:'network',overrides:{b24:2,b35:2}},
 {name:'rebuilt_career',start:'debt',overrides:{b17:1,c17:1,b35:1}},
 {name:'quiet_wholeness',start:'buffer',overrides:{b00:1,b35:1}},
 {name:'steady_steward',start:'buffer',overrides:{b35:1}},
 {name:'shared_method',start:'buffer',overrides:{b01:2,b03:2,b04:0,c07:2,b35:1}},
 {name:'recovered_boundary',start:'debt',overrides:{c07:2,c21:2,c29:2,b35:1}},
 {name:'open_ledger',start:'buffer',overrides:{c07:2,c15:2,c21:2,c29:2,b35:1,b38:2}},
 {name:'branches_public_record',start:'buffer',overrides:{b01:2,b35:1}},
 {name:'branches_no_prior_risk',start:'buffer',overrides:{c03:2,b04:1,b16:1,b35:1}},
 {name:'branches_junior_autonomy',start:'buffer',overrides:{c05:2,b10:1,c20:1,b35:1}},
 {name:'branches_credit_friend',start:'buffer',overrides:{c02:2,c08:1,b35:1}}
];
function accept(p){
 paths.push(p);endingCounts[p.ending]=(endingCounts[p.ending]||0)+1;
 if(!endingWitness[p.ending])endingWitness[p.ending]=p;
 for(const id of p.events)if(!eventWitness[id])eventWitness[id]={seed:p.seed,start:p.start};
 for(const chain of story.chains){
  if(chainWitness[chain.id])continue;
  if(chain.nodes.every(n=>p.events.includes(n.event)&&p.flags.includes(n.flag)&&(n.type!=='delayed'||p.delayed.some(d=>d.origin===n.event)))){
   chainWitness[chain.id]={seed:p.seed,start:p.start,nodes:JSON.parse(JSON.stringify(chain.nodes)),spanYears:chain.nodes.at(-1).year-chain.nodes[0].year};
  }
 }
}
function report(complete){
 const result={generatedAt:new Date().toISOString(),complete,method:'Delivered Game + fixed historical data; normal starts, eligible authored choices, one legal rest per market date, advance. Deterministic target routes; no final-state injection.',completedLives:paths.length,assertions,characters:story.characters.length,authoredEvents:story.events.length,authoredTextCharacters:story.events.reduce((sum,e)=>sum+Array.from(e.text).length,0),importantChoicesPerLife:42,plans,endingCounts,eventWitness,chainWitness,endingWitness,paths,missingEvents:story.events.map(e=>e.id).filter(id=>!eventWitness[id]),missingEndings:story.endings.map(e=>e.id).filter(id=>!endingWitness[id]),missingChains:story.chains.map(c=>c.id).filter(id=>!chainWitness[id])};
 fs.writeFileSync(path.join(root,'tests/story-reachability-results.json'),JSON.stringify(result,null,2));return result;
}
for(let i=0;i<plans.length;i++){
 const plan=plans[i],p=play(7000+i,plan.start,plan.overrides);p.plan=plan.name;accept(p);report(false);
 console.log(JSON.stringify({completed:paths.length,target:plan.name,ending:p.ending,events:Object.keys(eventWitness).length,chains:Object.keys(chainWitness).length}));
}
// One complete guide is replayed to check deterministic choice and terminal identity.
const first=paths[0],replay=play(first.seed,first.start,{},first.steps);
ok(replay.ending===first.ending&&replay.choiceText===first.choiceText,'full witness replay agrees');
const final=report(true);final.replayLives=1;
fs.writeFileSync(path.join(root,'tests/story-reachability-results.json'),JSON.stringify(final,null,2));
console.log(JSON.stringify({completedLives:paths.length,replayLives:1,assertions,eventsReached:Object.keys(eventWitness).length,endingsReached:Object.keys(endingWitness).length,chainsReached:Object.keys(chainWitness).length,endingCounts,missingEvents:final.missingEvents,missingEndings:final.missingEndings,missingChains:final.missingChains},null,2));
ok(final.missingEvents.length===0,'all authored nodes naturally reachable: '+final.missingEvents.join(','));
ok(final.missingEndings.length===0,'all declared endings naturally reachable: '+final.missingEndings.join(','));
ok(final.missingChains.length===0,'all complete causal chains naturally reachable: '+final.missingChains.join(','));
