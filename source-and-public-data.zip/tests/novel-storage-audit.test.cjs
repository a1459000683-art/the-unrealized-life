/* Independent UI storage audit.
 * Executes the real novel-ui.js event handlers in node:vm with a deliberately
 * small mock DOM, storage and Novel. This is not Safari/browser/layout evidence
 * and does not validate the real story or finance engine (see novel-audit.test).
 * Run: node --test tests/novel-storage-audit.test.cjs
 */
'use strict';
const test = require('node:test');
const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');
const vm = require('node:vm');
const {gzipSync,gunzipSync} = require('node:zlib');
const SOURCE = fs.readFileSync(path.join(__dirname, '../src/novel-ui.js'), 'utf8');
const VENDOR = fs.readFileSync(path.join(__dirname, '../src/fflate.js'), 'utf8');
const PREFIX = 'unrealized-life-novel:v1:';
const CODEC_PREFIX = 'unrealized-life-novel:gzip-base64:v1:';
const LEGACY = 'unrealized-life.v1.';
const flush = () => new Promise(resolve => setImmediate(resolve));
const copy = value => JSON.parse(JSON.stringify(value));
// Independent Node zlib oracle: UI compression itself uses the real bundled
// fflate in each VM, never a codec stub or the missing-vendor fallback.
const packed = raw => CODEC_PREFIX+gzipSync(Buffer.from(raw,'utf8'),{level:1,mtime:0}).toString('base64');
const storedText = disk => disk.startsWith(CODEC_PREFIX)
  ?gunzipSync(Buffer.from(disk.slice(CODEC_PREFIX.length),'base64')).toString('utf8'):disk;
const storedObject = disk => JSON.parse(storedText(disk));

function saved(marker, revision = 0) {
  return JSON.stringify({game:'unrealized-life-novel', schemaVersion:1,
    state:{marker, revision, start:'buffer'}});
}
function deferred() {
  let resolve;
  const promise = new Promise(done => { resolve = done; });
  return {promise, resolve};
}
class Target {
  constructor() { this.listeners = new Map(); }
  addEventListener(type, fn) {
    if (!this.listeners.has(type)) this.listeners.set(type, []);
    this.listeners.get(type).push(fn);
  }
  async emit(type, event = {}) {
    for (const fn of this.listeners.get(type) || []) await fn(event);
  }
  count(type) { return (this.listeners.get(type) || []).length; }
}
function fixture(initial = {}, sharedDisk = null, options = {}) {
  const disk = sharedDisk || new Map(Object.entries(initial)), operations = [], downloads = [], nativeClicks = [];
  const failures = {getter:false, get:false, set:false, remove:false};
  const document = new Target(), browser = new Target();
  const metrics = {construct:0, validate:0, restore:0, choose:0, ready:0};
  const errors = [], urls = new Map();
  let urlCount = 0;
  class Element extends Target {
    constructor(id = '') {
      super();this.id=id;this.innerHTML='';this.textContent='';this.className='';
      this.style={};this.dataset={};this.value='';this.files=[];this.open=false;
      this.attributes=new Map();this.classes=new Set();this.disabled=false;this.children=[];
      this.classList={add:value=>this.classes.add(value), remove:value=>this.classes.delete(value),
        contains:value=>this.classes.has(value)};
    }
    focus() { document.activeElement=this; }
    setAttribute(key, value) { this.attributes.set(key, value);if(key==='open'&&this.reflectOpen!==false)this.open=true; }
    hasAttribute(key) { return this.attributes.has(key); }
    removeAttribute(key) { this.attributes.delete(key);if(key==='open'&&this.reflectOpen!==false)this.open=false; }
    showModal() { this.open=true;this.attributes.set('open', ''); }
    close() { this.open=false;this.attributes.delete('open'); }
    querySelector(selector) { return this.querySelectorAll(selector)[0]||null; }
    querySelectorAll(selector) {
      const nodes=renderedElements(this).concat(this.children);
      if(selector==='button')return nodes.filter(n=>n.tagName==='BUTTON');
      if(selector==='a[href]')return nodes.filter(n=>n.tagName==='A'&&n.href);
      // Keep programmatically appended controls in document order. In
      // particular, bare "input" includes the hidden picker; :not([hidden])
      // must actually filter it or the real Tab handler's last-item test fails.
      return nodes.filter(n=>!n.disabled&&!(n.tagName==='INPUT'&&n.hasAttribute('hidden')&&selector.includes('input:not([hidden])')));
    }
    contains(target) { for(let node=target;node;node=node.parentNode)if(node===this)return true;return false; }
    closest(selector) { return selector==='[data-action]'&&this.dataset.action?this:null; }
    appendChild(child) { child.remove();child.parentNode=this;this.children.push(child);return child; }
    remove() { if(this.parentNode&&this.parentNode.children)this.parentNode.children=this.parentNode.children.filter(child=>child!==this);this.parentNode=null; }
    click() {
      this.clickCount=(this.clickCount||0)+1;
      const event={type:'click',target:this,defaultPrevented:false,propagationStopped:false,
        preventDefault(){this.defaultPrevented=true;},stopPropagation(){this.propagationStopped=true;}};
      const record={target:this,host:this.parentNode,event,documentReached:false};nativeClicks.push(record);
      // Native click dispatch is synchronous: async handlers run through their
      // first await before default activation is decided. Model the actual
      // ancestor chain so fallback guards also see generated download anchors.
      for(let target=this;target;target=target.parentNode){
        event.currentTarget=target;if(target===document)record.documentReached=true;
        for(const fn of target.listeners.get('click')||[]){
          try { const result=fn(event);if(result&&typeof result.catch==='function')result.catch(e=>errors.push(e)); }
          catch(e){errors.push(e);}
        }
        if(event.propagationStopped)break;
      }
      if(!event.defaultPrevented){
        if(this.download)downloads.push({name:this.download,blob:urls.get(this.href)});
        if(this.id==='novel-import')this.pickerOpenCount=(this.pickerOpenCount||0)+1;
      }
    }
  }
  const elements = Object.fromEntries(['novel-app','novel-dialog','novel-dialog-content',
    'novel-import','novel-toast','novel-main'].map(id=>[id,new Element(id)]));
  elements['novel-dialog-content'].parentNode=elements['novel-dialog'];
  elements['novel-import'].tagName='INPUT';elements['novel-import'].setAttribute('hidden','');
  if(options.unknownDialog){
    const dialog=elements['novel-dialog'];dialog.reflectOpen=false;delete dialog.open;
    dialog.showModal=undefined;dialog.close=undefined;
  }
  function renderedElements(container) {
    const owner=container.id==='novel-dialog'?elements['novel-dialog-content']:container,markup=owner.innerHTML;
    if(owner.parsedMarkup===markup)return owner.parsedNodes;
    owner.parsedMarkup=markup;owner.parsedNodes=[];
    for(const match of markup.matchAll(/<(button|a|input|select|textarea|summary)\b([^>]*)>/g)){
      const el=new Element(),attrs=Object.fromEntries([...match[2].matchAll(/([a-z-]+)="([^"]*)"/g)].map(m=>[m[1],m[2]]));
      el.tagName=match[1].toUpperCase();el.parentNode=owner;
      el.dataset=Object.fromEntries(Object.entries(attrs).filter(([k])=>k.startsWith('data-')).map(([k,v])=>[k.slice(5),v]));
      el.href=attrs.href;el.disabled=/\bdisabled\b/.test(match[2]);owner.parsedNodes.push(el);
    }
    return owner.parsedNodes;
  }
  document.getElementById=id=>elements[id]||null;
  document.createElement=tag=>{const element=new Element();element.tagName=tag.toUpperCase();return element;};
  document.body=new Element('body');document.activeElement=document.body;
  document.body.parentNode=document;
  for(const element of Object.values(elements))if(!element.parentNode)element.parentNode=document.body;
  const storage={
    getItem(key) { operations.push({type:'get',key});if(failures.get)throw Error('get blocked');return disk.get(key)??null; },
    setItem(key,value) { operations.push({type:'set',key});if(failures.set)throw Error('quota exceeded');disk.set(key,String(value)); },
    removeItem(key) { operations.push({type:'remove',key});if(failures.remove)throw Error('remove blocked');disk.delete(key); }
  };
  // Intentionally permissive about the outer envelope: the UI must reject wrong
  // game/schema identities before reaching this mock engine's own validator.
  class MockNovel {
    static STORAGE_PREFIX=PREFIX;
    constructor(start='buffer') { metrics.construct++;this.state={marker:start,revision:0,start}; }
    view() { const s=this.state;return {phase:s.result?'result':'choice',result:s.result||null,date:'2000-01-03',age:24,revision:s.revision,
      node:{id:'mock-scene',title:`${s.marker} / page ${s.revision}`,text:'Controlled UI fixture.',choices:[{id:'wait',label:'继续'}]},
      chapter:{title:'Controlled fixture'},progress:{choiceCount:s.revision,totalGroups:10},people:[]}; }
    choose(choice,node,revision) {
      metrics.choose++;
      if(choice!=='wait'||node!=='mock-scene'||revision!==this.state.revision)return {ok:false,error:'stale fixture choice'};
      this.state.revision++;return {ok:true};
    }
    exportSave() { return JSON.stringify({game:'unrealized-life-novel',schemaVersion:1,state:this.state}); }
    summary() { return this.state.marker; }
    static validateSave(raw) {
      metrics.validate++;
      try {const v=typeof raw==='string'?JSON.parse(raw):raw;
        return v&&v.state&&typeof v.state.marker==='string'&&Number.isInteger(v.state.revision)&&!v.state.invalid
          ?{ok:true}:{ok:false,error:'mock state rejected'};
      } catch { return {ok:false,error:'mock JSON rejected'}; }
    }
    static fromSave(raw) {
      metrics.restore++;
      const next=Object.create(MockNovel.prototype);next.state=copy((typeof raw==='string'?JSON.parse(raw):raw).state);return next;
    }
  }
  class MockURL extends URL {
    static createObjectURL(blob) { const id=`blob:mock-${++urlCount}`;urls.set(id,blob);return id; }
    static revokeObjectURL(id) { urls.delete(id); }
  }
  const context=vm.createContext({document,Novel:MockNovel,Blob,URL:MockURL,TextEncoder,TextDecoder,atob,btoa,
    console:{error:e=>errors.push(e)},setTimeout:()=>1,clearTimeout:()=>{},
    requestAnimationFrame:fn=>fn(),scrollTo:()=>{},
    addEventListener:(type,fn)=>browser.addEventListener(type,fn),
    NOVEL_BOOT_READY:()=>metrics.ready++});
  Object.defineProperty(context,'localStorage',{get(){if(failures.getter)throw Error('storage getter denied');return storage;}});
  vm.runInContext(VENDOR,context,{filename:'src/fflate.js'});
  assert.equal(typeof context.fflate.gzipSync,'function','actual bundled codec must be loaded');
  assert.equal(typeof context.fflate.Gunzip,'function','actual streaming decoder must be loaded');
  vm.runInContext(SOURCE,context,{filename:'src/novel-ui.js'});
  function mount() { context.NovelUI.mount();assert.deepEqual(errors,[],'render/mount should not hit fatal recovery'); }
  function button(action, data = {}, background = false) {
    const dialog=elements['novel-dialog'],container=!background&&(dialog.open||dialog.hasAttribute('open'))?dialog:elements['novel-app'];
    const el=container.querySelectorAll('button').find(el=>el.dataset.action===action&&Object.entries(data).every(([k,v])=>el.dataset[k]===String(v)));
    if(el)return el;
    assert.fail(`No rendered button: ${action} ${JSON.stringify(data)}\n${container.innerHTML||elements['novel-dialog-content'].innerHTML}`);
  }
  async function dispatch(type,props) {
    const event={defaultPrevented:false,propagationStopped:false,preventDefault(){this.defaultPrevented=true;},stopPropagation(){this.propagationStopped=true;},...props};
    await document.emit(type,event);await flush();assert.deepEqual(errors,[]);return event;
  }
  async function click(action,data) { const target=button(action,data);target.focus();return dispatch('click',{target}); }
  async function change(file) {
    const input=elements['novel-import'];input.files=file?[file]:[];input.value=file?'mock-selected.json':'';
    await input.emit('change',{target:input});await flush();assert.deepEqual(errors,[]);
  }
  async function start() { await click('start',{start:'buffer'});if(elements['novel-dialog'].open)await click('confirm'); }
  async function choose() { await click('choose'); }
  async function importRaw(raw) {
    if(elements['novel-dialog'].open)await click('close');
    await click('saves');await click('import');await change({size:Buffer.byteLength(raw),text:()=>Promise.resolve(raw)});
  }
  async function exported(action='export',data) {
    const count=downloads.length;await click(action,data);assert.equal(downloads.length,count+1);
    return JSON.parse(await downloads.at(-1).blob.text());
  }
  return {context,disk,operations,downloads,nativeClicks,failures,elements,document,browser,metrics,errors,
    mount,click,change,start,choose,importRaw,exported,button,dispatch,
    get root(){return elements['novel-app'].innerHTML;},
    get dialog(){return elements['novel-dialog-content'].innerHTML;},
    get toast(){return elements['novel-toast'].textContent;}};
}

test('novel UI mock DOM: all storage mutations stay in the independent namespace',async()=>{
  const old=Object.fromEntries(['auto','slot1','slot2','slot3','slot4','settings'].map(k=>[LEGACY+k,`legacy sentinel ${k}`]));
  const h=fixture(old);h.mount();assert.equal(h.operations.some(op=>op.type!=='get'),false);
  await h.start();await h.click('saves');await h.click('save',{slot:'slot1'});await h.click('close');
  await h.choose();await h.click('saves');await h.click('save',{slot:'slot2'});
  const slot2=h.disk.get(PREFIX+'slot2');
  await h.click('delete',{slot:'slot1'});await h.click('confirm');
  assert.equal(h.disk.has(PREFIX+'slot1'),false);assert.equal(h.disk.get(PREFIX+'slot2'),slot2);
  await h.importRaw(saved('imported'));await h.click('confirm');
  for(const [key,value]of Object.entries(old))assert.equal(h.disk.get(key),value);
  assert.ok(h.operations.filter(op=>op.type!=='get').every(op=>op.key.startsWith(PREFIX)));
  assert.equal(storedObject(h.disk.get(PREFIX+'auto')).state.marker,'imported');
});

test('novel UI mock DOM: wrong outer identities and malformed JSON are rejected before mock engine validation',async()=>{
  const valid=JSON.parse(saved('foreign'));
  const rejected=[JSON.stringify({...valid,game:'The Unrealized Life'}),JSON.stringify({...valid,schemaVersion:2}),
    JSON.stringify({...valid,schemaVersion:'1'}),JSON.stringify(valid.state),JSON.stringify({state:valid.state}),'not-json'];
  for(const raw of rejected){
    const h=fixture();h.mount();await h.start();await h.click('saves');await h.click('import');
    const before=h.disk.get(PREFIX+'auto'),scene=h.root,validations=h.metrics.validate;
    await h.change({size:raw.length,text:()=>Promise.resolve(raw)});
    assert.equal(h.metrics.validate,validations,'outer gate should reject before delegating');
    assert.match(h.toast,/导入未完成/);assert.equal(h.disk.get(PREFIX+'auto'),before);assert.equal(h.root,scene);
    assert.equal(h.elements['novel-import'].value,'');
  }
});

test('novel UI mock DOM: mock validator failure preserves live state and stored slots',async()=>{
  const h=fixture();h.mount();await h.start();await h.click('saves');await h.click('save',{slot:'slot1'});
  const before=[...h.disk],scene=h.root,bad=JSON.parse(saved('bad'));bad.state.invalid=true;
  await h.importRaw(JSON.stringify(bad));assert.match(h.toast,/mock state rejected/);
  assert.deepEqual([...h.disk],before);assert.equal(h.root,scene);
});

test('novel UI mock DOM: quota failure keeps newer auto and empty manual slots in memory despite readable old disk',async()=>{
  const h=fixture();h.mount();await h.start();const oldDisk=h.disk.get(PREFIX+'auto');
  assert.ok(oldDisk.startsWith(CODEC_PREFIX),'quota regression starts with a real compressed disk entry');
  h.failures.set=true;await h.choose();await h.click('saves');
  assert.match(h.dialog,/buffer \/ page 1/);assert.equal(h.disk.get(PREFIX+'auto'),oldDisk);
  await h.click('save',{slot:'slot1'});assert.equal(h.disk.has(PREFIX+'slot1'),false);
  assert.match(h.toast,/导出/);assert.equal((await h.exported('export-slot',{slot:'slot1'})).state.revision,1);
  await h.click('load',{slot:'auto'});await h.click('confirm');assert.match(h.root,/buffer \/ page 1/);
  await h.click('home');await h.click('confirm');await h.click('resume');
  assert.match(h.root,/buffer \/ page 1/);assert.equal(h.disk.get(PREFIX+'auto'),oldDisk);
  await h.click('saves');assert.equal((await h.exported()).state.revision,1);
});

test('novel UI mock DOM: denied localStorage getter still mounts and retains exportable session progress',async()=>{
  const h=fixture();h.failures.getter=true;h.mount();await h.start();await h.choose();
  await h.click('saves');await h.click('save',{slot:'slot1'});
  assert.match(h.dialog,/临时保留/);assert.equal((await h.exported('export-slot',{slot:'slot1'})).state.revision,1);
  await h.click('load',{slot:'slot1'});await h.click('confirm');assert.match(h.root,/buffer \/ page 1/);
  assert.equal(h.disk.size,0);assert.equal(h.context.__novelMounted,true);
});

test('novel UI mock DOM: failed deletion preserves the bookmark and never reports success',async()=>{
  const h=fixture();h.mount();await h.start();await h.click('saves');await h.click('save',{slot:'slot1'});
  const before=h.disk.get(PREFIX+'slot1');h.failures.remove=true;
  await h.click('delete',{slot:'slot1'});await h.click('confirm');
  assert.equal(h.disk.get(PREFIX+'slot1'),before);assert.match(h.toast,/未能删除|删除未完成/);
  assert.doesNotMatch(h.toast,/已删除/);assert.match(h.dialog,/buffer \/ page 0/);
  assert.equal((await h.exported('export-slot',{slot:'slot1'})).state.revision,0);
});

test('novel UI mock DOM: later fast import wins over earlier slow File.text completion',async()=>{
  const h=fixture();h.mount();await h.start();await h.click('saves');await h.click('import');
  const slow=deferred(),before=h.disk.get(PREFIX+'auto');
  await h.change({size:100,text:()=>slow.promise});await h.change({size:100,text:()=>Promise.resolve(saved('B-fast'))});
  assert.match(h.dialog,/B-fast/);const confirmation=h.dialog;
  slow.resolve(saved('A-slow'));await flush();assert.equal(h.dialog,confirmation);
  assert.equal(h.disk.get(PREFIX+'auto'),before,'file selection cannot replace state before confirmation');
  await h.click('confirm');assert.equal(storedObject(h.disk.get(PREFIX+'auto')).state.marker,'B-fast');
});

test('novel UI mock DOM: closing saves cancels pending File.text and cannot replace a newer dialog',async()=>{
  const h=fixture();h.mount();await h.start();await h.click('saves');await h.click('import');
  const slow=deferred(),before=h.disk.get(PREFIX+'auto');await h.change({size:100,text:()=>slow.promise});
  await h.click('close');await h.click('people');const newer=h.dialog;
  slow.resolve(saved('cancelled-file'));await flush();
  assert.equal(h.dialog,newer,'cancelled read must not reopen import confirmation over the people dialog');
  assert.equal(h.disk.get(PREFIX+'auto'),before);assert.match(h.root,/buffer \/ page 0/);
});

test('novel UI mock DOM: cancel import confirmation preserves progress and reselecting the same file works',async()=>{
  const h=fixture();h.mount();await h.start();const before=h.disk.get(PREFIX+'auto'),raw=saved('same-file');
  await h.importRaw(raw);assert.match(h.dialog,/same-file/);await h.click('close');
  assert.equal(h.disk.get(PREFIX+'auto'),before);assert.match(h.root,/buffer \/ page 0/);
  await h.importRaw(raw);await h.click('confirm');assert.equal(storedObject(h.disk.get(PREFIX+'auto')).state.marker,'same-file');
});

test('novel UI mock DOM: oversized import clears stale candidate and resets file input without reading it',async()=>{
  const h=fixture();h.mount();await h.start();const before=h.disk.get(PREFIX+'auto');await h.importRaw(saved('candidate'));
  let reads=0;await h.change({size:8000001,text:()=>{reads++;return Promise.resolve(saved('too-large'));}});
  assert.equal(reads,0);assert.equal(h.elements['novel-import'].value,'');assert.match(h.toast,/8 MB/);
  await h.click('confirm');assert.equal(h.disk.get(PREFIX+'auto'),before,'stale candidate cannot be imported');
});

test('novel UI mock DOM: repeat mount neither rewrites autosave nor duplicates click and change handlers',async()=>{
  const h=fixture({[PREFIX+'auto']:saved('existing')});h.mount();h.mount();h.mount();
  assert.equal(h.document.count('click'),1);assert.equal(h.document.count('keydown'),1);
  assert.equal(h.elements['novel-import'].count('change'),1);assert.equal(h.browser.count('storage'),1);
  assert.equal(h.operations.filter(op=>op.type!=='get').length,0);
  assert.equal(h.disk.get(PREFIX+'auto'),saved('existing'));await h.click('resume');
  const before=h.operations.filter(op=>op.type==='set').length;await h.choose();
  assert.equal(h.metrics.choose,1);assert.equal(h.operations.filter(op=>op.type==='set').length,before+1);
  assert.equal(storedObject(h.disk.get(PREFIX+'auto')).state.revision,1);
});

test('novel UI mock DOM: two VMs protect newer shared auto while the stale VM can export its own progress',async()=>{
  const shared=new Map([[PREFIX+'auto',packed(saved('shared'))]]),a=fixture({},shared),b=fixture({},shared);
  a.mount();b.mount();await a.click('resume');await b.click('resume');
  const original=shared.get(PREFIX+'auto');await a.choose();await a.choose();
  const newer=shared.get(PREFIX+'auto'),bScene=b.root;
  await b.browser.emit('storage',{key:PREFIX+'auto',oldValue:original,newValue:newer});
  assert.equal(b.root,bScene,'a storage event must not replace the live reading');
  assert.match(b.toast,/另一标签页/);
  const writes=b.operations.filter(op=>op.type==='set').length;
  await b.choose();assert.equal(shared.get(PREFIX+'auto'),newer);
  assert.equal(b.operations.filter(op=>op.type==='set').length,writes,'stale VM cannot call setItem');
  assert.match(b.root,/shared \/ page 1/);assert.equal(storedObject(newer).state.revision,2);
  await b.click('saves');assert.match(b.dialog,/另一标签页/);
  assert.equal((await b.exported()).state.revision,1);
  assert.equal((await b.exported('export-slot',{slot:'auto'})).state.revision,1);
  assert.equal(shared.get(PREFIX+'auto'),newer,'exporting memory progress cannot touch the shared disk');
});

test('novel UI mock DOM: stale manual bookmark overwrite and deletion both preserve the other VM version',async()=>{
  const shared=new Map([[PREFIX+'auto',packed(saved('shared'))],[PREFIX+'slot1',packed(saved('original-bookmark'))]]);
  const a=fixture({},shared),b=fixture({},shared);a.mount();b.mount();
  await a.click('resume');await b.click('resume');
  await a.click('saves');await b.click('saves'); // Both observe the same bookmark baseline.
  await a.click('close');await a.choose();await a.click('saves');
  await a.click('save',{slot:'slot1'});await a.click('confirm');
  const newer=shared.get(PREFIX+'slot1'),writes=b.operations.filter(op=>op.type==='set').length;
  // Deliberately do not deliver a storage event: the write-time comparison must
  // protect the slot even when a browser notification is delayed or absent.
  await b.click('save',{slot:'slot1'});await b.click('confirm');
  assert.equal(shared.get(PREFIX+'slot1'),newer);assert.match(b.toast,/另一标签页/);
  assert.equal(b.operations.filter(op=>op.type==='set').length,writes);
  assert.equal((await b.exported('export-slot',{slot:'slot1'})).state.revision,0);
  const removals=b.operations.filter(op=>op.type==='remove').length;
  await b.click('delete',{slot:'slot1'});await b.click('confirm');
  assert.equal(shared.get(PREFIX+'slot1'),newer);assert.match(b.toast,/删除已取消|删除未完成/);
  assert.equal(b.operations.filter(op=>op.type==='remove').length,removals,'conflict must stop before removeItem');
  assert.equal(storedObject(newer).state.revision,1);
});

test('novel UI mock DOM: only confirming reload-external accepts the shared auto and permits subsequent writes',async()=>{
  const shared=new Map([[PREFIX+'auto',packed(saved('shared'))]]),a=fixture({},shared),b=fixture({},shared);
  a.mount();b.mount();await a.click('resume');await b.click('resume');
  await a.choose();await a.choose();await b.choose();
  const writes=b.operations.filter(op=>op.type==='set').length,protectedAuto=shared.get(PREFIX+'auto');
  await b.click('saves');await b.click('reload-external',{slot:'auto'});
  assert.equal(shared.get(PREFIX+'auto'),protectedAuto);assert.match(b.root,/shared \/ page 1/);
  await b.click('close');await b.choose();
  assert.equal(b.operations.filter(op=>op.type==='set').length,writes,'cancelling does not accept the new baseline');
  assert.equal(shared.get(PREFIX+'auto'),protectedAuto);
  await a.choose();const latest=shared.get(PREFIX+'auto');
  await b.click('saves');await b.click('reload-external',{slot:'auto'});
  assert.match(b.root,/shared \/ page 2/);assert.equal(shared.get(PREFIX+'auto'),latest);
  await b.click('confirm');assert.match(b.root,/shared \/ page 3/);
  assert.equal(shared.get(PREFIX+'auto'),latest,'accepted state matches the selected external snapshot');
  const acceptedWrites=b.operations.filter(op=>op.type==='set').length;
  await b.choose();assert.equal(b.operations.filter(op=>op.type==='set').length,acceptedWrites+1);
  assert.equal(storedObject(shared.get(PREFIX+'auto')).state.revision,4);
  await b.click('saves');assert.equal((await b.exported()).state.revision,4);
});

test('novel UI real fflate: five large Unicode saves compress, reopen and export byte-identical raw JSON',async()=>{
  const value=JSON.parse(saved('中文与 emoji 🙂'));
  value.state.journal='history row: 长期记忆与账目 🙂 / 2000-01-03\n'.repeat(30000);
  const raw=JSON.stringify(value);assert.ok(Buffer.byteLength(raw,'utf8')*5>5_000_000);
  const h=fixture();h.mount();await h.importRaw(raw);await h.click('confirm');await h.click('saves');
  for(let i=1;i<=4;i++)await h.click('save',{slot:'slot'+i});
  const stored=['auto','slot1','slot2','slot3','slot4'].map(key=>h.disk.get(PREFIX+key));
  for(const entry of stored){
    assert.ok(entry.startsWith(CODEC_PREFIX),'production writer must use gzip/base64, not raw fallback');
    const bytes=Buffer.from(entry.slice(CODEC_PREFIX.length),'base64');
    assert.deepEqual([...bytes.subarray(0,3)],[0x1f,0x8b,8]);
    assert.deepEqual([...bytes.subarray(4,8)],[0,0,0,0],'deterministic gzip timestamp');
    assert.equal(storedText(entry),raw,'independent zlib verifies gzip and exact Unicode round-trip');
  }
  assert.ok(stored.reduce((sum,s)=>sum+s.length*2,0)<5_000_000,'five stored values fit below 5 MB even charging UTF-16 bytes');
  await h.exported();assert.equal(await h.downloads.at(-1).blob.text(),raw);
  assert.match(h.downloads.at(-1).name,/\.json$/);
  const reopened=fixture({},h.disk);reopened.mount();await reopened.click('resume');
  assert.match(reopened.root,/中文与 emoji 🙂/);await reopened.click('saves');
  await reopened.exported('export-slot',{slot:'slot4'});
  assert.equal(await reopened.downloads.at(-1).blob.text(),raw,'compressed bookmark exports original JSON');
});

test('novel UI real fflate: existing raw JSON stays readable and is compressed only when saved',async()=>{
  const raw=saved('raw-backward-compatible',3),oldLegacy=JSON.stringify({legacy:'unchanged'});
  const h=fixture({[PREFIX+'auto']:raw,[PREFIX+'slot1']:raw,[LEGACY+'auto']:oldLegacy});h.mount();
  assert.equal(h.disk.get(PREFIX+'auto'),raw,'mount does not migrate or overwrite stored bytes');
  await h.click('saves');await h.exported('export-slot',{slot:'slot1'});
  assert.equal(await h.downloads.at(-1).blob.text(),raw);assert.equal(h.disk.get(PREFIX+'slot1'),raw);
  await h.click('close');await h.click('resume');
  assert.ok(h.disk.get(PREFIX+'auto').startsWith(CODEC_PREFIX));assert.equal(storedText(h.disk.get(PREFIX+'auto')),raw);
  await h.choose();assert.equal(storedObject(h.disk.get(PREFIX+'auto')).state.revision,4);
  assert.equal(h.disk.get(PREFIX+'slot1'),raw);assert.equal(h.disk.get(LEGACY+'auto'),oldLegacy);
});

test('novel UI real fflate: corrupt encoded bookmarks are rejected without replacing current state or disk bytes',async()=>{
  const good=gzipSync(Buffer.from(saved('corrupt-candidate'),'utf8'),{mtime:0});
  const crc=Buffer.from(good);crc[crc.length-8]^=1;
  const size=Buffer.from(good);size[size.length-4]^=1;
  const cases=[['base64',CODEC_PREFIX+'%%%not-base64%%%'],
    ['gzip header',CODEC_PREFIX+Buffer.from('not a gzip stream').toString('base64')],
    ['truncated gzip',CODEC_PREFIX+good.subarray(0,good.length-9).toString('base64')],
    ['CRC32',CODEC_PREFIX+crc.toString('base64')],['ISIZE',CODEC_PREFIX+size.toString('base64')]];
  for(const [name,bad]of cases){
    const h=fixture({[PREFIX+'auto']:packed(saved('safe-current')),[PREFIX+'slot1']:bad});h.mount();await h.click('resume');
    const beforeAuto=h.disk.get(PREFIX+'auto'),beforeScene=h.root,beforeRestores=h.metrics.restore;
    await h.click('saves');assert.match(h.dialog,/需要检查/,name);
    assert.doesNotMatch(h.dialog,/<button[^>]*data-action="load"[^>]*data-slot="slot1"/,name+' must not offer invalid restore');
    assert.equal(h.disk.get(PREFIX+'slot1'),bad);assert.equal(h.disk.get(PREFIX+'auto'),beforeAuto);assert.equal(h.root,beforeScene);
    assert.equal(h.metrics.restore,beforeRestores+1,'only the valid autosave may be restored for its listing');
    const downloads=h.downloads.length;await h.click('export-slot',{slot:'slot1'});assert.equal(h.downloads.length,downloads+1);
    assert.equal(await h.downloads.at(-1).blob.text(),bad,'corrupt bytes are offered unchanged for recovery');
    assert.match(h.downloads.at(-1).name,/\.txt$/,'corrupt recovery cannot masquerade as valid JSON');
    assert.equal(h.disk.get(PREFIX+'slot1'),bad);assert.equal(h.disk.get(PREFIX+'auto'),beforeAuto);
  }
});

test('novel UI real fflate: gzip expansion above 8 MB is rejected even when ISIZE understates its output',async()=>{
  const raw='A'.repeat(8_000_001),bytes=gzipSync(Buffer.from(raw),{level:1,mtime:0});
  bytes.writeUInt32LE(1,bytes.length-4); // Do not trust the claimed uncompressed size.
  const bomb=CODEC_PREFIX+bytes.toString('base64');assert.ok(bomb.length<100000);
  const h=fixture({[PREFIX+'auto']:bomb,[PREFIX+'slot1']:packed(saved('safe-bookmark'))});h.mount();
  assert.match(h.root,/未通过校验|未被覆盖/);assert.equal(h.metrics.validate,0,'oversized expansion never reaches engine validation');
  assert.equal(h.operations.filter(op=>op.type!=='get').length,0);assert.equal(h.disk.get(PREFIX+'auto'),bomb);
  await h.click('saves');assert.match(h.dialog,/8|8000000|过大|超过/);
  assert.doesNotMatch(h.dialog,/<button[^>]*data-action="load"[^>]*data-slot="auto"/);
  assert.equal(h.disk.get(PREFIX+'auto'),bomb,'invalid auto must not be silently replaced by a fresh game');
});

test('novel UI real fflate: normal compressed resume and choice persist without false CAS or memory fallback',async()=>{
  const h=fixture({[PREFIX+'auto']:packed(saved('normal-resume',4))});h.mount();
  await h.click('resume');assert.match(h.root,/normal-resume \/ page 4/);
  assert.doesNotMatch(h.toast,/另一标签页|临时|未能/);assert.doesNotMatch(h.root,/本页临时存档/);
  assert.equal(storedObject(h.disk.get(PREFIX+'auto')).state.revision,4);
  const writes=h.operations.filter(op=>op.type==='set').length;await h.choose();
  assert.equal(h.operations.filter(op=>op.type==='set').length,writes+1);
  assert.equal(storedObject(h.disk.get(PREFIX+'auto')).state.revision,5);
  assert.doesNotMatch(h.toast,/另一标签页|临时|未能/);assert.doesNotMatch(h.root,/本页临时存档/);
  await h.click('saves');assert.doesNotMatch(h.dialog,/另一标签页更改|临时保留/);
  assert.equal((await h.exported()).state.revision,5);
});

test('novel UI real fflate: getItem failure after load keeps newer session progress exportable and resumable',async()=>{
  const h=fixture();h.mount();await h.start();await h.choose();const old=h.disk.get(PREFIX+'auto');
  h.failures.get=true;await h.choose();assert.equal(h.disk.get(PREFIX+'auto'),old);
  await h.click('saves');await h.click('save',{slot:'slot2'});
  assert.equal((await h.exported('export-slot',{slot:'slot2'})).state.revision,2);
  assert.equal(h.disk.has(PREFIX+'slot2'),false);assert.match(h.dialog,/临时保留/);
  await h.click('close');await h.click('home');await h.click('confirm');await h.click('resume');
  assert.match(h.root,/buffer \/ page 2/);await h.click('saves');
  assert.equal((await h.exported()).state.revision,2);assert.equal(h.disk.get(PREFIX+'auto'),old);
});

test('novel UI fallback dialog: background buttons and ordinary links are blocked until the dialog closes',async()=>{
  const h=fixture({},null,{unknownDialog:true});h.mount();
  const background=h.button('start',{start:'buffer'},true),link=h.elements['novel-app'].querySelectorAll('a[href]').find(el=>el.href==='legacy.html');
  assert.ok(link);assert.equal(h.elements['novel-dialog'].open,undefined,'simulate an unknown dialog element');
  await h.click('saves');const modal=h.elements['novel-dialog'],before=h.dialog;
  assert.equal(modal.hasAttribute('open'),true);assert.equal(modal.classList.contains('dialog-fallback'),true);
  assert.equal(modal.attributes.get('role'),'dialog');assert.equal(modal.attributes.get('aria-modal'),'true');
  for(const target of [background,link]){
    const event=await h.dispatch('click',{target});assert.equal(event.defaultPrevented,true);assert.equal(event.propagationStopped,true);
  }
  assert.equal(h.metrics.construct,0);assert.equal(h.disk.size,0);assert.equal(h.dialog,before);
  await h.click('close');assert.equal(modal.hasAttribute('open'),false);
  const event=await h.dispatch('click',{target:link});assert.equal(event.defaultPrevented,false);assert.equal(event.propagationStopped,false);
  await h.dispatch('click',{target:background});assert.equal(h.metrics.construct,1);
  assert.equal(storedObject(h.disk.get(PREFIX+'auto')).state.marker,'buffer');
});

test('novel UI fallback dialog: Tab re-enters and wraps the focus boundary, Escape restores the opener',async()=>{
  const h=fixture({},null,{unknownDialog:true});h.mount();const opener=h.button('saves',{},true);
  opener.focus();await h.dispatch('click',{target:opener});const modal=h.elements['novel-dialog'];
  const items=modal.querySelectorAll('button:not([disabled]),a[href],input,select,textarea,summary,[tabindex="0"]');
  assert.ok(items.length>1);const first=items[0],last=items.at(-1),background=h.button('start',{start:'buffer'},true);
  assert.equal(h.document.activeElement,first);
  for(const [active,shiftKey,expected]of [[background,false,first],[background,true,last],[last,false,first],[first,true,last]]){
    active.focus();const event=await h.dispatch('keydown',{key:'Tab',shiftKey});
    assert.equal(event.defaultPrevented,true);assert.equal(h.document.activeElement,expected);assert.equal(modal.contains(expected),true);
  }
  const escape=await h.dispatch('keydown',{key:'Escape'});assert.equal(escape.defaultPrevented,true);
  assert.equal(modal.hasAttribute('open'),false);assert.equal(h.document.activeElement,opener);
  const tab=await h.dispatch('keydown',{key:'Tab',shiftKey:false});assert.equal(tab.defaultPrevented,false,'closed dialog cannot trap focus');
});

test('novel UI fallback dialog: native download clicks bubble and activate for memory-only current, slot and journal exports',async()=>{
  for(const failure of ['getter','get']){
    const h=fixture({},null,{unknownDialog:true});h.failures[failure]=true;h.mount();await h.start();await h.choose();
    await h.click('saves');await h.click('save',{slot:'slot1'});
    const modal=h.elements['novel-dialog'],background=h.document.createElement('a');
    background.href='legacy.html';h.document.body.appendChild(background);background.click();
    assert.equal(h.nativeClicks.at(-1).documentReached,true);
    assert.equal(h.nativeClicks.at(-1).event.defaultPrevented,true,'ordinary background link remains blocked');
    assert.equal(h.nativeClicks.at(-1).event.propagationStopped,true);
    for(const [action,data]of [['export'],['export-slot',{slot:'slot1'}]]){
      const exported=await h.exported(action,data),native=h.nativeClicks.at(-1);
      assert.equal(exported.state.revision,1,failure+' preserves memory progress');
      assert.equal(native.target.tagName,'A');assert.equal(native.host,modal);
      assert.equal(native.documentReached,true,'generated anchor must reach the real document guard');
      assert.equal(native.event.defaultPrevented,false);assert.equal(native.event.propagationStopped,false);
      assert.equal(native.target.parentNode,null,'temporary anchor is removed after activation');
      assert.match(h.downloads.at(-1).name,/\.json$/);
    }
    await h.click('close');await h.click('life');const before=h.downloads.length;
    await h.click('export-summary');assert.equal(h.downloads.length,before+1);
    const journal=h.nativeClicks.at(-1);
    assert.equal(journal.host,modal);assert.equal(journal.documentReached,true);assert.equal(journal.event.defaultPrevented,false);
    assert.equal(await h.downloads.at(-1).blob.text(),'buffer');assert.match(h.downloads.at(-1).name,/\.txt$/);
    assert.equal(h.disk.size,0,'storage failure never gains an accidental disk write');
    await h.click('close');background.click();
    assert.equal(h.nativeClicks.at(-1).event.defaultPrevented,false,'background navigation recovers after close');
  }
  const corrupt=CODEC_PREFIX+'%%%invalid-base64%%%',h=fixture({[PREFIX+'slot1']:corrupt},null,{unknownDialog:true});
  h.mount();await h.start();await h.click('saves');const before=[...h.disk];
  await h.click('export-slot',{slot:'slot1'});const recovery=h.nativeClicks.at(-1);
  assert.equal(recovery.host,h.elements['novel-dialog']);assert.equal(recovery.documentReached,true);
  assert.equal(recovery.event.defaultPrevented,false);assert.equal(h.downloads.length,1);
  assert.equal(await h.downloads[0].blob.text(),corrupt);assert.match(h.downloads[0].name,/待恢复原始记录\.txt$/);
  assert.deepEqual([...h.disk],before,'fallback recovery export preserves the corrupt bookmark verbatim');
});

test('novel UI fallback dialog: the native import picker click bubbles without cancellation and change reaches confirmation',async()=>{
  const h=fixture({},null,{unknownDialog:true});h.mount();await h.start();await h.click('saves');
  const before=h.disk.get(PREFIX+'auto'),input=h.elements['novel-import'],modal=h.elements['novel-dialog'];
  await h.click('import');const activation=h.nativeClicks.at(-1);
  assert.equal(activation.target,input);assert.equal(activation.documentReached,true);
  assert.equal(activation.event.defaultPrevented,false,'the file picker default action cannot be cancelled by the fallback background guard');
  assert.equal(activation.event.propagationStopped,false);assert.equal(input.pickerOpenCount,1);
  assert.equal(modal.contains(input),true,'the activated control belongs to the open modal');
  assert.equal(input.parentNode,modal,'the input survives dialog-content replacement as a direct dialog child');
  assert.equal(input.count('change'),1,'the original mounted change listener is retained');
  const first=modal.querySelectorAll('button')[0],last=modal.querySelectorAll('button').at(-1);
  assert.equal(last.dataset.action,'import');last.focus();
  const tab=await h.dispatch('keydown',{key:'Tab',shiftKey:false});
  assert.equal(tab.defaultPrevented,true,'appended hidden picker cannot become the Tab boundary');
  assert.equal(h.document.activeElement,first);assert.notEqual(h.document.activeElement,input);
  await h.change({size:100,text:()=>Promise.resolve(saved('fallback-file-import',6))});
  assert.match(h.dialog,/fallback-file-import/);assert.equal(h.disk.get(PREFIX+'auto'),before,'selection still needs explicit confirmation');
  await h.click('confirm');assert.equal(storedObject(h.disk.get(PREFIX+'auto')).state.marker,'fallback-file-import');
  assert.equal(storedObject(h.disk.get(PREFIX+'auto')).state.revision,6);
  await h.click('saves');await h.click('import');
  assert.equal(h.document.getElementById('novel-import'),input,'reopening retains the same input node');
  assert.equal(input.count('change'),1,'reopening does not duplicate the listener');
  assert.equal(input.pickerOpenCount,2,'the same input remains usable after the first dialog closes');
  assert.equal(h.nativeClicks.at(-1).event.defaultPrevented,false);assert.equal(input.value,'');
});

test('novel UI result rendering: technical notices start folded while nonexecution and failure messages remain visible',async()=>{
  const raw=JSON.parse(saved('result-fixture',1)),xss='<img src=x onerror="globalThis.XSS=1">';
  const notes=['本段客户投资账户的时间加权变动为 +1%，剔除客户申赎。',
    '个人净资产变化还包括工资、生活支出和债务变化，不等于投资赚亏。',
    '委员会批准有限额度：测试公司上限10%。','完成了测试公司的一项研究，使用了本阶段 1 次时间。',
    '按个人账户实际额度买入测试公司；申请目标 10%，本次允许的单一标的上限 40%。',
    '现有持仓、现金或总风险预算已限制新增买入；另一家公司本次没有成交。',
    '当前没有可执行报价，这次交易未能完成。',xss];
  raw.state.result={title:'一个可以阅读的结果',text:'故事正文仍然可见。',fromDate:'2000-01-03',toDate:'2000-06-30',
    changes:[{label:'健康',before:80,after:85,delta:5}],notices:notes,transactions:[],
    performance:{client:{twr:.01},personal:{twr:.02}}};
  const h=fixture();h.mount();await h.importRaw(JSON.stringify(raw));await h.click('confirm');
  const details=[...h.root.matchAll(/<details\b([^>]*)>([\s\S]*?)<\/details>/g)];assert.equal(details.length,1);
  assert.doesNotMatch(details[0][1],/\bopen\b/,'financial appendix is initially collapsed');
  const visible=h.root.replace(/<details\b[^>]*>[\s\S]*?<\/details>/g,'');
  assert.match(visible,/故事正文仍然可见/);assert.match(visible,/当前没有可执行报价，这次交易未能完成/);
  assert.match(visible,/这次没有追加投入/);assert.match(visible,/已按当前可用额度，为自己买入测试公司/);
  assert.doesNotMatch(visible,/时间加权|申请目标|委员会批准有限额度|使用了本阶段|本金净值/);
  for(const text of ['时间加权','申请目标','委员会批准有限额度','使用了本阶段','本金净值'])assert.ok(details[0][2].includes(text),text+' remains available in the appendix');
  assert.equal(h.context.XSS,undefined);assert.equal(h.root.includes('<img src=x'),false);assert.ok(h.root.includes('&lt;img src=x'));
  const failed=fixture();failed.mount();await failed.start();const stale=failed.button('choose');
  await failed.dispatch('click',{target:stale});const before=failed.disk.get(PREFIX+'auto');
  await failed.dispatch('click',{target:stale});assert.match(failed.toast,/stale fixture choice/);
  assert.match(failed.elements['novel-toast'].className,/is-visible.*is-error/);assert.equal(failed.disk.get(PREFIX+'auto'),before);
});

test('novel UI compressed CAS: writes from another VM while import or reload confirmation is open stay protected',async()=>{
  for(const scenario of ['import','reload-external']){
    const disk=new Map([[PREFIX+'auto',packed(saved('shared'))]]),a=fixture({},disk),b=fixture({},disk);
    a.mount();b.mount();await a.click('resume');await b.click('resume');
    let expectedMarker,expectedRevision;
    if(scenario==='import'){
      await b.importRaw(saved('pending-import',7));expectedMarker='pending-import';expectedRevision=7;
    }else{
      await a.choose();await b.choose();await b.click('saves');await b.click('reload-external',{slot:'auto'});
      expectedMarker='shared';expectedRevision=1;
    }
    await a.choose();const latest=disk.get(PREFIX+'auto'),writes=b.operations.filter(op=>op.type==='set').length;
    await b.click('confirm');assert.equal(disk.get(PREFIX+'auto'),latest,scenario+' cannot overwrite an intervening write');
    assert.equal(b.operations.filter(op=>op.type==='set').length,writes);
    await b.click('saves');assert.match(b.dialog,/另一标签页/);const retained=await b.exported();
    assert.equal(retained.state.marker,expectedMarker);assert.equal(retained.state.revision,expectedRevision);
  }
});
