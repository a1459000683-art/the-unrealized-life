const test=require('node:test'),assert=require('node:assert/strict'),fs=require('node:fs'),vm=require('node:vm'),path=require('node:path'),crypto=require('node:crypto');
const root=path.resolve(__dirname,'..');
function read(p){return fs.readFileSync(path.join(root,p),'utf8');}
test('novel single file includes startup recovery before data and application scripts',()=>{
 const html=read('index.html'),scripts=[...html.matchAll(/<script\b([^>]*)>([\s\S]*?)<\/script\s*>/gi)];
 assert.equal(scripts.length,3);assert.match(scripts[0][2],/NOVEL_BOOT_FAIL/);assert.match(scripts[1][1],/application\/json/);
 assert.ok(html.indexOf('id="boot-status"')<html.indexOf('id="market-data"'));assert.match(html,/data-boot-message/);
 assert.doesNotThrow(()=>new vm.Script(scripts[0][2]));assert.doesNotThrow(()=>new vm.Script(scripts[2][2]));
 assert.deepEqual(JSON.parse(scripts[1][2]),JSON.parse(read('data/market.json')));
 assert.doesNotMatch(html,/<script[^>]+src=|@import\s|@font-face\s*\{/i);
 for(const[tag]of html.matchAll(/<link\b[^>]*>/gi)){const href=/\bhref=["']([^"']*)/i.exec(tag)?.[1];assert.ok(!href||href.startsWith('data:'),tag);}
});
test('novel build retains the exact frozen legacy experience and separate save identity',()=>{
 const actual=crypto.createHash('sha256').update(fs.readFileSync(path.join(root,'legacy-v1.1.html'))).digest('hex');
 assert.equal(actual,'b5c692d20fe293d9fedfa9a7590cd803edb536b03e1667bca2dd48c907e94907');
 assert.match(read('index.html'),/legacy\.html/);assert.match(read('src/novel.js'),/unrealized-life-novel/);
 assert.match(read('legacy.html'),/unrealized-life\.v1\./);
});
