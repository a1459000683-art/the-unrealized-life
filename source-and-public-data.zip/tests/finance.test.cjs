'use strict';
const { test } = require('node:test');
const assert = require('node:assert/strict');
const F = require('../src/finance.js');
const near = (actual, expected, tolerance = 1e-8) => assert.ok(Math.abs(actual - expected) <= tolerance * Math.max(1, Math.abs(expected)), `${actual} != ${expected}`);
const account = (n = 10000) => F.createAccount(n, '2000-01-01');
const buy = (a, id = 'A', price = 10, quantity = 100, date = a.date, feeRate = 0) => F.buy(a, { id, price, quantity, date, feeRate });
const sell = (a, id = 'A', price = 10, quantity = 100, date = a.date, feeRate = 0) => F.sell(a, { id, price, quantity, date, feeRate });
const finiteTree = value => { if (typeof value === 'number') assert.ok(Number.isFinite(value)); else if (value && typeof value === 'object') Object.values(value).forEach(finiteTree); };
const unchanged = (a, fn, code) => { const before = JSON.stringify(a); const r = fn(); assert.equal(r.ok, false); if (code) assert.equal(r.code, code); assert.equal(JSON.stringify(a), before); };
const reconcile = a => {
  const s = F.stats(a, a.prices, a.date);
  near(s.nav, a.cash + Object.entries(a.positions).reduce((sum, [id, p]) => sum + p.quantity * a.prices[id], 0), 1e-7);
  near(s.reconciliationError, 0, 1e-7);
  near(a.cash, a.ledger.reduce((sum, row) => sum + (row.amount || 0), 0), 1e-7);
  assert.ok(a.cash >= -1e-8);
  finiteTree(a); finiteTree(s);
};

test('an untouched account has no holdings and no investment profit', () => {
  const a = account(); assert.equal(Object.keys(a.positions).length, 0);
  const s = F.stats(a, {}, '2001-01-01'); near(s.profit, 0); near(s.twr, 0); near(s.mwr.rate, 0); reconcile(a);
});
test('invalid initial cash and invalid calendar date are rejected', () => {
  for (const cash of [-1, NaN, Infinity]) assert.throws(() => account(cash));
  assert.throws(() => F.createAccount(1, '2000-02-30'));
});
test('orders cannot exceed available cash and rejection is atomic', () => {
  const a = account(100); unchanged(a, () => buy(a, 'A', 10, 11), 'insufficient_cash');
});
test('fees are included in cash sufficiency', () => {
  const a = account(100); unchanged(a, () => buy(a, 'A', 10, 10, a.date, 0.01), 'insufficient_cash');
});
test('invalid quantities prices fees and IDs are rejected without mutations', () => {
  const a = account();
  for (const quantity of [0, -1, NaN, Infinity]) unchanged(a, () => buy(a, 'A', 10, quantity));
  for (const price of [0, -1, NaN, Infinity]) unchanged(a, () => buy(a, 'A', price));
  for (const feeRate of [-0.1, 1.1, NaN]) unchanged(a, () => buy(a, 'A', 10, 1, a.date, feeRate));
  unchanged(a, () => buy(a, '__proto__'));
});
test('explicit absence of authorization rejects institutional order', () => {
  const a = account(); unchanged(a, () => F.buy(a, { id: 'A', date: a.date, price: 10, quantity: 10, authorized: false }), 'unauthorized');
});
test('unlisted suspended and cancelled status reject trades', () => {
  const a = account();
  for (const status of ['unlisted', 'suspended', 'cancelled']) unchanged(a, () => F.buy(a, { id: 'A', date: a.date, price: 10, quantity: 10, status }), 'not_tradable');
});
test('cannot sell unowned shares or more than holdings', () => {
  const a = account(); unchanged(a, () => sell(a), 'insufficient_holdings'); buy(a);
  unchanged(a, () => sell(a, 'A', 10, 101), 'insufficient_holdings');
});
test('selling a tiny quantity after complete liquidation is rejected without NaN',()=>{
 const a=account(1000);buy(a,'A',10,1);sell(a,'A',10,1);
 unchanged(a,()=>sell(a,'A',10,1e-10),'insufficient_holdings');finiteTree(a);reconcile(a);
});
test('tiny positive holdings are valued and may be sold; a zero-cash account cannot buy for free',()=>{
 const a=account(10);assert.equal(buy(a,'A',1e10,1e-10).ok,true);near(F.stats(a).nav,10);assert.equal(a.positions.A.quantity,1e-10);
 assert.equal(sell(a,'A',2e10,1e-10).ok,true);near(a.cash,11);finiteTree(a);reconcile(a);
 const empty=account(0);unchanged(empty,()=>buy(empty,'A',10,1e-10),'insufficient_cash');
});
test('buy fees enter average cost; partial sale allocates proportional cost', () => {
  const a = account(); buy(a, 'A', 10, 100, a.date, 0.01); buy(a, 'A', 20, 100, a.date, 0.01);
  near(a.positions.A.cost, 3030); near(a.cash, 6970);
  const r = sell(a, 'A', 30, 50, '2001-01-01', 0.01);
  near(r.costRemoved, 757.5); near(r.realized, 727.5); near(a.positions.A.cost, 2272.5); near(a.positions.A.quantity, 150);
  const s = F.positionStats(a, 'A', 30); near(s.unrealized, 2227.5); near(s.fees, 45); near(s.totalProfit, 2955); assert.equal(s.cagr, null);
  reconcile(a);
});
test('full sale preserves cash proceeds and closes cost to zero', () => {
  const a = account(); buy(a); const r = sell(a, 'A', 12, 100, '2001-01-01', 0.001);
  near(r.realized, 198.8); near(a.cash, 10198.8); near(a.positions.A.cost, 0); near(a.positions.A.quantity, 0); reconcile(a);
});
test('fractional ordinary shares are tracked without integer truncation', () => {
  const a = account(); buy(a, 'A', 12, 1.25); sell(a, 'A', 13, 0.5); near(a.positions.A.quantity, 0.75); near(a.positions.A.cost, 9); reconcile(a);
});
test('split changes shares and quote, never economic value or cost', () => {
  const a = account(); buy(a); const before = F.stats(a).nav;
  assert.equal(F.action(a, { id: 'A-split', companyId: 'A', date: '2001-01-01', type: 'split', ratio: 2 }).ok, true);
  near(a.positions.A.quantity, 200); near(a.prices.A, 5); near(a.positions.A.cost, 1000); near(F.stats(a).nav, before); near(F.stats(a).twr, 0); reconcile(a);
});
test('reverse split preserves fractional entitlements', () => {
  const a = account(); buy(a, 'A', 10, 101);
  F.action(a, { id: 'A-reverse', companyId: 'A', date: '2001-01-01', type: 'split', ratio: 0.1 });
  near(a.positions.A.quantity, 10.1); near(a.prices.A, 100); near(a.positions.A.cost, 1010); reconcile(a);
});
test('dividends are received once and replay does not mutate saved accounts', () => {
  const a = account(); buy(a);
  const action = { id: 'A-div-2001', companyId: 'A', date: '2001-01-01', type: 'dividend', amount: 2 };
  F.action(a, action); near(a.cash, 9200); near(a.totals.dividends, 200);
  const restored = JSON.parse(JSON.stringify(a)), before = JSON.stringify(restored);
  assert.equal(F.action(restored, action).duplicate, true); assert.equal(JSON.stringify(restored), before); reconcile(restored);
});
test('ex-dividend price plus distribution has neutral economic return', () => {
  const a = account(1000); buy(a);
  F.action(a, { id: 'd', companyId: 'A', date: '2001-01-01', type: 'dividend', amount: 1 });
  F.mark(a, '2001-01-01', { A: 9 });
  near(F.stats(a).twr, 0); near(F.positionStats(a, 'A', 9).twr, 0); near(F.stats(a).profit, 0); reconcile(a);
});
test('same-date dividend and ex-dividend settlement cannot create an artificial drawdown peak', () => {
  const a = F.createAccount(1000,'2000-01-03'); buy(a,'A',100,10);
  F.action(a,{id:'d',companyId:'A',date:'2001-01-03',type:'dividend',amount:10});
  F.mark(a,'2001-01-03',{A:90});
  near(F.stats(a).nav,1000); near(F.stats(a).twr,0); near(F.stats(a).maxDrawdown,0); near(F.positionStats(a,'A',90).maxDrawdown,0);
  assert.equal(a.history.filter(x=>x.date==='2001-01-03').length,1);
});
test('interim dividends at stale quotes are excluded from observed maximum drawdown', () => {
  const a=account(1000);buy(a);
  F.action(a,{id:'d',companyId:'A',date:'2000-03-01',type:'dividend',amount:1});
  F.action(a,{id:'s',companyId:'A',date:'2000-04-01',type:'split',ratio:2});
  F.mark(a,'2000-06-30',{A:4.5});
  near(F.stats(a).nav,1000);near(F.stats(a).maxDrawdown,0);near(F.positionStats(a,'A',4.5).twr,0);near(F.positionStats(a,'A',4.5).maxDrawdown,0);
});
test('total-return units reject duplicate raw split or dividend treatment', () => {
  const a = account(); a.priceBasis = 'total_return'; buy(a);
  unchanged(a, () => F.action(a, { id: 'd', companyId: 'A', date: a.date, type: 'dividend', amount: 1 }), 'double_count_prevented');
  unchanged(a, () => F.action(a, { id: 's', companyId: 'A', date: a.date, type: 'split', ratio: 2 }), 'double_count_prevented');
});
test('cash merger settles consideration and extinguishes old shares', () => {
  const a = account(); buy(a); F.action(a, { id: 'm', companyId: 'A', date: '2001-01-01', type: 'cash_merger', amount: 15 });
  near(a.cash, 10500); near(a.positions.A.quantity, 0); near(a.positions.A.realized, 500); assert.equal(a.positions.A.cancelled, true); reconcile(a);
});
test('cancel only destroys remaining equity; prior dividends sales and other assets survive', () => {
  const a = account(); buy(a); buy(a, 'B', 20, 100);
  F.action(a, { id: 'd', companyId: 'A', date: '2001-01-01', type: 'dividend', amount: 1 });
  sell(a, 'A', 8, 25, '2001-01-01');
  const cash = a.cash;
  F.action(a, { id: 'c', companyId: 'A', date: '2002-01-01', type: 'cancel' });
  near(a.cash, cash); near(a.positions.B.quantity, 100); near(a.totals.dividends, 100); near(a.positions.A.quantity, 0); near(a.positions.A.realized, -800);
  near(F.stats(a).profit, -700); unchanged(a, () => buy(a), 'cancelled_equity'); reconcile(a);
});
test('action seen without ownership cannot pay a later purchaser on replay', () => {
  const a = account(), d = { id: 'd', companyId: 'A', date: a.date, type: 'dividend', amount: 1 };
  F.action(a, d); buy(a); const before = a.cash; assert.equal(F.action(a, d).duplicate, true); near(a.cash, before); reconcile(a);
});
test('missing suspended quote carries last verified valuation with explicit stale marker', () => {
  const a = account(); buy(a); const r = F.mark(a, '2001-01-01', {});
  near(r.nav, 10000); assert.deepEqual(r.stale, ['A']); near(a.prices.A, 10);
  unchanged(a, () => F.sell(a, { id: 'A', date: a.date, price: 10, quantity: 100, status: 'suspended' }));
});
test('invalid quotes reject the entire mark atomically', () => {
  const a = account(); buy(a); unchanged(a, () => F.mark(a, '2001-01-01', { A: -1 }));
  unchanged(a, () => F.mark(a, '2001-01-01', { A: Infinity }));
});
test('backdated mutation is rejected', () => {
  const a = account(); F.mark(a, '2001-01-01', {}); unchanged(a, () => buy(a, 'A', 10, 1, '2000-12-31'), 'backdated_operation');
});
test('external subscriptions do not inflate return or profit', () => {
  const a = account(1000); buy(a); F.mark(a, '2001-01-01', { A: 12 });
  near(F.stats(a).twr, 0.2); F.flow(a, 10000, a.date, '客户申购');
  near(F.stats(a).nav, 11200); near(F.stats(a).profit, 200); near(F.stats(a).twr, 0.2); reconcile(a);
});
test('withdrawals preserve TWR while removing external capital', () => {
  const a = account(1000); buy(a); F.mark(a, '2001-01-01', { A: 12 }); sell(a, 'A', 12, 50);
  F.flow(a, -600, a.date, '客户赎回'); near(F.stats(a).twr, 0.2);
  F.mark(a, '2002-01-01', { A: 15 }); near(F.stats(a).twr, 0.5); near(F.stats(a).profit, 350); reconcile(a);
});
test('oversized redemption cannot create margin debt', () => {
  const a = account(); buy(a); unchanged(a, () => F.flow(a, -10000, a.date, '赎回'), 'insufficient_cash');
});
test('zero initial capital followed by funding produces no phantom gain', () => {
  const a = account(0); F.flow(a, 1000, '2001-01-01', '申购'); near(F.stats(a).twr, 0); near(F.stats(a).profit, 0); reconcile(a);
});
test('fees reduce TWR and are not misclassified as external redemptions', () => {
  const a = account(1000); F.expense(a, 5, '2001-01-01', '管理费');
  near(F.stats(a).twr, -0.005); near(F.stats(a).profit, -5); near(F.stats(a).fees, 5); near(F.stats(a).netContributions, 1000); reconcile(a);
});
test('expense refusal is atomic when the account has insufficient liquid cash', () => {
  const a = account(1000); buy(a); unchanged(a, () => F.expense(a, 1, a.date, '管理费'), 'insufficient_cash');
});
test('complete loss is finite and does not create unbounded liability', () => {
  const a = account(1000); buy(a); F.action(a, { id: 'c', companyId: 'A', date: '2001-01-01', type: 'cancel' });
  const s = F.stats(a); near(s.nav, 0); near(s.profit, -1000); near(s.twr, -1); near(s.cagr, -1); assert.equal(s.mwr.rate, null); finiteTree(s); reconcile(a);
});
test('new funding after total loss does not erase the lifetime total-loss return', () => {
  const a = account(1000); buy(a); F.action(a, { id: 'c', companyId: 'A', date: '2001-01-01', type: 'cancel' });
  F.flow(a, 500, '2002-01-01', '追加'); near(F.stats(a).twr, -1); near(F.stats(a).profit, -1000); reconcile(a);
});
test('CAGR uses actual elapsed days and defines zero-day boundaries', () => {
  near(F.cagr(100, 121, 730), 0.1); near(F.cagr(100, 0, 365), -1);
  for (const args of [[0, 1, 365], [100, 100, 0], [100, -1, 365], [100, 1, -1], [NaN, 1, 365]]) assert.equal(F.cagr(...args), null);
  assert.equal(F.daysBetween('2000-01-01', '2001-01-01'), 366);
});
test('XIRR agrees with the documented Microsoft irregular-cashflow example', () => {
  const r = F.xirr([{date:'2008-01-01',amount:-10000},{date:'2008-03-01',amount:2750},{date:'2008-10-30',amount:4250},{date:'2009-02-15',amount:3250},{date:'2009-04-01',amount:2750}]);
  near(r.rate, 0.3733625335188315, 1e-9); assert.equal(r.reason, null);
});
test('XIRR recovers a constructed irregular cashflow rate', () => {
  const rate = 0.08, t1 = 180/365, t2 = 800/365, terminal = (1000 + 500 / Math.pow(1+rate,t1)) * Math.pow(1+rate,t2);
  const r = F.xirr([{ date:'2001-01-01',amount:-1000 },{ date:'2001-06-30',amount:-500 },{ date:'2003-03-12',amount:terminal }]);
  near(r.rate, rate, 1e-10);
});
test('XIRR rejects choosing one arbitrary root of a two-root investment', () => {
  const r = F.xirr([{date:'2001-01-01',amount:-100},{date:'2002-01-01',amount:230},{date:'2003-01-01',amount:-132}]);
  assert.equal(r.rate, null); assert.equal(r.reason, 'multiple_roots'); assert.equal(r.roots.length, 2); near(r.roots[0],0.1,1e-8); near(r.roots[1],0.2,1e-8);
});
test('XIRR detects a tangent root instead of declaring no solution', () => {
  const r = F.xirr([{date:'2001-01-01',amount:-100},{date:'2002-01-01',amount:200},{date:'2003-01-01',amount:-100}]);
  assert.equal(r.rate,null); assert.equal(r.reason,'tangent_root_ambiguous'); near(r.roots[0],0);
});
test('XIRR no solution zero days and invalid inputs return explicit reasons', () => {
  for (const flows of [[], [{date:'2000-01-01',amount:NaN}], [{date:'2000-02-30',amount:1}], [{date:'2000-01-01',amount:-100},{date:'2000-01-01',amount:110}], [{date:'2000-01-01',amount:-100},{date:'2001-01-01',amount:-10}]]) {
    const r = F.xirr(flows); assert.equal(r.rate,null); assert.ok(r.reason); finiteTree(r);
  }
  assert.equal(F.xirr([{date:'2001-01-01',amount:-100},{date:'2002-01-01',amount:10},{date:'2003-01-01',amount:-100}]).reason,'no_solution');
});
test('XIRR is invariant to input ordering and combines same-day flows', () => {
  const a = [{date:'2001-01-01',amount:-60},{date:'2002-01-01',amount:110},{date:'2001-01-01',amount:-40}];
  near(F.xirr(a).rate,0.1); near(F.xirr([...a].reverse()).rate,0.1);
});
test('huge mathematically valid XIRR is surfaced as out of numeric range', () => {
  const r = F.xirr([{date:'2001-01-01',amount:-0.000001},{date:'2001-01-02',amount:1000000}]);
  assert.equal(r.rate,null); assert.equal(r.reason,'rate_outside_numeric_range'); finiteTree(r);
});
test('account CAGR is withheld after added capital while TWR remains valid', () => {
  const a = account(); F.flow(a, 500, '2001-01-01', '工资储蓄'); assert.equal(F.stats(a).cagr,null); assert.ok(F.stats(a).cagrReason); near(F.stats(a).twr,0);
});
test('position returns include exit cash remaining exposure dividends and all fees', () => {
  const a = account(); buy(a, 'A', 10, 100, a.date, 0.01);
  F.action(a, {id:'d',companyId:'A',date:'2001-01-01',type:'dividend',amount:1}); sell(a,'A',12,40,'2001-01-01',0.01);
  const s=F.positionStats(a,'A',15,'2002-01-01');
  near(s.invested,1010); near(s.proceeds,475.2); near(s.marketValue,900); near(s.dividends,100); near(s.totalProfit,465.2); near(s.totalReturn,465.2/1010); assert.equal(s.cagr,null); finiteTree(s);
});
test('actual holding days exclude a fully exited interval before re-entry',()=>{
 const a=account();buy(a,'A',10,100,'2000-01-01');sell(a,'A',11,100,'2001-01-01');
 buy(a,'A',12,50,'2003-01-01');F.mark(a,'2004-01-01',{A:13});
 const s=F.positionStats(a,'A',13);assert.equal(s.holdingDays,731);assert.equal(s.elapsedDays,1461);assert.equal(s.holdingPeriods.length,2);assert.equal(s.cagr,null);
});
test('maximum drawdown ignores cash inflows and labels its sampling', () => {
  const a=account(1000); buy(a); F.mark(a,'2001-01-01',{A:20}); F.flow(a,20000,a.date,'申购'); F.mark(a,'2002-01-01',{A:10});
  const s=F.stats(a); near(s.maxDrawdown,-1000/22000); assert.match(s.sampling,/不是日内/);
  near(F.drawdown([1,2,1,1.5]),-0.5); near(F.drawdown([0,0]),0);
});
test('same deterministic ledger is reproduced byte for byte after save and restore', () => {
  const a=account(); buy(a); F.mark(a,'2001-01-01',{A:8}); const b=JSON.parse(JSON.stringify(a));
  for (const c of [a,b]) { sell(c,'A',9,20,'2002-01-01'); F.flow(c,400,c.date,'工资'); F.expense(c,10,c.date,'管理费'); }
  assert.equal(JSON.stringify(a),JSON.stringify(b)); reconcile(a); reconcile(b);
});
test('full account validator accepts authentic buys partials corporate actions flows and expenses',()=>{
 const a=account();assert.equal(F.validateAccount(a,a.date).ok,true);
 buy(a,'A',10,100,a.date,0.001);F.action(a,{id:'d',companyId:'A',date:'2001-01-01',type:'dividend',amount:1});
 F.action(a,{id:'s',companyId:'A',date:'2001-03-01',type:'split',ratio:2});F.mark(a,'2001-06-30',{A:9});sell(a,'A',9,50,a.date,0.001);
 F.expense(a,10,a.date,'fee');F.flow(a,100,a.date,'salary');assert.deepEqual(F.validateAccount(JSON.parse(JSON.stringify(a)),a.date),{ok:true});
 F.action(a,{id:'c',companyId:'A',date:'2002-01-01',type:'cancel'});assert.deepEqual(F.validateAccount(a,a.date),{ok:true});
});
test('full account validator rejects typed-field corruption and ledger inconsistency',()=>{
 const a=account();buy(a);F.action(a,{id:'d',companyId:'A',date:'2001-01-01',type:'dividend',amount:1});F.mark(a,'2001-06-30',{A:9});
 const mutations=[b=>b.prices.A='10',b=>b.prices.A=-1,b=>b.quoteDates.A='2099-01-01',b=>b.totals.expenses='0',b=>b.positions.A.pendingDistribution=-1,b=>b.positions.A.quantity=2,b=>b.positions.A.cost=10,b=>b.positions.A.cashFlows[0].amount=0,b=>b.ledger[1].amount=0,b=>b.ledger[1].date='2000-02-30',b=>b.history[0].unitValue=-1,b=>b.appliedActions.d.companyId='B',b=>b.cash+=100,b=>b.externalFlows[0].amount+=100,b=>b.positions.A.lastValue=NaN,b=>b.positions.A.cancelled='false',b=>b.history[0].stale={},b=>b.prices=[]];
 for(const change of mutations){const b=JSON.parse(JSON.stringify(a));change(b);const result=F.validateAccount(b,b.date);assert.equal(result.ok,false);assert.ok(result.error);}
 assert.equal(F.validateAccount(a,'2002-01-01').ok,false);
});
test('seeded 1200-operation simulation conserves cash and P&L through losses partials flows and actions', () => {
  const a=account(100000); let seed=71823; const random=()=>{seed=(Math.imul(seed,1664525)+1013904223)>>>0;return seed/4294967296;};
  const ids=['A','B','C','D'], prices={A:20,B:30,C:40,D:50};
  for (let i=0;i<1200;i++) {
    const date=new Date(Date.UTC(2000,0,1+i)).toISOString().slice(0,10),id=ids[Math.floor(random()*ids.length)],p=a.positions[id];
    prices[id]*=0.9+0.2*random(); F.mark(a,date,prices);
    const op=Math.floor(random()*6);
    if(op===0) buy(a,id,prices[id],Math.floor(random()*100),date,0.001);
    if(op===1 && p?.quantity>0) sell(a,id,prices[id],p.quantity*random(),date,0.001);
    if(op===2) F.flow(a,random()<0.6?200:-Math.min(a.cash,100),date,'simulation cashflow');
    if(op===3) F.expense(a,Math.min(a.cash,3),date,'simulation fee');
    if(op===4) F.action(a,{id:'d'+i,companyId:id,date,type:'dividend',amount:0.01});
    if(op===5 && p?.quantity>0) {F.action(a,{id:'s'+i,companyId:id,date,type:'split',ratio:2});prices[id]/=2;}
    // Reconciliation is independent of the return solver to keep simulation bounded.
    const nav=a.cash+Object.entries(a.positions).reduce((s,[k,pos])=>s+pos.quantity*a.prices[k],0);
    const cost=Object.values(a.positions).reduce((s,pos)=>s+pos.cost,0), market=nav-a.cash;
    near(nav-a.externalFlows.reduce((s,f)=>s+f.amount,0),a.totals.realized+market-cost+a.totals.dividends-a.totals.expenses,1e-7);
    near(a.cash,a.ledger.reduce((s,row)=>s+(row.amount||0),0),1e-7); assert.ok(a.cash>=0); finiteTree(a);
  }
  for(let i=1;i<a.ledger.length;i++) assert.ok(a.ledger[i].date>=a.ledger[i-1].date);
  assert.deepEqual(F.validateAccount(a,a.date),{ok:true});
});
