/* Static, individually authored interactive-novel scenes. Historical data lives in MARKET. */
globalThis.NOVEL_STORY = {
  "version": 1,
  "title": "未实现的人生",
  "subtitle": "有些东西会复利，有些不会等你。",
  "setting": "2000年，你24岁，在美国一家虚构的基层资产管理公司开始工作。所有人物、雇主、私人经历均属虚构；证券的价格和公开信息来自独立历史资料。",
  "characters": [
    {
      "id": "lin",
      "name": "林知远",
      "role": "资深研究员与研究导师",
      "goal": "把能被别人复核的研究方法留下，业余修复旧家具",
      "boundary": "不替任何人签自己没有读过的报告",
      "roleHistory": [
        {
          "from": "2000-01-01",
          "role": "资深研究员与研究导师"
        },
        {
          "from": "2011-01-01",
          "role": "退休研究员，旧家具修复爱好者"
        }
      ]
    },
    {
      "id": "mara",
      "name": "玛拉·韦斯",
      "role": "海岬资产管理组合主管",
      "goal": "让团队在集团的预算争夺中活下来，也争取自己的席位",
      "boundary": "不接受绕过委员会动用客户资金",
      "roleHistory": [
        {
          "from": "2000-01-01",
          "role": "海岬资产管理组合主管"
        }
      ]
    },
    {
      "id": "june",
      "name": "朱恩·赵",
      "role": "客户关系负责人",
      "goal": "让客户的实际用款日期进入投资决策，也为自己的生活留下稳定时间",
      "boundary": "拒绝用保本承诺换取续约",
      "roleHistory": [
        {
          "from": "2000-01-01",
          "role": "客户关系负责人"
        }
      ]
    },
    {
      "id": "elias",
      "name": "伊莱·洛佩斯",
      "role": "合规同事",
      "goal": "建立遇到压力仍可使用的记录制度",
      "boundary": "不能为朋友删除利益冲突记录",
      "roleHistory": [
        {
          "from": "2000-01-01",
          "role": "合规同事"
        },
        {
          "from": "2017-01-01",
          "role": "公益机构运营人员"
        }
      ]
    },
    {
      "id": "mei",
      "name": "梅·陈",
      "role": "博物馆藏品登记员",
      "goal": "完成自己的巡回展，在友情中保留独立生活",
      "boundary": "不无限等待没有日期的约定",
      "roleHistory": [
        {
          "from": "2000-01-01",
          "role": "博物馆藏品登记员"
        },
        {
          "from": "2011-01-01",
          "role": "展览项目主管"
        }
      ]
    },
    {
      "id": "sam",
      "name": "山姆·里德",
      "role": "年轻研究同事",
      "goal": "得到可署名的工作，兼顾父亲的日常照护",
      "boundary": "不再长期承担别人的紧急加班",
      "roleHistory": [
        {
          "from": "2000-01-01",
          "role": "年轻研究同事"
        },
        {
          "from": "2014-01-01",
          "role": "独立带组的研究同事，与旧同事保持项目合作"
        }
      ]
    },
    {
      "id": "nora",
      "name": "诺拉·陈",
      "role": "姐姐，建筑绘图员",
      "goal": "开自己的小事务所，与家人平等分担照顾责任",
      "boundary": "不把自己的工作永远排在玩家工作后面",
      "roleHistory": [
        {
          "from": "2000-01-01",
          "role": "姐姐，建筑绘图员"
        },
        {
          "from": "2005-01-01",
          "role": "姐姐，独立建筑绘图事务所负责人"
        }
      ]
    },
    {
      "id": "darius",
      "name": "达里厄斯·科尔",
      "role": "社区图书馆成人教育协调员",
      "goal": "让夜校课程靠稳定预算运转，而非靠讲师的英雄主义",
      "boundary": "不接受以课程名义推销金融产品",
      "roleHistory": [
        {
          "from": "2000-01-01",
          "role": "社区图书馆成人教育协调员"
        }
      ]
    }
  ],
  "chapters": [
    {
      "id": "first",
      "title": "第一部 · 以为来得及",
      "fromIndex": 0,
      "toIndex": 15,
      "summary": "2000—2006，从整理别人的文件开始，把未来写得很满。"
    },
    {
      "id": "fracture",
      "title": "第二部 · 钱有用途，人有去处",
      "fromIndex": 16,
      "toIndex": 30,
      "summary": "2007—2013，市场改变工作，也让一些旧约定变得具体。"
    },
    {
      "id": "homeward",
      "title": "第三部 · 剩下的时间",
      "fromIndex": 31,
      "toIndex": 52,
      "summary": "2014—2020，继续、离开、等待，都会留下不同的日常。"
    }
  ],
  "starts": [
    {
      "id": "debt",
      "title": "带着借款来到这里",
      "text": "你读完书，背着6.5万美元债务，手边只有1.4万美元。工作是机会，也是下一张账单的来源。姐姐说她可以帮忙，但你不愿每次接电话都先解释钱。",
      "note": "现金少、债务重；先留生活缓冲也算一个决定。"
    },
    {
      "id": "buffer",
      "title": "有一笔可以等待的钱",
      "text": "家人留下的积蓄与此前工作所得，让你有9万美元现金，另有8000美元债务。它让你可以慢一点，却没有替你回答：这笔钱到底是用来证明自己，还是让生活更从容？",
      "note": "较厚缓冲；家人并未因此放弃自己的需要。"
    },
    {
      "id": "network",
      "title": "经人介绍走进门",
      "text": "你有3.2万美元现金、8000美元债务，一位旧识替你争取到面试。大家愿意听你说话，也会记得是谁推荐你。你想把人情变成自己的能力，而不只是下一次好开口。",
      "note": "关系与沟通起点较好；投资权限仍要靠工作获得。"
    }
  ],
  "groupCount": 77,
  "secondSlots": [
    0,
    1,
    2,
    4,
    6,
    10,
    11,
    12,
    14,
    16,
    18,
    20,
    22,
    23,
    25,
    27,
    28,
    30,
    31,
    32,
    35,
    37,
    39,
    49
  ],
  "nodes": [
    {
      "id": "n00_0",
      "dateIndex": 0,
      "slot": 0,
      "priority": 0,
      "chapter": "first",
      "title": "没有名字的工位",
      "text": "你把纸箱塞到桌下，电脑屏幕亮起时，海岬资产管理的门刚打开。你二十四岁，名片还没印好。林知远递来一份旧报告：结论写得很响亮，后面的算式却找不到出处。\n\n玛拉下午要用它开会。你可以让这份工作很快看起来完成，也可以承认自己还没看懂。窗外的城市不等你准备好，屋里却有人会因为你写下的一句话去动用别人的钱。",
      "characters": [
        "lin",
        "mara"
      ],
      "chain": "archive",
      "choices": [
        {
          "id": "a",
          "label": "先把算式找回来",
          "detail": "今天交得慢一点，留下可以核对的记录。",
          "result": {
            "text": "你在页边写出三个问号。林没有替你解答，只把原件柜的钥匙放在桌上。下午，你交的是一份不完整、但知道哪里不完整的报告。"
          },
          "effects": {
            "research": 6,
            "discipline": 5,
            "stress": 3,
            "relations": {
              "lin": 6
            },
            "flags": [
              "kept_notes"
            ]
          }
        },
        {
          "id": "b",
          "label": "先问会议究竟要决定什么",
          "detail": "向主管确认用途，再安排有限的时间。",
          "result": {
            "text": "玛拉停下脚步，说委员会今天只讨论要不要继续研究。你删掉未经核实的结论，写清需要的材料。她记住了你问问题的方式。"
          },
          "effects": {
            "communication": 6,
            "trust": 4,
            "relations": {
              "mara": 4
            }
          }
        },
        {
          "id": "c",
          "label": "把报告整理得像样些",
          "detail": "先交一版，争取尽快被看见。",
          "result": {
            "text": "标题和图表准时出现在会议桌上。玛拉说谢谢。散会后，林在你桌上留了便条：明天还得回答，那个数字从哪里来。"
          },
          "effects": {
            "reputation": 5,
            "stress": 5,
            "discipline": -3,
            "flags": [
              "presentation_first"
            ]
          }
        }
      ]
    },
    {
      "id": "n00_1",
      "dateIndex": 0,
      "slot": 1,
      "priority": 0,
      "chapter": "first",
      "title": "姐姐冰箱上的便条",
      "text": "下班后，你去姐姐诺拉的小公寓吃饭。她把一张购物单翻过来，背面写着母亲的复诊日期、房租和她自己的加课时间。她不是来审问你的薪水，只想知道这个星期日你能不能回来一起吃饭。\n\n你忽然发现，办公室里的日历叫“安排”，家里的日历却经常被你叫作“看看再说”。桌边还有空位；你需要决定留给什么。",
      "characters": [
        "nora"
      ],
      "chain": "family",
      "choices": [
        {
          "id": "a",
          "label": "把星期日留出来",
          "detail": "承诺一个具体时间，也留出生活缓冲。",
          "result": {
            "text": "诺拉把你的名字写进日历。她没有说这就足够，只问你喜欢吃什么。你第一次觉得，留下一天也可以是一项明确的安排。"
          },
          "effects": {
            "freedom": 4,
            "health": 3,
            "relations": {
              "nora": 7
            },
            "flags": [
              "home_call",
              "seed_saving"
            ]
          }
        },
        {
          "id": "b",
          "label": "先把手边一部分债还掉",
          "detail": "使用当前可用现金的20%，不会卖出股票。",
          "result": {
            "text": "你回家核对账单，按可用现金的20%偿还，最多还到实际欠款为零。有的开局这笔钱足够结清，有的仍需慢慢还；准确的余额留在账本里，你也给姐姐回了消息。"
          },
          "effects": {
            "discipline": 5,
            "flags": [
              "debt_plan"
            ]
          },
          "strategy": {
            "type": "repay",
            "account": "personal",
            "targetPercent": 20
          }
        },
        {
          "id": "c",
          "label": "先答应办公室随叫随到",
          "detail": "希望加快站稳脚跟，家里的约定暂不固定。",
          "result": {
            "text": "你把号码留给所有同事。夜里第一个电话响起，你以为这就是被需要的声音。姐姐也接到了你的改期电话，她说知道了。"
          },
          "effects": {
            "trust": 5,
            "stress": 7,
            "health": -3,
            "relations": {
              "nora": -4
            },
            "flags": [
              "career_first"
            ]
          }
        }
      ]
    },
    {
      "id": "n01_0",
      "dateIndex": 1,
      "slot": 0,
      "priority": 0,
      "chapter": "first",
      "title": "黄纸背面的条件",
      "text": "半年过去，你已经学会在电话响第三声前接起来。林带你复核一份零件企业的资料，最醒目的不是利润，而是客户能不能方便地换一家供货商。你问，找到好企业是否就等于找到好投资。\n\n他把黄纸翻过来：“也要看付多少钱。”办公室里有人正讨论更热闹的股票，你可以把这张纸留下，也可以让它随着今天的会议一起结束。",
      "characters": [
        "lin"
      ],
      "chain": "archive",
      "choices": [
        {
          "id": "a",
          "label": "写下什么情况会让自己改主意",
          "detail": "记录判断的边界，不只记买入理由。",
          "result": {
            "text": "你写下客户流失、现金紧张与价格太贵三栏。林把日期盖上去，提醒你以后回来时，先读这一页，不要先看自己赚了多少。"
          },
          "effects": {
            "research": 5,
            "discipline": 5,
            "flags": [
              "kept_notes",
              "exit_reason"
            ],
            "relations": {
              "lin": 4
            }
          }
        },
        {
          "id": "b",
          "label": "请同事从反面挑错",
          "detail": "让别人看见你的疑问。",
          "result": {
            "text": "山姆把报告读到最后，说自己并不懂那项业务。他提出的问题很朴素，却让你删掉了两句从别处抄来的判断。"
          },
          "effects": {
            "research": 4,
            "communication": 5,
            "relations": {
              "sam": 5
            }
          }
        },
        {
          "id": "c",
          "label": "今天先不做结论",
          "detail": "把不知道的地方留下，正常下班。",
          "result": {
            "text": "你没有把空白补成答案。当天市场仍然涨跌，空白却没有因此变得可耻。回家路上，你终于把新街区走熟了一点。"
          },
          "effects": {
            "health": 3,
            "stress": -4,
            "discipline": 3
          },
          "strategy": {
            "type": "hold",
            "account": "personal"
          }
        }
      ]
    },
    {
      "id": "n01_1",
      "dateIndex": 1,
      "slot": 1,
      "priority": 0,
      "chapter": "first",
      "title": "门牌还没有变",
      "text": "玛拉叫住你，说团队准备多接几个客户，需要有人长期做那些没人愿意接的工作：校对、解释、在坏消息后回电话。她没有保证升职，只说做得好的人会慢慢得到更多权限。\n\n你把这句话听成机会，又想到办公桌里那张尚未寄出的家书。你当然可以想往上走；问题是要让谁先知道你打算怎么走。",
      "characters": [
        "mara",
        "june"
      ],
      "chain": "ambition",
      "choices": [
        {
          "id": "a",
          "label": "说清楚自己想承担更多",
          "detail": "主动争取工作，也要求有人复核。",
          "result": {
            "text": "玛拉给了你一项正式任务和一位复核人。你仍不能自由动用客户资金，但“以后再说”的愿望终于变成了可以检查的工作。"
          },
          "effects": {
            "trust": 6,
            "research": 2,
            "stress": 4,
            "authority": 5,
            "flags": [
              "promotion_requested"
            ],
            "relations": {
              "mara": 5
            }
          }
        },
        {
          "id": "b",
          "label": "先把现有工作做稳",
          "detail": "让能力和生活都保留余量。",
          "result": {
            "text": "你们约好三个月后再谈。玛拉没有生气，朱恩却松了一口气：至少这次答应客户的截止日，不需要有人突然失踪才能完成。"
          },
          "effects": {
            "discipline": 5,
            "health": 3,
            "relations": {
              "june": 4
            },
            "flags": [
              "steady_work"
            ]
          }
        },
        {
          "id": "c",
          "label": "问能不能只做更擅长的部分",
          "detail": "接受进展慢一些，换更明确的边界。",
          "result": {
            "text": "你留下研究和解释工作，放弃了一项对外露面的机会。名片没有变长，周末也没有被悄悄写进岗位说明。"
          },
          "effects": {
            "freedom": 6,
            "reputation": -2,
            "stress": -3,
            "flags": [
              "work_boundary"
            ]
          }
        }
      ]
    },
    {
      "id": "n02_0",
      "dateIndex": 2,
      "slot": 0,
      "priority": 0,
      "chapter": "first",
      "title": "卖软件的人，收维护费的人",
      "text": "你查的是一家给地方银行提供后台系统的企业。屏幕上的故事并不耀眼：客户每天开门、处理账户、出错时需要有人接电话。收入有持续服务的一面，换系统也有成本；但银行减少支出，或者竞争者做得更好，仍会改变生意。\n\n年末你有机会用自己的一小部分钱试着持有。林提醒你，懂一点用途，只是开始，还得承受买贵和看错的可能。",
      "characters": [
        "lin"
      ],
      "chain": "wealth",
      "choices": [
        {
          "id": "a",
          "label": "用个人账户的一小部分试买",
          "detail": "尝试把溪桥系统配到个人资产的10%。",
          "result": {
            "text": "交易会按这一天的真实价格和可用资金核算。你在记录里写下：这是对一门生意的有限押注，不能把下个月的生活费也叫作耐心。"
          },
          "effects": {
            "research": 4,
            "discipline": 3,
            "flags": [
              "seed_saving"
            ],
            "researchCompany": [
              {
                "companyId": "JKHY",
                "topic": "customers"
              }
            ]
          },
          "strategy": {
            "type": "invest",
            "account": "personal",
            "companyId": "JKHY",
            "targetPercent": 10
          }
        },
        {
          "id": "b",
          "label": "把现金先用于减轻债务",
          "detail": "拿当前可用现金的15%还债。",
          "result": {
            "text": "你没有参与今天这笔买入。若仍有欠款，账户用可用现金按既定比例偿还；若债务已清，就保留现金，不制造一张零金额的还款回执。负担与投资机会分别记账。"
          },
          "effects": {
            "discipline": 5,
            "stress": -3,
            "flags": [
              "debt_plan"
            ]
          },
          "strategy": {
            "type": "repay",
            "account": "personal",
            "targetPercent": 15
          }
        },
        {
          "id": "c",
          "label": "再观察一个阶段",
          "detail": "读客户资料，暂不买卖。",
          "result": {
            "text": "你把想知道的问题留在档案首页。没有人能保证等待会更便宜，等待至少让你知道，此刻为什么还不愿意交出现金。"
          },
          "effects": {
            "research": 5,
            "freedom": 2,
            "researchCompany": [
              {
                "companyId": "JKHY",
                "topic": "customers"
              }
            ]
          },
          "strategy": {
            "type": "hold",
            "account": "personal"
          }
        }
      ]
    },
    {
      "id": "n02_1",
      "dateIndex": 2,
      "slot": 1,
      "priority": 0,
      "chapter": "first",
      "title": "没有贴标签的相处",
      "text": "梅带你去看她参与登记的一批旧物。展厅闭馆后，胶带、手套和纸箱堆在角落；她说外人只看见布展后的灯光，没看见搬东西的人。你们谈了很久，却都没有给这段关系取名字。\n\n她周六有一场小型展览，希望你来。你手机上的未读工作邮件亮了几次。这不是一道关于谁更值得的题，她只是想知道，能不能把你算进那一天。",
      "characters": [
        "mei"
      ],
      "chain": "friend",
      "choices": [
        {
          "id": "a",
          "label": "答应，并把那天写进日历",
          "detail": "留一个可以兑现的日期。",
          "result": {
            "text": "你问清开门时间和她最需要帮忙的时段。梅把一张工作证递给你，说穿旧鞋来。约定从一句客套变成了具体的一双鞋。"
          },
          "effects": {
            "health": 3,
            "freedom": 3,
            "relations": {
              "mei": 7
            },
            "flags": [
              "promise_date"
            ]
          }
        },
        {
          "id": "b",
          "label": "坦白现在还不能保证",
          "detail": "不让她替不确定的约定空等。",
          "result": {
            "text": "梅说可以，她会先找别人。她仍把展览地址发给你，但没有再替你保留那个位置。诚实让相处轻一点，也让缺席变得真实。"
          },
          "effects": {
            "communication": 4,
            "discipline": 3,
            "relations": {
              "mei": 1
            }
          }
        },
        {
          "id": "c",
          "label": "先说会去，工作再看",
          "detail": "两边都不想拒绝。",
          "result": {
            "text": "你暂时得到了两个世界的欢迎。周六还没有到，日历上那一格却已经被写了两遍；冲突只是被推迟了，并没有消失。"
          },
          "effects": {
            "trust": 2,
            "stress": 5,
            "relations": {
              "mei": -3
            },
            "flags": [
              "double_promise"
            ]
          }
        }
      ]
    },
    {
      "id": "n03_0",
      "dateIndex": 3,
      "slot": 0,
      "priority": 0,
      "chapter": "first",
      "title": "客户把用途写在信封上",
      "text": "朱恩带来一只信封，里面不是投资建议，而是客户未来两年的几笔用款日期：学费、房屋维修、为亲人准备的照护费用。客户不懂你们常用的缩写，却很清楚哪笔钱不能迟到。\n\n同事在另一间屋里比较季度排名。你第一次看到，“回报不错”和“这笔钱有用”之间，可能隔着一段根本等不起的时间。朱恩等你决定怎样整理这份委托。",
      "characters": [
        "june"
      ],
      "chain": "clients",
      "choices": [
        {
          "id": "a",
          "label": "先把用钱日期排清楚",
          "detail": "将期限写入日后可以回看的记录。",
          "result": {
            "text": "你们把每笔用途分开。朱恩没有承诺客户永远不亏，只承诺讨论风险时不会把那几个日期藏起来。她把信封交给你保管副本。"
          },
          "effects": {
            "trust": 5,
            "communication": 4,
            "discipline": 5,
            "flags": [
              "client_dates"
            ],
            "relations": {
              "june": 7
            }
          }
        },
        {
          "id": "b",
          "label": "给客户解释不同选择的代价",
          "detail": "把好理解放在术语前面。",
          "result": {
            "text": "你用“多久不能动用”和“最怕什么”重新写了一页说明。客户提出了更多问题，会议开得更长，你却终于知道对方在担心什么。"
          },
          "effects": {
            "communication": 7,
            "trust": 3,
            "stress": 2,
            "relations": {
              "june": 4
            }
          }
        },
        {
          "id": "c",
          "label": "先争取更好看的近期成绩",
          "detail": "让团队更容易在续约时被看见。",
          "result": {
            "text": "简报获得了主管赞许。朱恩另建了一份用款表，没有阻止你，也没有让那只信封离开她的抽屉。你们开始承担不同的工作。"
          },
          "effects": {
            "reputation": 6,
            "stress": 4,
            "relations": {
              "june": -4
            },
            "flags": [
              "ranking_first"
            ]
          }
        }
      ]
    },
    {
      "id": "n04_0",
      "dateIndex": 4,
      "slot": 0,
      "priority": 0,
      "chapter": "first",
      "title": "九月以后，先问谁平安",
      "text": "城市经历袭击后的几个星期，办公室的电话比以往更安静。有些同事还在找熟人的消息，另一些人试着恢复每天的程序。市场的波动在屏幕上，害怕却不只在屏幕上。\n\n玛拉说今天不要求任何人表现得像什么都没发生。朱恩还是需要有人回应客户。你能做的很有限：确认自己知道什么，承认不知道什么，并决定今天把力气放在哪里。",
      "characters": [
        "mara",
        "june"
      ],
      "chain": "clients",
      "choices": [
        {
          "id": "a",
          "label": "先联系身边的人",
          "detail": "把平安和需要帮助的人记下来。",
          "result": {
            "text": "你没有替任何人许诺明天。电话那头有人只说了一句收到。晚上，你向主管说明尚未完成的工作，第一次没有为这句话加上长长的道歉。"
          },
          "effects": {
            "health": 4,
            "stress": -5,
            "relations": {
              "nora": 4,
              "mei": 4
            },
            "flags": [
              "people_first"
            ]
          }
        },
        {
          "id": "b",
          "label": "帮朱恩回复客户",
          "detail": "只说明已核实的安排。",
          "result": {
            "text": "你们把不能保证的事情从话术里删去。几个客户仍然很不安，但至少听见了一个活人的声音，也知道下一次何时会再被联系。"
          },
          "effects": {
            "communication": 5,
            "trust": 4,
            "stress": 4,
            "flags": [
              "client_dates"
            ],
            "relations": {
              "june": 5
            }
          }
        },
        {
          "id": "c",
          "label": "把交易决定暂缓",
          "detail": "让不确定留在纸面上。",
          "result": {
            "text": "你把当天的判断留白，完成需要处理的最低限度工作。等待没有让市场停止，也没有使你免于波动；它只是这一天你能够承担的边界。"
          },
          "effects": {
            "discipline": 5,
            "health": 2,
            "stress": -3
          },
          "strategy": {
            "type": "hold",
            "account": "personal"
          }
        }
      ]
    },
    {
      "id": "n04_1",
      "dateIndex": 4,
      "slot": 1,
      "priority": 0,
      "chapter": "first",
      "title": "星期三还要不要留着",
      "text": "日常逐渐恢复后，你发现自己连续几个星期都没在天黑前离开办公室。以前固定散步的星期三，只剩日历里一条被划掉的线。诺拉说最近很难约到你，林则把一份并不紧急的资料拿回去，说下周再看。\n\n没有人能凭几次疲惫判断你的健康会怎样。你能确定的是，时间不会因为一句“忙完这阵”就自动空出来，需要有人现在动手把它留住。",
      "characters": [
        "lin",
        "nora"
      ],
      "chain": "health",
      "choices": [
        {
          "id": "a",
          "label": "恢复每周一个不接工作的晚上",
          "detail": "说明交接人和真正紧急的联系方式。",
          "result": {
            "text": "第一晚你仍不时摸手机。走了几条街以后，才注意到常去的店换了招牌。工作还在，离开它几个小时也没有让你失去名字。"
          },
          "effects": {
            "health": 6,
            "stress": -7,
            "freedom": 5,
            "flags": [
              "weekly_boundary"
            ],
            "relations": {
              "nora": 4
            }
          }
        },
        {
          "id": "b",
          "label": "约一次检查，也和主管谈安排",
          "detail": "把不舒服交给专业人员评估，不自己下结论。",
          "result": {
            "text": "预约写进了日历。你没有从一次检查得到关于未来的保证，但和主管商量好的分工，从这一周就开始改变你的晚上。"
          },
          "effects": {
            "health": 4,
            "stress": -4,
            "personalCash": -180,
            "flags": [
              "care_sought"
            ],
            "relations": {
              "mara": 2
            }
          }
        },
        {
          "id": "c",
          "label": "把这个晚上继续借给工作",
          "detail": "希望熬过交付后再调整。",
          "result": {
            "text": "文件赶出来了，没人能否认你的投入。星期三的空格又被占用一次，林把资料放回桌上时问：你说的“之后”，准备写哪一天？"
          },
          "effects": {
            "stress": 10,
            "health": -6,
            "trust": 4,
            "flags": [
              "load_early"
            ]
          }
        }
      ]
    },
    {
      "id": "n05_0",
      "dateIndex": 5,
      "slot": 0,
      "priority": 0,
      "chapter": "first",
      "title": "修一辆旧车的钱",
      "text": "在汽车零件企业的资料旁，林放了一张自己的维修单。旧车继续开，人就还需要零件；这听上去比猜明年最流行什么容易理解。但仓库会占钱，门店需要人，顾客也可能选择别的渠道。\n\n你不能因为生意听起来朴素，就把它当成不会出错。年末的市场让不少人疲惫，桌上这张维修单却把问题拉回了一个具体的人，为什么愿意付这笔钱。",
      "characters": [
        "lin"
      ],
      "chain": "risk",
      "choices": [
        {
          "id": "a",
          "label": "用小仓位买这门维修生意",
          "detail": "尝试将路标配件配到个人资产的10%。",
          "result": {
            "text": "你把仓库和现金回收速度写进观察清单。成交与否依实际资金和权限计算；不论下一段价格怎样，这份理由都将在后来原样等着你。"
          },
          "effects": {
            "research": 4,
            "discipline": 3,
            "researchCompany": [
              {
                "companyId": "GPC",
                "topic": "cashflow"
              }
            ]
          },
          "strategy": {
            "type": "invest",
            "account": "personal",
            "companyId": "GPC",
            "targetPercent": 10
          }
        },
        {
          "id": "b",
          "label": "先把利益冲突讲清楚",
          "detail": "核对私人交易与工作研究是否需要备案。",
          "result": {
            "text": "伊莱替你找到表格，要求你自己填完整。他没有因为你是新同事就免掉记录，也没有把谨慎当成一种可笑的胆小。"
          },
          "effects": {
            "discipline": 6,
            "trust": 3,
            "flags": [
              "clear_record"
            ],
            "relations": {
              "elias": 6
            }
          },
          "strategy": {
            "type": "hold",
            "account": "personal"
          }
        },
        {
          "id": "c",
          "label": "先不买，把现金留着",
          "detail": "承认当下还有更需要确定的钱。",
          "result": {
            "text": "你折好维修单的复印件，留在资料旁。知道一门生意怎样挣钱，并不要求你今天就拥有它；现金也有等候其他用途的时候。"
          },
          "effects": {
            "freedom": 3,
            "stress": -2,
            "flags": [
              "cash_buffer"
            ]
          },
          "strategy": {
            "type": "hold",
            "account": "personal"
          }
        }
      ]
    },
    {
      "id": "n06_0",
      "dateIndex": 6,
      "slot": 0,
      "priority": 0,
      "chapter": "first",
      "title": "一个数字，两个版本",
      "text": "你复核资料时看见两个不同的旧年数字。较新的年报改了呈列方式，旧报告却已经按照当时公开的内容写完。玛拉希望下午前交出比较表，山姆问能否干脆把老数字全部换成新的，看上去整齐些。\n\n整齐并不等于诚实。你需要让读表的人知道，哪一个数字在什么时候才出现，也需要让同事知道，这不是在挑谁的毛病。",
      "characters": [
        "sam",
        "mara"
      ],
      "chain": "ethics",
      "choices": [
        {
          "id": "a",
          "label": "把两个公开版本都留下",
          "detail": "写清时间和口径，承认暂时不能直接比较。",
          "result": {
            "text": "表格多了一行说明，会议也多问了几分钟。山姆后来借走你的格式，把它用在自己的资料里；你们有了一种不必互相猜疑的核对办法。"
          },
          "effects": {
            "research": 6,
            "discipline": 6,
            "flags": [
              "clear_record"
            ],
            "relations": {
              "sam": 4,
              "elias": 3
            }
          }
        },
        {
          "id": "b",
          "label": "先缩小比较范围",
          "detail": "只谈能够确认的部分。",
          "result": {
            "text": "你删掉了最漂亮的一张跨年图，留下可以解释的几项数。玛拉接受了这份较短的材料，要求你下次提前告诉她缺口在哪里。"
          },
          "effects": {
            "discipline": 4,
            "communication": 3,
            "reputation": -1
          }
        },
        {
          "id": "c",
          "label": "为会议另做一张快览",
          "detail": "保留原件，但让同事知道快览不能代替原表。",
          "result": {
            "text": "你赶在截止前交出两份文件，一份简单，一份详细。它没有免去复核工作，只把“看懂”与“下决定”分成了不同的步骤。"
          },
          "effects": {
            "communication": 5,
            "stress": 4,
            "research": 2
          }
        }
      ]
    },
    {
      "id": "n06_1",
      "dateIndex": 6,
      "slot": 1,
      "priority": 0,
      "chapter": "first",
      "title": "谁去陪母亲等那班车",
      "text": "诺拉正在准备一次资格考试，母亲却需要有人陪着去办一件要等很久的事。她给你打电话时先说了考试日期，然后停下来，等你回答。以往你常说她离得近，这一次她也有不能挪开的工作。\n\n你们不是在清算谁爱家人更多，而是在安排一段真的会占用半天的时间。办公室同样有人等你，不能让每一边都以为你会到场。",
      "characters": [
        "nora"
      ],
      "chain": "family",
      "choices": [
        {
          "id": "a",
          "label": "请半天假，把这次接过来",
          "detail": "让分担成为可以依靠的安排。",
          "result": {
            "text": "候车厅的椅子很硬，你们没聊多少大事。诺拉晚上发来练习题的照片，题旁画了一个笑脸。那半天没有被绩效表记录，却被她记住了。"
          },
          "effects": {
            "health": 3,
            "stress": -2,
            "relations": {
              "nora": 8
            },
            "flags": [
              "shared_care"
            ]
          }
        },
        {
          "id": "b",
          "label": "一起找到可靠的替代安排",
          "detail": "分担费用，也把协调工作接过来。",
          "result": {
            "text": "你没有出现，但也没有只转一笔钱就关掉电话。你核对时间、确认接送，诺拉终于不必在考试前再重复这些安排。"
          },
          "effects": {
            "personalCash": -220,
            "communication": 4,
            "relations": {
              "nora": 5
            },
            "flags": [
              "shared_care"
            ]
          }
        },
        {
          "id": "c",
          "label": "请姐姐再顶一次",
          "detail": "告诉她工作的重要性，承担这次失约。",
          "result": {
            "text": "诺拉说她会处理，然后结束了电话。事情确实办完了，你也按时交了材料。后来她谈考试时，少讲了几句本来会告诉你的细节。"
          },
          "effects": {
            "trust": 4,
            "stress": 4,
            "relations": {
              "nora": -7
            },
            "flags": [
              "family_deferred"
            ]
          }
        }
      ]
    },
    {
      "id": "n07_0",
      "dateIndex": 7,
      "slot": 0,
      "priority": 0,
      "chapter": "first",
      "title": "名字排在哪里",
      "text": "年末的报告封面只剩一个位置。山姆整理了主要资料，你负责提出最后的建议，玛拉准备拿它去见客户。山姆没有开口要求署名，只反复检查附件是不是装订齐了。\n\n同一天，你还在研究一家摩托车企业：品牌让人愿意付钱，分期购买却会把消费者的钱包也带进风险里。你开始理解，漂亮的封面与漂亮的销售数字，都值得再往后翻几页。",
      "characters": [
        "sam",
        "mara"
      ],
      "chain": "junior",
      "choices": [
        {
          "id": "a",
          "label": "把山姆的名字放上去",
          "detail": "说清每个人做了哪部分工作。",
          "result": {
            "text": "玛拉要求你们各自回答负责的部分。你不再是这份材料唯一的面孔，山姆也第一次需要公开说明自己的判断，而不只是躲在附件里。"
          },
          "effects": {
            "trust": 4,
            "reputation": 2,
            "relations": {
              "sam": 9
            },
            "flags": [
              "sam_credit"
            ]
          }
        },
        {
          "id": "b",
          "label": "提出摩托车的小额投资建议",
          "detail": "客户账户目标5%，由实际权限审核。",
          "result": {
            "text": "你没有把品牌认同写成不会亏钱的理由，也列出信贷和消费转弱的可能。建议能否成交，要看当前授权、现金与集中度，不由封面上的名字决定。"
          },
          "effects": {
            "research": 4,
            "communication": 3,
            "authority": 5,
            "researchCompany": [
              {
                "companyId": "HOG",
                "topic": "debt"
              }
            ]
          },
          "strategy": {
            "type": "invest",
            "account": "client",
            "companyId": "HOG",
            "targetPercent": 5
          }
        },
        {
          "id": "c",
          "label": "保留自己的署名，私下道谢",
          "detail": "选择更快被外界记住。",
          "result": {
            "text": "山姆收到了你的感谢邮件。封面仍只有一个名字。你们没有争吵，只是下一次分工时，他问得比从前更清楚：这项工作最后会怎样呈现？"
          },
          "effects": {
            "reputation": 6,
            "relations": {
              "sam": -6
            },
            "flags": [
              "credit_taken"
            ]
          }
        }
      ]
    },
    {
      "id": "n08_0",
      "dateIndex": 8,
      "slot": 0,
      "priority": 0,
      "chapter": "first",
      "title": "承认一次判断还没有答案",
      "text": "一项你曾看好的生意没有按预期表现，办公室里开始有人寻找一句足够简短的解释。林把当时的黄纸放在会议桌中央，说价格变化是一件事，原来的理由是否成立是另一件事。\n\n你可以调整判断，也可以继续等待，但最好能说明为什么。那张纸不会因为今天感到难堪就自行消失；它同样不会因为你赚过钱，就替你证明所有判断都正确。",
      "characters": [
        "lin",
        "mara"
      ],
      "chain": "archive",
      "choices": [
        {
          "id": "a",
          "label": "逐条核对原来的理由",
          "detail": "把错误和仍待验证的部分分开。",
          "result": {
            "text": "你读出一条当时没有充分查证的假设。屋里没有掌声，问题却变得具体了。林说这页值得留下，因为你以后可能还会想绕过同一块石头。"
          },
          "effects": {
            "research": 6,
            "discipline": 5,
            "stress": 2,
            "flags": [
              "honest_memo"
            ],
            "relations": {
              "lin": 5
            }
          }
        },
        {
          "id": "b",
          "label": "请别人接手复核",
          "detail": "接受自己的解释未必最可靠。",
          "result": {
            "text": "山姆接过副本，先问资料日期。你把原件也给了他。交出一点控制权并不舒服，但它让这份工作不再只能靠你自己的说法维持。"
          },
          "effects": {
            "trust": 4,
            "communication": 4,
            "relations": {
              "sam": 4
            },
            "health": 2
          }
        },
        {
          "id": "c",
          "label": "暂停新增决定",
          "detail": "给自己一段整理材料的时间。",
          "result": {
            "text": "你没有把暂停写成反败为胜的技巧，只写清楚下一次回看的日期。市场照样前进，你终于停止用每一次价格变化重新解释过去。"
          },
          "effects": {
            "stress": -4,
            "discipline": 4
          },
          "strategy": {
            "type": "hold",
            "account": "personal"
          }
        }
      ]
    },
    {
      "id": "n09_0",
      "dateIndex": 9,
      "slot": 0,
      "priority": 0,
      "chapter": "first",
      "title": "报税生意旁边的新业务",
      "text": "春天过去，一家报税服务企业的资料仍留在你桌上。报税有熟悉的季节，客户每年会回来；但资料里也出现与住房贷款相关的业务，赚钱方式和风险未必与门店一样。\n\n玛拉问能不能用一句话概括。你盯着两个不同来源的收入，觉得一句话太容易让人误会。你可以投入小额资金继续观察，也可以先承认自己尚未把另一半生意看懂。",
      "characters": [
        "mara",
        "elias"
      ],
      "chain": "risk",
      "choices": [
        {
          "id": "a",
          "label": "先弄清贷款那部分怎样运转",
          "detail": "研究资金来源与坏账，暂不下单。",
          "result": {
            "text": "你把两种生意分开写。门店的经验不能自动解释贷款风险，这个结论没有告诉你未来股价，却阻止了你用熟悉的一半替陌生的一半担保。"
          },
          "effects": {
            "research": 7,
            "discipline": 4,
            "flags": [
              "exit_reason"
            ],
            "researchCompany": [
              {
                "companyId": "HRB",
                "topic": "debt"
              }
            ]
          },
          "strategy": {
            "type": "hold",
            "account": "personal"
          }
        },
        {
          "id": "b",
          "label": "只用很小一份个人资金持有",
          "detail": "尝试将橡街税务配到个人资产的5%。",
          "result": {
            "text": "你留下了仓位上限，也写清自己仍不懂什么。小仓位并不会把错误变成正确，但它让这次判断不至于占据你全部生活资金。"
          },
          "effects": {
            "research": 3,
            "stress": 2,
            "researchCompany": [
              {
                "companyId": "HRB",
                "topic": "debt"
              }
            ]
          },
          "strategy": {
            "type": "invest",
            "account": "personal",
            "companyId": "HRB",
            "targetPercent": 5
          }
        },
        {
          "id": "c",
          "label": "先核对风险，暂不买入",
          "detail": "保留现金，写清哪项证据还需要确认。",
          "result": {
            "text": "你把一季忙碌与一整年的经营分开记录。旺季能吸引很多顾客，不等于淡季不会消耗现金；这一轮你没有买入，仍保留以后核对的清单。"
          },
          "effects": {
            "discipline": 5,
            "stress": -3,
            "flags": [
              "exit_reason"
            ]
          },
          "strategy": {
            "type": "hold",
            "account": "personal"
          }
        }
      ]
    },
    {
      "id": "n10_0",
      "dateIndex": 10,
      "slot": 0,
      "priority": 0,
      "chapter": "first",
      "title": "把规则写在人情之前",
      "text": "一位熟人想请你吃饭，说可以介绍客户，也希望你“顺便”看一下他的私人安排。伊莱提醒你，工作里的权限、私人朋友的期待与公司的收费，不能靠一句“以后再说”混在一起。\n\n你不是突然遇到一个明显的坏人。对方热情，要求也像顺水人情；正因为如此，你需要在关系变得更复杂以前，说出哪些事情你能做，哪些事情要正式走程序。",
      "characters": [
        "elias"
      ],
      "chain": "ethics",
      "choices": [
        {
          "id": "a",
          "label": "先把边界说清楚",
          "detail": "留下记录，再决定要不要吃这顿饭。",
          "result": {
            "text": "朋友觉得你有些认真，最后仍答应了。伊莱没有给你颁奖，只提醒你保留那封说明邮件。规则从此不只是别人犯错时才会用到的东西。"
          },
          "effects": {
            "discipline": 6,
            "trust": 4,
            "flags": [
              "clear_record"
            ],
            "relations": {
              "elias": 6
            }
          }
        },
        {
          "id": "b",
          "label": "谢绝这次安排",
          "detail": "宁可错过介绍，也不接受自己无法处理的期待。",
          "result": {
            "text": "你把感谢说完整，没有暗示对方一定有问题。这个机会可能就此过去，日程却保持了你能解释的形状。"
          },
          "effects": {
            "freedom": 4,
            "reputation": -2,
            "stress": -2
          }
        },
        {
          "id": "c",
          "label": "请朱恩一起参加",
          "detail": "把私人邀约转成公开的工作会面。",
          "result": {
            "text": "朱恩事先说明了服务范围和费用。饭桌上的话题不再那么轻松，但所有人都知道，这不是一次可以随便许诺的帮忙。"
          },
          "effects": {
            "communication": 5,
            "trust": 3,
            "relations": {
              "june": 4
            },
            "flags": [
              "clear_record"
            ]
          }
        }
      ]
    },
    {
      "id": "n10_1",
      "dateIndex": 10,
      "slot": 1,
      "priority": 0,
      "chapter": "first",
      "title": "夜校不需要一位预言家",
      "text": "达里厄斯请你去图书馆讲一堂课，题目是“第一份工资怎么安排”。你准备了满页市场图，他却问能否先解释账单、缓冲和债务。来的人下班后赶车，没有义务懂你在办公室学会的缩写。\n\n课堂没有客户名单，也不允许推销。你可以接受这个小小的限制，看看知识离开头衔以后还剩多少，也可以坦白自己现在没有时间准备。",
      "characters": [
        "darius"
      ],
      "chain": "school",
      "choices": [
        {
          "id": "a",
          "label": "把讲稿重写成能听懂的话",
          "detail": "从一张普通家庭账单开始。",
          "result": {
            "text": "有人问如果下个月少一份收入怎么办。你终于合上演示稿，和大家一起把钱分成用途。达里厄斯问你愿不愿意明年再来。"
          },
          "effects": {
            "communication": 7,
            "research": 2,
            "stress": 2,
            "flags": [
              "class_started"
            ],
            "relations": {
              "darius": 7
            }
          }
        },
        {
          "id": "b",
          "label": "只帮忙审核教材",
          "detail": "不承诺固定授课，但完成一个明确任务。",
          "result": {
            "text": "你改掉几句听起来像保证的句子。达里厄斯按约定把你的名字写在感谢页，而没有擅自把你排进每月课程。"
          },
          "effects": {
            "discipline": 4,
            "communication": 3,
            "relations": {
              "darius": 4
            }
          }
        },
        {
          "id": "c",
          "label": "这次先谢绝",
          "detail": "把无法承担的事情说在开始前。",
          "result": {
            "text": "图书馆找到了另一位志愿者。你没有失去做这件事的资格，只是这堂课从你的日历上移走了；有些空白需要承认是自己留下的。"
          },
          "effects": {
            "health": 3,
            "stress": -3,
            "freedom": 3
          }
        }
      ]
    },
    {
      "id": "n11_0",
      "dateIndex": 11,
      "slot": 0,
      "priority": 0,
      "chapter": "first",
      "title": "一瓶不起眼的东西",
      "text": "你在五金店买灯泡，顺手拿起一种常见的保养用品。品牌让人少犹豫几秒，货架和分销又让它容易被找到。回到办公室，你翻的是类似生意的公开资料：产品并不神奇，价格也不应因为熟悉就免于检查。\n\n山姆说自己家里也有一瓶。你们笑了一下，然后开始讨论原料、零售渠道和竞争。生活经验能帮你提出问题，却不能替财务资料作答。",
      "characters": [
        "sam"
      ],
      "chain": "wealth",
      "choices": [
        {
          "id": "a",
          "label": "为小额持有补齐理由",
          "detail": "尝试将蓝罐养护配到个人资产的10%。",
          "result": {
            "text": "你把“我用过”从买入理由中删掉，改成客户为何会继续付钱。交易依实际账户执行；这份解释不会替你保证以后仍然成立。"
          },
          "effects": {
            "research": 4,
            "discipline": 3,
            "researchCompany": [
              {
                "companyId": "WDFC",
                "topic": "customers"
              }
            ]
          },
          "strategy": {
            "type": "invest",
            "account": "personal",
            "companyId": "WDFC",
            "targetPercent": 10
          }
        },
        {
          "id": "b",
          "label": "研究它，但暂不付这个价格",
          "detail": "把生意与买入价格分开。",
          "result": {
            "text": "你留下一份资料，也留下一句“暂时不买”。林说他想看的正是后半句的理由，而不是你能背出多少产品名字。"
          },
          "effects": {
            "research": 5,
            "discipline": 4,
            "researchCompany": [
              {
                "companyId": "WDFC",
                "topic": "valuation"
              }
            ]
          },
          "strategy": {
            "type": "hold",
            "account": "personal"
          }
        },
        {
          "id": "c",
          "label": "先核对风险，暂不买入",
          "detail": "保留现金，写清哪项证据还需要确认。",
          "result": {
            "text": "你记下品牌和货架位置，也去找原料与渠道费用的证据。熟悉的罐子没有变成无需追问的答案；这次现金留在账户里，功课继续留在桌上。"
          },
          "effects": {
            "stress": -3,
            "freedom": 3
          },
          "strategy": {
            "type": "hold",
            "account": "personal"
          }
        }
      ]
    },
    {
      "id": "n11_1",
      "dateIndex": 11,
      "slot": 1,
      "priority": 0,
      "chapter": "first",
      "title": "一笔钱不能拥有两个用途",
      "text": "整理年末个人账目时，你算了三遍：还债、搬家、追加投资，每件事都能说出道理。诺拉的工作室计划还停在草图上，她只请你看租赁条款，没有开口要钱。你却已经在心里把手边可用的资金分出超过它本身的份额。\n\n这次不需要猜市场。你需要先承认，一笔钱不能同时替所有愿望站岗；留着它，也必须有明确的理由。",
      "characters": [
        "nora"
      ],
      "chain": "wealth",
      "choices": [
        {
          "id": "a",
          "label": "先保留几个月生活缓冲",
          "detail": "把现金的用途写进自己的计划。",
          "result": {
            "text": "你给这笔钱起了一个不太漂亮的名字：如果工作出问题。它暂时没有带来新东西，却让你在听别人讲机会时，可以慢一点回答。"
          },
          "effects": {
            "discipline": 5,
            "stress": -5,
            "flags": [
              "cash_buffer",
              "seed_saving"
            ]
          },
          "strategy": {
            "type": "hold",
            "account": "personal"
          }
        },
        {
          "id": "b",
          "label": "用一部分现金继续还债",
          "detail": "还当前现金的25%，保留其他选择。",
          "result": {
            "text": "你先核对实际欠款，再使用可用现金偿还其中一部分。若此前已经还清，这次不会再次扣钱；没有涨跌曲线的财务整理，也值得认真对照账单完成。"
          },
          "effects": {
            "discipline": 5,
            "stress": -3,
            "flags": [
              "debt_plan"
            ]
          },
          "strategy": {
            "type": "repay",
            "account": "personal",
            "targetPercent": 25
          }
        },
        {
          "id": "c",
          "label": "帮姐姐逐条读租赁条款",
          "detail": "投入时间，先别替她决定是否开业。",
          "result": {
            "text": "诺拉纠正了你对她客户的一项想象。你们把不确定的费用列出来，她自己作决定。被认真听见，比收到一句“我支持你”更费时间。"
          },
          "effects": {
            "communication": 4,
            "relations": {
              "nora": 6
            },
            "flags": [
              "family_trust"
            ]
          }
        }
      ]
    },
    {
      "id": "n12_0",
      "dateIndex": 12,
      "slot": 0,
      "priority": 0,
      "chapter": "first",
      "title": "照顾不是一个人的兼职",
      "text": "山姆把调班申请推到你面前。他父亲需要固定陪同，他希望把两项工作交出去，而不是每次临时道歉。你也忙，玛拉更担心其他人觉得不公平。\n\n办公室常说这里是一个团队，真正需要分掉一项责任时，这句话才开始有重量。你可以帮他建立稳定的安排，也可以要求他继续用个人时间填上所有缺口。",
      "characters": [
        "sam",
        "mara"
      ],
      "chain": "junior",
      "choices": [
        {
          "id": "a",
          "label": "一起重新排工作",
          "detail": "把期限、署名和交接都写清。",
          "result": {
            "text": "山姆没有因此变得没有责任。他仍要完成自己的部分，只是不必每次陪父亲时都像在求特许。你们也终于知道彼此什么时候可以不在线。"
          },
          "effects": {
            "trust": 4,
            "communication": 5,
            "stress": 3,
            "flags": [
              "sam_helped"
            ],
            "relations": {
              "sam": 8
            }
          }
        },
        {
          "id": "b",
          "label": "替他接一次最急的任务",
          "detail": "帮过眼前，也说明不能永远代班。",
          "result": {
            "text": "这次材料按时送出。你们约定下周与主管谈长期安排，不把救急悄悄写成你的新职责。山姆把日期记得比你还认真。"
          },
          "effects": {
            "stress": 5,
            "health": -2,
            "relations": {
              "sam": 5
            },
            "flags": [
              "sam_emergency_help"
            ]
          }
        },
        {
          "id": "c",
          "label": "请主管正式处理",
          "detail": "自己不先承诺，让岗位决定分工。",
          "result": {
            "text": "玛拉接过申请。山姆有些失望，但你没有背后否定他的理由。事情进入了一套较慢的程序，是否公平仍要看后续如何执行。"
          },
          "effects": {
            "discipline": 4,
            "freedom": 2,
            "relations": {
              "sam": -1,
              "mara": 2
            }
          }
        }
      ]
    },
    {
      "id": "n12_1",
      "dateIndex": 12,
      "slot": 1,
      "priority": 0,
      "chapter": "first",
      "title": "她的地图不只有你的城市",
      "text": "梅收到一份巡展邀请，要去外州几个月。她把地图铺在桌上，讲运输路线、场地和她想做的新尝试。你发现自己最先想到的却是，你们以后怎么见面。\n\n她等你听完工作，再谈见面。她不是一项需要留在附近才能产生回报的安排，你也不必假装距离不会改变相处。你们需要一份两个人都参与写的日历。",
      "characters": [
        "mei"
      ],
      "chain": "friend",
      "choices": [
        {
          "id": "a",
          "label": "先听她讲完，再一起安排联系",
          "detail": "把支持落在可执行的约定上。",
          "result": {
            "text": "你们选了几个确定可以通话的晚上，其他时间留给各自的工作。梅说地图终于不像只画给她一个人看，但她仍会自己决定路线。"
          },
          "effects": {
            "communication": 5,
            "relations": {
              "mei": 8
            },
            "flags": [
              "mei_supported"
            ]
          }
        },
        {
          "id": "b",
          "label": "坦白自己不擅长远距离",
          "detail": "不把困难说成她不该离开。",
          "result": {
            "text": "梅没有立刻给出答案。你们多谈了一会儿，承认关系可以重要，也可以仍然需要试着调整。诚实没有消除距离，却让它有了名字。"
          },
          "effects": {
            "communication": 4,
            "stress": 2,
            "relations": {
              "mei": 3
            }
          }
        },
        {
          "id": "c",
          "label": "说等工作稳定再讨论",
          "detail": "暂时把不舒服放到一边。",
          "result": {
            "text": "地图被她收进筒里。你们仍约了一顿饭，但没有谈下一次。你把这叫作顺其自然，她则开始独自安排那些已经有截止日的事情。"
          },
          "effects": {
            "reputation": 2,
            "relations": {
              "mei": -6
            },
            "flags": [
              "friend_distance"
            ]
          }
        }
      ]
    },
    {
      "id": "n13_0",
      "dateIndex": 13,
      "slot": 0,
      "priority": 0,
      "chapter": "first",
      "title": "更大的桌子，更多人的钱",
      "text": "玛拉问你是否愿意承担组合管理工作的一部分。新职责包括审核别人的建议，也包括在业绩不好时站到客户面前。你当天正在看房车企业：订单背后有旅行的愿望，也有消费者贷款、经销商库存与季节。\n\n她没有要求你同时接受职位和股票。桌子可以变大，判断仍要一项一项作；别人信任你，并不意味着他们的钱就成了你的钱。",
      "characters": [
        "mara",
        "june"
      ],
      "chain": "ambition",
      "choices": [
        {
          "id": "a",
          "label": "接下职责，要求明确权限",
          "detail": "承担管理，也接受委员会约束。",
          "result": {
            "text": "玛拉把职责说明重新打印了一遍。你签的是会被追问的工作，不是一张自由下注的通行证。朱恩说，下次难听的电话你也得在场。"
          },
          "effects": {
            "career": "manager",
            "authority": 15,
            "trust": 5,
            "stress": 6,
            "health": -2,
            "flags": [
              "manager_accepted"
            ],
            "relations": {
              "mara": 5
            }
          }
        },
        {
          "id": "b",
          "label": "先给出有限的房车投资建议",
          "detail": "客户账户目标5%，考虑周期和借款。",
          "result": {
            "text": "你把需求转弱时可能发生的事放在建议前半页。实际委托仍受权限和风险限制；头衔不够时，建议会留下，客户资金不会偷偷成交。"
          },
          "effects": {
            "research": 5,
            "communication": 3,
            "researchCompany": [
              {
                "companyId": "THO",
                "topic": "debt"
              }
            ]
          },
          "strategy": {
            "type": "invest",
            "account": "client",
            "companyId": "THO",
            "targetPercent": 5
          }
        },
        {
          "id": "c",
          "label": "留在研究工作里",
          "detail": "接受升职慢些，保留明确的职责。",
          "result": {
            "text": "你给出的理由很简单：现在愿意做好的是研究。玛拉请你协助培训接手者，办公室没有因为一次拒绝就把你的工位收走。"
          },
          "effects": {
            "career": "senior",
            "research": 4,
            "health": 3,
            "freedom": 5,
            "flags": [
              "steady_work"
            ]
          }
        }
      ]
    },
    {
      "id": "n14_0",
      "dateIndex": 14,
      "slot": 0,
      "priority": 0,
      "chapter": "first",
      "title": "名片背面的铅笔字",
      "text": "你在一次午餐后把自己的工作内容写到名片背面：读资料、解释、等待、承担别人焦虑的一部分。独立开业听起来像拿回控制权，实际还会带来房租、合约和没有人兜底的日子。\n\n伊莱说他愿意告诉你需要哪些正式手续，但不会替你找捷径。现在你还不必离职，可以先决定，这个念头是偶尔逃离忙碌的幻想，还是值得花几年准备的工作。",
      "characters": [
        "elias",
        "mara"
      ],
      "chain": "autonomy",
      "choices": [
        {
          "id": "a",
          "label": "为独立工作做一份真实计划",
          "detail": "先研究成本、合约与客户边界。",
          "result": {
            "text": "名片背面很快写不下，你换了一本便宜的笔记本。第一页不是公司名字，而是没有收入时可以维持多久。想法终于开始接受现实的问题。"
          },
          "effects": {
            "research": 4,
            "discipline": 5,
            "freedom": 3,
            "flags": [
              "independence_seed"
            ],
            "relations": {
              "elias": 4
            }
          }
        },
        {
          "id": "b",
          "label": "与主管讨论内部的自主空间",
          "detail": "先尝试改变现有工作。",
          "result": {
            "text": "玛拉答应你负责一项小项目，也要求公开进度。你得到的自由不是没有人过问，而是可以解释自己的安排，并知道哪里需要共同决定。"
          },
          "effects": {
            "trust": 5,
            "authority": 5,
            "flags": [
              "leader_agenda"
            ],
            "relations": {
              "mara": 4
            }
          }
        },
        {
          "id": "c",
          "label": "把离职念头先放下",
          "detail": "承认现在更需要稳定。",
          "result": {
            "text": "你没有烧掉那张名片，只把它夹进书里。有些愿望可以等待；等待的前提是你知道自己暂时选择了什么，而不是把它当作从未想过。"
          },
          "effects": {
            "health": 3,
            "stress": -4,
            "flags": [
              "steady_work"
            ]
          }
        }
      ]
    },
    {
      "id": "n14_1",
      "dateIndex": 14,
      "slot": 1,
      "priority": 0,
      "chapter": "first",
      "title": "把一个晚上还给自己",
      "text": "最近你在回家后仍不断查看邮件，饭吃完也记不起味道。诺拉说她并不能替你判断原因，但可以陪你整理接下来一周。她先拿掉你写的“有空再休息”，请你换成一个具体时段。\n\n生活并不是工作剩余时间的自动集合。你也知道，眼前交付不会因为疲惫而消失；能改变的，是谁来接手、哪些承诺必须重新谈，以及何时寻求适当的帮助。",
      "characters": [
        "nora"
      ],
      "chain": "health",
      "choices": [
        {
          "id": "a",
          "label": "重新安排负荷和休息",
          "detail": "把至少一项职责交接出去。",
          "result": {
            "text": "你发出一封不太习惯写的邮件，说明自己无法再同时接三件事。同事没有全部赞同，但一项工作确实离开了你的晚上。"
          },
          "effects": {
            "health": 7,
            "stress": -8,
            "freedom": 5,
            "flags": [
              "weekly_boundary"
            ],
            "relations": {
              "nora": 4
            }
          }
        },
        {
          "id": "b",
          "label": "先找专业人员谈谈状态",
          "detail": "不凭游戏里的数字给自己下诊断。",
          "result": {
            "text": "你记下了近期睡眠和不适，交给专业人员评估。没有一句话能保证以后怎样，但你已经不再只靠自己硬猜原因。"
          },
          "effects": {
            "health": 5,
            "stress": -5,
            "personalCash": -200,
            "flags": [
              "care_sought"
            ]
          }
        },
        {
          "id": "c",
          "label": "继续把这段时间交给工作",
          "detail": "保住进度，但需要承担负荷。",
          "result": {
            "text": "你完成了交付，也又一次把晚饭热了两遍。姐姐没再劝，只请你保存好她的空闲时间：如果需要她，别等到想起什么才开口。"
          },
          "effects": {
            "stress": 10,
            "health": -7,
            "trust": 4,
            "flags": [
              "load_early"
            ]
          }
        }
      ]
    },
    {
      "id": "n15_0",
      "dateIndex": 15,
      "slot": 0,
      "priority": 0,
      "chapter": "first",
      "title": "畅销书之外的账",
      "text": "出版企业的资料比封面安静得多：印刷、库存、退货、学校采购周期，都会决定钱什么时候回来。一本受欢迎的书可以让一个年份显得出色，却不能替所有库存找到读者。\n\n你翻到现金流里那些另列的出版前投入，意识到简单地减掉设备开支，并没有扣除这门生意所有需要的钱。梅说她也常遇到同样的事：展览开幕后看得见的，只是工作的一小部分。",
      "characters": [
        "mei",
        "lin"
      ],
      "chain": "ethics",
      "choices": [
        {
          "id": "a",
          "label": "把投入的不同用途分开看",
          "detail": "完善纸灯出版研究，暂不交易。",
          "result": {
            "text": "你给报告补上一段范围说明。它让结论不那么锋利，却阻止别人把狭义的数字当成全部可以自由取走的钱。"
          },
          "effects": {
            "research": 6,
            "discipline": 5,
            "flags": [
              "research_boundaries"
            ],
            "researchCompany": [
              {
                "companyId": "SCHL",
                "topic": "cashflow"
              }
            ]
          },
          "strategy": {
            "type": "hold",
            "account": "personal"
          }
        },
        {
          "id": "b",
          "label": "只用小额资金参与",
          "detail": "尝试将纸灯出版配到个人资产的5%。",
          "result": {
            "text": "你把退货和季节性写在买入旁边，没有把喜欢阅读当作估值。若交易完成，这份有限的仓位会与实际公开资料一起接受后续检验。"
          },
          "effects": {
            "research": 3,
            "discipline": 2,
            "researchCompany": [
              {
                "companyId": "SCHL",
                "topic": "cashflow"
              }
            ]
          },
          "strategy": {
            "type": "invest",
            "account": "personal",
            "companyId": "SCHL",
            "targetPercent": 5
          }
        },
        {
          "id": "c",
          "label": "先核对风险，暂不买入",
          "detail": "保留现金，写清哪项证据还需要确认。",
          "result": {
            "text": "你把学校订单、库存与回款分开来看。喜欢阅读，不等于能够接受任何价格的出版生意。你保留现金，也承认自己的理解还不够完整。"
          },
          "effects": {
            "discipline": 4,
            "stress": -2
          },
          "strategy": {
            "type": "hold",
            "account": "personal"
          }
        }
      ]
    },
    {
      "id": "n16_0",
      "dateIndex": 16,
      "slot": 0,
      "priority": 0,
      "chapter": "fracture",
      "title": "先演练一次不顺利",
      "text": "开年的讨论仍然充满增长计划。你把一张空白纸放到玛拉面前：如果客户同时要用钱，如果收入变慢，如果最有把握的判断错了，谁来决定下一步？她问你是不是太悲观，朱恩却把椅子拉了过来。\n\n你没有预知任何危机，只是不想把“应该没问题”当成唯一安排。把坏情况写出来会占用今天的时间，也可能让一些人觉得你不够热情。",
      "characters": [
        "mara",
        "june"
      ],
      "chain": "risk",
      "choices": [
        {
          "id": "a",
          "label": "和团队演练减仓与沟通",
          "detail": "先约定需要核对的事实和责任。",
          "result": {
            "text": "你们争了很久，最后写下几项可以执行的条件。没有人因此免于犯错，但需要行动时，至少不必从谁有权开口开始争。"
          },
          "effects": {
            "discipline": 7,
            "communication": 4,
            "trust": 3,
            "flags": [
              "risk_rehearsed"
            ],
            "relations": {
              "june": 5
            }
          }
        },
        {
          "id": "b",
          "label": "只保留自己的退出理由",
          "detail": "先保证个人决定能被自己解释。",
          "result": {
            "text": "你重读旧记录，发现其中一条过于笼统，几乎什么结果都能往里套。改掉它并不舒服，却比日后假装早已想到更有用。"
          },
          "effects": {
            "discipline": 5,
            "research": 3,
            "flags": [
              "exit_reason"
            ]
          }
        },
        {
          "id": "c",
          "label": "先把增长计划交上去",
          "detail": "相信遇到问题时再调整来得及。",
          "result": {
            "text": "计划通过了，玛拉让你参加下一次客户会。空白的应对表仍在抽屉里；它没有立刻造成后果，只是没有变成团队共有的工具。"
          },
          "effects": {
            "reputation": 5,
            "stress": 5,
            "flags": [
              "growth_first"
            ]
          }
        }
      ]
    },
    {
      "id": "n16_1",
      "dateIndex": 16,
      "slot": 1,
      "priority": 0,
      "chapter": "fracture",
      "title": "加班开始有了固定座位",
      "text": "你在办公室留了一套换洗衣服，本来只是为了偶尔赶工。后来它一直没拿回家。晚饭常与电话一起吃，周末则先问同事有没有需要，才想起问自己。玛拉说团队的负荷确实在增加，愿意谈谈谁能接手。\n\n这不意味着你已经生病，也没有人能够预测你的身体。它只是一次足够清楚的提醒：现在的安排，正在慢慢变成默认的生活。",
      "characters": [
        "mara",
        "nora"
      ],
      "chain": "health",
      "choices": [
        {
          "id": "a",
          "label": "这次就重新分配任务",
          "detail": "把临时支撑结束在一个明确日期。",
          "result": {
            "text": "衣服被你装回纸袋。你没有因此变得不负责，只把负责人、交接与联络方式重新排了一遍。诺拉终于知道哪天可以约你。"
          },
          "effects": {
            "health": 8,
            "stress": -9,
            "freedom": 4,
            "flags": [
              "weekly_boundary"
            ]
          }
        },
        {
          "id": "b",
          "label": "继续承担，先换一份职责说明",
          "detail": "愿意更忙，但要求权限与工作量相匹配。",
          "result": {
            "text": "玛拉同意增加复核资源，工作却没有因此少掉很多。你得到更多责任，也需要更清楚地承认，头衔不能替身体完成休息。"
          },
          "effects": {
            "authority": 5,
            "trust": 4,
            "stress": 8,
            "health": -6,
            "flags": [
              "highload_2007"
            ]
          }
        },
        {
          "id": "c",
          "label": "今晚先回家，约好下周再谈",
          "detail": "让一次停顿真的发生。",
          "result": {
            "text": "你把没做完的部分发给同事，说明时间。回家后仍有焦虑，但晚饭终于没有在手机旁变凉。下周的谈话写进了双方日历。"
          },
          "effects": {
            "health": 5,
            "stress": -5,
            "relations": {
              "nora": 3
            },
            "flags": [
              "care_sought"
            ]
          }
        }
      ]
    },
    {
      "id": "n17_0",
      "dateIndex": 17,
      "slot": 0,
      "priority": 0,
      "chapter": "fracture",
      "title": "钢材价格和人的愿望",
      "text": "钢铁企业的报表让你想到工地：有人要建厂、修路、盖房，需求就会传到炉子前。可原料、能源、产能和价格都在变，景气时赚的钱不能自动当成每年都会有的钱。\n\n诺拉恰好给你发来一张工地照片，说某个项目推迟了。那不是判断整个行业的依据，却提醒你把宏大的增长故事拆回订单、成本和等待付款的人。",
      "characters": [
        "nora",
        "lin"
      ],
      "chain": "wealth",
      "choices": [
        {
          "id": "a",
          "label": "把周期风险写进小额持有",
          "detail": "尝试将炉石钢业配到个人资产的8%。",
          "result": {
            "text": "你没有用最好的一年替未来二十年作保证。账户按实际条件执行，记录里则留着一句：如果需求改变，必须回来重新看这份理由。"
          },
          "effects": {
            "research": 4,
            "discipline": 3,
            "researchCompany": [
              {
                "companyId": "NUE",
                "topic": "cashflow"
              },
              {
                "companyId": "NUE",
                "topic": "valuation"
              }
            ]
          },
          "strategy": {
            "type": "invest",
            "account": "personal",
            "companyId": "NUE",
            "targetPercent": 8
          }
        },
        {
          "id": "b",
          "label": "先留现金，继续看订单",
          "detail": "不把熟悉工地当成懂得整个周期。",
          "result": {
            "text": "诺拉笑说她的照片只是想让你看看工作。你回复了一句认真看过，然后把投资档案与姐姐的消息放进不同的文件夹。"
          },
          "effects": {
            "research": 4,
            "relations": {
              "nora": 3
            },
            "researchCompany": [
              {
                "companyId": "NUE",
                "topic": "customers"
              }
            ]
          },
          "strategy": {
            "type": "hold",
            "account": "personal"
          }
        },
        {
          "id": "c",
          "label": "先核对风险，暂不买入",
          "detail": "保留现金，写清哪项证据还需要确认。",
          "result": {
            "text": "你把眼前的利润和可能不同的下一轮需求并排写下。钢铁仍有人需要，但你不能用这一点推算每年的售价；这次等待让你暂时保留了调整的余地。"
          },
          "effects": {
            "discipline": 4,
            "stress": -3
          },
          "strategy": {
            "type": "hold",
            "account": "personal"
          }
        }
      ]
    },
    {
      "id": "n18_0",
      "dateIndex": 18,
      "slot": 0,
      "priority": 0,
      "chapter": "fracture",
      "title": "电话那头没有图表",
      "text": "客户来电时没有问季度排名，先说孩子的学校已经发来缴费通知。朱恩把电话交给你，纸上圈着很早以前就存在的日期。屏幕上的市场变化可以讨论，账单的截止日却不会因为讨论而移动。\n\n你需要解释账户眼下能做什么，也需要承认以前有没有把时间讲清楚。客户并不是来考你会不会使用术语，只想知道自己接下来能怎样安排生活。",
      "characters": [
        "june"
      ],
      "chain": "clients",
      "choices": [
        {
          "id": "a",
          "label": "先确认实际用途和时间",
          "detail": "与客户一起把近期需要的钱单列。",
          "result": {
            "text": "你把答复写成几句可以读给家人听的话。朱恩保留了通话记录，既记录承诺，也记录你没有能力保证的部分。"
          },
          "effects": {
            "communication": 6,
            "trust": 4,
            "discipline": 4,
            "flags": [
              "client_dates"
            ],
            "relations": {
              "june": 5
            }
          }
        },
        {
          "id": "b",
          "label": "诚实说明此前解释不足",
          "detail": "承担沟通责任，再讨论补救。",
          "result": {
            "text": "客户并没有立刻放心。你们约好第二次核对，少说了几句辩解，多写了一个明确的联系日期。承认不足没有补回损失，却让谈话可以继续。"
          },
          "effects": {
            "reputation": -2,
            "trust": 5,
            "discipline": 5,
            "relations": {
              "june": 4
            }
          }
        },
        {
          "id": "c",
          "label": "请主管一起作决定",
          "detail": "不独自答应超出权限的安排。",
          "result": {
            "text": "玛拉加入通话，询问你的记录。你把问题交到了有权决定的人面前，也需要继续在场，听完客户对你们共同提出的问题。"
          },
          "effects": {
            "trust": 3,
            "stress": 3,
            "communication": 3,
            "relations": {
              "mara": 2
            }
          }
        }
      ]
    },
    {
      "id": "n18_1",
      "dateIndex": 18,
      "slot": 1,
      "priority": 0,
      "chapter": "fracture",
      "title": "库存也会占住现金",
      "text": "你重新翻看房车业务时，最在意的变成了经销商和库存。每一辆车都对应一份旅行愿望，也对应现金、借款和等到愿望实现以前的费用。客户信心变化会传多久，没有人能用一句话算清。\n\n玛拉让你把曾考虑过的持仓理由再写一遍，不接受只说“从前看好”。若客户账户此前确实买入，重新判断既可能意味着继续持有，也可能意味着只卖一部分；没有持仓则不会凭空成交；你无需把每个选择都说成绝对正确。",
      "characters": [
        "mara"
      ],
      "chain": "risk",
      "choices": [
        {
          "id": "a",
          "label": "把房车仓位降到3%",
          "detail": "如客户账户持有，部分卖出至3%的目标。",
          "result": {
            "text": "交易按客户账户实际持有的份额核算；若原仓位高于目标，只减少超过的部分。没有持仓或未超过目标就不会卖出，客户的资金始终留在客户账户里。"
          },
          "effects": {
            "discipline": 5,
            "stress": -3,
            "flags": [
              "risk_position_cut"
            ]
          },
          "strategy": {
            "type": "reduce",
            "account": "client",
            "companyId": "THO",
            "targetPercent": 3
          }
        },
        {
          "id": "b",
          "label": "继续持有，先核查现金与借款",
          "detail": "不追加，也不因为一阵不安自动卖出。",
          "result": {
            "text": "你把新的问题放在旧理由旁边。坚持没有被写成勇敢，卖出也没有被写成胆小；需要解释的是，今天知道的事情是否改变了风险。"
          },
          "effects": {
            "research": 5,
            "stress": 2,
            "researchCompany": [
              {
                "companyId": "THO",
                "topic": "cashflow"
              }
            ]
          },
          "strategy": {
            "type": "hold",
            "account": "personal"
          }
        },
        {
          "id": "c",
          "label": "退出这项客户持仓",
          "detail": "接受退出后仍可能错过反弹。",
          "result": {
            "text": "订单按客户账户实际份额执行；如有卖出，所得现金仍属于客户账户。没有持仓就不产生交易，你也不会因为按下按钮获得一笔凭空的资金。"
          },
          "effects": {
            "freedom": 4,
            "stress": -4
          },
          "strategy": {
            "type": "exit",
            "account": "client",
            "companyId": "THO",
            "targetPercent": 0
          }
        }
      ]
    },
    {
      "id": "n19_0",
      "dateIndex": 19,
      "slot": 0,
      "priority": 0,
      "chapter": "fracture",
      "title": "九月的走廊",
      "text": "金融危机中的新闻不断更新，办公室却反复处理同样的事：确认资金、回应赎回、问清谁能签字。朱恩的嗓子有些哑，玛拉把自己的日程擦掉一半。你不能凭忙碌让市场停止下跌，也不能因为害怕就跳过客户的约定。\n\n桌上还有一家地方银行的资料。存款、贷款质量和借款不是同一回事。便宜的价格可能是机会，也可能只说明你尚未看清损失会从哪里来。",
      "characters": [
        "june",
        "mara"
      ],
      "chain": "clients",
      "choices": [
        {
          "id": "a",
          "label": "先帮客户把安排落地",
          "detail": "把已核实的事一通一通说明白。",
          "result": {
            "text": "电话有时以沉默结束。你没有许诺很快恢复，只把能办理的步骤与下一次联系时间讲清。朱恩在表上划掉的每一行，都对应一个具体的人。"
          },
          "effects": {
            "communication": 6,
            "trust": 5,
            "stress": 6,
            "flags": [
              "crisis_calls",
              "client_dates"
            ],
            "relations": {
              "june": 6
            }
          }
        },
        {
          "id": "b",
          "label": "用很小一份钱研究银行风险",
          "detail": "尝试将河湾银行配到个人资产的5%。",
          "result": {
            "text": "你先读贷款和资金来源，再提出有限持有。低价本身没有说服谁，成交与否也不会改变这场危机已经存在的不确定。"
          },
          "effects": {
            "research": 5,
            "stress": 4,
            "researchCompany": [
              {
                "companyId": "CBU",
                "topic": "debt"
              }
            ]
          },
          "strategy": {
            "type": "invest",
            "account": "personal",
            "companyId": "CBU",
            "targetPercent": 5
          }
        },
        {
          "id": "c",
          "label": "今天不增加风险",
          "detail": "整理账户和记录，保留现金。",
          "result": {
            "text": "你没有替等待寻找一个胜利的名字。它只是眼下你能解释的选择。回家前，你把个人账单和客户资料分开放好，提醒自己它们不是同一个账户。"
          },
          "effects": {
            "discipline": 5,
            "stress": -2,
            "flags": [
              "cash_buffer"
            ]
          },
          "strategy": {
            "type": "hold",
            "account": "personal"
          }
        }
      ]
    },
    {
      "id": "n20_0",
      "dateIndex": 20,
      "slot": 0,
      "priority": 0,
      "chapter": "fracture",
      "title": "年末不是一场答辩",
      "text": "最后一次年度会议没有人抢着先发言。有人亏了钱，有人失去了信心，也有人恰好少犯了一些错。玛拉要求每个人拿出原来的记录，说明哪些决定来自当时资料，哪些只是后来才显得容易解释。\n\n林说，复盘不是把自己扮演成早知道一切的人。你可以承认失误，也可以确认曾守住的边界；两者都不能替下一年作出保证。",
      "characters": [
        "lin",
        "mara"
      ],
      "chain": "risk",
      "choices": [
        {
          "id": "a",
          "label": "把真实发生的过程留下",
          "detail": "区分判断、权限、运气和实际结果。",
          "result": {
            "text": "你没有改动旧纸上的日期。几处难看的记录保留下来，也让下一次讨论有了可以落脚的地方。错误开始成为工作材料，而不只是个人秘密。"
          },
          "effects": {
            "research": 6,
            "discipline": 7,
            "flags": [
              "crisis_method"
            ],
            "relations": {
              "lin": 5
            }
          }
        },
        {
          "id": "b",
          "label": "请客户关系同事先说",
          "detail": "听完结果怎样影响了别人。",
          "result": {
            "text": "朱恩讲的不是涨跌，而是哪一位客户改了计划。你的报告因此多了一页：决定造成的影响，不能只用回报数字描述。"
          },
          "effects": {
            "communication": 6,
            "trust": 4,
            "flags": [
              "client_window"
            ],
            "relations": {
              "june": 6
            }
          }
        },
        {
          "id": "c",
          "label": "先承认自己已经很累",
          "detail": "申请减少一段时间的负荷。",
          "result": {
            "text": "你没有用疲惫否认工作责任，而是提出可执行的交接。玛拉把两项任务移了出去。你终于能在会议结束后注意到，天还没有完全黑。"
          },
          "effects": {
            "health": 7,
            "stress": -10,
            "freedom": 4,
            "flags": [
              "care_sought"
            ]
          }
        }
      ]
    },
    {
      "id": "n20_1",
      "dateIndex": 20,
      "slot": 1,
      "priority": 0,
      "chapter": "fracture",
      "title": "工牌也有失效的一天",
      "text": "重组通知送到桌上时，你先看的是生效日期。海岬要缩小一部分业务，留下的人同样需要重排工作。玛拉不能替所有人保住原来的位置，也不能把这个结果只归咎于某个人不够努力。\n\n你面前有几条都不轻松的路：结束雇佣关系后重新找工作、接受缩小后的职责，或离开这个行业。无论选哪条，生活还会继续产生账单，故事也不会在今天自动结束。",
      "characters": [
        "mara",
        "sam"
      ],
      "chain": "repair",
      "choices": [
        {
          "id": "a",
          "label": "接受离职，重新找路",
          "detail": "失去薪水与权限，保留继续求职的可能。",
          "result": {
            "text": "你把工牌放进纸袋。没有人在门口播放告别音乐，电梯仍按原来的速度下降。晚上你把必要开支写出来，给第二天安排了第一件具体的事。"
          },
          "effects": {
            "career": "unemployed",
            "authority": -100,
            "stress": 8,
            "freedom": 5,
            "flags": [
              "job_lost"
            ],
            "relations": {
              "sam": 3
            }
          }
        },
        {
          "id": "b",
          "label": "留在缩小后的团队",
          "detail": "接受更多杂事，先维持工作。",
          "result": {
            "text": "桌边少了几个名字，你接到的不只是一份留下的工资。朱恩把新的联络名单发来，第一行写着：承诺比以前少一点，但要真的做到。"
          },
          "effects": {
            "career": "senior",
            "authority": -5,
            "stress": 7,
            "health": -3,
            "flags": [
              "stayed_after_crisis"
            ]
          }
        },
        {
          "id": "c",
          "label": "把技能带到别的工作",
          "detail": "主动转行，收入与身份都需要重新适应。",
          "result": {
            "text": "你开始向更普通的岗位解释自己会做什么：核对资料、写清流程、把复杂事情说明白。履历上的词变了，过去的经验没有因此全部作废。"
          },
          "effects": {
            "career": "outside",
            "authority": -100,
            "freedom": 8,
            "stress": 3,
            "flags": [
              "outside_committed",
              "left_finance"
            ]
          }
        }
      ]
    },
    {
      "id": "n21_0",
      "dateIndex": 21,
      "slot": 0,
      "priority": 0,
      "chapter": "fracture",
      "title": "一颗螺丝也有客户",
      "text": "危机发生后，你读到一家卖紧固件和工业用品的企业。产品小得容易被忽略，客户却可能在缺少它时停工；仓库、配送和与客户的联系因此有价值，也因此有成本。工厂减少开工，订单就不会只因为你喜欢这个故事而回来。\n\n你不再急于用一笔投资证明自己已经恢复。可以买一点，可以继续查，也可以让现金先承担生活；每一种选择都需要接受实际账本的约束。",
      "characters": [
        "lin"
      ],
      "chain": "wealth",
      "choices": [
        {
          "id": "a",
          "label": "用有限个人资金持有",
          "detail": "尝试将北岭分销配到个人资产的10%。",
          "result": {
            "text": "你在理由里写了客户需要什么，也写了客户可能少买什么。实际持仓取决于可用现金；买入没有替你宣布危机结束，只增加了一份需要继续照看的所有权。"
          },
          "effects": {
            "research": 4,
            "discipline": 3,
            "flags": [
              "kept_ownership"
            ],
            "researchCompany": [
              {
                "companyId": "FAST",
                "topic": "customers"
              },
              {
                "companyId": "FAST",
                "topic": "valuation"
              }
            ]
          },
          "strategy": {
            "type": "invest",
            "account": "personal",
            "companyId": "FAST",
            "targetPercent": 10
          }
        },
        {
          "id": "b",
          "label": "先保住生活现金",
          "detail": "把暂不投入的理由写明。",
          "result": {
            "text": "你给现金留了一个具体用途，而不是把它叫作永远安全。没有人能够保证下一次机会还在原处，但你保住了等待下一次决定的能力。"
          },
          "effects": {
            "stress": -4,
            "freedom": 4,
            "flags": [
              "cash_buffer"
            ]
          },
          "strategy": {
            "type": "hold",
            "account": "personal"
          }
        },
        {
          "id": "c",
          "label": "先研究，再慢慢决定",
          "detail": "从货物怎样到客户手里开始。",
          "result": {
            "text": "这次你没有先找一句适合放在封面的结论。一个普通问题引出了几个需要核实的细节，你暂时只增加了知识，没有增加持仓。"
          },
          "effects": {
            "research": 6,
            "researchCompany": [
              {
                "companyId": "FAST",
                "topic": "customers"
              },
              {
                "companyId": "FAST",
                "topic": "cashflow"
              }
            ]
          },
          "strategy": {
            "type": "hold",
            "account": "personal"
          }
        }
      ]
    },
    {
      "id": "n22_0",
      "dateIndex": 22,
      "slot": 0,
      "priority": 0,
      "chapter": "fracture",
      "title": "客户终于用到了那笔钱",
      "text": "朱恩发来一份简短回访。有人按计划支付学费，有人不得不延后家里的工程，也有人决定以后多留现金。她没有把这些不同的结果装进同一种胜利叙事，只请你核对，团队曾承诺过什么。\n\n一段服务是否有用，往往到钱离开账户、去往真实用途的时候才更清楚。你能继续关心它，也可以把注意力转到下一份排名上。",
      "characters": [
        "june"
      ],
      "chain": "clients",
      "choices": [
        {
          "id": "a",
          "label": "把用途是否按时实现记下来",
          "detail": "让客户的时间进入复盘。",
          "result": {
            "text": "你们给这段服务补上最后一栏。它不是替亏损找借口，也不是抹去好成绩，而是问：当时交给你们的事情，究竟完成了多少？"
          },
          "effects": {
            "trust": 6,
            "communication": 4,
            "flags": [
              "client_window"
            ],
            "relations": {
              "june": 6
            }
          }
        },
        {
          "id": "b",
          "label": "回信承认仍有没做好的地方",
          "detail": "为下一次服务建立更清楚的约定。",
          "result": {
            "text": "你没有把所有差错都写成外部环境。朱恩删掉一句过分自责的话，说她需要的是下次会怎样做。你们终于留下一个可以执行的改变。"
          },
          "effects": {
            "discipline": 5,
            "communication": 5,
            "relations": {
              "june": 4
            }
          }
        },
        {
          "id": "c",
          "label": "把手里的工作先做完",
          "detail": "只确认资料，不另接回访任务。",
          "result": {
            "text": "你没有继续参与这段回访。朱恩照常完成了记录。世界并不因为你缺席而停止，但有些后来才显得重要的细节，就这样不再从你这里经过。"
          },
          "effects": {
            "stress": -3,
            "freedom": 2
          }
        }
      ]
    },
    {
      "id": "n22_1",
      "dateIndex": 22,
      "slot": 1,
      "priority": 0,
      "chapter": "fracture",
      "title": "第二份履历",
      "text": "你重新整理工作经历，发现同一段时间可以被写成很多样子：失去机会、保住工作、离开熟悉的行业。山姆愿意替你看一遍，他最先删掉的是那句“可以承担任何任务”。\n\n他说，别人需要知道你具体能做什么，你也需要知道自己不想再怎样生活。接下来这份工作未必耀眼，但足够明确的开始，有时比一个宏大的自我证明更重要。",
      "characters": [
        "sam"
      ],
      "chain": "repair",
      "choices": [
        {
          "id": "a",
          "label": "申请一份边界清楚的研究岗位",
          "detail": "重新积累工作，不要求立刻回到原处。",
          "result": {
            "text": "面试里你讲了一次自己确实做错的判断，也讲了后来怎样处理。得到的不是保证，只是一份可以开始执行的工作安排。"
          },
          "effects": {
            "career": "senior",
            "authority": 10,
            "trust": 4,
            "stress": 2,
            "flags": [
              "rebuilt"
            ],
            "relations": {
              "sam": 5
            }
          }
        },
        {
          "id": "b",
          "label": "把新行业当作真正的选择",
          "detail": "不再只说“暂时做着”。",
          "result": {
            "text": "你认真修改了职业介绍，把旧工作中有用的能力留下。新同事不要求你每天解释从哪里来，你也逐渐停止替自己的选择道歉。"
          },
          "effects": {
            "career": "outside",
            "freedom": 6,
            "health": 4,
            "flags": [
              "outside_committed"
            ]
          }
        },
        {
          "id": "c",
          "label": "再留一段过渡时间",
          "detail": "继续做短期工作和求职准备。",
          "result": {
            "text": "你没有把这段时间叫作空白，而是列出本周的工作、开支和下一封申请。路仍不稳定，至少每一天不再只靠等待一个回复撑起来。"
          },
          "effects": {
            "stress": -2,
            "research": 4,
            "personalCash": 1200,
            "flags": [
              "bridge_work"
            ]
          }
        }
      ]
    },
    {
      "id": "n23_0",
      "dateIndex": 23,
      "slot": 0,
      "priority": 0,
      "chapter": "fracture",
      "title": "飞机落地之后",
      "text": "航空维修资料里写着零件、检修与周转，而不是远行的浪漫。飞机停在地面会产生成本，维护又不能省掉应有的标准。你关心维修企业能不能按时供货，也要看库存、借款和航空客户的景气。\n\n林说，不必因为某项服务不可缺少，就认为提供服务的每家公司都值得任何价格。你把“必需”旁边又写下一个问题：这份必需，最后有多少能够变成稳定的现金？",
      "characters": [
        "lin"
      ],
      "chain": "risk",
      "choices": [
        {
          "id": "a",
          "label": "小额持有维修业务",
          "detail": "尝试将天际维修配到个人资产的8%。",
          "result": {
            "text": "你把客户景气和库存周转列在同一页。交易按真实行情发生，不会因为文字里的必需就免于波动。你保留了之后重新检视的责任。"
          },
          "effects": {
            "research": 4,
            "discipline": 3,
            "researchCompany": [
              {
                "companyId": "AIR",
                "topic": "customers"
              },
              {
                "companyId": "AIR",
                "topic": "debt"
              },
              {
                "companyId": "AIR",
                "topic": "valuation"
              }
            ]
          },
          "strategy": {
            "type": "invest",
            "account": "personal",
            "companyId": "AIR",
            "targetPercent": 8
          }
        },
        {
          "id": "b",
          "label": "继续等待更多证据",
          "detail": "完成现金流研究，不新增仓位。",
          "result": {
            "text": "你读完了今天能看到的材料，也写下仍然缺少的部分。等待不是对未来结果的预测，而是对当下认识边界的一次确认。"
          },
          "effects": {
            "research": 5,
            "researchCompany": [
              {
                "companyId": "AIR",
                "topic": "cashflow"
              }
            ]
          },
          "strategy": {
            "type": "hold",
            "account": "personal"
          }
        },
        {
          "id": "c",
          "label": "先核对风险，暂不买入",
          "detail": "保留现金，写清哪项证据还需要确认。",
          "result": {
            "text": "你重新问了一遍，库存多久能变成客户支付的钱。飞机需要维护并不能消除公司的经营风险；你没有下单，准备等下一份可核验资料再回来。"
          },
          "effects": {
            "stress": -3,
            "discipline": 4
          },
          "strategy": {
            "type": "hold",
            "account": "personal"
          }
        }
      ]
    },
    {
      "id": "n23_1",
      "dateIndex": 23,
      "slot": 1,
      "priority": 0,
      "chapter": "fracture",
      "title": "讲台前换了一批面孔",
      "text": "达里厄斯又来邀请你。图书馆的教室换了几张椅子，来听课的人也不同了，有人刚找到工作，有人问失业后该先处理哪张账单。他不需要你证明过去几年看对了市场，只希望你把不确定说得诚实一点。\n\n你可以参与这次课程，也可以交出一份别人能用的教材。真正的帮助未必要求你始终站在讲台前，但需要有一件事情被认真完成。",
      "characters": [
        "darius"
      ],
      "chain": "school",
      "choices": [
        {
          "id": "a",
          "label": "讲一次真实的困难",
          "detail": "不用自己的成绩替别人作保证。",
          "result": {
            "text": "有人问你也有没有不知道该怎么办的时候。你说有，然后讲怎样列清眼前能决定的事。达里厄斯把下一年的邀请留到下课以后再谈。"
          },
          "effects": {
            "communication": 6,
            "trust": 3,
            "flags": [
              "class_return",
              "class_started"
            ],
            "relations": {
              "darius": 6
            }
          }
        },
        {
          "id": "b",
          "label": "把教材交给另一位讲师",
          "detail": "让事情不只依赖自己出场。",
          "result": {
            "text": "你们一起删除了几页过于漂亮的案例。最后的材料可以被别人使用，也允许别人继续修改。你没有失去贡献，只是把它换了一种位置。"
          },
          "effects": {
            "discipline": 4,
            "freedom": 3,
            "flags": [
              "class_return"
            ],
            "relations": {
              "darius": 4
            }
          }
        },
        {
          "id": "c",
          "label": "坦白今年没有余力",
          "detail": "谢绝固定承诺，保留一次阅读建议。",
          "result": {
            "text": "达里厄斯接受了。他说稳定的课程不能靠每个人都勉强挤出一点时间。你把拒绝说在排课以前，这一次别人不必临时替你收场。"
          },
          "effects": {
            "health": 4,
            "stress": -4,
            "freedom": 3
          }
        }
      ]
    },
    {
      "id": "n24_0",
      "dateIndex": 24,
      "slot": 0,
      "priority": 0,
      "chapter": "fracture",
      "title": "不再只是把自己做快",
      "text": "玛拉在会议后问，你是否愿意负责一支小团队。工作会从自己写报告，变成决定别人什么时候能写完、谁来复核、出了问题谁在场。她把一份预算推过来，没有先谈新头衔。\n\n这些年你认识的同事各有自己的生活，不能因为你愿意加班，就默认他们都能一样。成为负责人，可能意味着少一点亲自完成的满足，多一点把条件准备好的耐心。",
      "characters": [
        "mara",
        "sam"
      ],
      "chain": "ambition",
      "choices": [
        {
          "id": "a",
          "label": "接下团队，先安排好复核与轮值",
          "detail": "把责任分配写得和业务目标一样清楚。",
          "result": {
            "text": "你第一次需要解释为什么某项任务不该接。玛拉说这也是负责人的工作。桌子变大以后，你开始花时间让别人能够正常离开自己的桌子。"
          },
          "effects": {
            "career": "head",
            "authority": 10,
            "trust": 5,
            "communication": 5,
            "stress": 5,
            "flags": [
              "leader_agenda"
            ],
            "relations": {
              "sam": 4
            }
          }
        },
        {
          "id": "b",
          "label": "继续做一名可靠的专业人员",
          "detail": "不把所有成长都写成管理职务。",
          "result": {
            "text": "你接下更复杂的研究，也拒绝了一部分管理责任。日历仍然很满，但它至少更多地对应你真正想做、也能够完成的工作。"
          },
          "effects": {
            "career": "senior",
            "research": 5,
            "health": 3,
            "freedom": 4,
            "flags": [
              "steady_work"
            ]
          }
        },
        {
          "id": "c",
          "label": "与主管讨论更短的工作时间",
          "detail": "愿意让收入和机会随之调整。",
          "result": {
            "text": "谈话比你预想得慢，需要重新划分职责。你没有得到原样不动的所有好处，却终于把私人时间当作可以正式谈判的条件。"
          },
          "effects": {
            "health": 7,
            "stress": -7,
            "freedom": 6,
            "reputation": -2,
            "flags": [
              "work_boundary"
            ]
          }
        }
      ]
    },
    {
      "id": "n25_0",
      "dateIndex": 25,
      "slot": 0,
      "priority": 0,
      "chapter": "fracture",
      "title": "保单背后是一次续约",
      "text": "保险经纪企业帮助客户寻找保单，自己未必承担保险事故的全部赔付。你把这项区别写清楚，又继续问：佣金怎样来，客户为何续约，收购来的业务能否留住人？一个轻巧的生意故事，也可能藏着整合和价格的负担。\n\n朱恩说她最理解最后一个问题。关系不是收入表上的永久项目，对方有一天会重新决定，还愿不愿意把事情交给你。",
      "characters": [
        "june"
      ],
      "chain": "clients",
      "choices": [
        {
          "id": "a",
          "label": "把经纪业务纳入小额持有",
          "detail": "尝试将杉谷经纪配到个人资产的10%。",
          "result": {
            "text": "你把续约和人员稳定写进跟踪清单。它们无法保证价格表现，却让你知道以后回来看这份投资时，应该先问哪几个问题。"
          },
          "effects": {
            "research": 4,
            "discipline": 3,
            "researchCompany": [
              {
                "companyId": "BRO",
                "topic": "customers"
              }
            ]
          },
          "strategy": {
            "type": "invest",
            "account": "personal",
            "companyId": "BRO",
            "targetPercent": 10
          }
        },
        {
          "id": "b",
          "label": "先找出收购与借款的关系",
          "detail": "暂不买卖，补齐自己不懂的部分。",
          "result": {
            "text": "你不再把收入增长都称作自然长大。今天的资料只回答了其中一部分，你把未解的问题留给下一次，而没有替企业编一个完整的故事。"
          },
          "effects": {
            "research": 6,
            "researchCompany": [
              {
                "companyId": "BRO",
                "topic": "debt"
              }
            ]
          },
          "strategy": {
            "type": "hold",
            "account": "personal"
          }
        },
        {
          "id": "c",
          "label": "先核对风险，暂不买入",
          "detail": "保留现金，写清哪项证据还需要确认。",
          "result": {
            "text": "你核对经纪业务怎样留住客户，以及收入会受哪些谈判影响。收费方式看起来熟悉，却仍需要自己的证据。现金暂时没有换成持仓，问题也没有被删掉。"
          },
          "effects": {
            "freedom": 3,
            "stress": -2
          },
          "strategy": {
            "type": "hold",
            "account": "personal"
          }
        }
      ]
    },
    {
      "id": "n25_1",
      "dateIndex": 25,
      "slot": 1,
      "priority": 0,
      "chapter": "fracture",
      "title": "第二次说“等忙完”",
      "text": "工作已经比最初复杂得多，你却仍沿用当年一个人处理一切的办法。林约你吃饭，你临时改到办公室楼下，整顿饭里接了三次电话。他没有替你诊断，只问你上一次完整休息是什么时候。\n\n你想起这些年反复说过的“忙完这阵”。它曾经指某一份报告，如今越来越像没有日期的承诺。眼前还有任务，也有一次可以认真重新分配它们的机会。",
      "characters": [
        "lin",
        "nora"
      ],
      "chain": "health",
      "choices": [
        {
          "id": "a",
          "label": "继续撑住这一轮交付",
          "detail": "留下真实的负荷，别把它说成没有代价。",
          "result": {
            "text": "你吃完已经凉下来的饭，回去处理剩下的电话。林没有争论，把自己的空闲时间写给你。这个提醒没有强迫你改变，你也确实没有改变。"
          },
          "effects": {
            "stress": 12,
            "health": -10,
            "trust": 3,
            "flags": [
              "highload_2011"
            ]
          }
        },
        {
          "id": "b",
          "label": "把两项职责正式交出去",
          "detail": "让恢复不只停留在一次休假。",
          "result": {
            "text": "交接比独自做完更费一时的工夫。几周后，你第一次发现有件事已经被别人妥当地完成，而你不需要为没有亲自动手感到羞愧。"
          },
          "effects": {
            "health": 9,
            "stress": -12,
            "freedom": 5,
            "flags": [
              "load_reduced"
            ]
          }
        },
        {
          "id": "c",
          "label": "寻求评估，也请家人帮忙安排",
          "detail": "不靠意志给不适下结论。",
          "result": {
            "text": "你把近期的状态认真记录下来，交给合适的专业人员。诺拉帮你留出行程，但也说以后需要你一起承担安排，而不只是临时求救。"
          },
          "effects": {
            "personalCash": -250,
            "health": 7,
            "stress": -8,
            "relations": {
              "nora": 4
            },
            "flags": [
              "care_sought"
            ]
          }
        }
      ]
    },
    {
      "id": "n26_0",
      "dateIndex": 26,
      "slot": 0,
      "priority": 0,
      "chapter": "fracture",
      "title": "别人也会有下一站",
      "text": "年末聚餐时，山姆提到想争取一个新的岗位。他讲了准备学什么、父亲的安排，以及希望自己也能负责完整工作的原因。你意识到，他已不再只是你忙起来时会叫过来的年轻同事。\n\n你可以帮他，也可以担心团队少一个熟手。两种感受并不矛盾，但最后需要说出口的是一个具体的答复，而不是让他从你的沉默里猜自己的位置。",
      "characters": [
        "sam"
      ],
      "chain": "junior",
      "choices": [
        {
          "id": "a",
          "label": "帮他把做过的工作说清楚",
          "detail": "提供真实推荐，不夸大他的经历。",
          "result": {
            "text": "你们一起找回几份旧记录。山姆不需要被写成从未犯错的人，只需要别人看见他承担过什么。临走前，他说以后也愿意帮你看一份材料。"
          },
          "effects": {
            "communication": 4,
            "trust": 3,
            "relations": {
              "sam": 7
            },
            "flags": [
              "sam_bridge"
            ]
          }
        },
        {
          "id": "b",
          "label": "坦白担心，再认真谈交接",
          "detail": "让离开不必以翻脸为代价。",
          "result": {
            "text": "你说明团队的困难，山姆也说清自己的期限。最后留下的是几周的交接安排，而不是一份永远欠着的人情。"
          },
          "effects": {
            "discipline": 4,
            "relations": {
              "sam": 4
            },
            "flags": [
              "sam_helped"
            ]
          }
        },
        {
          "id": "c",
          "label": "希望他先留下来",
          "detail": "说明你能提供什么，也接受他可能拒绝。",
          "result": {
            "text": "山姆没有马上答应。你给出的条件被认真听完，他仍保留自己的决定。你第一次如此清楚地感到，关系不等于对方必须一直在原位。"
          },
          "effects": {
            "stress": 2,
            "relations": {
              "sam": -2
            },
            "reputation": 2
          }
        }
      ]
    },
    {
      "id": "n27_0",
      "dateIndex": 27,
      "slot": 0,
      "priority": 0,
      "chapter": "fracture",
      "title": "工作也有松紧的时候",
      "text": "人力服务企业的客户需要招人时，它能提供筛选和临时安排；企业收缩时，这些需求也可能很快减少。你读资料时想到自己那份曾反复修改的履历：收入表里的一项波动，在某个人家里会是一整年的打算。\n\n理解这种波动不能让你躲过周期。它至少能提醒你，持仓可以有限，判断可以修改，不要把自己的职业愿望也塞进股票里，要求它一起实现。",
      "characters": [
        "sam"
      ],
      "chain": "repair",
      "choices": [
        {
          "id": "a",
          "label": "有限参与招聘服务生意",
          "detail": "尝试将格点人才配到个人资产的8%。",
          "result": {
            "text": "你记录招聘需求和现金状况，没把自己的求职经历当成整个行业的缩影。账户会按当天条件处理，这笔投资也要接受与你的人生愿望分开的检验。"
          },
          "effects": {
            "research": 4,
            "discipline": 3,
            "researchCompany": [
              {
                "companyId": "RHI",
                "topic": "customers"
              }
            ]
          },
          "strategy": {
            "type": "invest",
            "account": "personal",
            "companyId": "RHI",
            "targetPercent": 8
          }
        },
        {
          "id": "b",
          "label": "继续积累职业与财务缓冲",
          "detail": "今天不增加风险。",
          "result": {
            "text": "你完成了工作，也把一份备用履历存好。缓冲不只是一笔现金，还包括有人能介绍你做过的事，以及你自己仍愿意学习下一份工作。"
          },
          "effects": {
            "research": 3,
            "freedom": 3,
            "flags": [
              "cash_buffer",
              "second_offer"
            ]
          },
          "strategy": {
            "type": "hold",
            "account": "personal"
          }
        },
        {
          "id": "c",
          "label": "先核对风险，暂不买入",
          "detail": "保留现金，写清哪项证据还需要确认。",
          "result": {
            "text": "你把企业愿不愿意招人放在收入判断前面。人才服务连接真实需求，也会直接面对需求退潮；这次你先等候，把未确定的部分说明白。"
          },
          "effects": {
            "discipline": 4,
            "stress": -3
          },
          "strategy": {
            "type": "hold",
            "account": "personal"
          }
        }
      ]
    },
    {
      "id": "n27_1",
      "dateIndex": 27,
      "slot": 1,
      "priority": 0,
      "chapter": "fracture",
      "title": "一顿终于没有改期的饭",
      "text": "梅从巡展回来，带来一个边角磨旧的行李箱。她讲不同城市的工作、一个不合适的职位，以及下一次仍然想试的项目。你们的关系可能比从前亲近，也可能保留着距离；眼前这顿饭并没有替过去自动补上所有缺席。\n\n她问的只是，以后怎样安排才对双方都公平。你可以重新约定，也可以承认自己只能保留较松的联系。",
      "characters": [
        "mei"
      ],
      "chain": "friend",
      "choices": [
        {
          "id": "a",
          "label": "让两个人的计划都占位置",
          "detail": "商量固定时间，不要求谁永远等待。",
          "result": {
            "text": "你们拿出各自的日历，先写她已经确定的项目，再写你的安排。约定没有抹平过去，却终于不再只围着其中一个人的空闲转。"
          },
          "effects": {
            "relations": {
              "mei": 7
            },
            "communication": 5,
            "freedom": 3,
            "flags": [
              "mei_equal"
            ]
          }
        },
        {
          "id": "b",
          "label": "保留真诚但不密集的联系",
          "detail": "不承诺自己做不到的亲近。",
          "result": {
            "text": "梅点了点头，话题回到展品和路上的见闻。你们仍能分享一顿饭，只是不再把每一次告别都说成很快会再见。"
          },
          "effects": {
            "relations": {
              "mei": 2
            },
            "freedom": 5,
            "flags": [
              "friend_distance"
            ]
          }
        },
        {
          "id": "c",
          "label": "把这次见面交给当下",
          "detail": "认真听完，暂不作长期承诺。",
          "result": {
            "text": "你终于把手机放进外套口袋。没有宏大的决定，却有一段没有被打断的谈话。它不能替未来保证什么，至少今天确实发生了。"
          },
          "effects": {
            "health": 4,
            "stress": -4,
            "relations": {
              "mei": 4
            }
          }
        }
      ]
    },
    {
      "id": "n28_0",
      "dateIndex": 28,
      "slot": 0,
      "priority": 0,
      "chapter": "fracture",
      "title": "签字之前再问一遍",
      "text": "伊莱让你核对一份工作安排，里面有一句含糊的表述，可以让客户误以为某种结果已被保证。提出修改会推迟签约，也可能让介绍人觉得你不好合作。\n\n这些年你已经看过承诺进入账单以后会发生什么。今天仍然需要作选择：把不确定写清楚，让有权决定的人共同承担，或者寄希望于所有人都按你心里的意思理解。",
      "characters": [
        "elias",
        "june"
      ],
      "chain": "ethics",
      "choices": [
        {
          "id": "a",
          "label": "把那句保证改掉",
          "detail": "留下明确范围，愿意为此慢一点。",
          "result": {
            "text": "签约没有按原定时间完成。朱恩逐一说明修改，伊莱把最终版本收进记录。你付出了一个真实的延期，也少留下一句将来无法解释的话。"
          },
          "effects": {
            "discipline": 6,
            "trust": 4,
            "flags": [
              "boundary_followed"
            ],
            "relations": {
              "elias": 6,
              "june": 3
            }
          }
        },
        {
          "id": "b",
          "label": "请对方当面复述理解",
          "detail": "确认分歧，再决定是否继续。",
          "result": {
            "text": "你没有用一封“已阅读”邮件替代谈话。对方说出的理解果然与你不同，会议多花了半小时，也避免让同一个句子装下两种期待。"
          },
          "effects": {
            "communication": 6,
            "discipline": 4,
            "flags": [
              "boundary_followed"
            ]
          }
        },
        {
          "id": "c",
          "label": "暂时不接这项业务",
          "detail": "把自己无法承担的条件还回去。",
          "result": {
            "text": "你失去一项可能的收入，却没有把拒绝包装成高人一等。只是这项委托需要的条件，与你现在能够兑现的工作不一致。"
          },
          "effects": {
            "freedom": 5,
            "stress": -3,
            "reputation": -2,
            "flags": [
              "work_boundary"
            ]
          }
        }
      ]
    },
    {
      "id": "n28_1",
      "dateIndex": 28,
      "slot": 1,
      "priority": 0,
      "chapter": "fracture",
      "title": "一种新工作，不是一种新身份",
      "text": "你把过去几年的工作经验重新列了一遍：哪些需要机构资源，哪些可以独立完成，哪些其实已经不想再做。独立经营的想法可能仍在，也可能只是偶尔冒出来。伊莱提醒你，重新印名片并不会自动带来客户、手续或稳定收入。\n\n眼前有一笔实实在在的启动费用，也有继续工作的选择。无论如何，你不需要今天就把余生说得完整。",
      "characters": [
        "elias",
        "mara"
      ],
      "chain": "autonomy",
      "choices": [
        {
          "id": "a",
          "label": "先准备，再决定是否独立",
          "detail": "整理预算与规则，保留目前的工作或求职安排。",
          "result": {
            "text": "你把事情拆成可以核实的几项：费用、资格、合同、客户用途。名片上的名字仍没想好，笔记本里却终于有了能用来判断是否开始的依据。"
          },
          "effects": {
            "research": 5,
            "discipline": 4,
            "flags": [
              "independence_seed"
            ]
          }
        },
        {
          "id": "b",
          "label": "接受机构的研究岗位安排",
          "detail": "在机构内继续工作，或明确重新入职后承担研究职责。",
          "result": {
            "text": "你接受玛拉提供的研究岗位安排，确认入职或岗位调整的手续，以及需要完成的交接。选择留在或回到机构由这次答复明确下来，职责与时间边界也写得比模糊期待更清楚。"
          },
          "effects": {
            "career": "senior",
            "health": 3,
            "trust": 4,
            "flags": [
              "steady_work"
            ]
          }
        },
        {
          "id": "c",
          "label": "正式选择转行",
          "detail": "承认新工作的价值，不只把它当退路。",
          "result": {
            "text": "你在职业介绍里写上新岗位，没有再加一句“暂时”。研究和沟通的经验跟着你走，客户投资权限则留在原来的制度里。"
          },
          "effects": {
            "career": "outside",
            "authority": -100,
            "freedom": 7,
            "health": 4,
            "flags": [
              "outside_committed",
              "left_finance"
            ]
          }
        }
      ]
    },
    {
      "id": "n29_0",
      "dateIndex": 29,
      "slot": 0,
      "priority": 0,
      "chapter": "fracture",
      "title": "镜子里的客户集中度",
      "text": "汽车电子镜企业让你看到一种不太显眼的产品改进：驾驶者未必天天想到它，车厂却需要稳定品质和可靠交付。你喜欢这种重复发生的用途，也注意到客户集中、车型变化和技术竞争可能同时影响结果。\n\n一家企业可以有好产品，也可能被大客户压价。你在资料页上写了这两句话，决定接下来是用少量资金参与，还是先看自己究竟懂得了多少。",
      "characters": [
        "lin"
      ],
      "chain": "wealth",
      "choices": [
        {
          "id": "a",
          "label": "为有限持有补齐研究",
          "detail": "尝试将镜原精密配到个人资产的10%。",
          "result": {
            "text": "你把客户集中列在产品优点旁边，没有用一个动听的技术故事盖住它。实际仓位将受可用资金限制，之后的结果不会修改今天这份原始理由。"
          },
          "effects": {
            "research": 4,
            "discipline": 3,
            "flags": [
              "kept_ownership"
            ],
            "researchCompany": [
              {
                "companyId": "GNTX",
                "topic": "customers"
              },
              {
                "companyId": "GNTX",
                "topic": "valuation"
              }
            ]
          },
          "strategy": {
            "type": "invest",
            "account": "personal",
            "companyId": "GNTX",
            "targetPercent": 10
          }
        },
        {
          "id": "b",
          "label": "先研究客户可能换供应商的原因",
          "detail": "暂不下单。",
          "result": {
            "text": "问题把你带回质量、价格和替换成本。它们没有替你预测下一张订单，却比一句“汽车越来越先进”更接近这门生意真正需要做好的事情。"
          },
          "effects": {
            "research": 6,
            "researchCompany": [
              {
                "companyId": "GNTX",
                "topic": "challenge"
              }
            ]
          },
          "strategy": {
            "type": "hold",
            "account": "personal"
          }
        },
        {
          "id": "c",
          "label": "先核对风险，暂不买入",
          "detail": "保留现金，写清哪项证据还需要确认。",
          "result": {
            "text": "你追问产品怎样装进客户的订单，客户又能多快改用别的供应者。一个看得见的产品，不代表看得清全部风险；你把买入留到理解更充分的时候。"
          },
          "effects": {
            "freedom": 3,
            "stress": -2
          },
          "strategy": {
            "type": "hold",
            "account": "personal"
          }
        }
      ]
    },
    {
      "id": "n30_0",
      "dateIndex": 30,
      "slot": 0,
      "priority": 0,
      "chapter": "fracture",
      "title": "过了关，不等于不再需要休息",
      "text": "你终于完成一项持续很久的工作，本以为结束后会自然轻松，新的任务却在庆祝邮件之前到了。与你协作的人问下一个项目是否继续由你负责，语气里有信任，也有惯于依靠你的期待。\n\n你已经知道自己的能力，也该开始知道能力并不意味着每一次都要用满。休整、交接、继续冲刺，都可以是选择；区别在于你是否愿意承认各自的代价。",
      "characters": [
        "mara"
      ],
      "chain": "health",
      "choices": [
        {
          "id": "a",
          "label": "留一段真正的休整时间",
          "detail": "明确交接，恢复原来的生活安排。",
          "result": {
            "text": "你没有把所有问题带进假期。刚开始的空闲让人不习惯，后来你终于记起几件不会出现在工作清单上的小事。"
          },
          "effects": {
            "health": 8,
            "stress": -10,
            "freedom": 5,
            "flags": [
              "load_reduced",
              "weekly_boundary"
            ]
          }
        },
        {
          "id": "b",
          "label": "继续负责，但缩小承诺",
          "detail": "留下最重要的一部分，其他交给同事。",
          "result": {
            "text": "你和相关的人一起列出不能接的项目。承认边界比说“都可以”难，却让彼此第一次能照着真实的容量安排工作。"
          },
          "effects": {
            "trust": 4,
            "health": 3,
            "stress": -3,
            "communication": 4,
            "flags": [
              "work_boundary"
            ]
          }
        },
        {
          "id": "c",
          "label": "把这股劲用到下一项工作",
          "detail": "接受更高负荷，争取继续向前。",
          "result": {
            "text": "新项目很快填满空出的日程。你受到认可，也确实更疲惫。成功完成一项工作，并没有让下一项工作的消耗自动归零。"
          },
          "effects": {
            "reputation": 6,
            "stress": 9,
            "health": -6,
            "flags": [
              "career_first"
            ]
          }
        }
      ]
    },
    {
      "id": "n30_1",
      "dateIndex": 30,
      "slot": 1,
      "priority": 0,
      "chapter": "fracture",
      "title": "姐姐的工作也要有人等",
      "text": "诺拉的小事务所有一份重要图纸需要交，她请你帮忙处理一次家庭安排。你听见她说截止日，恰好与自己常说的那种语气一样。她并没有要求你放弃工作，只是不想自己的工作永远先被当作可以挪开的部分。\n\n你们这些年的分担并不总是平衡，今天仍有机会重新商量。一次答应不能抹平过去，一次认真完成却可以让下一次开口不那么难。",
      "characters": [
        "nora"
      ],
      "chain": "family",
      "choices": [
        {
          "id": "a",
          "label": "这次由自己把安排接完整",
          "detail": "不只转发消息，完成核对和联络。",
          "result": {
            "text": "诺拉把交付后的第一张照片发给你。你们没有统计谁欠谁，只约好下次提前把需要写出来。她终于可以暂时只顾自己的工作。"
          },
          "effects": {
            "relations": {
              "nora": 8
            },
            "communication": 4,
            "flags": [
              "family_trust"
            ]
          }
        },
        {
          "id": "b",
          "label": "一起请可靠的人帮忙",
          "detail": "分担费用，也尊重姐姐的选择。",
          "result": {
            "text": "你们一起核对安排，而不是由你付钱后宣布解决。帮助有了明确的范围，诺拉不必再把额外协调悄悄背回自己身上。"
          },
          "effects": {
            "personalCash": -350,
            "relations": {
              "nora": 5
            },
            "flags": [
              "family_trust"
            ]
          }
        },
        {
          "id": "c",
          "label": "这次确实接不过来",
          "detail": "明确拒绝，并承认她同样有难处。",
          "result": {
            "text": "诺拉找了别的办法。她没有要求你说漂亮话，你也没有用自己的头衔证明谁更忙。谈话不轻松，却比假装会来诚实一点。"
          },
          "effects": {
            "communication": 3,
            "relations": {
              "nora": -3
            },
            "stress": 3
          }
        }
      ]
    },
    {
      "id": "n31_0",
      "dateIndex": 31,
      "slot": 0,
      "priority": 0,
      "chapter": "homeward",
      "title": "地下的资源，地上的账单",
      "text": "能源企业的资料里有储量、产量和技术，也有持续投入与大宗商品价格。你知道人们需要能源，却不能因此知道某个价格会维持多久。把地下的东西取出来，需要先在地上支付一系列账单。\n\n玛拉问你是否愿意给出建议。你可以有限参与，也可以先看现金怎样进出。无论怎样，不能把一个行业对社会有用，直接写成它对每一位股东都一定有利。",
      "characters": [
        "mara"
      ],
      "chain": "risk",
      "choices": [
        {
          "id": "a",
          "label": "用有限仓位参与能源业务",
          "detail": "尝试将荒原能源配到个人资产的8%。",
          "result": {
            "text": "你把价格下降时的现金需要写进研究。交易由真实资金与行情决定，这个小仓位不会让你免于看错，只让你知道自己承诺了多少。"
          },
          "effects": {
            "research": 5,
            "discipline": 3,
            "researchCompany": [
              {
                "companyId": "EOG",
                "topic": "cashflow"
              },
              {
                "companyId": "EOG",
                "topic": "debt"
              },
              {
                "companyId": "EOG",
                "topic": "valuation"
              }
            ]
          },
          "strategy": {
            "type": "invest",
            "account": "personal",
            "companyId": "EOG",
            "targetPercent": 8
          }
        },
        {
          "id": "b",
          "label": "暂不买入，先看资金投入",
          "detail": "把设备、勘探和借款分别弄清。",
          "result": {
            "text": "你没有把所有支出都塞进同一栏。多花的时间让建议显得不够痛快，却减少了用一个漂亮数字替不同用途作答的冲动。"
          },
          "effects": {
            "research": 6,
            "discipline": 4,
            "researchCompany": [
              {
                "companyId": "EOG",
                "topic": "cashflow"
              }
            ]
          },
          "strategy": {
            "type": "hold",
            "account": "personal"
          }
        },
        {
          "id": "c",
          "label": "先核对风险，暂不买入",
          "detail": "保留现金，写清哪项证据还需要确认。",
          "result": {
            "text": "你把开采成本与能源售价分别记录，没有用一个乐观数字盖住它们之间的距离。这次不买，仍然要面对市场继续变化，却不必为尚未理解的波动付出仓位。"
          },
          "effects": {
            "stress": -3,
            "freedom": 3
          },
          "strategy": {
            "type": "hold",
            "account": "personal"
          }
        }
      ]
    },
    {
      "id": "n31_1",
      "dateIndex": 31,
      "slot": 1,
      "priority": 0,
      "chapter": "homeward",
      "title": "提醒没有替你作决定",
      "text": "你最近常把钥匙放错地方，几场连续的电话也让自己难以安静下来。诺拉没有把这些变化解释成某种确定疾病，只认真说，如果状态让你担心，就应该找合适的人评估，而不是一遍遍用忙作答。\n\n与你有工作往来的人愿意讨论负荷，朋友也提出帮助。这些支持并不会自动变成休息。你仍然要决定，是现在腾出位置，还是继续让已经拥挤的日历再挤一点。",
      "characters": [
        "nora",
        "mara"
      ],
      "chain": "health",
      "choices": [
        {
          "id": "a",
          "label": "先完成这一轮，再考虑调整",
          "detail": "拒绝眼前的减负安排，继续高负荷。",
          "result": {
            "text": "你把谈话记在心里，却没有改变本周任何一项承诺。任务推进了，疲惫也仍在。诺拉没有因此离开，只说下次需要帮助时，别假装必须独自处理。"
          },
          "effects": {
            "stress": 13,
            "health": -11,
            "reputation": 3,
            "flags": [
              "highload_2014"
            ]
          }
        },
        {
          "id": "b",
          "label": "现在就把一项工作交出去",
          "detail": "接受机会和速度随之变化。",
          "result": {
            "text": "交接当天并不轻松，你需要解释很多细节。几周以后，那项工作不再出现在夜里的电话里，日历也终于出现能实际使用的空白。"
          },
          "effects": {
            "health": 9,
            "stress": -12,
            "freedom": 5,
            "flags": [
              "load_reduced"
            ]
          }
        },
        {
          "id": "c",
          "label": "安排专业评估，重新谈工作量",
          "detail": "不把一次休假当成所有问题的答案。",
          "result": {
            "text": "你认真描述了近期状态，也重新确认自己能够承担的工作与承诺。没有人给出关于余生的保证，改变至少已经进入下一周的安排。"
          },
          "effects": {
            "personalCash": -300,
            "health": 8,
            "stress": -9,
            "flags": [
              "care_sought"
            ],
            "relations": {
              "nora": 4
            }
          }
        }
      ]
    },
    {
      "id": "n32_0",
      "dateIndex": 32,
      "slot": 0,
      "priority": 0,
      "chapter": "homeward",
      "title": "合伙人的门没有自己打开",
      "text": "玛拉邀请你参加一次更重要的讨论。团队需要有人承担预算、人事与长期客户关系，她问你愿不愿意把职业继续往前推。机会是真的，代价也不仅是多几封邮件：别人会因为你的安排调整自己的生活。\n\n你想起刚入职时那张没有名字的桌子。走到这里并不要求你否认当年的愿望，只是现在知道，愿望实现以后也会继续产生需要处理的事。",
      "characters": [
        "mara",
        "june"
      ],
      "chain": "ambition",
      "choices": [
        {
          "id": "a",
          "label": "接受更大的责任",
          "detail": "进入合伙职责，承担明确的工作量。",
          "result": {
            "text": "你们把权限和复核写进新安排。头衔没有替客户的钱换主人，只把你需要回答的问题变多了。离开会议室时，你给家人发了一个提前说明日程的消息。"
          },
          "effects": {
            "career": "partner",
            "authority": 10,
            "reputation": 7,
            "stress": 7,
            "health": -3,
            "flags": [
              "partner_accepted",
              "career_peak"
            ],
            "relations": {
              "mara": 5
            }
          }
        },
        {
          "id": "b",
          "label": "接一部分，不接全部",
          "detail": "保留专业职责，拒绝无限扩张。",
          "result": {
            "text": "玛拉需要重新安排另一位负责人。你得到的机会比最初小，也少了几项无法兑现的承诺。你开始习惯把选择的代价一并说清楚。"
          },
          "effects": {
            "trust": 5,
            "communication": 4,
            "health": 4,
            "freedom": 5,
            "flags": [
              "work_boundary"
            ]
          }
        },
        {
          "id": "c",
          "label": "把重心移向工作以外",
          "detail": "不把停在这里解释成失败。",
          "result": {
            "text": "你没有用一句“钱不重要”替现实收尾。工作仍然需要做好，账单仍然要付；只是下一段时间，你想把同样认真的安排给生活。"
          },
          "effects": {
            "freedom": 7,
            "stress": -6,
            "health": 5,
            "flags": [
              "life_priority",
              "steady_work"
            ]
          }
        }
      ]
    },
    {
      "id": "n32_1",
      "dateIndex": 32,
      "slot": 1,
      "priority": 0,
      "chapter": "homeward",
      "title": "谁来拿教室的钥匙",
      "text": "达里厄斯准备把夜校的课程交给更多讲师。他请你看看一份交接表，里面没有明星讲师的照片，只有预算、教材、联络人和钥匙放在哪里。你忽然明白，他想建立的是自己请假时仍然会开门的教室。\n\n你可以参与，也可以只做一项具体的工作。最难放下的，也许不是时间，而是那种“非我不可”带来的满足。",
      "characters": [
        "darius"
      ],
      "chain": "school",
      "choices": [
        {
          "id": "a",
          "label": "把方法交给别人继续用",
          "detail": "愿意让教材和课堂出现其他人的名字。",
          "result": {
            "text": "新讲师提出一个你从未想到的问题。你们一起改了讲义，最终版本不再像任何一个人的独白。教室多了一位能找到钥匙的人。"
          },
          "effects": {
            "communication": 5,
            "freedom": 3,
            "flags": [
              "class_shared"
            ],
            "relations": {
              "darius": 6
            }
          }
        },
        {
          "id": "b",
          "label": "认领一项固定而有限的任务",
          "detail": "稳定支持，不包揽所有空缺。",
          "result": {
            "text": "你选择了每年更新资料这一项，并说明自己不能保证更多。达里厄斯把任务写进表里，没有再用“方便的时候”代替截止日。"
          },
          "effects": {
            "discipline": 4,
            "health": 2,
            "flags": [
              "class_return"
            ],
            "relations": {
              "darius": 4
            }
          }
        },
        {
          "id": "c",
          "label": "这次只提供一次建议",
          "detail": "把固定位置留给有余力的人。",
          "result": {
            "text": "你把能想到的风险认真讲完，并说明这次只提供建议，不加入常驻名单。课堂会继续，固定位置留给有余力承担的人；有限的帮助也可以有清楚的边界。"
          },
          "effects": {
            "health": 4,
            "stress": -4,
            "freedom": 4
          }
        }
      ]
    },
    {
      "id": "n33_0",
      "dateIndex": 33,
      "slot": 0,
      "priority": 0,
      "chapter": "homeward",
      "title": "小零件也必须经得起检查",
      "text": "航空替换零件企业的资料让你再次想到那些看不见的日常工作。客户需要可靠供货，质量与认证又不能靠热情省略。一个零件可能很小，出问题时牵连的安排却不小。\n\n你喜欢这门生意里反复发生的需求，也知道竞争、价格和收购整合都需要继续看。所谓耐心，不是给企业一次永远有效的信任，而是愿意多年以后仍认真检查同样的问题。",
      "characters": [
        "lin"
      ],
      "chain": "wealth",
      "choices": [
        {
          "id": "a",
          "label": "有限持有航空零件业务",
          "detail": "尝试将湖岸航材配到个人资产的10%。",
          "result": {
            "text": "你记录客户为何选择它，也记录可能离开的原因。交易以实际账户为准；拥有一部分生意，不会让你自动拥有关于未来的答案。"
          },
          "effects": {
            "research": 5,
            "discipline": 3,
            "flags": [
              "kept_ownership",
              "patient_reset"
            ],
            "researchCompany": [
              {
                "companyId": "HEI",
                "topic": "customers"
              },
              {
                "companyId": "HEI",
                "topic": "valuation"
              }
            ]
          },
          "strategy": {
            "type": "invest",
            "account": "personal",
            "companyId": "HEI",
            "targetPercent": 10
          }
        },
        {
          "id": "b",
          "label": "继续核对，不急着下单",
          "detail": "读质量、竞争和收购相关资料。",
          "result": {
            "text": "你没有把“需求稳定”当作免查证的通行证。调查只是让你更清楚地知道自己看过什么，并没有替你保证最重要的风险都已被找出。"
          },
          "effects": {
            "research": 6,
            "flags": [
              "patient_reset"
            ],
            "researchCompany": [
              {
                "companyId": "HEI",
                "topic": "challenge"
              }
            ]
          },
          "strategy": {
            "type": "hold",
            "account": "personal"
          }
        },
        {
          "id": "c",
          "label": "先核对风险，暂不买入",
          "detail": "保留现金，写清哪项证据还需要确认。",
          "result": {
            "text": "你重新看客户认证和业务组合，也承认收购整合可能带来难题。飞机上的零件很具体，未来的回报却没有保证；你先留住现金与继续研究的时间。"
          },
          "effects": {
            "discipline": 4,
            "freedom": 3
          },
          "strategy": {
            "type": "hold",
            "account": "personal"
          }
        }
      ]
    },
    {
      "id": "n34_0",
      "dateIndex": 34,
      "slot": 0,
      "priority": 0,
      "chapter": "homeward",
      "title": "重建以后，还有普通的星期一",
      "text": "你已经走过几个重新安排工作的年份。新的职责渐渐有了日常，最初急于证明自己的劲也不再时时出现。山姆给你介绍一位年轻同事，希望你能讲讲如何从一份做错的材料继续工作。\n\n你不必把自己的经历讲成励志故事。可以说当时得到过哪些帮助，也可以承认运气与环境；人真正需要的，往往是一种能够在下个星期一继续使用的办法。",
      "characters": [
        "sam"
      ],
      "chain": "repair",
      "choices": [
        {
          "id": "a",
          "label": "把经历讲成可以复用的方法",
          "detail": "分享帮助、错误与重新开始的步骤。",
          "result": {
            "text": "年轻同事问了一个很实际的问题：明天第一封邮件应该发给谁。你笑了，和他一起把事情排成顺序。旧经历终于不只属于你一个人。你和山姆把来年共同项目的分工写下来，各自保留退出和调整的权利。"
          },
          "effects": {
            "communication": 5,
            "trust": 4,
            "flags": [
              "rebuilt_stable",
              "sam_partner"
            ],
            "relations": {
              "sam": 6
            }
          }
        },
        {
          "id": "b",
          "label": "认真做好现在这份普通工作",
          "detail": "不再要求每一天都证明自己翻身。",
          "result": {
            "text": "你准时完成了职责，也准时离开。那一天没有值得写进履历的新词，但你在回家路上想到，稳定有时就是这样的重复。"
          },
          "effects": {
            "health": 5,
            "stress": -5,
            "freedom": 4,
            "flags": [
              "steady_work",
              "rebuilt_stable"
            ]
          }
        },
        {
          "id": "c",
          "label": "再争取一次更高的位置",
          "detail": "愿意重新承担可见度与压力。",
          "result": {
            "text": "你把申请递了出去，说明自己能带来什么，也问清需要放下什么。机会没有承诺一定成功，至少这次你不是只为了抹掉过去才往前走。"
          },
          "effects": {
            "reputation": 6,
            "stress": 6,
            "trust": 3,
            "flags": [
              "promotion_requested"
            ]
          }
        }
      ]
    },
    {
      "id": "n35_0",
      "dateIndex": 35,
      "slot": 0,
      "priority": 0,
      "chapter": "homeward",
      "title": "客户的孩子已经长大",
      "text": "朱恩整理旧档案时说，曾经写在信封上的某个学费计划，如今已是一个年轻人的真实生活。她没有向你透露不该透露的细节，只请你以曾经参与过这段服务的人的身份，看看匿名后的流程是否还适合现在的需要。\n\n客户会变，家庭的需要会变；一份多年以前正确的安排，也需要重新确认。你可以把这次回访当作又一份工作，也可以借它提醒自己，时间不是只有市场图上的横轴。",
      "characters": [
        "june"
      ],
      "chain": "clients",
      "choices": [
        {
          "id": "a",
          "label": "把新的生活需要重新问一遍",
          "detail": "不沿用旧资料替对方决定。",
          "result": {
            "text": "你们更新了用途与期限。客户没有因此变得更容易服务，你却少了一种危险的熟悉感：认识多年，就以为已经知道对方现在需要什么。"
          },
          "effects": {
            "communication": 6,
            "trust": 5,
            "flags": [
              "client_legacy"
            ],
            "relations": {
              "june": 6
            }
          }
        },
        {
          "id": "b",
          "label": "把这套回访交给年轻同事",
          "detail": "复核方法，让关心可以持续。",
          "result": {
            "text": "你和朱恩检查第一轮记录，再把后续交出去。客户仍有明确联络人，这项工作也不再必须等你有空才会发生。"
          },
          "effects": {
            "discipline": 5,
            "freedom": 3,
            "flags": [
              "client_window"
            ],
            "relations": {
              "sam": 4
            }
          }
        },
        {
          "id": "c",
          "label": "今天只处理必须完成的部分",
          "detail": "承认精力有限，不额外许诺。",
          "result": {
            "text": "你说明了自己的时间，朱恩重新分配了余下工作。一次有限的承诺未必动听，但比悄悄让截止日过去更容易被别人安排。"
          },
          "effects": {
            "health": 3,
            "stress": -3,
            "communication": 2
          }
        }
      ]
    },
    {
      "id": "n35_1",
      "dateIndex": 35,
      "slot": 1,
      "priority": 0,
      "chapter": "homeward",
      "title": "身体不是另一张待办表",
      "text": "你把休息也写成了待办，却总排在最后。家人已经不止一次提起你的状态，工作中的提醒也从“别太累”变成“哪些事可以交出去”。没有人能由此给出关于疾病的确定结论，长期安排是否值得改变，却已经是一个现实问题。\n\n你可以现在采取行动，也可以继续承担。重要的是别把“我愿意”误当成“不会有代价”，更别让别人以为你从来没有需要。",
      "characters": [
        "nora",
        "mara"
      ],
      "chain": "health",
      "choices": [
        {
          "id": "a",
          "label": "继续把这一阶段扛下来",
          "detail": "拒绝本次交接，承担连续负荷。",
          "result": {
            "text": "你向等候交付的人保证进度，接受了新的截止日。诺拉听完只说，她希望下次联系时听到的不只是工作。你没有答应调整，这一点被时间真实地记下了。"
          },
          "effects": {
            "stress": 13,
            "health": -11,
            "trust": 3,
            "flags": [
              "highload_2016"
            ]
          }
        },
        {
          "id": "b",
          "label": "主动申请一段减负安排",
          "detail": "让工作量发生可以检查的变化。",
          "result": {
            "text": "你列出必须由自己完成的部分，其余逐项交接。减负没有使所有烦恼消失，但电话数量和回家时间确实开始不同。"
          },
          "effects": {
            "health": 10,
            "stress": -12,
            "freedom": 6,
            "flags": [
              "load_reduced"
            ]
          }
        },
        {
          "id": "c",
          "label": "向专业人员说明近期状态",
          "detail": "同步安排工作，不只等一句安慰。",
          "result": {
            "text": "你认真准备了要说的情况，也留出后续处理的时间。家人能陪伴你，却不会替你作医学判断；工作上的调整仍需要你继续参与。"
          },
          "effects": {
            "personalCash": -350,
            "health": 8,
            "stress": -9,
            "flags": [
              "care_sought"
            ],
            "relations": {
              "nora": 4
            }
          }
        }
      ]
    },
    {
      "id": "n36_0",
      "dateIndex": 36,
      "slot": 0,
      "priority": 0,
      "chapter": "homeward",
      "title": "伊莱换了一张名片",
      "text": "伊莱告诉你，他准备到公益机构做运营。新工作少了一些收入，也有新的预算、合同与责任。他说自己并不是突然不再关心规则，而是想看看这些能力在另一种地方能做些什么。\n\n你发现自己一度想问这样是否“划算”。他笑了，说账当然要算，但不能假设每一项重要的东西都在同一个账户里。你们还会联系，只是不再每天经过同一扇门。",
      "characters": [
        "elias"
      ],
      "chain": "ethics",
      "choices": [
        {
          "id": "a",
          "label": "帮他把工作交接完整",
          "detail": "尊重新选择，也留下未来联系。",
          "result": {
            "text": "你们整理了记录的归属和仍需跟进的事。告别时没有把办公室说成牢笼，也没有把离开说成胜利；他只是开始另一份真实的工作。"
          },
          "effects": {
            "discipline": 4,
            "communication": 4,
            "relations": {
              "elias": 7
            },
            "flags": [
              "boundary_followed"
            ]
          }
        },
        {
          "id": "b",
          "label": "聊聊自己是否也想换方向",
          "detail": "把念头当作需要研究的现实。",
          "result": {
            "text": "伊莱讲了收入和工作内容，也讲了还不知道的部分。你没有当天作决定，却第一次把另一种生活从想象变成可以提问的事情。"
          },
          "effects": {
            "freedom": 5,
            "research": 3,
            "flags": [
              "outside_considered"
            ],
            "relations": {
              "elias": 4
            }
          }
        },
        {
          "id": "c",
          "label": "祝福他，继续自己的路",
          "detail": "不必用同一种选择证明友谊。",
          "result": {
            "text": "你们约好以后偶尔吃饭。彼此走向不同方向，没有让过去共同做过的事失去意义；关系需要的是新的安排，而不是永远相同的工牌。"
          },
          "effects": {
            "health": 3,
            "stress": -3,
            "relations": {
              "elias": 3
            }
          }
        }
      ]
    },
    {
      "id": "n37_0",
      "dateIndex": 37,
      "slot": 0,
      "priority": 0,
      "chapter": "homeward",
      "title": "门店里的生活想象",
      "text": "周末你陪诺拉去买工作室需要的小东西，走过几家家居商店。暖黄的灯、摆得恰好的餐桌和打折的装饰品，让人很容易想象另一种日常。诺拉看了一圈，只拿起清单上写过的东西。\n\n你们说到店铺怎样承担租金、备货和送货，顾客又为什么愿意回来。这时你手中没有可用于这场游戏交易的完整零售档案。逛过一家店可以引出问题，却不能替代研究，也不必马上变成一张买单。",
      "characters": [
        "lin"
      ],
      "chain": "risk",
      "choices": [
        {
          "id": "a",
          "label": "记下想弄清的生意问题",
          "detail": "只形成研究问题，今天没有交易。",
          "result": {
            "text": "你写下顾客、租约和库存三个问题，没有把逛店印象当成某家公司已核实的数字。这份观察留给以后的资料，今天的预算仍然属于生活。"
          },
          "effects": {
            "research": 5,
            "discipline": 3
          },
          "strategy": {
            "type": "hold",
            "account": "personal"
          }
        },
        {
          "id": "b",
          "label": "把注意力留给姐姐的工作室",
          "detail": "听听她为什么只需要清单上的几件东西。",
          "result": {
            "text": "诺拉解释桌子怎样摆才方便展开图纸，也说起不想为一时好看增加每月支出。你发现她并非没有愿望，只是在认真给已经选择的生活腾地方。"
          },
          "effects": {
            "communication": 4,
            "relations": {
              "nora": 5
            },
            "flags": [
              "retail_observed"
            ]
          },
          "strategy": {
            "type": "hold",
            "account": "personal"
          }
        },
        {
          "id": "c",
          "label": "不买东西，一起走回去",
          "detail": "让这个下午不必产生一笔交易。",
          "result": {
            "text": "你们空着一部分袋子离开商店，在路上谈起下周的安排。橱窗里的日常很好看，却不需要全部带回家，才算没有错过这个下午。"
          },
          "effects": {
            "health": 4,
            "stress": -4,
            "freedom": 3
          },
          "strategy": {
            "type": "hold",
            "account": "personal"
          }
        }
      ]
    },
    {
      "id": "n37_1",
      "dateIndex": 37,
      "slot": 1,
      "priority": 0,
      "chapter": "homeward",
      "title": "两本日历放在一起",
      "text": "梅在谈一个新的展览项目，你也有自己的工作安排。见面时，她把日历放在桌上，没有先替谁让出位置。你们经历过联系密集的时候，也可能经历过疏远；这一顿饭并没有要求关系必须走向某个标准答案。\n\n她问，你们愿意怎样在各自的生活里给对方留下位置。可以亲近，可以保留距离，但最好不是让一个人永远猜另一个人什么时候有空。",
      "characters": [
        "mei"
      ],
      "chain": "friend",
      "choices": [
        {
          "id": "a",
          "label": "一起留出可以兑现的时间",
          "detail": "把双方的工作都当作真实需要。",
          "result": {
            "text": "你们各自让出一点，也各自保留一点。约定看起来并不浪漫，却能放进下一周的生活。梅说，这比一句随时找我更让她知道怎样开口。"
          },
          "effects": {
            "relations": {
              "mei": 8
            },
            "health": 3,
            "freedom": 4,
            "flags": [
              "shared_calendar"
            ]
          }
        },
        {
          "id": "b",
          "label": "把关系放在舒服的距离",
          "detail": "不勉强承诺更紧密的陪伴。",
          "result": {
            "text": "你们把能做与不能做的事说明白，谈话反而轻松了一些。距离并不自动等于破裂，它只要求双方都不再假装看不见。"
          },
          "effects": {
            "relations": {
              "mei": 2
            },
            "freedom": 6,
            "flags": [
              "friend_distance"
            ]
          }
        },
        {
          "id": "c",
          "label": "先完成眼前的一次约定",
          "detail": "留一个具体日期，不许诺整年。",
          "result": {
            "text": "你们约了下月的一场活动，谁负责什么写得清楚。长期关系未必靠一句长远保证维持，也可能靠下一次真的出现。"
          },
          "effects": {
            "communication": 4,
            "relations": {
              "mei": 5
            },
            "flags": [
              "promise_date"
            ]
          }
        }
      ]
    },
    {
      "id": "n38_0",
      "dateIndex": 38,
      "slot": 0,
      "priority": 0,
      "chapter": "homeward",
      "title": "账户之外的用途",
      "text": "你的个人账户已经留下很多年的记录。里面有工资储蓄，有真实交易结果，也有现金停留的时间；它们不能混成一句“我靠投资赚了多少”。你把账本展开，试着给每笔钱写一个现在的用途。\n\n有些愿望仍在，有些已经不再属于今天的自己。你可以继续持有看得懂的生意，也可以安排用钱；等待只有与生活放在一起，才不只是无限延后的一个动作。",
      "characters": [
        "nora"
      ],
      "chain": "wealth",
      "choices": [
        {
          "id": "a",
          "label": "保留长期持有，也留出使用的钱",
          "detail": "按真实账户规划，不为漂亮曲线牺牲用途。",
          "result": {
            "text": "你没有因为生活要用钱就把投资判作失败。长期持有与适时使用，被你写进同一份计划；钱终于不再只负责让下一个数字更大。"
          },
          "effects": {
            "discipline": 5,
            "freedom": 4,
            "flags": [
              "compound_patience",
              "wealth_frame"
            ]
          },
          "strategy": {
            "type": "hold",
            "account": "personal"
          }
        },
        {
          "id": "b",
          "label": "先用现金继续减少债务",
          "detail": "偿还当前可用现金的20%。",
          "result": {
            "text": "如果仍有欠款，个人现金将按实际余额偿还，减少相应债务；如果已经没有欠款，现金就留在账户里。这次决定不被记成投资收益，也不会让同一笔债被重复偿还。"
          },
          "effects": {
            "discipline": 5,
            "stress": -3,
            "flags": [
              "debt_plan"
            ]
          },
          "strategy": {
            "type": "repay",
            "account": "personal",
            "targetPercent": 20
          }
        },
        {
          "id": "c",
          "label": "重新核查自己的集中风险",
          "detail": "今天只整理，不为了忙而交易。",
          "result": {
            "text": "你把同一类风险的持仓放到一起，发现名字不同未必就彼此独立。这份发现没有逼你立即行动，却让下一次下单前多了一个真正的问题。"
          },
          "effects": {
            "research": 5,
            "discipline": 5,
            "flags": [
              "patient_reset"
            ]
          },
          "strategy": {
            "type": "hold",
            "account": "personal"
          }
        }
      ]
    },
    {
      "id": "n39_0",
      "dateIndex": 39,
      "slot": 0,
      "priority": 0,
      "chapter": "homeward",
      "title": "周围的人都有自己的时间表",
      "text": "诺拉谈起工作室的下一步，梅有新的项目，山姆也在带自己的团队。你突然发现，这些人并不是站在原地等待你完成职业。他们各自失去过机会，也各自得到过一些没有及时告诉你的好消息。\n\n你可以继续关心，也可以接受关系已经改变。真正的问题不是能否把每个人都留在身边，而是还愿不愿意花时间认识他们现在是谁。",
      "characters": [
        "nora",
        "mei",
        "sam"
      ],
      "chain": "family",
      "choices": [
        {
          "id": "a",
          "label": "认真问一问他们最近的生活",
          "detail": "把一次联系留给倾听。",
          "result": {
            "text": "你听见了一些以前不知道的细节，没有急着给建议。那晚没有重大决定，却让几个人知道，你还愿意为他们已经发生的生活留一点时间。"
          },
          "effects": {
            "communication": 5,
            "health": 3,
            "relations": {
              "nora": 4,
              "mei": 4,
              "sam": 4
            },
            "flags": [
              "home_anchor"
            ]
          }
        },
        {
          "id": "b",
          "label": "约一次可以真正出席的相聚",
          "detail": "不求热闹，只求日历上有位置。",
          "result": {
            "text": "安排几经调整，最后只剩很普通的一顿饭。你们没有把缺席的人说成不在意，也没有让这次出现承担弥补所有过去的任务。"
          },
          "effects": {
            "health": 5,
            "stress": -5,
            "relations": {
              "nora": 5,
              "mei": 3
            },
            "flags": [
              "family_trust"
            ]
          }
        },
        {
          "id": "c",
          "label": "承认自己目前仍以工作为重",
          "detail": "不要求别人为此一直等待。",
          "result": {
            "text": "你发出真诚的问候，也说明自己的时间。收到的回复仍然友善，但有些计划已经不再把你算作一定会来的那个人。"
          },
          "effects": {
            "reputation": 3,
            "stress": 4,
            "relations": {
              "nora": -3,
              "mei": -3
            },
            "flags": [
              "career_first"
            ]
          }
        }
      ]
    },
    {
      "id": "n39_1",
      "dateIndex": 39,
      "slot": 1,
      "priority": 0,
      "chapter": "homeward",
      "title": "已经被提起过很多次",
      "text": "工作成果越来越容易被别人看见，消耗却仍藏在回家后的时间里。你不止一次得到过调班和求助的建议，也不止一次决定先把眼前的事做完。这一次，与你协作的人直接把可交接的清单带到你面前，让你选择。\n\n没有人能够从这些选择推断某种确定的疾病或寿命。长期承受的负荷是真实的，你有权继续承担，也有权现在承认需要改变，不能再说根本没有别的办法。",
      "characters": [
        "mara",
        "nora"
      ],
      "chain": "health",
      "choices": [
        {
          "id": "a",
          "label": "这轮仍然由自己全部承担",
          "detail": "明确拒绝本次交接。",
          "result": {
            "text": "你把清单推回去，承诺按时完成。对方没有把这种做法当成往后的默认安排，诺拉也仍愿意接你的电话。负荷继续留下，没有被赞许抵消。"
          },
          "effects": {
            "stress": 14,
            "health": -12,
            "reputation": 4,
            "flags": [
              "highload_2018"
            ]
          }
        },
        {
          "id": "b",
          "label": "接受交接，降低持续负荷",
          "detail": "让过去的提醒终于改变安排。",
          "result": {
            "text": "你们确定了接手人和联络界限。事情不会因为一张表就永远顺利，但接下来的几个星期，至少有一些晚上不再被同一串电话占满。"
          },
          "effects": {
            "health": 11,
            "stress": -14,
            "freedom": 6,
            "flags": [
              "load_reduced",
              "weekly_boundary"
            ]
          }
        },
        {
          "id": "c",
          "label": "暂停额外承诺并寻求帮助",
          "detail": "给评估与后续安排留下真实时间。",
          "result": {
            "text": "你没有要求家人替自己保证一切会好起来，只说明现在需要什么。几个人帮你把安排落实，而你终于不用先证明自己还能撑住，才有资格开口。"
          },
          "effects": {
            "personalCash": -400,
            "health": 9,
            "stress": -11,
            "relations": {
              "nora": 5
            },
            "flags": [
              "care_sought"
            ]
          }
        }
      ]
    },
    {
      "id": "n40_0",
      "dateIndex": 40,
      "slot": 0,
      "priority": 0,
      "chapter": "homeward",
      "title": "林把椅子修好了",
      "text": "林发来一张旧椅子的照片，说终于把摇晃的地方修好。他退休后的生活没有围着你的职业展开，有自己的朋友、手艺和几次未完成的旅行。你们坐下聊时，他仍会问工作，却不再先问最近的成绩。\n\n你曾希望多年以后能获得一个清楚的评价。眼前这个人反而更愿意听，你最近有什么东西值得花时间慢慢做完。你需要自己决定怎样回答。",
      "characters": [
        "lin"
      ],
      "chain": "archive",
      "choices": [
        {
          "id": "a",
          "label": "和他谈一次没有数字的生活",
          "detail": "认真了解他的现在，也说自己的需要。",
          "result": {
            "text": "你们聊到那把椅子缺的一颗木钉。林说后来换了做法，并不算把从前全部否定。你没有把这句话急着变成投资格言，只帮他扶稳了椅背。"
          },
          "effects": {
            "health": 5,
            "stress": -5,
            "relations": {
              "lin": 6
            },
            "flags": [
              "mentor_legacy"
            ]
          }
        },
        {
          "id": "b",
          "label": "请他再看一份研究方法",
          "detail": "保留交流，也尊重他可以拒绝。",
          "result": {
            "text": "林答应看一小部分，明确说不替你作最后决定。你把资料缩到真正需要讨论的范围，终于不再用整箱工作表达对一个人的信任。"
          },
          "effects": {
            "research": 5,
            "discipline": 3,
            "relations": {
              "lin": 4
            },
            "flags": [
              "archive_shared"
            ]
          }
        },
        {
          "id": "c",
          "label": "送上祝福，把下一次约好",
          "detail": "不假装自己今天有完整的下午。",
          "result": {
            "text": "你们订下另一个具体日期。林说不用带报告，带双适合走路的鞋。一次有限但诚实的安排，也可以成为关系继续的方式。"
          },
          "effects": {
            "communication": 3,
            "health": 2,
            "relations": {
              "lin": 3
            }
          }
        }
      ]
    },
    {
      "id": "n41_0",
      "dateIndex": 41,
      "slot": 0,
      "priority": 0,
      "chapter": "homeward",
      "title": "被看见以后，想留下什么",
      "text": "一场行业活动邀请你谈职业经历。你看着介绍里那些足够整齐的年份，想起真正走过的日子并不整齐：合作、改期、停顿、几次不愿承认的错误，以及别人替你分担的事情。\n\n你可以继续扩大自己的位置，也可以把机会交给更适合的人。没有哪种决定能够替二十年盖一个总分，最多只能说明，你想让接下来的时间更像什么。",
      "characters": [
        "mara",
        "sam"
      ],
      "chain": "ambition",
      "choices": [
        {
          "id": "a",
          "label": "接受邀请，也讲清帮助来自哪里",
          "detail": "把成就与承担过的责任一起说明。",
          "result": {
            "text": "你没有把经历写成一条独自向上的直线。台下有人记住了你的头衔，也有人记住你说出的同事名字；这两件事并不需要互相取消。"
          },
          "effects": {
            "reputation": 6,
            "communication": 5,
            "flags": [
              "career_peak"
            ],
            "relations": {
              "sam": 3
            }
          }
        },
        {
          "id": "b",
          "label": "推荐年轻同事参加",
          "detail": "让机会不总回到自己这里。",
          "result": {
            "text": "你介绍了对方真正做过的工作，没有用“新人需要锻炼”掩盖自己的偷懒。邀请被接住以后，你终于可以不把每一次不出场都当成失去。"
          },
          "effects": {
            "trust": 5,
            "freedom": 4,
            "flags": [
              "junior_legacy"
            ],
            "relations": {
              "sam": 5
            }
          }
        },
        {
          "id": "c",
          "label": "把这个周末留给生活",
          "detail": "谢绝露面，兑现已有安排。",
          "result": {
            "text": "你写了一封简短的回信，没有编造别的紧急任务。日历里原来的约定第一次不需要证明自己比职业机会更重要，才能被保留下来。"
          },
          "effects": {
            "health": 5,
            "stress": -5,
            "freedom": 5,
            "flags": [
              "life_priority"
            ]
          }
        }
      ]
    },
    {
      "id": "n42_0",
      "dateIndex": 42,
      "slot": 0,
      "priority": 0,
      "chapter": "homeward",
      "title": "越来越低的价格不是答案",
      "text": "你第一次拿到旧港家居在本游戏交易窗口内可核验的资料。门店的故事需要回到库存、租约、销售与现金，而报价只是其中一个数字。低价能吸引买家，也容易让人先想象反弹，再寻找支持想象的理由。\n\n朱恩问，如果这项判断继续出错，会影响你哪一笔真实的用款。这个问题没有要求你一定买或一定不买，只要求你别把“也许会变好”当成没有金额上限的承诺。",
      "characters": [
        "june"
      ],
      "chain": "risk",
      "choices": [
        {
          "id": "a",
          "label": "先研究，不急着下单",
          "detail": "不因价格低就扩大押注。",
          "result": {
            "text": "你把现金、库存和固定承诺分开看。核查可能形成判断，也可能留下更多疑问；今天没有新增持仓，等待不需要被写成对某个未来结果的保证。"
          },
          "effects": {
            "research": 5,
            "discipline": 5,
            "flags": [
              "retail_followed"
            ],
            "researchCompany": [
              {
                "companyId": "PIR",
                "topic": "cashflow"
              }
            ]
          },
          "strategy": {
            "type": "hold",
            "account": "personal"
          }
        },
        {
          "id": "b",
          "label": "用较大一份个人资金押经营修复",
          "detail": "尝试配到个人资产40%；可能承受重大损失。",
          "result": {
            "text": "你写明这是一项高度集中的风险选择，不能靠日后补写理由消除。实际成交仍受账户和权限约束，剧情不会替这笔资金保证出路。"
          },
          "effects": {
            "stress": 8,
            "discipline": -5,
            "flags": [
              "rescue_bet"
            ],
            "researchCompany": [
              {
                "companyId": "PIR",
                "topic": "cashflow"
              }
            ]
          },
          "strategy": {
            "type": "invest",
            "account": "personal",
            "companyId": "PIR",
            "targetPercent": 40
          }
        },
        {
          "id": "c",
          "label": "不接这份经营修复的风险",
          "detail": "承认目前不能接受这笔不确定性。",
          "result": {
            "text": "你没有下单，也不需要证明以后一定继续下跌，才有资格承认今天不愿承担这项风险。之后市场仍会发生，你把自己的资金留给别的用途。"
          },
          "effects": {
            "discipline": 5,
            "stress": -4,
            "flags": [
              "risk_legacy"
            ]
          },
          "strategy": {
            "type": "hold",
            "account": "personal"
          }
        }
      ]
    },
    {
      "id": "n43_0",
      "dateIndex": 43,
      "slot": 0,
      "priority": 0,
      "chapter": "homeward",
      "title": "再给一个月，不等于重新想过",
      "text": "一个月很短，足以让价格再次改变，却未必足以让一门生意发生你期待的变化。你看着旧记录里那句“再等等”，发现它没有写需要等到什么信息。\n\n林曾提醒你，耐心与不肯承认错误，看起来有时很像。区别不在于后来是否赚钱，而在于当下还能不能说清理由，以及是否愿意给风险留一个不会伤及全部生活的边界。",
      "characters": [
        "lin"
      ],
      "chain": "risk",
      "choices": [
        {
          "id": "a",
          "label": "把等待的条件写具体",
          "detail": "不新增资金，留下下一次核查要看的事。",
          "result": {
            "text": "你补上了现金、固定承诺和顾客需求的问题。这些字没有让结果更确定，却让下一次回看不再只能重复“已经等这么久”。"
          },
          "effects": {
            "discipline": 6,
            "research": 4,
            "flags": [
              "patient_reset"
            ]
          },
          "strategy": {
            "type": "hold",
            "account": "personal"
          }
        },
        {
          "id": "b",
          "label": "把这项风险降至个人资产10%",
          "detail": "部分卖出，不必等到完全没有希望。",
          "result": {
            "text": "只有实际持仓超过目标时，账户才会卖出超过的部分；没有持仓或已低于目标就不成交。你可能为以后价格的变化而遗憾，今天能够确认的是自己愿意承担的上限，而不是一笔尚未发生的盈利。"
          },
          "effects": {
            "stress": -5,
            "discipline": 5,
            "flags": [
              "risk_legacy"
            ]
          },
          "strategy": {
            "type": "reduce",
            "account": "personal",
            "companyId": "PIR",
            "targetPercent": 10
          }
        },
        {
          "id": "c",
          "label": "继续将它放在40%的目标位置",
          "detail": "接受集中与经营修复未成的风险。",
          "result": {
            "text": "你把新的承诺记在旧承诺旁边，没有让均价替你回答生意的问题。此后发生的市场与公司行动不会因你的坚持而改变。"
          },
          "effects": {
            "stress": 8,
            "discipline": -4,
            "flags": [
              "rescue_bet"
            ],
            "researchCompany": [
              {
                "companyId": "PIR",
                "topic": "valuation"
              }
            ]
          },
          "strategy": {
            "type": "invest",
            "account": "personal",
            "companyId": "PIR",
            "targetPercent": 40
          }
        }
      ]
    },
    {
      "id": "n44_0",
      "dateIndex": 44,
      "slot": 0,
      "priority": 0,
      "chapter": "homeward",
      "title": "今年留下的，不只有账户余额",
      "text": "你整理年末材料，发现一张很旧的便条：有些名字仍经常出现，有些已经很久没有见面。账户可以给出清楚的金额，关系却需要一件件记得曾经怎样回应。两者都真实，不能互相抵销。\n\n你可以安排下一年的职业，也可以安排已经拖了很久的一顿饭。没有一种安排能保证事情总按计划发生，明确写下它，至少让今天的选择不只剩下模糊的愿望。",
      "characters": [
        "nora",
        "mei"
      ],
      "chain": "wealth",
      "choices": [
        {
          "id": "a",
          "label": "把钱按现在的生活用途重新排好",
          "detail": "分别看投资结果、储蓄与未来支出。",
          "result": {
            "text": "你没有把整个账户增长都算作判断成功，也没有因为一次损失否认所有积累。钱的来处与去处清楚了一些，下一年才有更实在的安排。"
          },
          "effects": {
            "discipline": 5,
            "freedom": 4,
            "flags": [
              "wealth_frame"
            ]
          },
          "strategy": {
            "type": "hold",
            "account": "personal"
          }
        },
        {
          "id": "b",
          "label": "先兑现一件拖欠很久的小事",
          "detail": "给家人或朋友一个确定的时间。",
          "result": {
            "text": "你只约了自己确实能够做到的一件事。回复来得很普通，没有电影式的和解；日历上多出的一格，仍然值得被认真完成。"
          },
          "effects": {
            "health": 4,
            "stress": -4,
            "relations": {
              "nora": 4,
              "mei": 4
            },
            "flags": [
              "home_anchor",
              "life_priority"
            ]
          }
        },
        {
          "id": "c",
          "label": "继续争取职业上的下一步",
          "detail": "承认它仍是自己想要的东西。",
          "result": {
            "text": "你写下下一年的工作目标，也给相关的人说明可能的忙碌。愿望不因走过很多年就显得可笑，只是现在更需要与别人的安排放在一起谈。"
          },
          "effects": {
            "reputation": 5,
            "stress": 5,
            "flags": [
              "career_first"
            ]
          }
        }
      ]
    },
    {
      "id": "n45_0",
      "dateIndex": 45,
      "slot": 0,
      "priority": 0,
      "chapter": "homeward",
      "title": "翻开最后一本旧档案",
      "text": "新年刚开始，你把零售企业的材料重新放到桌上。资料里能找到的问题，需要按今天知道的内容回答；还没有发生的变化，不能被你提前写成结局。\n\n你已经跟踪过这门生意，也可能从未持有它。两种情况下都值得记住，市场没有义务照顾你的成本或记忆。真正需要照顾的，是个人资金的用途，以及愿意为这个判断继续承担多大份额。",
      "characters": [
        "june"
      ],
      "chain": "risk",
      "choices": [
        {
          "id": "a",
          "label": "退出仍可处理的个人持仓",
          "detail": "按实际交易限制执行，不假定一定有流动性。",
          "result": {
            "text": "交易结果会说明能否卖出以及得到多少现金。你做出的不是关于企业命运的预言，而是一次承认自己风险边界的安排。"
          },
          "effects": {
            "discipline": 5,
            "stress": -4,
            "flags": [
              "risk_legacy"
            ]
          },
          "strategy": {
            "type": "exit",
            "account": "personal",
            "companyId": "PIR",
            "targetPercent": 0
          }
        },
        {
          "id": "b",
          "label": "继续以40%目标承担修复风险",
          "detail": "只用个人账户，可能面临无法挽回的损失。",
          "result": {
            "text": "你再次确认这是个人资金，客户的钱不会替你承受这项选择。剧情没有把坚持写成回报承诺，实际账本会记录每一份获得与失去。"
          },
          "effects": {
            "stress": 9,
            "discipline": -4,
            "flags": [
              "rescue_bet"
            ],
            "researchCompany": [
              {
                "companyId": "PIR",
                "topic": "cashflow"
              }
            ]
          },
          "strategy": {
            "type": "invest",
            "account": "personal",
            "companyId": "PIR",
            "targetPercent": 40
          }
        },
        {
          "id": "c",
          "label": "今天不交易，先把判断写完整",
          "detail": "等待本身也有风险与机会成本。",
          "result": {
            "text": "你记录仍愿意等待的理由，也保留可能看错的部分。没有下单不代表脱离了已有持仓的涨跌，它只表示今天没有增加新的买卖。"
          },
          "effects": {
            "research": 4,
            "discipline": 3
          },
          "strategy": {
            "type": "hold",
            "account": "personal"
          }
        }
      ]
    },
    {
      "id": "n46_0",
      "dateIndex": 46,
      "slot": 0,
      "priority": 0,
      "chapter": "homeward",
      "title": "二月的一次核对",
      "text": "你决定核对一次眼下的风险，却发现本游戏的核验资料中，没有这一天旧港家居的可成交报价。缺少数据不能被填成一个看似合理的价格；今天无法通过按钮买卖它，原有风险也不会因此暂停。\n\n梅给你发来一张工作照片，你还没有回复。桌上是两个不同的问题：在不能交易的时候怎样对待自己的判断，怎样回应一个真实的人。它们可以都被认真对待，却不能指望做好其中一个就自动完成另一个。",
      "characters": [
        "mei"
      ],
      "chain": "risk",
      "choices": [
        {
          "id": "a",
          "label": "写清下一次复核需要什么",
          "detail": "今天不成交，记录未来决定所需的证据。",
          "result": {
            "text": "你列出需要确认的现金、负担和可执行行情，没有预先写下一张将来必定成交的订单。记录不能消除已有风险，但让下一次决定多一个可以回看的依据。"
          },
          "effects": {
            "discipline": 5,
            "stress": -3,
            "relations": {
              "mei": 2
            },
            "flags": [
              "risk_legacy"
            ]
          },
          "strategy": {
            "type": "hold",
            "account": "personal"
          }
        },
        {
          "id": "b",
          "label": "保持现有持仓，不再加钱",
          "detail": "承认仍在承担全部已有风险。",
          "result": {
            "text": "你把“不再加钱”写得清楚。这没有给旧持仓加上一层保护，只替下一次冲动留下一个需要解释的边界。"
          },
          "effects": {
            "discipline": 3,
            "research": 2
          },
          "strategy": {
            "type": "hold",
            "account": "personal"
          }
        },
        {
          "id": "c",
          "label": "先回应朋友，暂时离开屏幕",
          "detail": "不改变持仓，把这一小时还给生活。",
          "result": {
            "text": "你认真看完照片，问起她的工作，而不是把话题再次带回自己的账户。持仓没有因为这次聊天发生变化，风险仍在；这一小时的关心也真实发生了。"
          },
          "effects": {
            "health": 3,
            "stress": -4,
            "relations": {
              "mei": 4
            },
            "flags": [
              "life_priority"
            ]
          },
          "strategy": {
            "type": "hold",
            "account": "personal"
          }
        }
      ]
    },
    {
      "id": "n47_0",
      "dateIndex": 47,
      "slot": 0,
      "priority": 0,
      "chapter": "homeward",
      "title": "一门生意进入另一种程序",
      "text": "公开消息已经提到这家家居零售企业进入重整程序。消息不会因为你是否持有而改变，也不能被简单翻译成普通股东一定能拿回多少钱。经营、债权与股权，在这样的程序里各有不同的位置。\n\n你能做的是核对已经公开的内容，知道交易与估值可能受到限制，并把自己的生活资金安排清楚。还未有结论的部分，仍然只能留作未知。",
      "characters": [
        "elias",
        "june"
      ],
      "chain": "risk",
      "choices": [
        {
          "id": "a",
          "label": "按公开信息记录风险",
          "detail": "等待明确公司行动，不擅自填一个回收金额。",
          "result": {
            "text": "你把未确认的地方保持空白。账户里的持仓、现金与公司行动会分别留下记录，不会因为一个猜测就被提前抹去或提前补回。"
          },
          "effects": {
            "research": 5,
            "discipline": 6,
            "flags": [
              "loss_understood"
            ]
          },
          "strategy": {
            "type": "hold",
            "account": "personal"
          }
        },
        {
          "id": "b",
          "label": "检查生活资金是否受影响",
          "detail": "先区分必要支出与仍在承担的风险。",
          "result": {
            "text": "你没有把客户资金与个人损失混在一起。必要支出被重新排好，几项愿望往后移动；这是一份具体的生活调整，而不是替投资写的新理由。"
          },
          "effects": {
            "discipline": 5,
            "stress": -2,
            "flags": [
              "cash_buffer",
              "loss_understood"
            ]
          },
          "strategy": {
            "type": "hold",
            "account": "personal"
          }
        },
        {
          "id": "c",
          "label": "和可信任的人谈清楚实际情况",
          "detail": "不靠隐瞒维持自己一贯正确的样子。",
          "result": {
            "text": "你只讲已经发生的事和仍未知的部分。对方不能替你改变市场，却能知道你现在需要的是倾听、核对，还是一起安排接下来的日常。"
          },
          "effects": {
            "communication": 5,
            "stress": -3,
            "relations": {
              "nora": 4
            },
            "flags": [
              "loss_understood"
            ]
          }
        }
      ]
    },
    {
      "id": "n48_0",
      "dateIndex": 48,
      "slot": 0,
      "priority": 0,
      "chapter": "homeward",
      "title": "世界缩成一块屏幕",
      "text": "疫情改变了工作和相聚的方式。朱恩说客户在电话里问市场，也问家里的收入，她请你帮忙读一遍联络说明。你自己的工作与生活，也需要在不断变化的条件下重新安排。隔着屏幕，每个人看起来都像还有余力，实际生活却常常已经挤满。\n\n你不能保证明天恢复正常，也不能用一份行情表替别人解释所有担心。眼前可以做的仍然有限：核对、说明、安排休息，并承认有些问题需要比工作更多的帮助。",
      "characters": [
        "june",
        "nora"
      ],
      "chain": "risk",
      "choices": [
        {
          "id": "a",
          "label": "帮朱恩把联络步骤写清楚",
          "detail": "说明该由谁核对用途和权限，不代替客户作决定。",
          "result": {
            "text": "你把每一项答复写得比平时短，避免让焦虑藏进复杂句子。它没有让波动消失，却让对方知道，下一次该找谁、确认什么。"
          },
          "effects": {
            "communication": 6,
            "discipline": 5,
            "stress": 4,
            "flags": [
              "risk_legacy",
              "crisis_calls"
            ],
            "relations": {
              "june": 5
            }
          }
        },
        {
          "id": "b",
          "label": "先照顾基本生活和联系",
          "detail": "减少非必要承诺，留出适当支持。",
          "result": {
            "text": "你与家人重新安排联络，也向同事说明自己的容量。每一边都没有因此完美，但没有人需要继续猜，你是不是还在独自硬撑。"
          },
          "effects": {
            "health": 7,
            "stress": -8,
            "relations": {
              "nora": 5,
              "mei": 3
            },
            "flags": [
              "load_reduced"
            ]
          }
        },
        {
          "id": "c",
          "label": "不因恐慌新增交易",
          "detail": "承认仍需承担已有风险。",
          "result": {
            "text": "你核对记录后关闭了多余的报价窗口。没有买卖不等于没有变化，账户仍会随真实市场计算；你只是拒绝让每一条消息都立刻变成一个订单。"
          },
          "effects": {
            "discipline": 5,
            "stress": -4
          },
          "strategy": {
            "type": "hold",
            "account": "personal"
          }
        }
      ]
    },
    {
      "id": "n49_0",
      "dateIndex": 49,
      "slot": 0,
      "priority": 0,
      "chapter": "homeward",
      "title": "电话不用等到有大事才打",
      "text": "诺拉来电时说没什么要紧事，只问你吃了没有。你突然想起二十年前她冰箱上的便条：那些约定有的完成，有的改期，有的已经没有补做的机会。她仍有自己的工作与烦恼，不是专门负责提醒你生活的人。\n\n这通电话没有要求你总结人生。你只需要决定，今天是否真的留一段时间，也是否愿意问问她，而不只回答自己的近况。",
      "characters": [
        "nora"
      ],
      "chain": "family",
      "choices": [
        {
          "id": "a",
          "label": "把手边的事放一会儿",
          "detail": "认真问她最近怎样。",
          "result": {
            "text": "你们聊的是普通的饭菜和一个迟迟没做完的小项目。电话结束后没有发生巨大的改变，只是你又知道了姐姐生活里一件真实的小事。"
          },
          "effects": {
            "health": 4,
            "stress": -5,
            "relations": {
              "nora": 7
            },
            "flags": [
              "home_anchor"
            ]
          }
        },
        {
          "id": "b",
          "label": "约好晚一点完整地回拨",
          "detail": "说明时间，并留出能兑现的位置。",
          "result": {
            "text": "你按约回了电话，没有把它挤进另一场通话的空隙。诺拉说这样很好，她也可以把自己的事先安排完。关系不再只靠临时碰巧有空。"
          },
          "effects": {
            "discipline": 4,
            "relations": {
              "nora": 5
            },
            "flags": [
              "family_trust"
            ]
          }
        },
        {
          "id": "c",
          "label": "坦白今天实在没有余力",
          "detail": "不让她把沉默误认为不在意。",
          "result": {
            "text": "诺拉接受了你的说明，也说自己不会一直在线。你们各自保留需要，只是这一次被拒绝的时间，不再必须靠猜测来解释。"
          },
          "effects": {
            "communication": 3,
            "stress": -2,
            "relations": {
              "nora": -1
            }
          }
        }
      ]
    },
    {
      "id": "n49_1",
      "dateIndex": 49,
      "slot": 1,
      "priority": 0,
      "chapter": "homeward",
      "title": "最后一次把提醒推到以后",
      "text": "最近的安排使你再次面对一个老问题：工作可以继续加，承受它的人却不是无限的。家人与同事提出了具体帮助，不只是泛泛一句保重；能交接的职责、能安排的休息、可以寻求的专业评估，都需要留出时间。\n\n这是多年里又一次机会。无论过去如何，你可以现在降低负荷，也可以拒绝。故事不会把其中任何一个选择解释成对疾病或寿命的确定预测。",
      "characters": [
        "nora",
        "mara"
      ],
      "chain": "health",
      "choices": [
        {
          "id": "a",
          "label": "仍然拒绝调整，继续全部承担",
          "detail": "记录这次选择，也承担持续高负荷。",
          "result": {
            "text": "你保住了原来的日程，没有接受已经提出的交接。周围的人仍愿意提供帮助，但帮助不会因为存在就自动发生；你依然把它推到了以后。"
          },
          "effects": {
            "stress": 15,
            "health": -13,
            "flags": [
              "highload_2020"
            ],
            "relations": {
              "nora": -2
            }
          }
        },
        {
          "id": "b",
          "label": "接受帮助，马上减少承诺",
          "detail": "把调整落实到日历和接手人。",
          "result": {
            "text": "你没有等到所有工作结束才允许自己停下。有人接走任务，有人帮你安排生活；这不保证未来，却真实改变了从今天开始的负荷。"
          },
          "effects": {
            "health": 13,
            "stress": -16,
            "freedom": 6,
            "flags": [
              "load_reduced"
            ],
            "removeFlags": [
              "highload_2020"
            ]
          }
        },
        {
          "id": "c",
          "label": "暂停额外工作，寻求适当评估",
          "detail": "让家人知道自己需要什么支持。",
          "result": {
            "text": "你认真说明状态，不让一串游戏数值替自己作诊断。该由专业人员处理的交给专业人员，该重新安排的工作，也从现在开始重新安排。"
          },
          "effects": {
            "personalCash": -450,
            "health": 11,
            "stress": -13,
            "relations": {
              "nora": 5
            },
            "flags": [
              "care_sought"
            ],
            "removeFlags": [
              "highload_2020"
            ]
          }
        }
      ]
    },
    {
      "id": "n50_0",
      "dateIndex": 50,
      "slot": 0,
      "priority": 0,
      "chapter": "homeward",
      "title": "还需要等到正式确认",
      "text": "关于家居零售企业旧股权的去向，你仍需要等候已经公开、能够核验的正式材料。发生了什么，什么时候向市场说明，是两件需要分别记下的事。在可以确认以前，你不能把传闻或猜测填成账本里的结果。\n\n若你曾持有，取得与买卖的记录会一直保留；若没有持有，也不会凭空制造损失。你可以检查自己曾承担多少风险，给难受留一点空间，却不能用后来才知道的事情，替过去写一份当时并不存在的答案。",
      "characters": [
        "lin",
        "elias"
      ],
      "chain": "risk",
      "choices": [
        {
          "id": "a",
          "label": "完整保存这次记录",
          "detail": "让结果与当时理由并排留下。",
          "result": {
            "text": "你没有删掉难看的那几页。持仓和公司行动按账本处理，回看时仍能分清：当时知道什么、后来发生什么，以及你究竟作了哪些决定。"
          },
          "effects": {
            "discipline": 7,
            "research": 4,
            "flags": [
              "loss_understood",
              "risk_legacy"
            ]
          },
          "strategy": {
            "type": "hold",
            "account": "personal"
          }
        },
        {
          "id": "b",
          "label": "先处理情绪，再谈下一笔投资",
          "detail": "不急着靠一次下注把损失赢回来。",
          "result": {
            "text": "你给自己留出一段不新增承诺的时间。难受没有立刻消失，却不必马上变成新的订单。账户之外，生活仍有需要继续照顾的人和事。"
          },
          "effects": {
            "health": 5,
            "stress": -7,
            "flags": [
              "loss_understood"
            ]
          },
          "strategy": {
            "type": "hold",
            "account": "personal"
          }
        },
        {
          "id": "c",
          "label": "与可信任的人一起复盘",
          "detail": "允许别人指出自己没看见的部分。",
          "result": {
            "text": "对方没有替你把每一步都说成合理。你听完不舒服的意见，也保留自己的判断；讨论终于从证明谁正确，转回以后准备怎样做。"
          },
          "effects": {
            "communication": 5,
            "discipline": 4,
            "relations": {
              "elias": 4
            },
            "flags": [
              "loss_understood"
            ]
          },
          "strategy": {
            "type": "hold",
            "account": "personal"
          }
        }
      ]
    },
    {
      "id": "n51_0",
      "dateIndex": 51,
      "slot": 0,
      "priority": 0,
      "chapter": "homeward",
      "title": "灯不必总由自己来关",
      "text": "达里厄斯正在安排接下来的课程，问你愿意留下些什么。也许是改过许多次的讲义，也许只是一种讲清不知道的方式。他没有要求你永远在场，课程也需要能够由其他人继续。\n\n你想起这二十年里的交接：一把钥匙、一份记录、一张日历。它们没有把你变成不可替代的人，却可能让某件有用的事情，在你离开房间以后仍然能够进行。",
      "characters": [
        "darius",
        "sam"
      ],
      "chain": "school",
      "choices": [
        {
          "id": "a",
          "label": "把能用的方法正式交出去",
          "detail": "让别人可以修改，也可以署上自己的名字。",
          "result": {
            "text": "你们核对了愿意分享的材料，再把它们交给后续负责课程的人。那不是对个人成绩的封存，而是允许有用的办法继续长成与你不同的样子。"
          },
          "effects": {
            "communication": 5,
            "freedom": 4,
            "flags": [
              "school_end"
            ],
            "relations": {
              "darius": 6,
              "sam": 3
            }
          }
        },
        {
          "id": "b",
          "label": "认领一个有限而稳定的位置",
          "detail": "承诺今后能做到的一部分，不包揽所有缺口。",
          "result": {
            "text": "你写下能够承诺的频率和范围。达里厄斯照着安排排课，没有把感谢变成新的额外任务。持续有时比一次耗尽自己更需要耐心。"
          },
          "effects": {
            "discipline": 5,
            "health": 3,
            "flags": [
              "school_end",
              "work_boundary"
            ],
            "relations": {
              "darius": 4
            }
          }
        },
        {
          "id": "c",
          "label": "这次不接固定工作",
          "detail": "交出愿意分享的建议，把下一段时间留给自己。",
          "result": {
            "text": "你说明这次能够提供的建议，也明确自己不会接下固定工作。教室还有别的人，日历也会出现新的安排；保留距离并不要求否认曾经在意。"
          },
          "effects": {
            "health": 5,
            "stress": -5,
            "freedom": 6,
            "flags": [
              "life_priority"
            ]
          }
        }
      ]
    },
    {
      "id": "n52_0",
      "dateIndex": 52,
      "slot": 0,
      "priority": 0,
      "chapter": "homeward",
      "title": "四十四岁，明天还没有写好",
      "text": "这一年最后一天，你四十四岁。二十年前没有名字的工位、家里的便条、被改写的报告和那些不同方向的告别，都已成为真的发生过的事情。账户会给出各自的数字，人物也保留自己的生活；没有一个总分能替你把它们合并。\n\n你仍有想做的事，也有承认没能做到的事。故事走到这里，不需要你选一句漂亮的话证明一切值得，只需要决定，今晚准备把时间交给谁。",
      "characters": [
        "nora",
        "mei",
        "lin"
      ],
      "chain": "family",
      "choices": [
        {
          "id": "a",
          "label": "留给仍然在乎的人",
          "detail": "完成今晚的联系，不要求它弥补全部过去。",
          "result": {
            "text": "你拨出号码，或认真写下一封会发送的消息。没有一声铃响能够替二十年收尾，但此刻的关心不必因为来得晚，就被判定没有意义。"
          },
          "effects": {
            "health": 3,
            "stress": -4,
            "relations": {
              "nora": 3,
              "mei": 3
            },
            "flags": [
              "finish_home"
            ]
          }
        },
        {
          "id": "b",
          "label": "留给自己尚未完成的计划",
          "detail": "承认愿望，也承认需要重新安排。",
          "result": {
            "text": "你翻开一页新纸，只写了下一步，没有写必赢、永远或来得及。余下的愿望不自动等于遗憾，它们只是还没有发生的生活。"
          },
          "effects": {
            "freedom": 5,
            "discipline": 3,
            "flags": [
              "finish_future"
            ]
          }
        },
        {
          "id": "c",
          "label": "安静地把这一年的记录收好",
          "detail": "不急着给自己定一个评价。",
          "result": {
            "text": "你分别放好工作、个人账户和生活的记录。赚到的、失去的、被支持的、没有兑现的，都可以保留原来的名字，不必互相抵销。"
          },
          "effects": {
            "health": 4,
            "stress": -5,
            "flags": [
              "finish_account"
            ]
          }
        }
      ]
    },
    {
      "id": "v18",
      "dateIndex": 18,
      "slot": 0,
      "priority": 10,
      "requires": {
        "flagsAll": [
          "sam_credit"
        ]
      },
      "chapter": "fracture",
      "title": "名字下面的一周",
      "text": "山姆把一张排班表放在你的键盘旁。他父亲摔伤后刚回到家，白天无人照看；母亲坚持说自己能应付，电话里却已经听不清他说话。他想调开下周的两次晚班，向几个人开过口，都没有得到确定答复。\n\n他记得那份报告上，你没有抹去他的名字。这回他没有拿旧事要求回报，只问你能否给一个明确答案。你自己的日历也挤满了安排，替他答应整周，就得取消其中一件；而含糊说一句“再看”，会让他今晚仍然订不了回家的车票。",
      "characters": [
        "sam",
        "nora"
      ],
      "chain": "junior",
      "choices": [
        {
          "id": "a",
          "label": "接下两次晚班",
          "detail": "挪走自己的安排，答应明确日期。",
          "effects": {
            "health": -3,
            "stress": 4,
            "research": 0,
            "trust": 3,
            "reputation": 0,
            "communication": 0,
            "freedom": 0,
            "discipline": 0,
            "relations": {
              "sam": 9,
              "nora": -2
            },
            "flags": [
              "sam_helped"
            ],
            "removeFlags": []
          },
          "result": {
            "text": "山姆当着你的面买好了车票，把交接事项逐条写下。他没有说以后一定报答，只在出门时认真道了谢。你给被取消约定的人打去电话，听完了对方的失望；这次帮助确实占用了你自己的生活。"
          }
        },
        {
          "id": "b",
          "label": "陪他谈一份新排班",
          "detail": "一起找主管分担，也承认无法全接。",
          "effects": {
            "health": 0,
            "stress": 2,
            "research": 0,
            "trust": 0,
            "reputation": 0,
            "communication": 4,
            "freedom": 0,
            "discipline": 2,
            "relations": {
              "sam": 4,
              "mara": 1
            },
            "flags": [
              "sam_rota_brokered"
            ],
            "removeFlags": []
          },
          "result": {
            "text": "你们找到还没离开的主管，把两次晚班拆给不同的人。山姆需要多做一轮交接，你也为此留下了一个晚上。最后的安排没有谁独自扛住所有事，却让他的车票终于有了确定的日期。"
          }
        },
        {
          "id": "c",
          "label": "说清这次帮不上",
          "detail": "保住已答应别人的时间，承受失望。",
          "effects": {
            "health": 2,
            "stress": -2,
            "research": 0,
            "trust": 0,
            "reputation": 0,
            "communication": 0,
            "freedom": 3,
            "discipline": 0,
            "relations": {
              "sam": -4
            },
            "flags": [
              "sam_shift_declined"
            ],
            "removeFlags": []
          },
          "result": {
            "text": "你没有拿忙碌当作一句遮挡所有事情的话，而是把不能调开的安排说清楚。山姆点点头，收起了表格。你们仍会一起工作，但他离开前那一小段沉默提醒你，坦诚拒绝也不能免去对方的难处。"
          }
        }
      ]
    },
    {
      "id": "v20",
      "dateIndex": 20,
      "slot": 1,
      "priority": 10,
      "requires": {
        "flagsAll": [
          "risk_rehearsed"
        ]
      },
      "chapter": "fracture",
      "title": "演练之外的冬天",
      "text": "玛拉在一间关了灯的会议室等你，桌上有三份不同的文件。机构需要裁员，留下的人要接更多账户，还要面对不断来电的客户；另一份材料来自愿意接收转行者的社区项目，但薪水更低，需要重新学习。\n\n你想起以前做过的风险演练。那时你们讨论现金能撑多久，谁来接听电话，却没有排练过如何告诉家人自己明年可能没有工作。窗外的人照常赶末班车。玛拉没有替你选，只把裁员补偿、留任责任和转行课程各自需要签字的位置指给你看。",
      "characters": [
        "mara",
        "nora"
      ],
      "chain": "risk",
      "choices": [
        {
          "id": "a",
          "label": "接受裁员安排",
          "detail": "失去固定工作，换取一段可支配时间。",
          "effects": {
            "health": 0,
            "stress": 7,
            "research": 0,
            "trust": 0,
            "reputation": -3,
            "communication": 0,
            "freedom": 7,
            "discipline": 0,
            "relations": {
              "mara": 2
            },
            "flags": [
              "job_lost"
            ],
            "removeFlags": [],
            "career": "unemployed"
          },
          "result": {
            "text": "你签下离职文件，把尚未办完的事情列成了交接单。玛拉陪你走到门口，没有许诺很快就能回来。回家路上你重新算了生活开销，发现空出来的时间并不等于轻松，明年的每一次求职都得自己开始。"
          }
        },
        {
          "id": "b",
          "label": "留下接住更多工作",
          "detail": "保住职位，接受加重的责任与负担。",
          "effects": {
            "health": -7,
            "stress": 12,
            "research": 0,
            "trust": 0,
            "reputation": 4,
            "communication": 0,
            "freedom": -5,
            "discipline": 0,
            "relations": {
              "mara": 4,
              "nora": -3
            },
            "flags": [
              "crisis_stayed"
            ],
            "removeFlags": []
          },
          "result": {
            "text": "你留下了。第一批移交来的材料很快占满桌面，原先答应自己的休息被重新排期。玛拉把你的名字列在负责人的栏里，也明确说以后会直接追问进度。收入有了着落，身体和耐心却都需要另付代价。"
          }
        },
        {
          "id": "c",
          "label": "转去社区项目",
          "detail": "收入下降，花费时间与积蓄重新起步。",
          "effects": {
            "health": 0,
            "stress": 3,
            "research": -2,
            "trust": 0,
            "reputation": -3,
            "communication": 0,
            "freedom": 8,
            "discipline": 0,
            "relations": {
              "mara": -2,
              "darius": 3
            },
            "flags": [
              "outside_committed"
            ],
            "removeFlags": [],
            "career": "outside",
            "personalCash": -8000
          },
          "result": {
            "text": "你带走的是一份新的课程表，而不是熟悉的职位名称。社区项目的人愿意让你试做，却不能补齐原来的收入。第一笔学习和过渡费用从个人积蓄里扣掉，你把生活缩小了一圈，也第一次拥有了另一个方向。"
          }
        }
      ]
    },
    {
      "id": "v22",
      "dateIndex": 22,
      "slot": 1,
      "priority": 10,
      "requires": {
        "flagsAll": [
          "job_lost"
        ]
      },
      "chapter": "fracture",
      "title": "第二张工作证",
      "text": "这一年的求职邮件分在三个文件夹里：没有回音的、谢绝的、仍在等待的。今天你终于得到一份正式邀请，对方需要有经验的人带项目，但要求你说明那段空白，并接受比想象中更小的团队和更杂的工作。\n\n另一封信来自社区服务站，问你是否愿意加入。桌边还有一张短期整理资料的工时单，足够支付眼下几笔账单，却没有明年的承诺。你已经学会自己安排没有工作证的日子；现在的问题，是重新进入哪一种生活，而不是用哪个头衔证明这一年没有白过。",
      "characters": [
        "sam",
        "darius"
      ],
      "chain": "repair",
      "choices": [
        {
          "id": "a",
          "label": "接受小团队的邀请",
          "detail": "重返行业，重新承担带人与交付责任。",
          "effects": {
            "health": 0,
            "stress": 5,
            "research": 3,
            "trust": 0,
            "reputation": 5,
            "communication": 0,
            "freedom": -3,
            "discipline": 0,
            "relations": {
              "sam": 4
            },
            "flags": [
              "rebuilt"
            ],
            "removeFlags": [],
            "career": "senior"
          },
          "result": {
            "text": "你在回复里写下接受，也写清需要补上的交接资料。新的工作证没有抹掉失业的那一年，面试时说过的不足仍要逐一补课。第一次带小组开会时，你给每个人留出了说难处的时间，包括你自己。"
          }
        },
        {
          "id": "b",
          "label": "加入社区服务站",
          "detail": "接受较低收入，让新的工作成为正职。",
          "effects": {
            "health": 0,
            "stress": -3,
            "research": 0,
            "trust": 0,
            "reputation": -2,
            "communication": 5,
            "freedom": 4,
            "discipline": 0,
            "relations": {
              "darius": 7
            },
            "flags": [
              "outside_committed"
            ],
            "removeFlags": [],
            "career": "outside"
          },
          "result": {
            "text": "服务站把你列进下一年的正式排班。你仍要认真计算每月开销，旧同事也未必明白这份选择。有人第一次记住你的姓名，是因为你愿意把一张复杂的表耐心讲完，这让新工作有了具体形状。"
          }
        },
        {
          "id": "c",
          "label": "先接短期整理工作",
          "detail": "维持过渡收入，暂时承受没有归属的日子。",
          "effects": {
            "health": 0,
            "stress": 4,
            "research": 0,
            "trust": 0,
            "reputation": 0,
            "communication": 0,
            "freedom": 2,
            "discipline": 4,
            "relations": {
              "sam": 1
            },
            "flags": [
              "bridge_work"
            ],
            "removeFlags": [],
            "career": "unemployed",
            "personalCash": 2400
          },
          "result": {
            "text": "工时单盖好了章，你知道接下来的几周能靠什么生活，却仍不能在表格里填上一份长期工作。你继续保留求职的时间，也继续面对等待。短工没有被包装成成功，它只是让你能够把今天稳稳地过完。"
          }
        }
      ]
    },
    {
      "id": "v24",
      "dateIndex": 24,
      "slot": 0,
      "priority": 10,
      "requires": {
        "flagsAll": [
          "kept_notes"
        ]
      },
      "chapter": "fracture",
      "title": "可以带走的纸箱",
      "text": "林知远退休那天，没有让人替他办很大的仪式。他指着门口两只纸箱，说其中一箱是旧衣服，另一箱是这些年留下的笔记。有的页角还贴着你当年用过的便签，问题后面没有答案，只有后来补写的日期。\n\n他已经问过资料里出现过的人，哪些可以删去姓名后留给后来者；另有几页涉及私人处境，他打算亲手处理。你曾认真保留自己的笔记，因此他愿意请你帮忙。但这些纸也不是一份必须继承的使命，他还想腾出下周去学木工的时间。",
      "characters": [
        "lin"
      ],
      "chain": "archive",
      "choices": [
        {
          "id": "a",
          "label": "一起整理后开放借阅",
          "detail": "花时间去除私人信息，留下可用的经验。",
          "effects": {
            "health": 0,
            "stress": 2,
            "research": 4,
            "trust": 0,
            "reputation": 0,
            "communication": 0,
            "freedom": 0,
            "discipline": 4,
            "relations": {
              "lin": 8
            },
            "flags": [
              "archive_shared"
            ],
            "removeFlags": []
          },
          "result": {
            "text": "你们把可以分享的笔记编成目录，把私人部分单独还给本人处理。林知远没有要求你沿用他的判断，只在首页写下“请补上你自己的问题”。纸箱变轻以后，他准时去上了木工课，档案也有了别人能够使用的入口。"
          }
        },
        {
          "id": "b",
          "label": "只留两人的通信",
          "detail": "保存私人记忆，不接下完整整理工作。",
          "effects": {
            "health": 0,
            "stress": -2,
            "research": 0,
            "trust": 0,
            "reputation": 0,
            "communication": 0,
            "freedom": 3,
            "discipline": 0,
            "relations": {
              "lin": 5
            },
            "flags": [
              "archive_letters_kept"
            ],
            "removeFlags": []
          },
          "result": {
            "text": "你挑出双方愿意保留的信，装进一个薄文件夹。其余资料仍由林知远决定去处，他没有流露失望，反而讲起新买的工具。你们约好以后写信不必总谈工作，旧纸张因此保留了一种更安静的用途。"
          }
        },
        {
          "id": "c",
          "label": "帮他联系合适的保管人",
          "detail": "把责任交给愿意长期维护资料的人。",
          "effects": {
            "health": 0,
            "stress": 0,
            "research": 0,
            "trust": 0,
            "reputation": 0,
            "communication": 4,
            "freedom": 0,
            "discipline": 2,
            "relations": {
              "lin": 4
            },
            "flags": [
              "archive_custodian_found"
            ],
            "removeFlags": []
          },
          "result": {
            "text": "你找到愿意接收档案的小组，陪林知远把使用边界讲清楚。交接需要几次往返，最后却没有把一项长期职责压在任何一个人身上。他留下一份目录，问你下次来时要不要看看他做的第一只木盒。"
          }
        }
      ]
    },
    {
      "id": "v26",
      "dateIndex": 26,
      "slot": 0,
      "priority": 10,
      "requires": {
        "flagsAll": [
          "sam_helped"
        ]
      },
      "chapter": "fracture",
      "title": "那张换班表之后",
      "text": "山姆从外地回来，约你在车站旁吃一碗热汤。他父亲现在需要的照护有了稳定安排，他也终于能把电话放在桌上，不必每响一次就立刻站起来。说到你当年认真帮他重新安排工作，他没有夸大那次帮助，只说有人一起考虑办法，让他不必独自面对所有冲突。\n\n最近他参与一个跨团队的小项目，缺一位能讲清复杂事情的人。他愿意替你介绍，却先问你究竟想不想接。汤面上的热气慢慢散开，你们还有许多不涉及工作的近况，可以从容地说完。",
      "characters": [
        "sam"
      ],
      "chain": "junior",
      "choices": [
        {
          "id": "a",
          "label": "认真谈谈合作边界",
          "detail": "接受介绍，先说明时间和责任。",
          "effects": {
            "health": 0,
            "stress": 2,
            "research": 0,
            "trust": 0,
            "reputation": 3,
            "communication": 4,
            "freedom": 0,
            "discipline": 0,
            "relations": {
              "sam": 7
            },
            "flags": [
              "sam_bridge"
            ],
            "removeFlags": []
          },
          "result": {
            "text": "你们没有把当年的帮助折算成一份人情债，而是把新项目的时间、报酬和退出办法写清楚。山姆替你安排了一次正式见面，结果仍要靠双方决定。离开餐馆时，你们都知道这座桥可以走，也可以礼貌地停在桥边。"
          }
        },
        {
          "id": "b",
          "label": "这次只把饭吃完",
          "detail": "暂不接受合作，让关系有工作之外的部分。",
          "effects": {
            "health": 2,
            "stress": -3,
            "research": 0,
            "trust": 0,
            "reputation": 0,
            "communication": 0,
            "freedom": 2,
            "discipline": 0,
            "relations": {
              "sam": 5
            },
            "flags": [
              "sam_friend_meal"
            ],
            "removeFlags": []
          },
          "result": {
            "text": "你说现在不想再接一个项目，山姆把手机翻了过去。后半顿饭讲的是父亲的新脾气和你最近常走的路，没有谁急着证明见面有用。你们约好下次换一家店，这次拒绝没有变成一笔要记住的亏欠。"
          }
        },
        {
          "id": "c",
          "label": "推荐另一位合适的人",
          "detail": "放过机会，承担一次认真引荐的责任。",
          "effects": {
            "health": 0,
            "stress": 0,
            "research": 0,
            "trust": 3,
            "reputation": 0,
            "communication": 3,
            "freedom": 0,
            "discipline": 0,
            "relations": {
              "sam": 3
            },
            "flags": [
              "sam_referral_given"
            ],
            "removeFlags": []
          },
          "result": {
            "text": "你解释了另一位同事适合的原因，也先征得对方同意才交出联系方式。山姆收下推荐，提醒你不必因此替任何人保证结果。项目的机会从你手边经过，留下的不是空手感，而是一段边界清楚的介绍。"
          }
        }
      ]
    },
    {
      "id": "v27",
      "dateIndex": 27,
      "slot": 1,
      "priority": 10,
      "requires": {
        "flagsAll": [
          "promise_date"
        ]
      },
      "chapter": "fracture",
      "title": "巡展不等人",
      "text": "梅的巡展终于排上日程，开幕日期与你眼下的安排撞在一起。她带来的不是一封请你批准的通知，而是一张还留着空白的行程表：哪些晚上能打电话，哪些日子必须独处，哪些地方如果你想来，她愿意给你留一张票。\n\n你记得多年前曾为她的展览认真留出一个周六。那一次约定已经过去，如今要重新商量的是持续的联系。梅说，她希望自己的工作不总被称作“忙完这一阵”，就像她没有要求你把职业缩成一个爱好。桌上的两杯茶已经凉了，新的安排得容得下两个都有自己方向的人。",
      "characters": [
        "mei"
      ],
      "chain": "friend",
      "choices": [
        {
          "id": "a",
          "label": "一起重排共同的时间",
          "detail": "承认双方事业同样重要，承担协调成本。",
          "effects": {
            "health": 0,
            "stress": 2,
            "research": 0,
            "trust": 3,
            "reputation": 0,
            "communication": 5,
            "freedom": 0,
            "discipline": 0,
            "relations": {
              "mei": 9
            },
            "flags": [
              "mei_equal"
            ],
            "removeFlags": []
          },
          "result": {
            "text": "你们调整眼下的日期，各自说出无法让步的安排，再找出真正能相见的空档。新的日历不如旧约定好看，却更像两个人的生活。梅收起行程表时没有承诺永远不冲突，你也不再把每次改期都当作谁不够在意。"
          }
        },
        {
          "id": "b",
          "label": "把关系放得远一点",
          "detail": "承认此刻难以协调，接受亲密程度下降。",
          "effects": {
            "health": 0,
            "stress": -2,
            "research": 0,
            "trust": 0,
            "reputation": 0,
            "communication": 0,
            "freedom": 4,
            "discipline": 0,
            "relations": {
              "mei": -5
            },
            "flags": [
              "friend_distance"
            ],
            "removeFlags": []
          },
          "result": {
            "text": "你坦白自己无法轻松应对这样的安排，也不愿用抱怨让她缩短行程。你们决定暂时减少对彼此时间的要求，仍保留可以认真说话的联系。走出茶馆时你感到失落，梅也没有假装，这是一种毫无代价的成熟。"
          }
        },
        {
          "id": "c",
          "label": "先保留一个月的试行",
          "detail": "不替未来下保证，约好具体的回看日期。",
          "effects": {
            "health": 0,
            "stress": 1,
            "research": 0,
            "trust": 0,
            "reputation": 0,
            "communication": 3,
            "freedom": 0,
            "discipline": 3,
            "relations": {
              "mei": 3
            },
            "flags": [
              "mei_trial_calendar"
            ],
            "removeFlags": []
          },
          "result": {
            "text": "你们先订下一个月的通话和见面安排，并约好届时一起谈哪里难以坚持。梅接受这个有限的答案，你也承认试行可能暴露更多分歧。茶杯被收走之前，你们把那个回看日期都写进了自己的日历。"
          }
        }
      ]
    },
    {
      "id": "v28",
      "dateIndex": 28,
      "slot": 1,
      "priority": 10,
      "requires": {
        "flagsAll": [
          "independence_seed"
        ]
      },
      "chapter": "fracture",
      "title": "门牌还没有挂上",
      "text": "那份独立工作的草案已经在抽屉里放了很久。如今你找到一间可以按月租用的小屋，算过最初几个月的费用，也终于收到一个愿意认真谈合同的询问。纸上的空间够放一张桌子，放不下你曾想象的体面前台。\n\n眼下的工作、短工或求职安排，也需要为下一年重新确认。另一边，社区项目愿意让你承担更稳定的工作，但那意味着把职业重心真正挪走。你翻到草案最后一页，看见自己早年写下“有一天”。现在没有人催你兑现这句话，可每条路都需要放下另外一些可能。",
      "characters": [
        "mara",
        "darius"
      ],
      "chain": "autonomy",
      "choices": [
        {
          "id": "a",
          "label": "用积蓄正式开张",
          "detail": "支付一万二千美元启动费用，自负收入起伏。",
          "effects": {
            "health": 0,
            "stress": 8,
            "research": 0,
            "trust": 0,
            "reputation": 0,
            "communication": 0,
            "freedom": 8,
            "discipline": 3,
            "relations": {
              "mara": -2
            },
            "flags": [
              "indie_launched"
            ],
            "removeFlags": [],
            "career": "independent",
            "personalCash": -12000
          },
          "result": {
            "text": "你从个人积蓄中拿出启动费用，把第一份合同逐句看完，再在门上贴好自己的名字。屋子没有因此变得宽敞，来询问的人也没有自动成为客户。晚些时候你关灯离开，钥匙在口袋里提醒你，自主同时意味着亲自承担账单。"
          }
        },
        {
          "id": "b",
          "label": "暂缓开张，继续做准备",
          "detail": "保留当前工作或求职安排，将独立计划明确延期。",
          "effects": {
            "health": 0,
            "stress": -2,
            "research": 0,
            "trust": 0,
            "reputation": 0,
            "communication": 0,
            "freedom": -3,
            "discipline": 4,
            "relations": {
              "mara": 3
            },
            "flags": [
              "independence_deferred"
            ],
            "removeFlags": []
          },
          "result": {
            "text": "你把接下来的工作或求职安排写进日历，把草案另存为一个写着回看日期的版本。创业费用暂不支出，筹备仍然需要时间；这份清单留待真正具备条件时再打开。"
          }
        },
        {
          "id": "c",
          "label": "转向社区里的工作",
          "detail": "接受收入与身份变化，放下这次创业。",
          "effects": {
            "health": 0,
            "stress": 2,
            "research": 0,
            "trust": 0,
            "reputation": -2,
            "communication": 4,
            "freedom": 5,
            "discipline": 0,
            "relations": {
              "darius": 6
            },
            "flags": [
              "outside_committed"
            ],
            "removeFlags": [],
            "career": "outside"
          },
          "result": {
            "text": "你回复了社区项目，把那间小屋的租赁意向取消。独立工作的草案仍然存在，却不再是必须向谁交出的证明。新的职责更贴近每天见得到的人，收入安排也更朴素；你开始学习如何在另一种工作里认真站稳。"
          }
        }
      ]
    },
    {
      "id": "v30",
      "dateIndex": 30,
      "slot": 1,
      "priority": 10,
      "requires": {
        "flagsAll": [
          "shared_care"
        ]
      },
      "chapter": "fracture",
      "title": "工作室的灯",
      "text": "诺拉的工作室临时少了一个人，赶在月底交付的几套模型和成册图纸还没有装箱。她打来电话时先问你的安排，然后很认真地说，自己需要的是两只手和一个能一起商量的人，不是你替她开一张支票。\n\n以前你们已经谈过照护家人的分担，她不想因此让每次求助都被算进同一本账。你走进工作室，看见她把完成的图纸和待改模型分开摆好，墙上贴着新的报价单。她正在试着让这份工作养活自己，也想保留决定怎么做的权利。今晚的帮助需要先问清边界。",
      "characters": [
        "nora"
      ],
      "chain": "family",
      "choices": [
        {
          "id": "a",
          "label": "按她的安排一起装箱",
          "detail": "投入一个晚上，尊重她对工作的决定。",
          "effects": {
            "health": -2,
            "stress": 2,
            "research": 0,
            "trust": 4,
            "reputation": 0,
            "communication": 0,
            "freedom": 0,
            "discipline": 0,
            "relations": {
              "nora": 9
            },
            "flags": [
              "family_trust"
            ],
            "removeFlags": []
          },
          "result": {
            "text": "诺拉给你示范怎么包住容易碰坏的边角，你照着做，没有顺手替她重写经营计划。到最后一只箱子封好时，你们都很疲惫，却把下一次需要帮忙时如何开口说得更清楚。她关灯，你负责把垃圾带到楼下。"
          }
        },
        {
          "id": "b",
          "label": "帮她联系临时人手",
          "detail": "分担寻找的麻烦，不替她挑选与付钱。",
          "effects": {
            "health": 0,
            "stress": 0,
            "research": 0,
            "trust": 0,
            "reputation": 0,
            "communication": 4,
            "freedom": 0,
            "discipline": 2,
            "relations": {
              "nora": 4
            },
            "flags": [
              "family_help_bounded"
            ],
            "removeFlags": []
          },
          "result": {
            "text": "你列出几位可能愿意接短工的人，先询问，再让诺拉自己谈时间和报酬。她选了其中一位，并删掉你提议的一项安排。你忍住继续替她拍板的冲动，发现帮助别人保留决定权，也需要一点练习。"
          }
        },
        {
          "id": "c",
          "label": "说清今晚无法留下",
          "detail": "承受她的失望，约一个确实能到的时段。",
          "effects": {
            "health": 2,
            "stress": 0,
            "research": 0,
            "trust": 0,
            "reputation": 0,
            "communication": 0,
            "freedom": 3,
            "discipline": 0,
            "relations": {
              "nora": -2
            },
            "flags": [
              "family_help_rescheduled"
            ],
            "removeFlags": []
          },
          "result": {
            "text": "诺拉听完后停了一会儿，没有说“没关系”来替你轻松。你们把周末两个小时定下来，只处理届时仍然需要的事情。离开前你帮她搬开门边的箱子，这个小动作没有抵消拒绝，却让约定不再停留在一句客气话里。"
          }
        }
      ]
    },
    {
      "id": "v31",
      "dateIndex": 31,
      "slot": 0,
      "priority": 10,
      "requires": {
        "flagsAll": [
          "indie_launched"
        ],
        "career": "independent"
      },
      "chapter": "homeward",
      "title": "合同的最后一页",
      "text": "第一批忙乱过后，一位潜在客户带来足够让办公室宽裕起来的合同。他很客气，甚至记得你喜欢哪种茶，只在最后一页加了几句话：希望你在对外说明时省略一部分不确定，也希望重要决定不再留那么多书面记录。\n\n你把笔停在桌面上。这间屋子的房租、独立工作的日常开销，都不会因为你守住某种原则而自动减少。对方似乎也看见了这份犹豫，说如果合作顺利，还能介绍朋友来。你需要回答的不是自己是否喜欢这个人，而是这张门牌下面到底允许怎样工作。",
      "characters": [
        "elias",
        "mara"
      ],
      "chain": "autonomy",
      "choices": [
        {
          "id": "a",
          "label": "写清规则再谈合作",
          "detail": "冒着失去合同的风险，保留如实记录。",
          "effects": {
            "health": 0,
            "stress": 4,
            "research": 0,
            "trust": 4,
            "reputation": 0,
            "communication": 0,
            "freedom": 0,
            "discipline": 6,
            "relations": {
              "elias": 6
            },
            "flags": [
              "rules_owned"
            ],
            "removeFlags": []
          },
          "result": {
            "text": "你把需要删除和补充的地方标了出来，解释这些不是针对他个人的戒备。对方没有立即答应，桌上的预算仍然紧张。伊莱后来读过条款，只说它们能够被执行；这份边界从此也约束你，不只约束来访的人。"
          }
        },
        {
          "id": "b",
          "label": "谢绝这份合同",
          "detail": "放弃眼前机会，承担重新寻找收入的成本。",
          "effects": {
            "health": 0,
            "stress": 5,
            "research": 0,
            "trust": 0,
            "reputation": 1,
            "communication": 0,
            "freedom": 0,
            "discipline": 4,
            "relations": {
              "elias": 3
            },
            "flags": [
              "indie_contract_declined"
            ],
            "removeFlags": []
          },
          "result": {
            "text": "你退回文件，感谢对方愿意来谈，也没有留下含糊的口头承诺。办公室在客人离开后显得更安静，待办清单上的费用一项也没有消失。你开始联系其他可能的合作方，知道拒绝能结束一次谈判，却不能替你完成下一次。"
          }
        },
        {
          "id": "c",
          "label": "请对方给出书面解释",
          "detail": "延后答复，为核对问题投入时间。",
          "effects": {
            "health": 0,
            "stress": 3,
            "research": 4,
            "trust": 0,
            "reputation": 0,
            "communication": 3,
            "freedom": 0,
            "discipline": 0,
            "relations": {
              "elias": 2
            },
            "flags": [
              "indie_contract_review"
            ],
            "removeFlags": []
          },
          "result": {
            "text": "你没有签字，也没有当场宣布谈判破裂，而是把疑问整理成一封需要正式回复的信。对方要多等几天，你也得额外付出核对的时间。事情暂时停在桌面上，这份停顿让你有机会看清，对方究竟愿不愿意接受可以追问的合作。"
          }
        }
      ]
    },
    {
      "id": "v32",
      "dateIndex": 32,
      "slot": 1,
      "priority": 10,
      "requires": {
        "flagsAll": [
          "class_started",
          "class_return"
        ]
      },
      "chapter": "homeward",
      "title": "粉笔交给谁",
      "text": "达里厄斯把夜校下一学期的安排摊在课桌上。他要减少授课时间，照顾自己的家人，也留一点晚上给一直没完成的学习计划。你这些年回来过，学生知道你的名字，于是自然有人问，是不是由你把全部课程接下来。\n\n教室里最后一排还摆着今天没来得及收好的椅子。你知道这门课曾怎样改变自己的处境，也知道感激不是一张永远不能拒绝的排班表。达里厄斯说，他更希望课程离开任何一个人也能继续，而不是换一个继续熬夜的人。",
      "characters": [
        "darius"
      ],
      "chain": "school",
      "choices": [
        {
          "id": "a",
          "label": "与学员一起分担课程",
          "detail": "搭建可轮换的安排，投入交接时间。",
          "effects": {
            "health": 0,
            "stress": 2,
            "research": 0,
            "trust": 0,
            "reputation": 0,
            "communication": 5,
            "freedom": 0,
            "discipline": 4,
            "relations": {
              "darius": 8
            },
            "flags": [
              "class_shared"
            ],
            "removeFlags": []
          },
          "result": {
            "text": "你们把课程拆成几段，邀请有意愿的学员试讲，再约定遇到困难时如何求助。第一版安排并不整齐，有人需要退出，也有人后来加入。达里厄斯终于能够空出自己的晚上，而这间教室没有把钥匙只交到你一个人手里。"
          }
        },
        {
          "id": "b",
          "label": "只接自己熟悉的两课",
          "detail": "承担有限职责，不许下整学期承诺。",
          "effects": {
            "health": 0,
            "stress": 0,
            "research": 3,
            "trust": 0,
            "reputation": 0,
            "communication": 0,
            "freedom": 2,
            "discipline": 3,
            "relations": {
              "darius": 4
            },
            "flags": [
              "class_two_lessons"
            ],
            "removeFlags": []
          },
          "result": {
            "text": "你写下能够准备好的两堂课，其余空白仍留给大家商量。达里厄斯没有劝你多做，只提醒你按时把材料交来。这个答案不够壮观，却能被认真执行；你回家后开始备课，也保留了原本答应家人的几个晚上。"
          }
        },
        {
          "id": "c",
          "label": "帮忙找新的授课伙伴",
          "detail": "负责介绍与试讲安排，自己退到后排。",
          "effects": {
            "health": 0,
            "stress": -2,
            "research": 0,
            "trust": 0,
            "reputation": 0,
            "communication": 4,
            "freedom": 0,
            "discipline": 0,
            "relations": {
              "darius": 3
            },
            "flags": [
              "class_new_teacher"
            ],
            "removeFlags": []
          },
          "result": {
            "text": "你联系了愿意尝试的人，说明课程的实际需要，没有拿自己的经历替他们作保证。试讲那晚你坐在后排，第一次看见别人用完全不同的方式讲清同一个问题。达里厄斯笑着记了几笔，新的课堂终于开始长出自己的样子。"
          }
        }
      ]
    },
    {
      "id": "v34",
      "dateIndex": 34,
      "slot": 0,
      "priority": 10,
      "requires": {
        "flagsAll": [
          "job_lost",
          "rebuilt"
        ],
        "career": [
          "senior",
          "manager",
          "head",
          "partner"
        ]
      },
      "chapter": "homeward",
      "title": "不必再藏的空白",
      "text": "年底的小组回顾会上，有位年轻同事把自己的履历翻过去，低声说他曾有半年没有正式工作，担心客户知道后会觉得不可靠。几年前你重新拿到工作证时，也曾反复练习怎样解释类似的空白。\n\n现在你终于能看到那段重建留下的东西：有人愿意提前告诉你项目可能做不完，会议不再只剩漂亮的进度。山姆提出明年与你更平等地分担负责人的职责，而不是继续帮忙救火。你可以把这份改变固定下来，也可以继续用自己随时补位的方式，维持眼前熟悉的秩序。",
      "characters": [
        "sam"
      ],
      "chain": "repair",
      "choices": [
        {
          "id": "a",
          "label": "把责任和名字都分开",
          "detail": "与山姆平等分工，公开承认重建经历。",
          "effects": {
            "health": 0,
            "stress": -3,
            "research": 0,
            "trust": 5,
            "reputation": 0,
            "communication": 4,
            "freedom": 0,
            "discipline": 0,
            "relations": {
              "sam": 9
            },
            "flags": [
              "rebuilt_stable",
              "sam_partner"
            ],
            "removeFlags": []
          },
          "result": {
            "text": "你没有要求年轻同事把空白包装得更好，而是谈了自己当时如何一步步回到工作。随后你和山姆写下各自可以决定的事情，也写下需要共同承担的部分。团队不再只有一个兜底的人，你终于可以把重建当作经历，而不是污点。"
          }
        },
        {
          "id": "b",
          "label": "先改善一项具体安排",
          "detail": "从可执行的交接开始，暂缓职责调整。",
          "effects": {
            "health": 0,
            "stress": -2,
            "research": 0,
            "trust": 0,
            "reputation": 0,
            "communication": 0,
            "freedom": 0,
            "discipline": 4,
            "relations": {
              "sam": 3
            },
            "flags": [
              "rebuilt_handoff"
            ],
            "removeFlags": []
          },
          "result": {
            "text": "你们先把最容易拖到深夜的交接改到白天，并留下复查日期。山姆接受这个小一些的开始，也提醒你不要让“以后再说”变成永久的答案。年轻同事收好履历，至少知道这里可以提前说出困难，不必等到失败以后。"
          }
        },
        {
          "id": "c",
          "label": "继续亲自补上缺口",
          "detail": "维持控制感，承担更重的精力负担。",
          "effects": {
            "health": -5,
            "stress": 7,
            "research": 2,
            "trust": 0,
            "reputation": 0,
            "communication": 0,
            "freedom": -4,
            "discipline": 0,
            "relations": {
              "sam": -4
            },
            "flags": [
              "rebuilt_control_kept"
            ],
            "removeFlags": []
          },
          "result": {
            "text": "你表示还想亲自看过每一处关键细节，山姆把已经写好的分工方案收了回去。事情暂时仍按熟悉的方式运转，你也仍是最晚离开的人。那位年轻同事没有再提履历上的空白，你无法知道这份沉默究竟意味着放心还是退缩。"
          }
        }
      ]
    },
    {
      "id": "v35",
      "dateIndex": 35,
      "slot": 0,
      "priority": 10,
      "requires": {
        "flagsAll": [
          "client_window"
        ]
      },
      "chapter": "homeward",
      "title": "录取通知之外",
      "text": "朱恩征得客户同意，邀请你以早年服务参与者的身份一起回访。客户的孩子收到了录取通知，选中的学校不在最初的预算里，还想保留一个暑假自己打工和旅行。朱恩约好了一次视频会谈，让一家人能一起核对当年谈过的用款期限。\n\n你找到旧记录，上面写的不是一个要击败谁的数字，而是家庭预计何时需要用钱。屏幕那头，孩子第一次完整听到这些安排，也认真问哪些决定应该由自己参与。你面对的不只是到了日期的一笔支出，还有一个家庭准备让下一代开始说话的时刻。",
      "characters": [
        "june"
      ],
      "chain": "clients",
      "choices": [
        {
          "id": "a",
          "label": "让孩子一起核对安排",
          "detail": "兑现讨论期限，把决定权讲给全家听。",
          "effects": {
            "health": 0,
            "stress": 0,
            "research": 0,
            "trust": 5,
            "reputation": 0,
            "communication": 5,
            "freedom": 0,
            "discipline": 3,
            "relations": {
              "june": 8
            },
            "flags": [
              "client_legacy"
            ],
            "removeFlags": []
          },
          "result": {
            "text": "你按记录逐项说明已经确定和仍需选择的部分，请孩子自己说出最在意的事情。家长没有立刻同意所有想法，却开始直接向孩子提问。谈话结束时他们带走一份能共同阅读的清单，而不是一张替整个家庭作完决定的答案。"
          }
        },
        {
          "id": "b",
          "label": "先核清每笔实际费用",
          "detail": "暂缓扩展计划，为家庭保留决定空间。",
          "effects": {
            "health": 0,
            "stress": 1,
            "research": 4,
            "trust": 0,
            "reputation": 0,
            "communication": 0,
            "freedom": 0,
            "discipline": 4,
            "relations": {
              "june": 3
            },
            "flags": [
              "client_costs_checked"
            ],
            "removeFlags": []
          },
          "result": {
            "text": "你建议先把学费、生活费和可调整的项目分开核实，再决定需要怎样改变原来的安排。孩子有些失望，仍愿意负责收集自己能查清的部分。朱恩把旧记录重新折好，这一次旁边多了一张由孩子亲手写下的待办单。"
          }
        },
        {
          "id": "c",
          "label": "安排一次有家人同席的再谈",
          "detail": "不给当场结论，承受客户等待的不安。",
          "effects": {
            "health": 0,
            "stress": 2,
            "research": 0,
            "trust": 1,
            "reputation": 0,
            "communication": 3,
            "freedom": 0,
            "discipline": 0,
            "relations": {
              "june": 1
            },
            "flags": [
              "client_family_meeting"
            ],
            "removeFlags": []
          },
          "result": {
            "text": "你承认今天的信息还不足以替他们排出全部时间，建议让需要承担费用的家人一起再谈。家长原本想立刻得到安心，听完后叹了口气，还是订下了日期。孩子留下自己的联系方式，开始以参与者的身份等待下一次会面。"
          }
        }
      ]
    },
    {
      "id": "v37",
      "dateIndex": 37,
      "slot": 1,
      "priority": 10,
      "requires": {
        "flagsAll": [
          "mei_equal"
        ]
      },
      "chapter": "homeward",
      "title": "两份日历",
      "text": "梅获得了一个需要长期往返的工作机会，你的下一阶段安排也刚刚确定。几年前你们已经谈过，谁的事业都不该只在另一人的空隙里生长。如今这句话遇到的是机场距离、各自住处的事务，还有常常无法同时休息的周末。\n\n她把自己的日历放在你旁边，没有先擦掉任何行程。你们都知道，认真对待两个职业不等于每件事都会自然公平。各自窗边的植物需要浇水，各自家里的老人偶尔需要探望，谁负责记住这些小事，也会慢慢决定一个人是否还有余力做自己想做的工作。",
      "characters": [
        "mei",
        "nora"
      ],
      "chain": "friend",
      "choices": [
        {
          "id": "a",
          "label": "把日常安排与见面一起排",
          "detail": "共同承担看不见的琐事，保留两个职业。",
          "effects": {
            "health": 0,
            "stress": 2,
            "research": 0,
            "trust": 0,
            "reputation": 0,
            "communication": 5,
            "freedom": 0,
            "discipline": 4,
            "relations": {
              "mei": 8
            },
            "flags": [
              "shared_calendar"
            ],
            "removeFlags": []
          },
          "result": {
            "text": "你们不只圈出相见的日子，也说清哪些探望能够一起安排、哪些住处事务仍由各自负责。遇到冲突时先商量，不能来的那个人负责提出新的安排。梅保存好两份日历，它们仍然会撞在一起，却不再默认由同一个人不断擦掉自己的事情。"
          }
        },
        {
          "id": "b",
          "label": "保留各自的生活空间",
          "detail": "付出距离与生活成本，保留各自的工作空间。",
          "effects": {
            "health": 0,
            "stress": 3,
            "research": 0,
            "trust": 0,
            "reputation": 0,
            "communication": 0,
            "freedom": 5,
            "discipline": 2,
            "relations": {
              "mei": 2
            },
            "flags": [
              "mei_two_homes"
            ],
            "removeFlags": []
          },
          "result": {
            "text": "你们决定各自安排方便工作的住处，不因为外人的猜测就仓促改变生活方式，并把往返开销写进自己的预算。告别时仍有不舍，你们约定认真回顾这段安排，看看距离到底帮到了谁，又难住了谁。亲近不需要先满足别人的标准。"
          }
        },
        {
          "id": "c",
          "label": "承认现在只能少见面",
          "detail": "降低相聚频率，不把失望交给对方独担。",
          "effects": {
            "health": 0,
            "stress": -2,
            "research": 0,
            "trust": 0,
            "reputation": 0,
            "communication": 0,
            "freedom": 3,
            "discipline": 0,
            "relations": {
              "mei": -2
            },
            "flags": [
              "mei_fewer_meetings"
            ],
            "removeFlags": []
          },
          "result": {
            "text": "你坦白目前承担不了更密集的往返，也听她说完少见面的失落。你们删掉一些漂亮却难以做到的计划，保留能够兑现的约定。日历空了几格，感情没有因此自动轻松，但至少这份遗憾被两个人一起看见，而不是留给一方猜测。"
          }
        }
      ]
    },
    {
      "id": "v38",
      "dateIndex": 38,
      "slot": 0,
      "priority": 10,
      "requires": {
        "flagsAll": [
          "kept_ownership"
        ]
      },
      "chapter": "homeward",
      "title": "抽屉里的旧计划",
      "text": "你整理抽屉时翻出多年前的一页研究与配置记录，旁边夹着同一时期的房租收据。那时你尝试为一门生意安排有限的份额，真实成交多少需要看账本；纸上没有写着它后来应该带来怎样的人生，更没有保证任何等待都会得到奖励。\n\n眼下家里有一笔确定的支出，你自己的休息计划也拖了很久。账户中的现金和实际持仓都需要按当下的需要重新核对。你把旧纸放在今天的生活预算旁边，忽然觉得最难的不是证明过去英明，而是允许现在的需要，有权改变一个曾经很认真的决定。",
      "characters": [
        "nora",
        "lin"
      ],
      "chain": "wealth",
      "choices": [
        {
          "id": "a",
          "label": "先为生活留出清楚预算",
          "detail": "保留长期视角，也承认当下支出的边界。",
          "effects": {
            "health": 0,
            "stress": -3,
            "research": 0,
            "trust": 0,
            "reputation": 0,
            "communication": 0,
            "freedom": 2,
            "discipline": 5,
            "relations": {
              "nora": 3
            },
            "flags": [
              "compound_patience",
              "wealth_frame"
            ],
            "removeFlags": []
          },
          "result": {
            "text": "你把近期需要的钱和可以继续等待的部分分开记录，再回到账户页面核对实际安排。旧笔记没有被供起来，也没有被撕掉。你依然愿意耐心，但这一次耐心有了范围，不再要求家人和自己的生活无限期地排在后面。"
          }
        },
        {
          "id": "b",
          "label": "重新检查这份持有理由",
          "detail": "投入时间审视旧判断，接受可能改变主意。",
          "effects": {
            "health": 0,
            "stress": 2,
            "research": 5,
            "trust": 0,
            "reputation": 0,
            "communication": 0,
            "freedom": 0,
            "discipline": 3,
            "relations": {
              "lin": 2
            },
            "flags": [
              "ownership_reexamined"
            ],
            "removeFlags": []
          },
          "result": {
            "text": "你重新打开当年写下的理由，逐条区分哪些仍能查证，哪些只是后来添上的自我解释。检查没有立即给出一个舒服的结论，却让你愿意承认自己可能改变。生活预算仍留在桌上，提醒你研究结束后还要作实际安排。"
          }
        },
        {
          "id": "c",
          "label": "今天先陪家人做预算",
          "detail": "把账户决定暂缓，不再拖延生活里的对话。",
          "effects": {
            "health": 0,
            "stress": -2,
            "research": 0,
            "trust": 3,
            "reputation": 0,
            "communication": 4,
            "freedom": 0,
            "discipline": 0,
            "relations": {
              "nora": 6
            },
            "flags": [
              "ownership_life_budget"
            ],
            "removeFlags": []
          },
          "result": {
            "text": "你合上旧文件，先把确定要发生的支出和家人逐项谈完。有人提出比你预想更小的方案，也有人说出了此前一直没好意思开口的需要。账户里的决定仍待处理，但今晚不再有人因为一个遥远的结果而被要求停止自己的生活。"
          }
        }
      ]
    },
    {
      "id": "v39",
      "dateIndex": 39,
      "slot": 1,
      "priority": 10,
      "requires": {
        "flagsAll": [
          "indie_launched",
          "rules_owned"
        ],
        "career": "independent"
      },
      "chapter": "homeward",
      "title": "多出来的房间",
      "text": "有人愿意出资让你的独立业务扩大，隔壁的房间也刚好空出来。对方画出的计划很热闹：更多人、更多城市、更多不能错过的机会。只是新的合同希望你先承诺尚未具备的人手，并在有争议时把说明交给他们统一处理。\n\n你翻出当年写下的工作规则，发现它们在小屋里很清楚，放进这份扩张计划却显得碍事。员工想知道会不会有更好的前景，房东在等回复。你不想用清高替代发工资的责任，也不愿让门牌仍写着自己的名字，屋里发生什么却不再能够回答。",
      "characters": [
        "elias",
        "mara"
      ],
      "chain": "autonomy",
      "choices": [
        {
          "id": "a",
          "label": "按原有边界继续经营",
          "detail": "放弃危险扩张，接受更慢且有限的增长。",
          "effects": {
            "health": 0,
            "stress": -2,
            "research": 0,
            "trust": 4,
            "reputation": 0,
            "communication": 0,
            "freedom": 0,
            "discipline": 6,
            "relations": {
              "elias": 6
            },
            "flags": [
              "indie_renewed"
            ],
            "removeFlags": []
          },
          "result": {
            "text": "你拒绝了那些无法兑现的承诺，把能承担的业务范围重新讲给团队听。有人感到遗憾，你也承认较小的规模有自己的难处。隔壁最终租给别人，你的名字仍留在原来的门上，下面那些规则也仍需要每天被实际遵守。"
          }
        },
        {
          "id": "b",
          "label": "提出一个较小的试点",
          "detail": "为核验新合作付出时间，不预先承诺扩张。",
          "effects": {
            "health": 0,
            "stress": 4,
            "research": 3,
            "trust": 0,
            "reputation": 0,
            "communication": 4,
            "freedom": 0,
            "discipline": 0,
            "relations": {
              "elias": 2
            },
            "flags": [
              "indie_pilot_proposed"
            ],
            "removeFlags": []
          },
          "result": {
            "text": "你把计划缩成可以停止的一段试点，列出人手、费用和公开说明的要求。对方需要重新考虑，团队也得为尚未确定的项目多做准备。这条路没有立即变宽，但每一步至少都能看见由谁负责，什么时候可以说不。"
          }
        },
        {
          "id": "c",
          "label": "暂时停止接新业务",
          "detail": "牺牲眼前机会，先解决内部已经出现的疲惫。",
          "effects": {
            "health": 4,
            "stress": -4,
            "research": 0,
            "trust": 0,
            "reputation": -2,
            "communication": 0,
            "freedom": 2,
            "discipline": 0,
            "relations": {
              "mara": -2
            },
            "flags": [
              "indie_intake_paused"
            ],
            "removeFlags": []
          },
          "result": {
            "text": "你宣布一段明确的暂停期，把已经答应的事情做完，再与团队逐个谈话。有人担心收入，有人终于说出近来的疲惫，你都记了下来。扩张者没有继续等候，原有工作也并未消失，这次收缩需要你用真实安排承担后果。"
          }
        }
      ]
    },
    {
      "id": "v40",
      "dateIndex": 40,
      "slot": 0,
      "priority": 10,
      "requires": {
        "flagsAll": [
          "archive_shared"
        ]
      },
      "chapter": "homeward",
      "title": "他自己的下午",
      "text": "林知远约你下午见面，特意提醒别带工作材料。他做的木盒已经从歪斜变得结实，如今正和邻居商量一个小展览。你问起那些开放借阅的旧笔记，他说偶尔会收到后来者的问题，但也有一些信，他暂时还不想回答。\n\n你曾习惯把他当成随时能给意见的人，现在看见他的桌面也有未完成的东西，有只属于自己的期待。临走前他请你看一张展览邀请卡，问的是字体是否清楚，而不是你的职业下一步。你们可以保留师生的记忆，也可以让这次见面长出新的内容。",
      "characters": [
        "lin"
      ],
      "chain": "archive",
      "choices": [
        {
          "id": "a",
          "label": "认真看他的展览邀请",
          "detail": "尊重他的退休生活，把关系带到工作之外。",
          "effects": {
            "health": 2,
            "stress": -3,
            "research": 0,
            "trust": 0,
            "reputation": 0,
            "communication": 3,
            "freedom": 0,
            "discipline": 0,
            "relations": {
              "lin": 8
            },
            "flags": [
              "mentor_legacy"
            ],
            "removeFlags": []
          },
          "result": {
            "text": "你和他一起读过邀请卡，把太小的字圈出来，再听他讲每只木盒哪里做得不够好。没有一条建议能替你解决眼下的职业难题，你却并不失望。离开时他请你届时来看看，你把那个下午当作朋友的邀请记了下来。"
          }
        },
        {
          "id": "b",
          "label": "先问他是否愿意听难处",
          "detail": "请求有限的倾听，也接受他可能拒绝。",
          "effects": {
            "health": 0,
            "stress": 0,
            "research": 0,
            "trust": 0,
            "reputation": 0,
            "communication": 4,
            "freedom": 0,
            "discipline": 2,
            "relations": {
              "lin": 4
            },
            "flags": [
              "mentor_boundary_asked"
            ],
            "removeFlags": []
          },
          "result": {
            "text": "你先说明自己有一件烦恼，再问他今天是否愿意听。林知远答应谈一会儿，到约定的时间便收住话题，继续拿出自己的木盒。你得到一些可以慢慢想的意见，也练习了不把一个人的善意理解为永远开放的门。"
          }
        },
        {
          "id": "c",
          "label": "替他把邀请送给朋友",
          "detail": "做一件具体的小事，不替他主持整个展览。",
          "effects": {
            "health": 0,
            "stress": 0,
            "research": 0,
            "trust": 3,
            "reputation": 0,
            "communication": 3,
            "freedom": 0,
            "discipline": 0,
            "relations": {
              "lin": 5
            },
            "flags": [
              "mentor_invites_delivered"
            ],
            "removeFlags": []
          },
          "result": {
            "text": "你问清他希望邀请的人，带走几张卡片，没有顺势包办场地和流程。林知远对这种恰到好处的帮忙很满意，还郑重提醒你留一张给自己。走到街上时你发现，这次你们谈得最多的，是他正在期待的下一件小事。"
          }
        }
      ]
    },
    {
      "id": "v41",
      "dateIndex": 41,
      "slot": 0,
      "priority": 10,
      "requires": {
        "flagsAll": [
          "sam_partner"
        ]
      },
      "chapter": "homeward",
      "title": "离开的那一边",
      "text": "山姆关上共同项目的办公室门，说自己准备结束这段合作，专心带领自己的小团队。他把你们共同签过的分工表带来了，也列好哪些职责需要交接。你曾希望他不必总在身后补位，如今他真的能够选择离开，你却先感到日常被挖走了一块。\n\n他没有催你说祝福，也没有把新机会说成对旧工作的否定。窗外有人招呼他去处理一件小事，他仍下意识地站起身；这些项目里的习惯，一时还没有改过来。你们都意识到，平等合作最后的一道考验，也许是允许对方不再继续为这里负责。",
      "characters": [
        "sam"
      ],
      "chain": "junior",
      "choices": [
        {
          "id": "a",
          "label": "一起完成有期限的交接",
          "detail": "支持他自主离开，自己承担留下的空缺。",
          "effects": {
            "health": 0,
            "stress": 4,
            "research": 0,
            "trust": 5,
            "reputation": 0,
            "communication": 4,
            "freedom": 0,
            "discipline": 0,
            "relations": {
              "sam": 8
            },
            "flags": [
              "junior_legacy"
            ],
            "removeFlags": []
          },
          "result": {
            "text": "你们把交接划定了结束日期，哪些能问、哪些不该再追着他解决，都写得很清楚。山姆离开前仍有些不舍，你也没有装作毫无影响。新的空缺需要你重新组织，而他终于能够带着自己的名字，去做一段不由你安排的工作。"
          }
        },
        {
          "id": "b",
          "label": "提出一次平等的续约谈话",
          "detail": "说明你的需要，接受他的最终决定。",
          "effects": {
            "health": 0,
            "stress": 3,
            "research": 0,
            "trust": 0,
            "reputation": 0,
            "communication": 4,
            "freedom": 0,
            "discipline": 0,
            "relations": {
              "sam": 2
            },
            "flags": [
              "sam_retention_open"
            ],
            "removeFlags": []
          },
          "result": {
            "text": "你把希望他留下的理由和能够改变的条件说清楚，没有搬出往年的帮助。山姆认真听完，答应给出明确回复。等待的几天让你不自在，却也让你看见，真正平等的谈话必须容得下一个仍然选择离开的答案。"
          }
        },
        {
          "id": "c",
          "label": "先坦白自己感到难过",
          "detail": "让关系容纳失落，不用情绪延长他的责任。",
          "effects": {
            "health": 0,
            "stress": 1,
            "research": 0,
            "trust": 3,
            "reputation": 0,
            "communication": 3,
            "freedom": 0,
            "discipline": 0,
            "relations": {
              "sam": 5
            },
            "flags": [
              "sam_farewell_honest"
            ],
            "removeFlags": []
          },
          "result": {
            "text": "你说自己会想念现在的合作，也担心一时找不到合适的人接手。山姆听完后没有急着安慰，反而坦白他也害怕新的开始。你们仍按原定日期交接；失落没有被否认，也没有变成拦住另一个人的理由。"
          }
        }
      ]
    },
    {
      "id": "v44",
      "dateIndex": 44,
      "slot": 0,
      "priority": 10,
      "requires": {
        "flagsAll": [
          "clear_record"
        ]
      },
      "chapter": "homeward",
      "title": "公益办公室的旧熟人",
      "text": "伊莱转去公益机构以后，已经很少穿那件深色西装。这次见面，他背着一个磨旧的布包，里面装着志愿者的报销单和还没整理好的来信。他说新工作并没有让分歧消失，只是分歧换了更贴近日常的名字。\n\n他记得你曾坚持把记录留清楚，如今有一批新来的同事想听实际经历。你愿不愿意讲，可以自己决定；他尤其提醒，不需要把故事修成一个总能战胜困难的人。窗边的打印机又卡了纸，他蹲下来拉开纸盒，等你把想法说完。",
      "characters": [
        "elias"
      ],
      "chain": "ethics",
      "choices": [
        {
          "id": "a",
          "label": "分享一次真实的艰难选择",
          "detail": "保留犹豫与代价，去除涉及他人的身份信息。",
          "effects": {
            "health": 0,
            "stress": 2,
            "research": 0,
            "trust": 0,
            "reputation": 0,
            "communication": 5,
            "freedom": 0,
            "discipline": 4,
            "relations": {
              "elias": 8
            },
            "flags": [
              "ethics_legacy"
            ],
            "removeFlags": []
          },
          "result": {
            "text": "你和伊莱先删去会暴露他人处境的细节，再把当时不知道什么、害怕什么一并写进提纲。新同事听完提出了并不客气的问题，你没有假装每个问题都已有答案。那次分享留下的是可追问的经验，而不是一张供人效仿的好人证书。"
          }
        },
        {
          "id": "b",
          "label": "帮他整理一份工作清单",
          "detail": "少谈个人故事，把经验变成可执行的小步骤。",
          "effects": {
            "health": 0,
            "stress": 0,
            "research": 3,
            "trust": 0,
            "reputation": 0,
            "communication": 0,
            "freedom": 0,
            "discipline": 4,
            "relations": {
              "elias": 4
            },
            "flags": [
              "ethics_checklist_shared"
            ],
            "removeFlags": []
          },
          "result": {
            "text": "你们从实际来信里找出反复出现的难处，写成一份注明适用范围的清单。伊莱删掉了几条听上去漂亮却做不到的话，也提醒你别把清单当作所有答案。它最后只有薄薄几页，却能让新同事知道，遇到不确定时该向谁提问。"
          }
        },
        {
          "id": "c",
          "label": "只作为朋友来见他",
          "detail": "谢绝公开分享，保留一段不被工作占满的相处。",
          "effects": {
            "health": 2,
            "stress": -3,
            "research": 0,
            "trust": 0,
            "reputation": 0,
            "communication": 0,
            "freedom": 3,
            "discipline": 0,
            "relations": {
              "elias": 5
            },
            "flags": [
              "ethics_friend_visit"
            ],
            "removeFlags": []
          },
          "result": {
            "text": "你说今天更想知道他过得怎样，伊莱把提纲放回布包，提起最近新学的一道菜。你们仍然谈到工作，却不再为了产出一份材料而寻找每句话的用处。公益办公室熄灯后，你们一起走到街口，各自继续自己的生活。"
          }
        }
      ]
    },
    {
      "id": "v49",
      "dateIndex": 49,
      "slot": 0,
      "priority": 10,
      "requires": {
        "flagsAll": [
          "family_trust"
        ]
      },
      "chapter": "homeward",
      "title": "屏幕这端的晚饭",
      "text": "诺拉把手机靠在一摞书上，让镜头能拍到她的小厨房。疫情期间，许多原本顺手就能帮忙的事情变得需要重新安排：送来的东西放在哪里，谁可以远程联系，哪些见面暂时不合适。她的工作室也换了运作方式，仍希望自己决定怎么撑过这一段。\n\n你们以前学过如何开口求助，现在又得学习怎样隔着屏幕看出一句“还好”后面有没有没说完的话。锅盖响了一下，诺拉回头关火。她问你今晚吃了什么，不需要漂亮答案，也不希望这通电话变成互相监督的检查表。",
      "characters": [
        "nora",
        "mei"
      ],
      "chain": "family",
      "choices": [
        {
          "id": "a",
          "label": "约好一段稳定的通话时间",
          "detail": "远程分担琐事，尊重彼此的生活与防护安排。",
          "effects": {
            "health": 0,
            "stress": -3,
            "research": 0,
            "trust": 5,
            "reputation": 0,
            "communication": 4,
            "freedom": 0,
            "discipline": 0,
            "relations": {
              "nora": 8
            },
            "flags": [
              "home_anchor"
            ],
            "removeFlags": []
          },
          "result": {
            "text": "你们约好一个双方能做到的通话时段，也说清忙不过来时可以怎样直接求助。需要送的东西先确认接收方式，不能见面的失落也没有被轻轻带过。那晚的饭各自在不同厨房吃完，关系却因为几件能够兑现的小事变得更有着落。"
          }
        },
        {
          "id": "b",
          "label": "帮她解决一项远程难题",
          "detail": "先问需要什么，只处理她同意交出的部分。",
          "effects": {
            "health": 0,
            "stress": 1,
            "research": 0,
            "trust": 0,
            "reputation": 0,
            "communication": 3,
            "freedom": 0,
            "discipline": 3,
            "relations": {
              "nora": 5
            },
            "flags": [
              "home_remote_task"
            ],
            "removeFlags": []
          },
          "result": {
            "text": "诺拉选了一项最费时间的整理工作，你隔着屏幕向她确认做法，再把结果发回去。她改了几处，也保留了自己不想解释的决定。你们没有因此解决所有困难，但至少这份帮助没有让她失去对自己工作室的掌握。"
          }
        },
        {
          "id": "c",
          "label": "坦白自己也撑得吃力",
          "detail": "提出可承担的联系频率，不勉强冒险见面。",
          "effects": {
            "health": 2,
            "stress": -4,
            "research": 0,
            "trust": 0,
            "reputation": 0,
            "communication": 3,
            "freedom": 0,
            "discipline": 0,
            "relations": {
              "nora": 3
            },
            "flags": [
              "home_limits_named"
            ],
            "removeFlags": []
          },
          "result": {
            "text": "你承认近来连按时吃饭都做得不太好，无法每天认真回应所有消息。诺拉听完，和你一起把联系安排调到能做到的程度。你们没有用一次仓促见面证明关心，而是留下一句可以直接发送的求助话，让沉默不必总被误解成冷淡。"
          }
        }
      ]
    },
    {
      "id": "v50",
      "dateIndex": 50,
      "slot": 0,
      "priority": 10,
      "requires": {
        "flagsAll": [
          "highload_2011",
          "highload_2014",
          "highload_2016",
          "highload_2018",
          "highload_2020"
        ],
        "max": {
          "health": 30
        },
        "min": {
          "stress": 70
        }
      },
      "chapter": "homeward",
      "title": "未说完的那一页",
      "text": "病房里的窗帘被拉开一半，你看见一小片秋天的天空。一次突发急病打断了原来的日程，病情没有按大家盼望的方向稳定下来。你清醒的时候，医护人员会解释眼前的情况，也给你留出说话和沉默的空间。没有人能够把这场病简单归到某一次选择上。\n\n诺拉隔着允许的联络方式陪着你，听得比平时慢一些。朋友们送来消息，有人说等你好些再聊，有人只是发来一张窗外的照片。你想起过去反复挤满的年份，也想起那些并未完成、却仍然属于你的日子。它们没有在此刻排成一张成败清单。\n\n你能够留下的安排有限，可以把几句话交给一个人，可以说明私人资料的去处，也可以暂时不整理任何事情。此刻不需要再完成一次漂亮的交付；无论你选择什么，亲友之后的悲伤和生活都不会因此得到一个整齐的答案。",
      "characters": [
        "nora",
        "mei",
        "lin",
        "sam"
      ],
      "chain": "health",
      "choices": [
        {
          "id": "a",
          "label": "给亲近的人留几句话",
          "detail": "说出感谢或惦念，不要求任何人作出承诺。",
          "effects": {
            "health": 0,
            "stress": 0,
            "research": 0,
            "trust": 0,
            "reputation": 0,
            "communication": 0,
            "freedom": 0,
            "discipline": 0,
            "relations": {
              "nora": 2
            },
            "flags": [
              "last_words_left",
              "death_final_choice"
            ],
            "removeFlags": []
          },
          "result": {
            "text": "你留下几句短短的话，有的说得完整，有的只叫了一个名字。后来亲友各自保存了这些声音，也会在不同时候选择暂时不听。你的人生在这一年停下，他们没有把你最后的话变成必须遵守的任务，思念仍然有各自的样子。"
          },
          "ending": "life_ended"
        },
        {
          "id": "b",
          "label": "说明私人资料的去处",
          "detail": "交代能确定的一小部分，其余允许他们再商量。",
          "effects": {
            "health": 0,
            "stress": 0,
            "research": 0,
            "trust": 0,
            "reputation": 0,
            "communication": 0,
            "freedom": 0,
            "discipline": 0,
            "relations": {
              "lin": 2
            },
            "flags": [
              "last_papers_named",
              "death_final_choice"
            ],
            "removeFlags": []
          },
          "result": {
            "text": "你指出哪些纸可以留下，哪些只是个人未完成的草稿，不需要公开。交代没有覆盖所有事情，亲友后来仍要一起商量。你的人生在这一年停下，那些资料没有替你说完全部故事，也没有替留下的人规定应该怎样记住你。"
          },
          "ending": "life_ended"
        },
        {
          "id": "c",
          "label": "请他们安静陪一会儿",
          "detail": "不再整理经历，让未说完的事情暂时留白。",
          "effects": {
            "health": 0,
            "stress": 0,
            "research": 0,
            "trust": 0,
            "reputation": 0,
            "communication": 0,
            "freedom": 0,
            "discipline": 0,
            "relations": {
              "mei": 2
            },
            "flags": [
              "last_silence_shared",
              "death_final_choice"
            ],
            "removeFlags": []
          },
          "result": {
            "text": "你没有再列清单，只请他们陪你安静待一会儿。有些话因此没有说出口，后来也没有人能够补成确定的答案。你的人生在这一年停下，亲友慢慢继续各自的日子，偶尔谈起你，也允许自己在想念时说不出任何完整的话。"
          },
          "ending": "life_ended"
        }
      ]
    },
    {
      "id": "v24_external",
      "dateIndex": 24,
      "slot": 0,
      "priority": 5,
      "chapter": "fracture",
      "title": "旧同事带来的邀请",
      "text": "玛拉以旧同事的身份联系你，说海岬有一个带小团队的空缺，想知道你是否考虑重返行业。她带来的是一份新的聘用安排，不是你已经接下的职责。离开之后走过的路，也不会因为这个电话就自动取消。\n\n你可以接受邀请，重新办理入职与交接；也可以继续现在的方向，或保留求职和过渡的时间。她需要一个明确答复，你则需要知道自己答应的是哪一种生活。",
      "characters": [
        "mara",
        "sam"
      ],
      "chain": "ambition",
      "choices": [
        {
          "id": "a",
          "label": "接受邀请，重返机构带团队",
          "detail": "明确重新入职，接下管理职责与客户权限。",
          "result": {
            "text": "你接受了新的聘用安排，说明目前需要完成的交接，再按约重新入职。玛拉与你写清权限、复核与轮值。回到行业是这次明确作出的决定，不能被写成你从来没有离开。"
          },
          "effects": {
            "career": "head",
            "authority": 10,
            "trust": 5,
            "communication": 5,
            "stress": 5,
            "flags": [
              "leader_agenda"
            ],
            "relations": {
              "sam": 4
            }
          }
        },
        {
          "id": "b",
          "label": "保留现在的职业方向",
          "detail": "谢绝这份邀请，继续现有工作或求职安排。",
          "result": {
            "text": "你谢谢玛拉把机会说明白，也明确说暂不重返机构。已经开始的新工作或仍在进行的求职，不需要被一通电话推翻。接下来，你仍按自己选定的方向走。"
          },
          "effects": {
            "research": 5,
            "health": 3,
            "freedom": 4,
            "flags": [
              "steady_work"
            ]
          }
        },
        {
          "id": "c",
          "label": "先不接受，留时间想清楚",
          "detail": "不取得新职位或客户权限，也不替以后作保证。",
          "result": {
            "text": "玛拉告诉你职位不能无限等候，你接受这个事实。你没有签下新的聘用安排，也没有因此失去继续选择的资格；空出来的时间先用来核对自己的需要。"
          },
          "effects": {
            "health": 7,
            "stress": -7,
            "freedom": 6,
            "reputation": -2,
            "flags": [
              "work_boundary"
            ]
          }
        }
      ],
      "requires": {
        "career": [
          "outside",
          "unemployed"
        ]
      }
    },
    {
      "id": "v32_independent",
      "dateIndex": 32,
      "slot": 0,
      "priority": 5,
      "chapter": "homeward",
      "title": "自己的门牌下面",
      "text": "独立业务有了新的询问，你开始需要决定能同时接多少工作、哪些说明必须亲自完成。伊莱以朋友的身份帮你读了一遍服务范围，提醒你：自己的门牌不会自动带来足够的人手。\n\n你仍在经营自己的业务，没有谁能替你决定规模。继续承担、缩小承诺、把时间留给生活，都需要你向正在合作的人说明白。",
      "characters": [
        "elias",
        "nora"
      ],
      "chain": "ambition",
      "choices": [
        {
          "id": "a",
          "label": "继续独立经营，认真安排新增工作",
          "detail": "保留独立身份，亲自承担服务范围与交付责任。",
          "result": {
            "text": "你在自己的业务计划里写下能接的工作、不能答应的期限和需要帮助的部分。你继续经营自己的业务，也继续亲自承担这些承诺。你把新增安排告诉家人，承认自由仍然需要逐项经营。"
          },
          "effects": {
            "authority": 10,
            "reputation": 7,
            "stress": 7,
            "health": -3,
            "flags": [
              "indie_capacity_reviewed"
            ],
            "relations": {
              "elias": 5
            }
          }
        },
        {
          "id": "b",
          "label": "缩小服务范围，留出余量",
          "detail": "继续独立经营，只承诺现在能够完成的部分。",
          "result": {
            "text": "你向合作方说明新的服务范围，把暂时接不了的部分退回去。机会比最初少了一些，留下的承诺却能被真正兑现。门牌仍是自己的，日历也终于按实际容量来排。"
          },
          "effects": {
            "trust": 5,
            "communication": 4,
            "health": 4,
            "freedom": 5,
            "flags": [
              "work_boundary"
            ]
          }
        },
        {
          "id": "c",
          "label": "把重心移向工作以外",
          "detail": "不把停在这里解释成失败。",
          "result": {
            "text": "你没有用一句“钱不重要”替现实收尾。工作仍然需要做好，账单仍然要付；只是下一段时间，你想把同样认真的安排给生活。"
          },
          "effects": {
            "freedom": 7,
            "stress": -6,
            "health": 5,
            "flags": [
              "life_priority",
              "steady_work"
            ]
          }
        }
      ],
      "requires": {
        "career": "independent"
      }
    },
    {
      "id": "v32_external",
      "dateIndex": 32,
      "slot": 0,
      "priority": 5,
      "chapter": "homeward",
      "title": "旧行业递来的新安排",
      "text": "玛拉问你是否考虑一份机构研究岗位。她知道你已经走上别的路，或仍在寻找合适的工作，因此先把薪水、职责和复核安排写清楚，没有把这次见面当成内部晋升。\n\n接受意味着重新入职；谢绝则保留现有方向。你也可以暂不答应，把时间留给眼下的工作、求职与生活。过去的经历让你有东西可谈，却没有替今天签字。",
      "characters": [
        "mara",
        "june"
      ],
      "chain": "ambition",
      "choices": [
        {
          "id": "a",
          "label": "接受研究岗位，重新回到机构",
          "detail": "结束当前过渡或完成原工作交接，明确重新入职。",
          "result": {
            "text": "你核对聘用安排，完成必要交接后重新入职。得到的是一份研究工作，而不是凭过去的头衔自动成为合伙人。你和玛拉约好复核方式，从能够完成的职责重新开始。"
          },
          "effects": {
            "career": "senior",
            "authority": 10,
            "reputation": 7,
            "stress": 7,
            "health": -3,
            "flags": [
              "rebuilt",
              "steady_work"
            ],
            "relations": {
              "mara": 5
            }
          }
        },
        {
          "id": "b",
          "label": "继续现在的方向",
          "detail": "谢绝机构岗位，不改变已有工作或求职身份。",
          "result": {
            "text": "你说明现在更想把原有方向走稳。玛拉接受了这个答复，机构的空缺会交给别人。你没有取得新的职位或客户权限，也不需要为保留自己的安排道歉。"
          },
          "effects": {
            "trust": 5,
            "communication": 4,
            "health": 4,
            "freedom": 5,
            "flags": [
              "work_boundary"
            ]
          }
        },
        {
          "id": "c",
          "label": "暂不接受，先安排眼下的生活",
          "detail": "不签新的聘用安排，继续原来的工作或求职。",
          "result": {
            "text": "你重新核对近期账单与能承担的安排，把旧行业的邀请暂时放下。接下来仍按原来的工作或求职计划走，也为今天真正需要处理的生活留出时间。"
          },
          "effects": {
            "freedom": 7,
            "stress": -6,
            "health": 5,
            "flags": [
              "life_priority",
              "steady_work"
            ]
          }
        }
      ],
      "requires": {
        "career": [
          "outside",
          "unemployed"
        ]
      }
    }
  ],
  "endings": [
    {
      "id": "life_ended",
      "kind": "death",
      "priority": 1000,
      "title": "留在这一年的名字",
      "requires": {
        "flagsAll": [
          "death_final_choice",
          "highload_2011",
          "highload_2014",
          "highload_2016",
          "highload_2018",
          "highload_2020"
        ],
        "min": {
          "dateIndex": 50,
          "stress": 70
        },
        "max": {
          "health": 30
        }
      },
      "text": "你的人生在2020年停下，四十四岁。亲友没有因此得到一张能解释一切的清单。疾病不是对野心、疲惫或某次错误选择的判决，故事也不声称知道现实里谁会因何病倒。\n\n此前多年，减少承诺与接受支持曾一次次摆在面前；在这条虚构人生里，它们多次被推后。这些经历构成你生活的背景，却不是一条医学定律。诺拉保留一些消息，梅继续自己的工作，朋友有时聚在一起，也会各自沉默。\n\n账户与遗留事务需要由适当的人按真实程序处理。这里不把死亡算作输掉比赛，也不替留下的人规定怎样悲伤。一个人没有完成的愿望，仍然可以被认真记得。"
    },
    {
      "id": "both_whole",
      "priority": 900,
      "title": "钱有余地，日子有人",
      "requires": {
        "flagsAll": [
          "shared_calendar",
          "home_anchor",
          "work_boundary"
        ],
        "min": {
          "wealth": 250000,
          "personalTwr": 0.05,
          "health": 55,
          "freedom": 45,
          "relations.mei": 55,
          "relations.nora": 55
        }
      },
      "text": "四十四岁时，你终于能够把账户和日历放在同一张桌上看。实际积累的个人净资产给生活留出余地，投资记录也留下了扣除外部收支之后的正回报；它们没有替你制造感情，却减少了一些不得不答应的事情。\n\n梅的工作仍有自己的方向，诺拉也会拒绝你自以为周到的建议。你们学会问清安排，而不是要求彼此一直方便。你没有把每个职业机会都接住，也没有把幸福写成从此不会争吵。\n\n这条人生里的两全并不完整。它只是你同时照料了几件重要的东西，而且在它们起冲突时，愿意提早开口。明天仍可能难，但你已不必只靠一个账户的数字证明自己过得好。"
    },
    {
      "id": "drawdown_years",
      "priority": 850,
      "title": "亏掉的钱，留下的日子",
      "requires": {
        "flagsAll": [
          "rescue_bet",
          "loss_understood"
        ],
        "max": {
          "personalTwr": -0.15
        }
      },
      "text": "旧港家居的旧股权归零，账本没有因为你需要一个好结局就换一种写法。一度加重的个人持仓，确实留下了严重的投资损失；工资、其他资产和债务另有各自的记录，不能拿来遮住这笔亏损。\n\n你曾希望价格回头时，所有疑问也能一起消失。后来回看，最难承认的是：想把钱赢回来，和生意已经变好，并不是同一件事。这个认识来得昂贵，也不自动让下一次判断正确。\n\n生活没有在证券注销那天同时注销。你仍要工作、处理账单、回应关心，也可能需要很久才能谈起这段经历。这里留下的是一条受损却继续的人生，接下来的选择仍有重量。"
    },
    {
      "id": "independent_home",
      "priority": 820,
      "title": "一张由自己排的日历",
      "requires": {
        "career": "independent",
        "flagsAll": [
          "indie_launched",
          "rules_owned",
          "indie_renewed"
        ],
        "min": {
          "wealth": 0,
          "trust": 45
        }
      },
      "text": "你的小机构仍然需要解释费用、回答客户，也会为下一年的收入担心。它没有因为挂上你的名字就自动自由；真正改变的是，你逐渐把服务范围、退出办法和能承担的承诺写进了经营方式。\n\n个人资产和机构收入分开记账，客户的钱也从未成为你的创业储蓄。账本给出的结果可能并不耀眼，却让你知道哪些生活能够维持，哪些扩张暂时负担不起。\n\n有人觉得你本可以去更大的地方。你并不急着反驳。四十四岁的你仍有野心，只是现在愿意先看一眼日历，再决定要不要为它增加一把椅子。"
    },
    {
      "id": "worn_success",
      "priority": 800,
      "title": "高处的灯一直亮着",
      "requires": {
        "career": [
          "head",
          "partner"
        ],
        "flagsAll": [
          "career_peak"
        ],
        "min": {
          "stress": 65
        },
        "max": {
          "health": 45
        }
      },
      "text": "职位和责任都是真的，你在会议里说的话也比二十年前更有分量。只是回到家时，经常连决定吃什么都觉得费力。你知道许多人的截止日，却越来越难说出自己下一次休息是哪天。\n\n这不是对努力的嘲讽。那些工作曾帮助你站稳，也给过你真实的满足。问题在于，你总把下一轮交付当作可以开始生活的门槛，门槛却一年年往后移动。\n\n四十四岁还不是最终判决。身边有人愿意谈分工，也有人已不再替你保留每次缺席的位置。你得到过想要的机会，同时需要承认，疲惫不能无限延期处理。"
    },
    {
      "id": "capital_room",
      "priority": 760,
      "title": "可以不答应的底气",
      "requires": {
        "flagsAll": [
          "wealth_frame",
          "compound_patience"
        ],
        "min": {
          "wealth": 500000,
          "personalTwr": 0.2
        }
      },
      "text": "你积累了一笔确实可核对的个人净资产。扣除工资、消费和其他外部现金流后，投资本身也留下了正回报。它来自有限的持有、等待和修正，并不证明你能看透下一轮市场。\n\n这笔钱最具体的作用，不是让所有人都承认你成功，而是让你在某些会议、某份工作和某次额外要求面前，可以认真考虑说不。它没有替你修好每段关系，已经错过的日子也不会自动回来。\n\n你把下一年的预算分成几个用途，发现愿望不必全部围绕收益率。此后的生活仍需要你去安排；账户只是终于给了安排更多空间。"
    },
    {
      "id": "quiet_good_life",
      "priority": 720,
      "title": "工作平常，生活很好",
      "requires": {
        "career": [
          "outside",
          "senior"
        ],
        "flagsAll": [
          "home_anchor",
          "life_priority"
        ],
        "min": {
          "health": 55,
          "relations.nora": 55,
          "freedom": 45
        }
      },
      "text": "你没有成为那家机构最耀眼的人。有些旧同事换了更长的头衔，你仍做着能够说明白、也能按时结束的一份工作。收入与资产都有边界，日常却不因此失去分量。\n\n诺拉知道什么时候能找到你，梅也不必先问有没有打扰工作。你们并非每天都快乐，只是遇到需要帮忙、庆祝或一起无聊的时候，彼此更常真正出现。\n\n四十四岁的生活没有戏剧性的最后一跃。它有一顿做得太咸的饭、一段普通的散步，也有明天能够继续的安排。你慢慢接受，这些事情本身就值得留下时间。"
    },
    {
      "id": "rebuilt",
      "priority": 680,
      "title": "断过的路，重新走稳",
      "requires": {
        "career": [
          "senior",
          "manager",
          "head",
          "partner"
        ],
        "flagsAll": [
          "job_lost",
          "rebuilt",
          "rebuilt_stable"
        ],
        "min": {
          "trust": 45
        }
      },
      "text": "失业那一年没有从简历里消失，也没有变成一句轻巧的“都是最好的安排”。你确实担心过钱，等过没有回音的邮件，重新做过原以为早已不用再做的杂事。\n\n后来的小团队给了你一份工作，你也用持续的交付把它做成可以信任的位置。重建没有把过去的收入补齐，却让你不再只能用失去的头衔介绍自己。\n\n四十四岁时，你对另一个走进门的求职者，会多问一句当下最需要什么。不是因为你能保证他的以后，而是你记得，人在等待答案的时候，也仍然需要被当作一个完整的人。"
    },
    {
      "id": "shared_light",
      "priority": 650,
      "title": "别人在教室里接着讲",
      "requires": {
        "flagsAll": [
          "class_started",
          "class_return",
          "class_shared",
          "school_end"
        ],
        "min": {
          "relations.darius": 50
        }
      },
      "text": "最后一次收好教室时，你没有把全部材料带走。新的讲师已经改掉几页讲义，加入了自己遇到的问题；课程还在继续，也越来越不像只有你能完成的事。\n\n你解释过账单、储蓄、风险和不知道。它们没有让每个人都富裕起来，却有时让一个原本不敢开口的人，能够把自己的问题完整问完。达里厄斯记得这件事，也记得你什么时候需要别人替一堂课。\n\n你的生活还有工作和私人烦恼，不是一座为帮助别人而立的纪念碑。只是四十四岁回看时，有一盏灯已经不需要你亲手去开，也照着后来走进房间的人。"
    },
    {
      "id": "ordinary_days",
      "priority": 0,
      "title": "未完成，也继续生活",
      "text": "四十四岁，你没有为自己找到一个足以概括全部经历的称呼。某些决定带来好结果，某些只是让日子得以继续；还有一些，到现在也很难知道换一种选择会怎样。\n\n工作、个人资产、客户的资金、亲近的人，各有自己的记录。它们没有被合成一张总分表。你可以承认一段关系变远，也可以承认自己做成过一些事情，不必让一种评价吞掉另一种。\n\n未实现的愿望仍然在。有的需要放下，有的可以换一种速度尝试。今晚你把记录收好，明天没有写完，但生活已经发生过，也仍将继续。"
    }
  ],
  "chains": [
    {
      "id": "archive",
      "title": "黄纸与旧档案",
      "nodes": [
        "n00_0",
        "n01_0",
        "n08_0",
        "v24",
        "v40"
      ],
      "flags": [
        "kept_notes",
        "archive_shared",
        "mentor_legacy"
      ]
    },
    {
      "id": "family",
      "title": "从便条到家人的工作室",
      "nodes": [
        "n00_1",
        "n06_1",
        "v30",
        "v49"
      ],
      "flags": [
        "home_call",
        "shared_care",
        "family_trust",
        "home_anchor"
      ]
    },
    {
      "id": "clients",
      "title": "钱的使用日期",
      "nodes": [
        "n03_0",
        "n19_0",
        "n22_0",
        "v35"
      ],
      "flags": [
        "client_dates",
        "crisis_calls",
        "client_window",
        "client_legacy"
      ]
    },
    {
      "id": "ethics",
      "title": "可以让别人复核的记录",
      "nodes": [
        "n05_0",
        "n15_0",
        "n28_0",
        "v44"
      ],
      "flags": [
        "clear_record",
        "research_boundaries",
        "boundary_followed",
        "ethics_legacy"
      ]
    },
    {
      "id": "friend",
      "title": "两个人各有一份日历",
      "nodes": [
        "n02_1",
        "n12_1",
        "v27",
        "v37"
      ],
      "flags": [
        "promise_date",
        "mei_supported",
        "mei_equal",
        "shared_calendar"
      ]
    },
    {
      "id": "junior",
      "title": "署名、帮助与平等离开",
      "nodes": [
        "n07_0",
        "v18",
        "v26",
        "n34_0",
        "v41"
      ],
      "flags": [
        "sam_credit",
        "sam_helped",
        "sam_bridge",
        "sam_partner",
        "junior_legacy"
      ]
    },
    {
      "id": "risk",
      "title": "先写下会改变判断的事情",
      "nodes": [
        "n01_0",
        "n16_0",
        "n20_0",
        "n33_0",
        "n48_0"
      ],
      "flags": [
        "exit_reason",
        "risk_rehearsed",
        "crisis_method",
        "patient_reset",
        "risk_legacy"
      ]
    },
    {
      "id": "repair",
      "title": "工作证消失以后",
      "nodes": [
        "n20_1",
        "v22",
        "n27_0",
        "v34"
      ],
      "flags": [
        "job_lost",
        "rebuilt",
        "second_offer",
        "rebuilt_stable"
      ]
    },
    {
      "id": "school",
      "title": "不只自己会讲的一堂课",
      "nodes": [
        "n10_1",
        "n23_1",
        "v32",
        "n51_0"
      ],
      "flags": [
        "class_started",
        "class_return",
        "class_shared",
        "school_end"
      ]
    },
    {
      "id": "autonomy",
      "title": "把自由写进经营边界",
      "nodes": [
        "n14_0",
        "v28",
        "v31",
        "v39"
      ],
      "flags": [
        "independence_seed",
        "indie_launched",
        "rules_owned",
        "indie_renewed"
      ]
    },
    {
      "id": "health",
      "title": "一直往后推的调整",
      "nodes": [
        "n04_1",
        "n16_1",
        "n25_1",
        "n31_1",
        "n35_1",
        "n39_1",
        "n49_1",
        "v50"
      ],
      "flags": [
        "load_early",
        "highload_2007",
        "highload_2011",
        "highload_2014",
        "highload_2016",
        "highload_2018",
        "highload_2020",
        "death_final_choice"
      ]
    },
    {
      "id": "wealth",
      "title": "为未知用途留下余地",
      "nodes": [
        "n00_1",
        "n02_0",
        "n11_1",
        "n21_0",
        "v38",
        "n44_0"
      ],
      "flags": [
        "seed_saving",
        "cash_buffer",
        "kept_ownership",
        "compound_patience",
        "wealth_frame"
      ]
    },
    {
      "id": "ambition",
      "title": "从门牌到会议桌",
      "nodes": [
        "n01_1",
        "n13_0",
        "n24_0",
        "n32_0",
        "n41_0"
      ],
      "flags": [
        "promotion_requested",
        "manager_accepted",
        "leader_agenda",
        "partner_accepted",
        "career_peak"
      ]
    }
  ],
  "saveCompatibility": {
    "resultText": [
      {
        "nodeId": "n00_1",
        "choiceId": "b",
        "from": "你回家核对账单，设置了这次还款。余额并没有神奇地消失，接下来几个月却更容易估计。你给姐姐回了消息，约好下次再谈具体日期。",
        "to": "你回家核对账单，按可用现金的20%偿还，最多还到实际欠款为零。有的开局这笔钱足够结清，有的仍需慢慢还；准确的余额留在账本里，你也给姐姐回了消息。"
      },
      {
        "nodeId": "n02_0",
        "choiceId": "b",
        "from": "你没有参与今天这笔买入。还款回执很安静，没有可以夸耀的曲线，但它减少了一项确定的支出，也留下将来再选择的空间。",
        "to": "你没有参与今天这笔买入。若仍有欠款，账户用可用现金按既定比例偿还；若债务已清，就保留现金，不制造一张零金额的还款回执。负担与投资机会分别记账。"
      },
      {
        "nodeId": "n11_1",
        "choiceId": "b",
        "from": "你把还款回执收好，没有把它当作错过行情的证据。债务少了一部分，剩下的钱才真正有资格承担另外一种用途。",
        "to": "你先核对实际欠款，再使用可用现金偿还其中一部分。若此前已经还清，这次不会再次扣钱；没有涨跌曲线的财务整理，也值得认真对照账单完成。"
      },
      {
        "nodeId": "n28_1",
        "choiceId": "b",
        "from": "玛拉愿意讨论你想保留的部分，也指出需要让出的机会。你没有得到所有想要的东西，但得到了一份比模糊期待更可执行的安排。",
        "to": "你接受玛拉提供的研究岗位安排，确认入职或岗位调整的手续，以及需要完成的交接。选择留在或回到机构由这次答复明确下来，职责与时间边界也写得比模糊期待更清楚。"
      },
      {
        "nodeId": "n30_0",
        "choiceId": "b",
        "from": "玛拉要求你列出不能接的项目。你把名单交了出去，发现承认边界比说“都可以”难，却也让团队第一次能照着真实的容量安排工作。",
        "to": "你和相关的人一起列出不能接的项目。承认边界比说“都可以”难，却让彼此第一次能照着真实的容量安排工作。"
      },
      {
        "nodeId": "n31_1",
        "choiceId": "c",
        "from": "你认真描述了近期状态，也与主管谈清能够承担的数量。没有人给出关于余生的保证，改变至少已经进入下一周的安排。",
        "to": "你认真描述了近期状态，也重新确认自己能够承担的工作与承诺。没有人给出关于余生的保证，改变至少已经进入下一周的安排。"
      },
      {
        "nodeId": "n32_1",
        "choiceId": "c",
        "from": "你把能想到的风险认真讲完，随后把名字从常驻名单上拿掉。课堂会继续，这不需要被解释成你曾经的努力不够重要。",
        "to": "你把能想到的风险认真讲完，并说明这次只提供建议，不加入常驻名单。课堂会继续，固定位置留给有余力承担的人；有限的帮助也可以有清楚的边界。"
      },
      {
        "nodeId": "n35_1",
        "choiceId": "a",
        "from": "你向主管保证进度，接受了新的截止日。诺拉听完只说，她希望下次联系时听到的不只是工作。你没有答应调整，这一点被时间真实地记下了。",
        "to": "你向等候交付的人保证进度，接受了新的截止日。诺拉听完只说，她希望下次联系时听到的不只是工作。你没有答应调整，这一点被时间真实地记下了。"
      },
      {
        "nodeId": "n38_0",
        "choiceId": "b",
        "from": "还款没有替你带来市场上的胜负，却减少了未来必须支付的一部分。你重新看见个人资金的多个来源，也更少把工资储蓄误认成选股本领。",
        "to": "如果仍有欠款，个人现金将按实际余额偿还，减少相应债务；如果已经没有欠款，现金就留在账户里。这次决定不被记成投资收益，也不会让同一笔债被重复偿还。"
      },
      {
        "nodeId": "n39_1",
        "choiceId": "a",
        "from": "你把清单推回去，承诺按时完成。玛拉没有把这种做法写成团队标准，诺拉也仍愿意接你的电话。负荷继续留下，没有被赞许抵消。",
        "to": "你把清单推回去，承诺按时完成。对方没有把这种做法当成往后的默认安排，诺拉也仍愿意接你的电话。负荷继续留下，没有被赞许抵消。"
      },
      {
        "nodeId": "n43_0",
        "choiceId": "b",
        "from": "如果仍持有可交易份额，账户会按实际数量调整。你可能为卖出后上涨而遗憾，也可能因此少承担损失；今天能确认的只有仓位变得更有限。",
        "to": "只有实际持仓超过目标时，账户才会卖出超过的部分；没有持仓或已低于目标就不成交。你可能为以后价格的变化而遗憾，今天能够确认的是自己愿意承担的上限，而不是一笔尚未发生的盈利。"
      },
      {
        "nodeId": "n51_0",
        "choiceId": "a",
        "from": "你们完成最后一次核对，然后把钥匙交给接手者。那不是对个人成绩的封存，而是允许一件工作继续长成与你不同的样子。",
        "to": "你们核对了愿意分享的材料，再把它们交给后续负责课程的人。那不是对个人成绩的封存，而是允许有用的办法继续长成与你不同的样子。"
      },
      {
        "nodeId": "n51_0",
        "choiceId": "c",
        "from": "你把未完成的部分说明白，没有用突然消失来结束关系。教室还有别的人，日历也会出现新的安排；离开并不要求否认曾经在意。",
        "to": "你说明这次能够提供的建议，也明确自己不会接下固定工作。教室还有别的人，日历也会出现新的安排；保留距离并不要求否认曾经在意。"
      },
      {
        "nodeId": "v27",
        "choiceId": "a",
        "from": "你们划掉原来的日期，各自说出无法让步的安排，再找出真正能相见的空档。新的日历不如旧约定好看，却更像两个人的生活。梅收起行程表时没有承诺永远不冲突，你也不再把每次改期都当作谁不够在意。",
        "to": "你们调整眼下的日期，各自说出无法让步的安排，再找出真正能相见的空档。新的日历不如旧约定好看，却更像两个人的生活。梅收起行程表时没有承诺永远不冲突，你也不再把每次改期都当作谁不够在意。"
      },
      {
        "nodeId": "v28",
        "choiceId": "b",
        "from": "你在下一年的工作安排上签了字，把草案另存为一个写着回看日期的版本。延期让预算松动了一些，也意味着仍要接受现有规则。你没有对旁人宣称梦想已经实现，只给自己留下了一份可以重新打开的准备清单。",
        "to": "你把接下来的工作或求职安排写进日历，把草案另存为一个写着回看日期的版本。创业费用暂不支出，筹备仍然需要时间；这份清单留待真正具备条件时再打开。"
      },
      {
        "nodeId": "v28",
        "choiceId": "b",
        "from": "你把草案另存为一个写着回看日期的版本，先整理眼前能够继续的工作或求职安排。创业费用暂时不必支出，但原有的收入与等待也不会因此改变。你没有对旁人宣称梦想已经实现，只留下一份可以重新打开的准备清单。",
        "to": "你把接下来的工作或求职安排写进日历，把草案另存为一个写着回看日期的版本。创业费用暂不支出，筹备仍然需要时间；这份清单留待真正具备条件时再打开。"
      }
    ],
    "sceneDestinations": [
      {
        "from": "n24_0",
        "to": [
          "v24_external"
        ]
      },
      {
        "from": "n32_0",
        "to": [
          "v32_independent",
          "v32_external"
        ]
      }
    ],
    "endingText": [
      {
        "endingId": "drawdown_years",
        "from": "旧港家居的旧股权归零，账本没有因为你需要一个好结局就换一种写法。那几次加重的个人持仓，确实留下了严重的投资损失；工资、其他资产和债务另有各自的记录，不能拿来遮住这笔亏损。\n\n你曾希望价格回头时，所有疑问也能一起消失。后来回看，最难承认的是：想把钱赢回来，和生意已经变好，并不是同一件事。这个认识来得昂贵，也不自动让下一次判断正确。\n\n生活没有在证券注销那天同时注销。你仍要工作、处理账单、回应关心，也可能需要很久才能谈起这段经历。这里留下的是一条受损却继续的人生，接下来的选择仍有重量。",
        "to": "旧港家居的旧股权归零，账本没有因为你需要一个好结局就换一种写法。一度加重的个人持仓，确实留下了严重的投资损失；工资、其他资产和债务另有各自的记录，不能拿来遮住这笔亏损。\n\n你曾希望价格回头时，所有疑问也能一起消失。后来回看，最难承认的是：想把钱赢回来，和生意已经变好，并不是同一件事。这个认识来得昂贵，也不自动让下一次判断正确。\n\n生活没有在证券注销那天同时注销。你仍要工作、处理账单、回应关心，也可能需要很久才能谈起这段经历。这里留下的是一条受损却继续的人生，接下来的选择仍有重量。"
      }
    ]
  }
};
