/* The Unrealized Life — deterministic financial ledger, USD, no leverage.
 * Cost basis: weighted average, purchase fees capitalized; sale fees reduce proceeds.
 * ACT/365 XIRR. TWR geometrically links valuation intervals around every external flow.
 * Missing quotes retain the last disclosed mark and are explicitly reported as stale.
 * This module does not create prices, authorize institutional trades or settle taxes.
 */
(function (root, factory) {
  'use strict';
  const api = factory();
  if (typeof module === 'object' && module.exports) module.exports = api;
  root.Finance = api;
})(typeof globalThis !== 'undefined' ? globalThis : this, function () {
  'use strict';
  const EPS = 1e-8, LIMIT = 1e15, DAY = 86400000;
  const own = (o, k) => Object.prototype.hasOwnProperty.call(o, k);
  const finite = n => typeof n === 'number' && Number.isFinite(n);
  const money = n => finite(n) && Math.abs(n) <= LIMIT;
  const clean = n => Math.abs(n) < 1e-10 ? 0 : n;
  const rounding = (a, b) => 4 * Number.EPSILON * Math.max(Math.abs(a), Math.abs(b));
  // Reject deltas below the current balance's representable precision. Otherwise
  // a tiny buy can add shares without debiting cash, or a tiny sale can pay cash
  // without removing shares. This is relative to the order, not the account.
  const preciseChange = (before, delta) => delta === 0 || (before + delta !== before && Math.abs(((before + delta) - before) - delta) <= Math.abs(delta) * 1e-8);
  const bounded = values => values.every(money);
  const factorAfter = (factor, value, previousValue) => previousValue > 0 ? factor * (value / previousValue) : factor;
  const fail = (code, error) => ({ ok: false, code, error });
  const idOK = id => typeof id === 'string' && /^[A-Za-z0-9_.:-]{1,100}$/.test(id) && !['__proto__', 'constructor', 'prototype'].includes(id);
  function timestamp(date) {
    if (typeof date !== 'string' || !/^\d{4}-\d{2}-\d{2}$/.test(date)) return null;
    const t = Date.parse(date + 'T00:00:00Z');
    return Number.isFinite(t) && new Date(t).toISOString().slice(0, 10) === date ? t : null;
  }
  function daysBetween(a, b) {
    const aa = timestamp(a), bb = timestamp(b);
    return aa === null || bb === null ? null : (bb - aa) / DAY;
  }
  function accountError(a, date) {
    if (!a || a.version !== 1 || !money(a.cash) || a.cash < -EPS || !a.positions || !Array.isArray(a.ledger)) return fail('invalid_account', '账户结构无效');
    if (timestamp(date) === null) return fail('invalid_date', '日期必须是有效的 YYYY-MM-DD');
    if (date < a.date) return fail('backdated_operation', '不能在已结算日期之前补做资金操作');
    return null;
  }
  function cagr(start, end, days) {
    if (!money(start) || !money(end) || !finite(days) || start <= 0 || end < 0 || days <= 0) return null;
    const r = end === 0 ? -1 : Math.expm1(Math.log(end / start) * 365 / days);
    return finite(r) ? r : null;
  }
  function drawdown(points) {
    let peak = null, worst = 0;
    for (const point of points || []) {
      const v = typeof point === 'number' ? point : (point.unitValue ?? point.factor ?? point.value ?? point.nav);
      if (!finite(v) || v < 0) continue;
      if (peak === null || v > peak) peak = v;
      if (peak > 0) worst = Math.min(worst, v / peak - 1);
    }
    return clean(worst);
  }

  /* All real roots of an exponential polynomial are isolated between the roots
   * of its derivative. This catches multiple and tangent roots, unlike Newton
   * iteration with one guess. Work in log(1+r), normalizing exponent sums. */
  function exponentialRoots(input) {
    const terms = input.map(x => ({ t: x.t - input[0].t, c: x.c }));
    const max = Math.max(...terms.map(x => Math.abs(x.c)));
    terms.forEach(x => { x.c /= max; });
    if (terms.length <= 1) return { roots: [], tangent: false, failed: false };
    const value = x => {
      const logs = terms.map(v => Math.log(Math.abs(v.c)) - v.t * x);
      const scale = Math.max(...logs);
      let sum = 0, correction = 0;
      for (let i = 0; i < terms.length; i++) {
        const y = Math.sign(terms[i].c) * Math.exp(logs[i] - scale) - correction;
        const next = sum + y;
        correction = (next - sum) - y;
        sum = next;
      }
      return sum;
    };
    const derivative = terms.slice(1).map(v => ({ t: v.t, c: -v.t * v.c }));
    const sub = exponentialRoots(derivative);
    if (sub.failed) return sub;
    const critical = sub.roots, roots = [], edges = [-Infinity, ...critical, Infinity];
    let tangent = false;
    for (const x of critical) {
      if (Math.abs(value(x)) < 1e-11) { roots.push(x); tangent = true; }
    }
    const signAt = x => x === -Infinity ? Math.sign(terms[terms.length - 1].c) : x === Infinity ? Math.sign(terms[0].c) : Math.sign(value(x));
    for (let i = 0; i < edges.length - 1; i++) {
      let lo = edges[i], hi = edges[i + 1];
      if ((finite(lo) && Math.abs(value(lo)) < 1e-11) || (finite(hi) && Math.abs(value(hi)) < 1e-11)) continue;
      const sl = signAt(lo), sh = signAt(hi);
      if (sl === sh) continue;
      if (!finite(lo)) {
        lo = finite(hi) ? Math.min(hi - 1, -1) : -1;
        let count = 0;
        while (signAt(lo) !== sl && count++ < 60) lo -= Math.max(1, Math.abs(lo));
        if (count >= 60) return { roots: [], tangent: false, failed: true };
      }
      if (!finite(hi)) {
        hi = Math.max(lo + 1, 1);
        let count = 0;
        while (signAt(hi) !== sh && count++ < 60) hi += Math.max(1, Math.abs(hi));
        if (count >= 60) return { roots: [], tangent: false, failed: true };
      }
      for (let j = 0; j < 180; j++) {
        const mid = (lo + hi) / 2, sm = signAt(mid);
        if (sm === 0 || hi - lo < 1e-13 * Math.max(1, Math.abs(mid))) { lo = hi = mid; break; }
        if (sm === sl) lo = mid; else hi = mid;
      }
      roots.push((lo + hi) / 2);
    }
    roots.sort((a, b) => a - b);
    return { roots: roots.filter((x, i) => !i || Math.abs(x - roots[i - 1]) > 1e-9), tangent, failed: false };
  }
  function xirr(flows) {
    const answer = (rate, reason, roots = []) => ({ rate, reason, roots, dayCount: 'ACT/365', method: '指数多项式递归导数区间隔离与二分法' });
    if (!Array.isArray(flows) || !flows.length || flows.some(f => !f || timestamp(f.date) === null || !money(f.amount))) return answer(null, 'invalid_cash_flows');
    const dates = new Map();
    for (const f of flows) dates.set(f.date, (dates.get(f.date) || 0) + f.amount);
    const all = [...dates].sort((a, b) => a[0].localeCompare(b[0]));
    if (all.length < 2) return answer(null, 'zero_holding_days');
    const nonzero = all.filter(x => x[1] !== 0);
    if (!nonzero.length) return answer(null, 'infinite_solutions');
    if (nonzero.length > 256) return answer(null, 'too_many_cash_flow_dates');
    if (!nonzero.some(x => x[1] > 0) || !nonzero.some(x => x[1] < 0)) return answer(null, 'no_sign_change');
    const terms = nonzero.map(x => ({ t: daysBetween(nonzero[0][0], x[0]) / 365, c: x[1] }));
    const solved = exponentialRoots(terms);
    if (solved.failed) return answer(null, 'numerical_limit');
    const roots = solved.roots.map(x => Math.expm1(x));
    if (roots.some(x => !finite(x) || x <= -1)) return answer(null, 'rate_outside_numeric_range', roots.filter(x => finite(x) && x > -1));
    if (roots.length > 1) return answer(null, 'multiple_roots', roots);
    if (solved.tangent) return answer(null, 'tangent_root_ambiguous', roots);
    if (!roots.length) return answer(null, 'no_solution');
    return answer(clean(roots[0]), null, roots);
  }

  function createAccount(initialCash, date) {
    if (!money(initialCash) || initialCash < 0 || timestamp(date) === null) throw new TypeError('初始现金或日期无效');
    return {
      version: 1, currency: 'USD', date, startDate: date, cash: initialCash,
      positions: {}, ledger: [{ seq: 1, type: 'external_flow', date, amount: initialCash, reason: '初始资金', cashAfter: initialCash }],
      externalFlows: [{ date, amount: initialCash, reason: '初始资金' }],
      history: [{ date, nav: initialCash, unitValue: 1, twr: 0, kind: 'initial', stale: [] }],
      prices: {}, quoteDates: {}, appliedActions: {}, twrFactor: 1, lastNav: initialCash,
      totals: { realized: 0, dividends: 0, fees: 0, expenses: 0 }, priceBasis: 'raw',
      sampling: '完整可核验报价的决策日最终净值；排除含陈旧估值的节点，同日后续结算覆盖；不是日内最大回撤'
    };
  }
  function values(a, overrides, date) {
    let marketValue = 0, unrealized = 0;
    const stale = [], missing = [];
    for (const [id, p] of Object.entries(a.positions)) {
      if (p.quantity <= 0) continue;
      const provided = overrides && own(overrides, id) && finite(overrides[id]) && overrides[id] >= 0;
      const price = provided ? overrides[id] : a.prices[id];
      if (!finite(price) || price < 0) { missing.push(id); continue; }
      if (!provided && a.quoteDates[id] !== date) stale.push(id);
      const v = p.quantity * price;
      marketValue += v;
      unrealized += v - p.cost;
    }
    return { nav: a.cash + marketValue, cash: a.cash, marketValue, unrealized, stale, missing };
  }
  function ledger(a, entry) {
    a.ledger.push({ seq: a.ledger.length + 1, ...entry, cashAfter: a.cash });
  }
  function sample(history, point) {
    const last = history[history.length - 1];
    // Cash distributions and their ex-distribution marks are settled in one
    // date. Keep only the final date valuation, never the mechanical interim
    // cash-plus-cum-distribution peak. Retain the initial unit baseline.
    if (last && last.date === point.date && !['initial', 'start'].includes(last.kind)) history[history.length - 1] = point;
    else history.push(point);
  }
  function positionSample(p, date, marketValue, distribution = 0, kind = 'mark') {
    distribution += p.pendingDistribution || 0;
    p.pendingDistribution = 0;
    p.performanceFactor = factorAfter(p.performanceFactor, marketValue + distribution, p.lastValue);
    p.lastValue = marketValue;
    sample(p.history, { date, marketValue, unitValue: clean(p.performanceFactor), kind });
  }
  function snapshot(a, date, kind, external = false) {
    const v = values(a, null, date);
    if (!external) a.twrFactor = factorAfter(a.twrFactor, v.nav, a.lastNav);
    a.lastNav = v.nav;
    a.date = date;
    sample(a.history, { date, nav: clean(v.nav), unitValue: clean(a.twrFactor), twr: clean(a.twrFactor - 1), kind, stale: v.stale.slice() });
    return v;
  }
  function mark(a, date, pricesById = {}) {
    const e = accountError(a, date); if (e) return e;
    if (!pricesById || typeof pricesById !== 'object' || Array.isArray(pricesById)) return fail('invalid_quotes', '估值行情无效');
    for (const [id, p] of Object.entries(pricesById)) {
      if (!idOK(id) || !money(p) || p < 0) return fail('invalid_quote', '行情必须是非负有限价格');
    }
    const v = values(a, pricesById, date);
    if (v.missing.length) return fail('missing_quote', '持仓缺少已知估值：' + v.missing.join('、'));
    if (!money(v.nav)) return fail('numeric_limit', '账户金额超出计算范围');
    if (!money(factorAfter(a.twrFactor, v.nav, a.lastNav))) return fail('numeric_return_limit', '累计收益指数超出可计算范围');
    for (const [id, p] of Object.entries(a.positions)) {
      if (p.quantity <= 0) continue;
      const px = own(pricesById, id) ? pricesById[id] : a.prices[id];
      const factor = factorAfter(p.performanceFactor, p.quantity * px + (p.pendingDistribution || 0), p.lastValue);
      if (!money(factor)) return fail('numeric_return_limit', '个股累计收益指数超出可计算范围');
    }
    for (const [id, price] of Object.entries(pricesById)) {
      a.prices[id] = price;
      a.quoteDates[id] = date;
    }
    for (const [id, p] of Object.entries(a.positions)) {
      if (p.quantity > 0 && a.quoteDates[id] === date) positionSample(p, date, p.quantity * a.prices[id]);
    }
    const current = snapshot(a, date, 'mark');
    return { ok: true, ...current, twr: clean(a.twrFactor - 1) };
  }
  function tradeCheck(a, o, selling) {
    if (!o) return fail('invalid_order', '订单无效');
    const e = accountError(a, o.date); if (e) return e;
    if (!idOK(o.id) || !money(o.price) || o.price <= 0 || !money(o.quantity) || o.quantity <= 0 || !finite(o.feeRate ?? 0) || (o.feeRate ?? 0) < 0 || (o.feeRate ?? 0) > 1) return fail('invalid_order', '价格、数量或费率无效');
    if (o.authorized === false) return fail('unauthorized', '尚未取得该笔交易授权');
    if (o.tradable === false || o.status === 'suspended' || o.status === 'unlisted' || o.status === 'cancelled') return fail('not_tradable', '证券在该日期不可交易');
    if (a.positions[o.id]?.cancelled || Object.values(a.appliedActions).some(x => x.companyId === o.id && ['cancel', 'cash_merger'].includes(x.type))) return fail('cancelled_equity', '原普通股已注销，不能以原身份重新买入');
    const gross = o.quantity * o.price, fee = gross * (o.feeRate ?? 0);
    if (!money(gross + fee) || gross <= 0) return fail('numeric_limit', '订单金额超出计算范围');
    if (selling && (!a.positions[o.id] || a.positions[o.id].quantity <= 0 || o.quantity > a.positions[o.id].quantity)) return fail('insufficient_holdings', '卖出数量超过持有数量');
    if (selling && !money(a.cash + gross - fee)) return fail('numeric_limit', '卖出后现金超出计算范围');
    if (!selling && gross + fee > a.cash + rounding(gross + fee, a.cash)) return fail('insufficient_cash', '现金不足，普通股账户不允许透支');
    const p = a.positions[o.id], amount = selling ? gross - fee : -(gross + fee);
    if (!preciseChange(a.cash, amount) || (p && !preciseChange(p.quantity, selling ? -o.quantity : o.quantity))) return fail('precision_limit', '订单过小，无法在当前现金或持仓精度下准确结算');
    return null;
  }
  function buy(a, o) {
    const e = tradeCheck(a, o, false); if (e) return e;
    const p0 = a.positions[o.id];
    if (p0 && !money(p0.quantity + o.quantity)) return fail('numeric_limit', '持仓数量超出范围');
    const gross = o.quantity * o.price, fee = gross * (o.feeRate ?? 0), amount = gross + fee;
    if (!bounded([(p0?.cost || 0) + amount, (p0?.totalInvested || 0) + amount, (p0?.fees || 0) + fee, a.totals.fees + fee])) return fail('numeric_limit', '累计成本或费用超出计算范围');
    if (p0 && !preciseChange(p0.cost, amount)) return fail('precision_limit', '订单过小，无法准确计入持仓成本');
    const m = mark(a, o.date, { [o.id]: o.price }); if (!m.ok) return m;
    let p = a.positions[o.id];
    if (!p) p = a.positions[o.id] = { id: o.id, quantity: 0, cost: 0, realized: 0, dividends: 0, fees: 0, totalInvested: 0, totalProceeds: 0, firstBuyDate: o.date, lastBuyDate: o.date, closedDate: null, cancelled: false, cashFlows: [], history: [{ date: o.date, unitValue: 1, marketValue: 0, kind: 'start' }], performanceFactor: 1, lastValue: 0 };
    const before = p.quantity * o.price;
    p.performanceFactor *= (before + gross) / (before + amount);
    p.quantity += o.quantity;
    p.cost += amount;
    p.totalInvested += amount;
    p.fees += fee;
    p.lastBuyDate = o.date;
    p.closedDate = null;
    p.cashFlows.push({ date: o.date, amount: -amount, type: 'buy' });
    p.lastValue = p.quantity * o.price;
    sample(p.history, { date: o.date, marketValue: p.lastValue, unitValue: p.performanceFactor, kind: 'buy' });
    a.cash = Math.max(0, a.cash - amount);
    a.totals.fees += fee;
    ledger(a, { type: 'buy', date: o.date, companyId: o.id, quantity: o.quantity, price: o.price, gross, fee, amount: -amount, costAfter: p.cost, quantityAfter: p.quantity });
    snapshot(a, o.date, 'buy');
    return { ok: true, gross, fee, amount, quantityAfter: p.quantity, cashAfter: a.cash };
  }
  function sell(a, o) {
    const e = tradeCheck(a, o, true); if (e) return e;
    const beforePosition = a.positions[o.id], expectedGross = o.quantity * o.price, expectedFee = expectedGross * (o.feeRate ?? 0), expectedProceeds = expectedGross - expectedFee;
    const expectedRemoved = beforePosition.cost * o.quantity / beforePosition.quantity, expectedRealized = expectedProceeds - expectedRemoved;
    if (!bounded([beforePosition.realized + expectedRealized, a.totals.realized + expectedRealized, beforePosition.totalProceeds + expectedProceeds, beforePosition.fees + expectedFee, a.totals.fees + expectedFee])) return fail('numeric_limit', '累计卖出所得或费用超出计算范围');
    if (!preciseChange(beforePosition.cost, -expectedRemoved)) return fail('precision_limit', '订单过小，无法准确扣除持仓成本');
    const m = mark(a, o.date, { [o.id]: o.price }); if (!m.ok) return m;
    const p = a.positions[o.id], quantity = Math.min(o.quantity, p.quantity);
    const gross = quantity * o.price, fee = gross * (o.feeRate ?? 0), proceeds = gross - fee;
    const costRemoved = p.cost * quantity / p.quantity, realized = proceeds - costRemoved;
    const before = p.quantity * o.price;
    if (before > 0) p.performanceFactor *= (before - fee) / before;
    p.quantity = p.quantity - quantity;
    p.cost = Math.max(0, p.cost - costRemoved);
    if (p.quantity <= 0) { p.quantity = 0; p.cost = 0; p.closedDate = o.date; }
    p.realized += realized;
    p.totalProceeds += proceeds;
    p.fees += fee;
    p.cashFlows.push({ date: o.date, amount: proceeds, type: 'sell' });
    p.lastValue = p.quantity * o.price;
    sample(p.history, { date: o.date, marketValue: p.lastValue, unitValue: p.performanceFactor, kind: 'sell' });
    a.cash += proceeds;
    a.totals.realized += realized;
    a.totals.fees += fee;
    ledger(a, { type: 'sell', date: o.date, companyId: o.id, quantity, price: o.price, gross, fee, amount: proceeds, costRemoved, realized, quantityAfter: p.quantity, costAfter: p.cost });
    snapshot(a, o.date, 'sell');
    return { ok: true, gross, fee, proceeds, realized, costRemoved, quantityAfter: p.quantity, cashAfter: a.cash };
  }
  function action(a, o) {
    if (!o || !idOK(o.id) || !idOK(o.companyId)) return fail('invalid_action', '公司行动必须有稳定 ID 和证券身份');
    if (a && a.appliedActions && own(a.appliedActions, o.id)) return { ok: true, duplicate: true, amount: 0 };
    const e = accountError(a, o.date); if (e) return e;
    if (!['split', 'dividend', 'cash_merger', 'cancel'].includes(o.type)) return fail('unsupported_action', '不支持的公司行动');
    if (o.type === 'split' && (!finite(o.ratio) || o.ratio <= 0 || o.ratio > 1e9)) return fail('invalid_ratio', '拆并股比例无效');
    if (['dividend', 'cash_merger'].includes(o.type) && (!money(o.amount) || o.amount < 0)) return fail('invalid_distribution', '每股分配金额无效');
    if (a.priceBasis === 'total_return' && ['split', 'dividend'].includes(o.type)) return fail('double_count_prevented', '总回报单位已包含此权益，不能再次派息或拆股');
    const p = a.positions[o.companyId], quantity = p ? p.quantity : 0;
    const payment = ['dividend', 'cash_merger'].includes(o.type) ? quantity * o.amount : 0;
    if (!money(payment + a.cash) || (o.type === 'split' && p && !money(quantity * o.ratio))) return fail('numeric_limit', '公司行动超出计算范围');
    if (o.type === 'split' && quantity > 0 && (!(quantity * o.ratio > 0) || !money(a.prices[o.companyId] / o.ratio))) return fail('numeric_limit', '拆并股后的股数或价格超出计算范围');
    if (p && quantity > 0 && o.type === 'dividend' && !bounded([p.dividends + payment, a.totals.dividends + payment, (p.pendingDistribution || 0) + payment])) return fail('numeric_limit', '累计分红超出计算范围');
    if (p && quantity > 0 && ['cancel', 'cash_merger'].includes(o.type) && !bounded([p.realized + (payment - p.cost), a.totals.realized + (payment - p.cost), p.totalProceeds + payment])) return fail('numeric_limit', '累计公司行动所得超出计算范围');
    if (p && quantity > 0) {
      const extinguish = o.type === 'cancel' || o.type === 'cash_merger';
      const markedValue = quantity * a.prices[o.companyId];
      const remainingValue = extinguish ? 0 : markedValue;
      if (!money(factorAfter(p.performanceFactor, remainingValue + payment + (p.pendingDistribution || 0), p.lastValue))) return fail('numeric_return_limit', '公司行动使累计收益指数超出可计算范围');
      if (!money(a.lastNav + payment - (extinguish ? markedValue : 0))) return fail('numeric_limit', '公司行动后的账户净值超出计算范围');
      if (!money(factorAfter(a.twrFactor, a.lastNav + payment - (extinguish ? markedValue : 0), a.lastNav))) return fail('numeric_return_limit', '公司行动使组合收益指数超出可计算范围');
    }
    // A company action never refreshes an unrelated security's stale valuation.
    let realized = 0;
    if (p && quantity > 0) {
      if (o.type === 'split') {
        p.quantity *= o.ratio;
        a.prices[o.companyId] /= o.ratio;
        // A mechanical share/quote conversion is not a newly observed price.
        // Keep previous marked value and pending cash distributions untouched.
      } else if (o.type === 'dividend') {
        a.cash += payment;
        p.dividends += payment;
        a.totals.dividends += payment;
        p.cashFlows.push({ date: o.date, amount: payment, type: 'dividend' });
        // Delay the position return link until its next mark, so an ex-dividend
        // price and its cash distribution enter one interval without a spurious
        // reinvestment at the previous cum-dividend quote.
        p.pendingDistribution = (p.pendingDistribution || 0) + payment;
      } else {
        realized = payment - p.cost;
        p.realized += realized;
        a.totals.realized += realized;
        a.cash += payment;
        p.totalProceeds += payment;
        p.cashFlows.push({ date: o.date, amount: payment, type: o.type });
        positionSample(p, o.date, 0, payment, o.type);
        p.quantity = 0; p.cost = 0; p.closedDate = o.date; p.cancelled = true;
        a.prices[o.companyId] = 0;
      }
    }
    // The old security identity remains extinguished even when the investor had
    // already sold all shares before the action. Unheld identities are retained
    // in appliedActions and also checked by tradeCheck.
    if (p && ['cancel', 'cash_merger'].includes(o.type)) p.cancelled = true;
    a.appliedActions[o.id] = { date: o.date, type: o.type, companyId: o.companyId };
    ledger(a, { type: o.type, actionId: o.id, date: o.date, companyId: o.companyId, quantityBefore: quantity, quantityAfter: p ? p.quantity : 0, perShare: o.amount ?? null, ratio: o.ratio ?? null, amount: payment, realized, costAfter: p ? p.cost : 0 });
    snapshot(a, o.date, o.type);
    return { ok: true, amount: payment, realized, quantityAfter: p ? p.quantity : 0 };
  }
  function flow(a, amount, date, reason = '外部现金流') {
    const e = accountError(a, date); if (e) return e;
    if (!money(amount) || !money(a.cash + amount)) return fail('invalid_flow', '现金流必须是计算范围内的有限金额');
    if (a.cash + amount < -rounding(a.cash, amount)) return fail('insufficient_cash', '赎回或支出超过现金；请先卖出足量持仓');
    if (!money(values(a, null, date).nav + amount)) return fail('numeric_limit', '现金流后的账户净值超出计算范围');
    if (!preciseChange(a.cash, amount)) return fail('precision_limit', '现金流过小，无法在当前余额精度下准确结算');
    const m = mark(a, date, {}); if (!m.ok) return m;
    a.cash = Math.max(0, a.cash + amount);
    a.externalFlows.push({ date, amount, reason: String(reason).slice(0, 200) });
    ledger(a, { type: 'external_flow', date, amount, reason: String(reason).slice(0, 200) });
    snapshot(a, date, 'external_flow', true);
    return { ok: true, cashAfter: a.cash, amount };
  }
  function expense(a, amount, date, reason = '账户费用') {
    const e = accountError(a, date); if (e) return e;
    if (!money(amount) || amount < 0) return fail('invalid_expense', '费用必须是非负有限金额');
    if (amount > a.cash + rounding(amount, a.cash)) return fail('insufficient_cash', '费用超过可用现金，需先变现持仓');
    if (!bounded([(a.totals.expenses || 0) + amount, a.totals.fees + amount])) return fail('numeric_limit', '累计费用超出计算范围');
    if (!preciseChange(a.cash, -amount)) return fail('precision_limit', '费用过小，无法在当前余额精度下准确结算');
    const m = mark(a, date, {}); if (!m.ok) return m;
    a.cash = Math.max(0, a.cash - amount);
    a.totals.expenses = (a.totals.expenses || 0) + amount;
    a.totals.fees += amount;
    ledger(a, { type: 'expense', date, amount: -amount, fee: amount, reason: String(reason).slice(0, 200) });
    snapshot(a, date, 'expense');
    return { ok: true, amount, cashAfter: a.cash };
  }
  function stats(a, prices = {}, date = a.date) {
    if (timestamp(date) === null || date < a.date) return fail('invalid_date', '复盘日期不得早于已结算日期');
    const v = values(a, prices, date), netContributions = a.externalFlows.reduce((s, f) => s + f.amount, 0);
    if (!money(v.nav)) return fail('numeric_limit', '估值超出可计算范围');
    const grossContributions = a.externalFlows.reduce((s, f) => s + Math.max(0, f.amount), 0);
    const profit = v.nav - netContributions;
    const factor = factorAfter(a.twrFactor, v.nav, a.lastNav);
    if (!money(factor)) return fail('numeric_return_limit', '收益指数超出可计算范围');
    const elapsedDays = daysBetween(a.startDate, date);
    const mwr = xirr([...a.externalFlows.map(f => ({ date: f.date, amount: -f.amount })), { date, amount: v.nav }]);
    const subsequentFlows = a.externalFlows.slice(1).filter(f => f.amount !== 0);
    const annualized = !subsequentFlows.length ? cagr(a.externalFlows[0].amount, v.nav, elapsedDays) : null;
    return {
      ok: true, ...v, realized: clean(a.totals.realized), unrealized: clean(v.unrealized),
      dividends: clean(a.totals.dividends), fees: clean(a.totals.fees), expenses: clean(a.totals.expenses || 0), netContributions: clean(netContributions), grossContributions,
      profit: clean(profit), reconciliationError: clean(profit - a.totals.realized - v.unrealized - a.totals.dividends + (a.totals.expenses || 0)),
      totalReturn: clean(factor - 1), twr: clean(factor - 1), mwr, cagr: annualized,
      cagrReason: subsequentFlows.length ? '存在中途现金流，请使用资金加权收益率' : elapsedDays <= 0 ? '持有不足一天' : annualized === null ? '没有有效起始资本' : null,
      capitalReturnRatio: grossContributions > 0 ? profit / grossContributions : null,
      elapsedDays, maxDrawdown: drawdown([...a.history.filter(h => !h.stale?.length), ...(!v.stale.length ? [{ unitValue: factor }] : [])]), sampling: a.sampling,
      cashFlowValuation: v.stale.length ? '部分证券按最近已核验价格估值；陈旧价格不构成可成交报价' : '当前公开估值',
      methodology: '加权平均成本；买入费计入成本；卖出费扣减所得；时间加权收益剔除外部资金'
    };
  }
  function positionStats(a, id, price, date = a.date) {
    const p = a.positions[id];
    if (!p) return fail('no_position', '尚未持有过该公司');
    if (timestamp(date) === null || date < a.date || !money(price) || price < 0) return fail('invalid_valuation', '价格或复盘日期无效');
    const endDate = p.quantity > 0 ? date : (p.closedDate || date), elapsedDays = daysBetween(p.firstBuyDate, endDate);
    const marketValue = p.quantity * price, unrealized = marketValue - p.cost;
    if (!money(marketValue)) return fail('numeric_limit', '持仓估值超出可计算范围');
    const totalProfit = p.realized + unrealized + p.dividends;
    const flows = [...p.cashFlows, ...(p.quantity > 0 ? [{ date, amount: marketValue }] : [])];
    const mwr = xirr(flows);
    const outflows = p.cashFlows.filter(f => f.amount < 0);
    const intervening = p.cashFlows.some(f => f.amount > 0 && f.date !== endDate);
    const annualized = outflows.length === 1 && !intervening ? cagr(p.totalInvested, p.totalProceeds + p.dividends + marketValue, elapsedDays) : null;
    const factor = factorAfter(p.performanceFactor, marketValue + (p.pendingDistribution || 0), p.lastValue);
    if (!money(factor)) return fail('numeric_return_limit', '持仓收益指数超出可计算范围');
    const holdingPeriods = [];
    let held = 0, entered = null;
    for (const r of a.ledger) {
      if (r.companyId !== id) continue;
      if (r.type === 'buy') { if (held <= 0) entered = r.date; held += r.quantity; }
      else if (r.type === 'split') held *= r.ratio;
      else if (r.type === 'sell') held -= r.quantity;
      else if (r.type === 'cancel' || r.type === 'cash_merger') held = 0;
      if (entered && held <= 0) { holdingPeriods.push({ from: entered, to: r.date, days: daysBetween(entered, r.date) }); entered = null; }
    }
    if (entered) holdingPeriods.push({ from: entered, to: date, days: daysBetween(entered, date) });
    const holdingDays = holdingPeriods.reduce((s, interval) => s + interval.days, 0);
    return {
      ok: true, id, quantity: p.quantity, cost: p.cost, averageCost: p.quantity > 0 ? p.cost / p.quantity : null,
      invested: p.totalInvested, proceeds: p.totalProceeds, marketValue, realized: p.realized, unrealized,
      dividends: p.dividends, fees: p.fees, totalProfit, totalReturn: p.totalInvested > 0 ? totalProfit / p.totalInvested : null,
      twr: clean(factor - 1), cagr: annualized, mwr, elapsedDays, holdingDays, holdingPeriods, firstBuyDate: p.firstBuyDate, endDate,
      cagrReason: outflows.length !== 1 || intervening ? '分批投入、退出或分红，不可简化为普通 CAGR' : elapsedDays <= 0 ? '持有不足一天' : null,
      maxDrawdown: drawdown([...p.history, { unitValue: factor }]), sampling: a.sampling,
      cancelled: p.cancelled, cashFlows: p.cashFlows.map(f => ({ ...f }))
    };
  }
  function validateAccount(a, asOfDate) {
    try {
      const require = (condition, message) => { if (!condition) throw new Error(message); };
      const plain = o => o && typeof o === 'object' && !Array.isArray(o) && [Object.prototype, null].includes(Object.getPrototypeOf(o));
      const number = (n, nonnegative = false) => money(n) && (!nonnegative || n >= 0);
      const same = (x, y) => finite(x) && finite(y) && Math.abs(x - y) <= 1e-8 * Math.max(1, Math.abs(x), Math.abs(y));
      const date = d => timestamp(d) !== null && d >= a.startDate && d <= a.date;
      const text = s => typeof s === 'string' && s.length <= 1000;
      const types = ['external_flow', 'buy', 'sell', 'split', 'dividend', 'cash_merger', 'cancel', 'expense'];
      require(plain(a) && a.version === 1 && a.currency === 'USD', '账户版本、币种或结构无效');
      require(timestamp(a.startDate) !== null && timestamp(a.date) !== null && a.date >= a.startDate, '账户日期无效');
      require(asOfDate === undefined || (timestamp(asOfDate) !== null && a.date === asOfDate), '账户结算日期与生涯日期不同');
      require(number(a.cash, true) && number(a.lastNav, true) && number(a.twrFactor, true), '现金、净值或收益指数无效');
      require(['raw', 'total_return'].includes(a.priceBasis) && text(a.sampling), '行情口径或采样说明损坏');
      for (const key of ['positions', 'prices', 'quoteDates', 'appliedActions', 'totals']) require(plain(a[key]), key + ' 必须是普通对象');
      for (const key of ['ledger', 'externalFlows', 'history']) require(Array.isArray(a[key]) && a[key].length > 0 && a[key].length <= 100000, key + ' 长度无效');
      for (const [id, px] of Object.entries(a.prices)) require(idOK(id) && number(px, true) && date(a.quoteDates[id]), '价格或报价日期非法');
      for (const [id, d] of Object.entries(a.quoteDates)) require(idOK(id) && own(a.prices, id) && date(d), '报价日期缺少对应价格');
      for (const key of ['realized', 'dividends', 'fees', 'expenses']) require(number(a.totals[key], key !== 'realized'), '累计金额无效：' + key);
      const replay = {}, seenActions = {}, extinguished = new Set(), flows = [], get = id => replay[id] || (replay[id] = { quantity: 0, cost: 0, realized: 0, dividends: 0, fees: 0, totalInvested: 0, totalProceeds: 0, cashFlows: [] });
      let balance = 0, previous = a.startDate, expenses = 0;
      for (let i = 0; i < a.ledger.length; i++) {
        const r = a.ledger[i];
        require(plain(r) && r.seq === i + 1 && types.includes(r.type) && date(r.date) && r.date >= previous, '流水类型、顺序或日期损坏');
        require(number(r.amount) && number(r.cashAfter, true), '流水金额无效'); previous = r.date;
        balance += r.amount; require(same(balance, r.cashAfter) && balance >= -EPS, '流水现金不守恒');
        if (r.type === 'external_flow') { require(text(r.reason), '现金流说明非法'); flows.push({ date: r.date, amount: r.amount }); continue; }
        if (r.type === 'expense') { require(number(r.fee, true) && same(r.amount, -r.fee) && text(r.reason), '费用流水损坏'); expenses += r.fee; continue; }
        require(idOK(r.companyId), '流水证券身份无效');
        if (r.type === 'buy' || r.type === 'sell') {
          require(number(r.quantity, true) && r.quantity > 0 && number(r.price, true) && r.price > 0 && number(r.gross, true) && number(r.fee, true), '交易数值非法');
          require(same(r.gross, r.quantity * r.price) && r.fee <= r.gross + EPS, '交易总额或费用不符');
          require(!extinguished.has(r.companyId), '已注销证券身份不能再次成交');
          const p = get(r.companyId); p.fees += r.fee;
          if (r.type === 'buy') {
            require(same(r.amount, -r.gross - r.fee), '买入现金流不符');
            p.quantity += r.quantity; p.cost -= r.amount; p.totalInvested -= r.amount;
          } else {
            require(r.quantity <= p.quantity && same(r.amount, r.gross - r.fee), '卖出现金流或数量不符');
            const removed = p.quantity ? p.cost * r.quantity / p.quantity : 0;
            require(same(r.costRemoved, removed) && same(r.realized, r.amount - removed), '卖出成本分配不符');
            p.quantity = p.quantity - r.quantity; p.cost = p.quantity > 0 ? Math.max(0, p.cost - removed) : 0; p.realized += r.realized; p.totalProceeds += r.amount;
          }
          p.cashFlows.push({ date: r.date, amount: r.amount, type: r.type });
          require(same(r.quantityAfter, p.quantity) && same(r.costAfter, p.cost), '交易后持仓与成本不符');
        } else {
          require(idOK(r.actionId) && !own(seenActions, r.actionId), '公司行动 ID 重复或非法');
          seenActions[r.actionId] = { date: r.date, type: r.type, companyId: r.companyId };
          if (['cancel', 'cash_merger'].includes(r.type)) extinguished.add(r.companyId);
          const p = replay[r.companyId], quantity = p?.quantity || 0;
          require(number(r.quantityBefore, true) && same(r.quantityBefore, quantity), '公司行动前股数不符');
          let realized = 0;
          if (r.type === 'split') {
            require(finite(r.ratio) && r.ratio > 0 && r.ratio <= 1e9 && same(r.amount, 0), '拆并股条目非法');
            if (p) p.quantity *= r.ratio;
          } else if (r.type === 'dividend' || r.type === 'cash_merger') {
            require(number(r.perShare, true) && same(r.amount, quantity * r.perShare), '每股分配与现金流不符');
            if (p && quantity > 0) {
              if (r.type === 'dividend') p.dividends += r.amount;
              else { realized = r.amount - p.cost; p.realized += realized; p.totalProceeds += r.amount; p.quantity = 0; p.cost = 0; }
              p.cashFlows.push({ date: r.date, amount: r.amount, type: r.type });
            }
          } else {
            require(same(r.amount, 0), '注销不应凭空产生现金');
            if (p && quantity > 0) { realized = -p.cost; p.realized += realized; p.quantity = 0; p.cost = 0; p.cashFlows.push({ date: r.date, amount: 0, type: r.type }); }
          }
          require(same(r.realized, realized) && same(r.quantityAfter, p?.quantity || 0) && same(r.costAfter, p?.cost || 0), '公司行动权益核算不符');
        }
      }
      require(a.ledger[0].type === 'external_flow' && a.ledger[0].date === a.startDate && a.ledger[0].amount >= 0, '缺失有效初始资金');
      require(same(balance, a.cash) && same(expenses, a.totals.expenses), '当前现金或费用合计与流水不符');
      require(flows.length === a.externalFlows.length, '外部现金流条数与流水不符');
      a.externalFlows.forEach((f, i) => require(plain(f) && date(f.date) && number(f.amount) && text(f.reason) && f.date === flows[i].date && same(f.amount, flows[i].amount), '外部现金流损坏'));
      require(Object.keys(seenActions).length === Object.keys(a.appliedActions).length, '已派发行动数量不符');
      for (const [id, r] of Object.entries(a.appliedActions)) require(idOK(id) && plain(r) && seenActions[id] && r.date === seenActions[id].date && r.type === seenActions[id].type && r.companyId === seenActions[id].companyId, '已派发行动记录不符');
      require(Object.keys(replay).length === Object.keys(a.positions).length, '持仓档案与交易流水不符');
      let nav = a.cash, realized = 0, dividends = 0, fees = expenses;
      for (const [id, p] of Object.entries(a.positions)) {
        require(idOK(id) && plain(p) && p.id === id && replay[id], '持仓结构或身份非法');
        for (const k of ['quantity', 'cost', 'realized', 'dividends', 'fees', 'totalInvested', 'totalProceeds']) require(number(p[k], k !== 'realized') && same(p[k], replay[id][k]), '持仓金额或股数与流水不符：' + k);
        require(number(p.lastValue, true) && number(p.performanceFactor, true) && date(p.firstBuyDate) && date(p.lastBuyDate), '持仓估值字段损坏');
        require(p.closedDate === null || date(p.closedDate), '清仓日期非法');
        require(typeof p.cancelled === 'boolean' && (!p.cancelled || p.quantity === 0), '注销状态非法');
        require(p.pendingDistribution === undefined || (number(p.pendingDistribution, true) && p.pendingDistribution <= p.dividends + EPS), '待结算股息字段非法');
        require(Array.isArray(p.cashFlows) && p.cashFlows.length === replay[id].cashFlows.length, '持仓现金流长度损坏');
        p.cashFlows.forEach((f, i) => { const r = replay[id].cashFlows[i]; require(plain(f) && f.date === r.date && f.type === r.type && same(f.amount, r.amount), '持仓现金流与流水不符'); });
        require(Array.isArray(p.history) && p.history.length > 0 && p.history.length <= 100000, '持仓历史无效');
        let prev = a.startDate;
        for (const h of p.history) { require(plain(h) && date(h.date) && h.date >= prev && number(h.marketValue, true) && number(h.unitValue, true) && ['start', 'mark', 'buy', 'sell', 'split', 'dividend', 'cash_merger', 'cancel'].includes(h.kind), '持仓历史字段损坏'); prev = h.date; }
        require(same(p.lastValue, p.history.at(-1).marketValue) && same(p.performanceFactor, p.history.at(-1).unitValue), '持仓历史与末次估值不符');
        if (p.quantity > 0) require(own(a.prices, id), '持仓缺少有效报价');
        nav += p.quantity * (a.prices[id] || 0); realized += p.realized; dividends += p.dividends; fees += p.fees;
      }
      require(same(nav, a.lastNav) && same(realized, a.totals.realized) && same(dividends, a.totals.dividends) && same(fees, a.totals.fees), '账户汇总与持仓不符');
      previous = a.startDate;
      for (const h of a.history) {
        require(plain(h) && date(h.date) && h.date >= previous && number(h.nav, true) && number(h.unitValue, true) && finite(h.twr) && same(h.twr, h.unitValue - 1), '净值历史数值非法');
        require(['initial', 'mark', ...types].includes(h.kind) && Array.isArray(h.stale) && h.stale.every(idOK), '净值历史采样字段非法'); previous = h.date;
      }
      require(a.history.at(-1).date === a.date && same(a.history.at(-1).nav, a.lastNav) && same(a.history.at(-1).unitValue, a.twrFactor), '末次净值与账户状态不符');
      return { ok: true };
    } catch (e) { return fail('invalid_account', e.message || '账户结构无效'); }
  }
  return Object.freeze({ createAccount, buy, sell, action, mark, flow, expense, stats, positionStats, xirr, cagr, drawdown, daysBetween, validateAccount });
});
