/* Keep this guard ES5-compatible so parse failures in the game remain visible. */
(function (G) {
  'use strict';
  if (!G.globalThis) G.globalThis = G;
  if (!Array.prototype.at) Object.defineProperty(Array.prototype, 'at', {
    configurable: true, writable: true, value: function (index) {
      var length = this.length >>> 0;
      var n = Number(index) || 0;
      n = n < 0 ? Math.ceil(n) : Math.floor(n);
      if (n < 0) n += length;
      return n < 0 || n >= length ? undefined : this[n];
    }
  });
  if (!Object.fromEntries) Object.fromEntries = function (entries) {
    var out = {}, index = 0, step, entry;
    var iterator = typeof Symbol !== 'undefined' && entries && entries[Symbol.iterator] ? entries[Symbol.iterator]() : null;
    if (!iterator && (!entries || typeof entries.length !== 'number')) throw new TypeError('Expected entries');
    while (iterator ? !(step = iterator.next()).done : index < entries.length) {
      entry = iterator ? step.value : entries[index++];
      if (!entry || typeof entry !== 'object') throw new TypeError('Invalid entry');
      Object.defineProperty(out, entry[0], { value: entry[1], enumerable: true, configurable: true, writable: true });
    }
    return out;
  };
  var ready = false;
  var timer = setTimeout(function () {
    if (!ready) show('加载时间较长，正在准备离线游戏。若长时间没有变化，可以重新加载；已有存档不会因此删除。');
  }, 12000);
  function show(message) {
    var el = document.getElementById('startup-message');
    if (el) el.textContent = message;
  }
  function fail(error) {
    if (!ready) { clearTimeout(timer); show('游戏启动未完成。请尝试重新加载或在更新后的 Safari / Chrome 中打开。已有存档仍保留。' + (error ? '（' + String(error.message || error).slice(0, 180) + '）' : '')); }
  }
  G.addEventListener('error', function (event) { fail(event.message || event.error); });
  G.addEventListener('unhandledrejection', function (event) { fail(event.reason); });
  G.__lifeReady = function () {
    ready = true;
    clearTimeout(timer);
    var el = document.getElementById('startup');
    if (el && el.parentNode) el.parentNode.removeChild(el);
  };
})(window);
