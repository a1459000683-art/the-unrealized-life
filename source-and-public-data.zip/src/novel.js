/* Independent mobile-novel orchestration. Uses the audited Game/Finance engines with their compatible QA safety fixes. */
(function(G){
'use strict';
const clone=x=>JSON.parse(JSON.stringify(x));
const finite=x=>typeof x==='number'&&Number.isFinite(x);
const plain=x=>!!x&&typeof x==='object'&&!Array.isArray(x);
const clamp=(x,a=0,b=100)=>Math.max(a,Math.min(b,x));
const idOK=x=>typeof x==='string'&&/^[A-Za-z0-9_.:-]{1,100}$/.test(x)&&!['constructor','prototype','__proto__'].includes(x);
const starts=['debt','buffer','network'];
const statKeys=['stress','health','reputation','trust','research','communication','freedom','discipline'];
const topics=['cashflow','debt','customers','valuation','challenge'];
const careers=['analyst','senior','manager','head','partner','unemployed','independent','outside'];
const industrial=new Set(['HEI','GNTX','AIR','FAST','GPC','EOG','HOG','NUE']);
const fail=error=>({ok:false,error});
const ok=extra=>({ok:true,...extra});
const contentCache=new WeakMap();
function content(){
 const original=G.NOVEL_STORY;if(!plain(original))throw Error('小说剧情尚未载入');
 if(contentCache.has(original))return contentCache.get(original);
 const c=clone(original);const validation=validateContent(c);if(!validation.ok)throw Error(validation.error);
 const groups=[];for(const node of c.nodes){const key=node.dateIndex+':'+(node.slot||0);let group=groups.find(g=>g.key===key);if(!group){group={key,dateIndex:node.dateIndex,slot:node.slot||0,nodes:[]};groups.push(group);}group.nodes.push(node);}
 groups.sort((a,b)=>a.dateIndex-b.dateIndex||a.slot-b.slot);
 for(const g of groups)g.nodes.sort((a,b)=>(b.priority||0)-(a.priority||0));
 c.groups=groups;c.nodeMap=Object.fromEntries(c.nodes.map(n=>[n.id,n]));c.endingMap=Object.fromEntries(c.endings.map(e=>[e.id,e]));contentCache.set(original,c);return c;
}
function validateContent(c){
 try{
  if(!plain(c)||c.version!==1||!Array.isArray(c.nodes)||!c.nodes.length||!Array.isArray(c.endings)||!c.endings.length)throw Error('剧情结构或版本无效');
  const dates=G.Game.dates(),ids=new Set(),groups=new Map();
  const numericStats=new Set([...statKeys,'authority','debt','personalCash','wealth','age','choices','choiceCount','dateIndex','unemployedMonths','careerMonths','personalNav','clientNav','clientTwr','personalTwr',...G.STORY.characters.map(p=>'relations.'+p.id)]);
  const checkCondition=r=>{if(r===undefined)return;if(!plain(r)||Object.keys(r).some(k=>!['flagsAll','flagsNone','flagsAny','min','max','start','career'].includes(k)))throw Error('条件结构无效');for(const k of ['flagsAll','flagsNone','flagsAny'])if(r[k]!==undefined&&(!Array.isArray(r[k])||r[k].some(x=>!idOK(x))))throw Error('条件标记无效');for(const k of ['min','max'])if(r[k]!==undefined&&(!plain(r[k])||Object.entries(r[k]).some(([k,v])=>!numericStats.has(k)||!finite(v))))throw Error('条件阈值无效');for(const [k,allowed]of [['start',starts],['career',careers]])if(r[k]!==undefined&&(Array.isArray(r[k])?r[k]:[r[k]]).some(v=>!allowed.includes(v)))throw Error('条件身份无效');};
  for(const n of c.nodes){
   if(!idOK(n.id)||ids.has(n.id)||!Number.isInteger(n.dateIndex)||n.dateIndex<0||n.dateIndex>=dates.length||![0,1].includes(n.slot||0)||typeof n.title!=='string'||typeof n.text!=='string'||!Array.isArray(n.choices)||n.choices.length<2||n.choices.length>4)throw Error('场景字段无效：'+n.id);
   ids.add(n.id);checkCondition(n.requires);const key=n.dateIndex+':'+(n.slot||0);if(!groups.has(key))groups.set(key,[]);groups.get(key).push(n);
   const choiceIds=new Set();for(const ch of n.choices){
    if(!idOK(ch.id)||choiceIds.has(ch.id)||typeof ch.label!=='string'||!ch.label||!plain(ch.result)||typeof ch.result.text!=='string')throw Error('选择缺少独立结果：'+n.id);choiceIds.add(ch.id);checkCondition(ch.requires);
    if(ch.next!==undefined)throw Error('当前版本不允许跳过场景组');
    const e=ch.effects||{};if(!plain(e)||Object.keys(e).some(k=>![...statKeys,'authority','debt','personalCash','career','flags','removeFlags','relations','researchCompany'].includes(k)))throw Error('效果无效');
    for(const [k,v]of Object.entries(e))if(statKeys.includes(k)||['authority','debt','personalCash'].includes(k)){if(!finite(v)||Math.abs(v)>1e8)throw Error('效果数值无效');}
    if(e.career!==undefined&&!careers.includes(e.career))throw Error('效果职业无效');
    for(const k of ['flags','removeFlags'])if(e[k]!==undefined&&(!Array.isArray(e[k])||e[k].some(x=>!idOK(x))))throw Error('效果标记无效');
    if(e.relations!==undefined&&(!plain(e.relations)||Object.entries(e.relations).some(([id,v])=>!G.STORY.characters.some(p=>p.id===id)||!finite(v))))throw Error('效果人物无效');
    if(e.researchCompany!==undefined&&(!Array.isArray(e.researchCompany)||e.researchCompany.some(r=>!plain(r)||!G.MARKET.companies.some(x=>x.id===r.companyId)||!topics.includes(r.topic))))throw Error('研究任务无效');
    if(ch.strategy){const s=ch.strategy;if(!plain(s)||!['invest','hold','reduce','exit','repay'].includes(s.type)||s.account!==undefined&&!['client','personal'].includes(s.account)||s.targetPercent!==undefined&&(!finite(s.targetPercent)||s.targetPercent<0||s.targetPercent>100))throw Error('策略字段无效');if(['invest','reduce','exit'].includes(s.type)&&!G.MARKET.companies.some(x=>x.id===s.companyId))throw Error('策略证券不存在');}
   }
  }
  const sorted=[...groups.values()].sort((a,b)=>a[0].dateIndex-b[0].dateIndex||(a[0].slot||0)-(b[0].slot||0));if(sorted[0][0].dateIndex!==0)throw Error('首个场景必须在开局日期');
  for(const ns of sorted)if(!ns.some(n=>!n.requires||Object.keys(n.requires).length===0))throw Error('场景组缺少无条件回退：'+ns[0].dateIndex+':'+(ns[0].slot||0));
  const endings=new Set();for(const e of c.endings){if(!idOK(e.id)||endings.has(e.id)||typeof e.title!=='string'||typeof e.text!=='string')throw Error('结局字段无效');endings.add(e.id);checkCondition(e.requires);}
  for(const n of c.nodes)for(const ch of n.choices)if(ch.ending&&!endings.has(ch.ending))throw Error('指定结局不存在');
  if(!c.endings.some(e=>!e.requires||!Object.keys(e.requires).length))throw Error('缺少兜底结局');
  if(c.saveCompatibility!==undefined){
   const compat=c.saveCompatibility;if(!plain(compat)||!Array.isArray(compat.resultText)||!Array.isArray(compat.sceneDestinations))throw Error('旧版兼容清单无效');
   for(const m of compat.resultText){const ch=c.nodes.find(n=>n.id===m?.nodeId)?.choices.find(ch=>ch.id===m.choiceId);if(!plain(m)||!ch||typeof m.from!=='string'||m.to!==ch.result.text)throw Error('旧结果文本兼容清单无效');}
   if(compat.endingText!==undefined){if(!Array.isArray(compat.endingText))throw Error('旧结局文本兼容清单无效');for(const m of compat.endingText){const end=c.endings.find(e=>e.id===m?.endingId);if(!plain(m)||!end||typeof m.from!=='string'||m.to!==end.text)throw Error('旧结局文本兼容清单无效');}}
   for(const m of compat.sceneDestinations){const source=c.nodes.find(n=>n.id===m?.from);if(!plain(m)||!source||!Array.isArray(m.to)||!m.to.length||m.to.some(id=>!c.nodes.some(n=>n.id===id&&n.dateIndex===source.dateIndex&&(n.slot||0)===(source.slot||0))))throw Error('旧场景兼容清单无效');}
  }
  return ok({nodes:c.nodes.length,groups:groups.size});
 }catch(e){return fail('剧情无法载入：'+e.message);}
}
class Novel{
 constructor(start='buffer',seed=2000){
  if(!starts.includes(start)||!Number.isInteger(seed)||seed<0||seed>0xffffffff)throw Error('无效开局或种子');
  const c=content();this.core=new G.Game(start,'industrial',seed);this.core.state.resolved=true;this.core.state.eventId=null;
  this.state={start,seed,phase:'choice',groupIndex:0,nodeId:null,revision:0,choiceCount:0,seenNodes:[],choiceLog:[],result:null,nextNodeId:null,nextGroupIndex:null,pendingEnding:null,ending:null,settledDateIndex:0};
  this.state.nodeId=this._selectNode(0).id;
 }
 static get STORAGE_PREFIX(){return 'unrealized-life-novel:v1:';}
 static validateContent(c=G.NOVEL_STORY){return validateContent(c);}
 _stat(key){const s=this.core.state;if(key.startsWith('relations.'))return s.relations[key.slice(10)]??0;if(key==='choices'||key==='choiceCount')return this.state.choiceCount;if(key==='dateIndex')return s.stage;if(key==='personalNav')return s.personal.lastNav;if(key==='clientNav')return s.client.lastNav;if(key==='wealth')return s.personal.lastNav-s.debt;if(key==='clientTwr')return s.client.twrFactor-1;if(key==='personalTwr')return s.personal.twrFactor-1;return this.core._stat(key);}
 eligible(r={}){
  const s=this.core.state;if(r.start&&!(Array.isArray(r.start)?r.start:[r.start]).includes(s.start))return false;if(r.career&&!(Array.isArray(r.career)?r.career:[r.career]).includes(s.career))return false;
  if(r.flagsAll?.some(f=>!s.flags.includes(f))||r.flagsNone?.some(f=>s.flags.includes(f))||r.flagsAny?.length&&!r.flagsAny.some(f=>s.flags.includes(f)))return false;
  if(r.min&&Object.entries(r.min).some(([k,v])=>this._stat(k)<v)||r.max&&Object.entries(r.max).some(([k,v])=>this._stat(k)>v))return false;return true;
 }
 _selectNode(index){const group=content().groups[index];const node=group?.nodes.find(n=>this.eligible(n.requires));if(!node)throw Error('没有可用的叙事分支');return node;}
 _token(node,ch){return node.id+'/'+ch.id+'/'+this.state.revision;}
 _company(id){return G.MARKET.companies.find(c=>c.id===id);}
 _quote(id){const c=this._company(id),date=this.core.state.date;if(!c||c.listed&&date<c.listed||c.delisted&&date>=c.delisted||c.suspended&&date>=c.suspended)return null;const p=c.prices.find(p=>p.date===date);return p&&finite(p.close)&&p.close>0?p.close:null;}
 _availability(ch){
  if(this.state.phase!=='choice')return '这项选择已记录';if(!this.eligible(ch.requires))return ch.unavailableReason||'先前的经历或当前处境还不满足这项选择';
  const s=this.core.state,e=ch.effects||{},research=e.researchCompany||[];let cost=0;const known=new Set();
  if(ch.ending){const end=content().endingMap[ch.ending];if(s.date<'2020-07-01'&&(end?.kind==='death'||ch.ending.includes('death')))return '这段结局尚未到发生的时点';}
  for(const r of research){if((s.research[r.companyId]||[]).includes(r.topic)||known.has(r.companyId+':'+r.topic))continue;known.add(r.companyId+':'+r.topic);const company=this._company(r.companyId);if(company.listed&&company.listed>s.date)return '这份档案尚未公开';cost+=industrial.has(company.ticker?.split('.')[0])?1:2;}
  if(cost>s.actionPoints)return '这一阶段可用于研究的时间不足';
  const st=ch.strategy;if(!st||['hold','repay'].includes(st.type))return null;
  if(!this._quote(st.companyId))return '当前日期没有可执行的已核验市场报价';
  const account=st.account||'client',career=e.career||s.career;
  if(account==='client'&&['unemployed','outside'].includes(career))return '当前没有机构客户账户交易授权';
  const flags=new Set(s.flags.filter(f=>!(e.removeFlags||[]).includes(f)).concat(e.flags||[]));
  if(account==='personal'&&flags.has('personal_pause'))return '个人交易仍处在合规回避期';
  if(st.type==='invest'){
   if(s.restricted.includes(st.companyId)||flags.has('restricted_trading')||flags.has('restricted_information'))return '当前处于回避窗口，不可新增风险';
   if(!(s.research[st.companyId]||[]).length&&!research.some(r=>r.companyId===st.companyId))return '需要先完成这家企业的一项研究';
   if(account==='client'&&clamp(s.stats.trust+(e.trust||0))<20)return '内部信任不足，委员会暂缓新增风险';
  }
  return null;
 }
 _effects(ch,node,notices){
  const e=clone(ch.effects||{}),research=e.researchCompany||[];delete e.researchCompany;
  this.core._effects(e,'小说选择 / '+node.title+' / '+ch.label);
  for(const r of research){if((this.core.state.research[r.companyId]||[]).includes(r.topic))continue;const result=this.core.researchCompany(r.companyId,r.topic);if(!result.ok)throw Error(result.error);notices.push('完成了'+this._company(r.companyId).alias+'的一项研究，使用了本阶段 '+result.cost+' 次时间。');}
  this.core._mark();
 }
 _strategy(ch,notices){
  const st=ch.strategy;if(!st||st.type==='hold')return;
  const s=this.core.state,which=st.account||'client';
  if(st.type==='repay'){const amount=Math.min(s.debt,s.personal.cash*(st.targetPercent??100)/100);if(amount>1e-8){const r=this.core.spend('repay',amount);if(!r.ok)throw Error(r.error);notices.push('以个人现金偿还债务 $'+amount.toFixed(2)+'。');}else notices.push('当前没有可用于偿还的个人现金或欠款，没有新增流水。');return;}
  const id=st.companyId,c=this._company(id),price=this._quote(id);if(!price)throw Error('当前没有已核验交易价格');
  const a=s[which],p=a.positions[id],nav=a.lastNav,current=(p?.quantity||0)*price,fee=this.core.permissions().feeRate;
  if(st.type==='reduce'||st.type==='exit'){
   const targetWeight=st.type==='exit'?0:(st.targetPercent??0)/100,target=nav*targetWeight;const gross=Math.max(0,(current-target)/(1-targetWeight*fee));const quantity=Math.min(p?.quantity||0,gross/price);
   if(quantity>1e-8){const r=this.core.trade(which,id,'sell',quantity);if(!r.ok)throw Error(r.error);notices.push((st.type==='exit'?'退出了':'减持了')+c.alias+'，已兑现部分按实际成交和费用记账。');}else notices.push(c.alias+'没有超过本次目标的持仓，未产生卖出流水。');return;
  }
  const t=st.thesis||{};const thesis={why:typeof t.why==='string'?t.why:(ch.detail||ch.label),risk:typeof t.risk==='string'?t.risk:(c.risk||'经营、估值和市场流动性可能变化'),horizon:typeof t.horizon==='string'?t.horizon:'持有到下一次有可核验资料的复盘，届时重新判断',invalidation:typeof t.invalidation==='string'?t.invalidation:'公开现金流、债务或经营证据反驳当前判断时重新评估'};
  let r=this.core.setThesis(id,thesis);if(!r.ok)throw Error(r.error);
  if(which==='client'){r=this.core.propose(id);if(!r.ok)throw Error(r.error);}
  const perms=this.core.permissions(),requested=st.targetPercent??10,limit=which==='client'?Math.min(s.approved[id],perms.concentration):perms.personalLimit;
  const target=Math.min(requested,limit)/100;let gross=Math.max(0,(target*nav-current)/(1+target*fee));
  const allMarket=nav-a.cash;if(which==='client')gross=Math.min(gross,Math.max(0,(perms.riskBudget/100*nav-allMarket)/(1+perms.riskBudget/100*fee)));
  gross=Math.min(gross,a.cash/(1+fee));const quantity=gross/price;
  if(quantity>1e-8&&gross>.005){r=this.core.trade(which,id,'buy',quantity);if(!r.ok)throw Error(r.error);notices.push('按'+(which==='client'?'客户账户':'个人账户')+'实际额度买入'+c.alias+'；申请目标 '+requested+'%，本次允许的单一标的上限 '+limit+'%。');}
  else notices.push('现有持仓、现金或总风险预算已限制新增买入；'+c.alias+'本次没有成交。');
 }
 _advanceTo(index){
  if(index<this.core.state.stage)throw Error('不能倒退金融日期');
  while(this.core.state.stage<index){this.core.state.resolved=true;const r=this.core.advance();if(!r.ok)throw Error(r.error);this.core.state.resolved=true;this.core.state.eventId=null;}
  this.state.settledDateIndex=this.core.state.stage;
 }
 _chooseEnding(id){
  const endings=content().endings;let end=id?endings.find(e=>e.id===id):[...endings].filter(e=>e.kind!=='death'&&!e.id.includes('death')).sort((a,b)=>(b.priority||0)-(a.priority||0)).find(e=>this.eligible(e.requires));
  if(!end||!this.eligible(end.requires))throw Error('这段结局的长期前提尚未形成');
  if((end.kind==='death'||end.id.includes('death'))&&this.core.state.date<'2020-07-01')throw Error('死亡终局必须经过长期铺垫并到达2020后段');
  return {id:end.id,title:end.title,text:end.text,kind:end.kind||'life',date:this.core.state.date,age:this.core.state.age};
 }
 choose(token,expectedNodeId,expectedRevision){
  if(this.state.phase!=='choice')return fail('当前选择已记录；请先阅读结果');
  const node=content().nodeMap[this.state.nodeId];
  if(expectedNodeId!==undefined&&expectedNodeId!==node.id||expectedRevision!==undefined&&expectedRevision!==this.state.revision)return fail('这条输入来自已经翻过的一页');
  const choice=node.choices.find(c=>this._token(node,c)===token||(expectedNodeId===node.id&&expectedRevision===this.state.revision&&c.id===token));
  if(!choice)return fail('选择标识已过期或不存在');
  const unavailable=this._availability(choice);if(unavailable)return fail(unavailable);
  const beforeCore=clone(this.core.state),beforeState=clone(this.state),before=this._brief(),notices=[],lengths={client:beforeCore.client.ledger.length,personal:beforeCore.personal.ledger.length},fromDate=beforeCore.date;
  try{
   this._effects(choice,node,notices);this._strategy(choice,notices);
   this.state.seenNodes.push(node.id);this.state.choiceCount++;
   const nextIndex=this.state.groupIndex+1;let nextNode=null,pendingEnding=null;
   if(choice.ending)pendingEnding=this._chooseEnding(choice.ending);
   else if(nextIndex>=content().groups.length){this._advanceTo(G.Game.dates().length-1);pendingEnding=this._chooseEnding();}
   else{this._advanceTo(content().groups[nextIndex].dateIndex);nextNode=this._selectNode(nextIndex);}
   const memory=this.core.state.memory.slice(beforeCore.memory.length);for(const m of memory)if(!m.companyId&&!m.exitQuantity)notices.push(m.title+'：'+m.text);
   const after=this._brief();const changes=[['个人净资产','personalNetWorth'],['客户组合','clientNav'],['个人债务','debt'],['健康','health'],['压力','stress']].filter(([,k])=>Math.abs(after[k]-before[k])>1e-8).map(([label,k])=>({label,before:before[k],after:after[k],delta:after[k]-before[k]}));
   const performance={};for(const which of ['client','personal']){const base=beforeCore[which].twrFactor;performance[which]={twr:base>0?this.core.state[which].twrFactor/base-1:null,reason:base>0?null:'期初累计净值已为零，不能计算本段比例'};}
   if(fromDate!==this.core.state.date){notices.push('本段客户投资账户的时间加权变动为 '+(performance.client.twr===null?'无法定义':(performance.client.twr*100).toFixed(2)+'%')+'，剔除客户申赎，包含交易和管理费用。');notices.push('个人净资产变化还包括工资、已归属奖金、生活支出和债务变化，不等于投资赚亏。');}
   const transactions=[];for(const which of ['client','personal'])for(const entry of this.core.state[which].ledger.slice(lengths[which]))if(['buy','sell','expense'].includes(entry.type)||['dividend','split','cash_merger','cancel'].includes(entry.type)&&entry.quantityBefore>0)transactions.push(this._ledgerRow(entry,which));
   const result={id:node.id+':'+choice.id+':'+this.state.choiceCount,nodeId:node.id,choiceId:choice.id,title:choice.result.title||'这次选择之后',text:choice.result.text,fromDate,toDate:this.core.state.date,changes,notices:[...new Set(notices)],transactions,performance,terminal:!!pendingEnding};
   this.state.choiceLog.push({nodeId:node.id,choiceId:choice.id,groupIndex:this.state.groupIndex,revision:beforeState.revision,date:fromDate,settledDate:this.core.state.date,nextNodeId:nextNode?.id||null,nextGroupIndex:nextNode?nextIndex:null,endingId:pendingEnding?.id||null});
   this.state.result=result;this.state.nextNodeId=nextNode?.id||null;this.state.nextGroupIndex=nextNode?nextIndex:null;this.state.pendingEnding=pendingEnding;this.state.phase='result';this.state.revision++;
   return ok({result:clone(result)});
  }catch(e){this.core.state=beforeCore;this.state=beforeState;return fail('这次选择没有结算：'+e.message);}
 }
 next(){
  if(this.state.phase!=='result')return fail('当前没有等待翻页的结果');
  if(this.state.pendingEnding){this.state.ending=this.state.pendingEnding;this.state.pendingEnding=null;this.state.phase='ending';this.core.state.spoiled=true;}
  else{if(!this.state.nextNodeId||!Number.isInteger(this.state.nextGroupIndex))return fail('下一页缺失');this.state.nodeId=this.state.nextNodeId;this.state.groupIndex=this.state.nextGroupIndex;this.state.phase='choice';}
  this.state.nextNodeId=null;this.state.nextGroupIndex=null;this.state.result=null;this.state.revision++;return ok();
 }
 _brief(){const s=this.core.state;return{career:G.CAREER_NAMES?.[s.career]||s.career,clientNav:s.client.lastNav,personalNav:s.personal.lastNav,personalNetWorth:s.personal.lastNav-s.debt,debt:s.debt,health:s.stats.health,stress:s.stats.stress,choiceCount:this.state.choiceCount,salaryTotal:s.salaryTotal,bonusTotal:s.bonusTotal,livingTotal:s.livingTotal};}
 _ledgerRow(e,account){const out={account,date:e.date,type:e.type,company:e.companyId?this._company(e.companyId)?.alias:null};for(const k of ['quantity','quantityBefore','quantityAfter','perShare','price','fee','amount','gross','cashAfter','reason','ratio'])if(e[k]!==undefined)out[k]=e[k];return out;}
 view(){
  const s=this.state,cs=this.core.state,c=content(),n=c.nodeMap[s.nodeId],chapter=(c.chapters||[]).find(ch=>ch.id===n.chapter)||{id:n.chapter||'career',title:typeof n.chapter==='string'?n.chapter:'人生继续'};
  const node={id:n.id,title:n.title,text:n.text,dateIndex:n.dateIndex,slot:n.slot||0,choices:n.choices.map(ch=>{const reason=this._availability(ch);return{id:this._token(n,ch),choiceId:ch.id,label:ch.label,detail:ch.detail||'',available:!reason,reason};})};
  const people=(c.characters||G.STORY.characters).map(p=>({id:p.id,name:p.name,role:(p.roleHistory||[]).filter(r=>r.from<=cs.date).at(-1)?.role||p.role||'',relationship:cs.relations[p.id],status:cs.relations[p.id]>=70?'彼此信赖':cs.relations[p.id]>=40?'仍有来往':cs.relations[p.id]>=20?'渐渐疏远':'联系很少'}));
  const ending=s.ending?{...clone(s.ending),reveal:G.MARKET.companies.filter(x=>!x.listed||x.listed<=cs.date).map(x=>({alias:x.alias,name:x.name||x.realName,ticker:x.ticker,business:x.business}))}:null;
  return clone({phase:s.phase,date:cs.date,age:cs.age,chapter,node,result:s.result,ending,people,summary:this._brief(),progress:{choiceCount:s.choiceCount,totalGroups:c.groups.length,groupIndex:s.groupIndex,dateIndex:cs.stage,totalDates:G.Game.dates().length},revision:s.revision});
 }
 audit(){const v=this.core.view(),s=this.core.state;return clone({date:s.date,clientStats:v.clientStats,personalStats:v.personalStats,positions:v.positions,companies:v.companies,permissions:v.permissions,clientHistory:v.clientHistory,benchmark:v.benchmark,oldFiles:v.oldFiles,ledgers:{client:s.client.ledger.map(e=>this._ledgerRow(e,'client')),personal:s.personal.ledger.map(e=>this._ledgerRow(e,'personal')),firm:s.firm.ledger,debt:s.debtLedger},firm:s.firm,summary:this.summary()});}
 summary(){const b=this._brief(),s=this.core.state;return ['未实现的人生 · 互动小说',s.date+' · '+s.age+' 岁',b.career,this.state.ending?.title||'生涯继续','个人净资产 $'+b.personalNetWorth.toFixed(2)+'；客户组合 $'+b.clientNav.toFixed(2),'工资 $'+b.salaryTotal.toFixed(2)+'；奖金 $'+b.bonusTotal.toFixed(2)+'；生活与利息 $'+b.livingTotal.toFixed(2),'没有综合人生总分。',...this.state.choiceLog.map(l=>{const n=content().nodeMap[l.nodeId],c=n.choices.find(c=>c.id===l.choiceId);return l.date+' | '+n.title+' | '+c.label+'\n'+c.result.text;})].join('\n\n');}
 exportSave(){return JSON.stringify({game:'unrealized-life-novel',schemaVersion:1,contentVersion:content().version,core:JSON.parse(this.core.exportSave()),state:this.state},null,2);}
 static validateSave(raw){
  try{
   if(typeof raw==='string'){if(raw.length>12000000)throw Error('存档超过安全大小');raw=JSON.parse(raw);}
   if(!plain(raw)||raw.game!=='unrealized-life-novel'||raw.schemaVersion!==1||raw.contentVersion!==content().version||!plain(raw.core)||raw.core.game!=='The Unrealized Life'||raw.core.version!==1||!plain(raw.state))throw Error('不是这一版互动小说的存档');
   let count=0;const walk=(o,depth=0)=>{if(++count>500000||depth>35)throw Error('存档结构过大');if(typeof o==='number'&&(!finite(o)||Math.abs(o)>1e15))throw Error('非法数值');if(typeof o==='string'&&o.length>200000)throw Error('文本过长');if(o&&typeof o==='object')for(const[k,v]of Object.entries(o)){if(['__proto__','constructor','prototype'].includes(k))throw Error('非法对象键');walk(v,depth+1);}};walk(raw);
   const cv=G.Game.validateSave(raw.core);if(!cv.ok)throw Error(cv.error);const s=clone(raw.state),cs=cv.state,c=content();
   if(!starts.includes(s.start)||s.start!==cs.start||s.seed!==cs.seed||!Number.isInteger(s.seed)||s.seed<0||s.seed>0xffffffff||!Number.isInteger(s.revision)||s.revision<0||!['choice','result','ending'].includes(s.phase)||!Number.isInteger(s.groupIndex)||s.groupIndex<0||s.groupIndex>=c.groups.length||!c.groups[s.groupIndex].nodes.some(n=>n.id===s.nodeId))throw Error('叙事位置损坏');
   if(cs.sector!=='industrial'||cs.choices!==0||cs.seen.length||cs.pending.length||cs.eventId!==null||cs.ending!==null||cs.stage!==s.settledDateIndex||cs.spoiled!==(s.phase==='ending')||!cs.resolved)throw Error('新旧引擎状态混用或结算位置损坏');
   if(!Number.isInteger(s.choiceCount)||s.choiceCount<0||s.choiceCount>c.groups.length||!Array.isArray(s.choiceLog)||s.choiceLog.length!==s.choiceCount||!Array.isArray(s.seenNodes)||s.seenNodes.length!==s.choiceCount||new Set(s.seenNodes).size!==s.seenNodes.length)throw Error('选择历史损坏');
   if(s.revision!==s.choiceCount*2-(s.phase==='result'?1:0))throw Error('选择版本与翻页历史不符');
   for(let i=0;i<s.choiceLog.length;i++){
    const l=s.choiceLog[i],n=c.nodeMap[l?.nodeId];if(!plain(l)||!n||!n.choices.some(x=>x.id===l.choiceId)||l.groupIndex!==i||!c.groups[i].nodes.some(x=>x.id===l.nodeId)||s.seenNodes[i]!==l.nodeId||l.revision!==i*2||l.date!==G.Game.dates()[n.dateIndex]||l.settledDate<l.date||l.settledDate>cs.date)throw Error('选择记录不一致');
    const ch=n.choices.find(x=>x.id===l.choiceId),nextGroup=c.groups[i+1];
    if(ch.ending||!nextGroup){if(i!==s.choiceLog.length-1||l.nextNodeId!==null||l.nextGroupIndex!==null||!c.endingMap[l.endingId]||ch.ending&&l.endingId!==ch.ending||l.settledDate!==(ch.ending?l.date:G.Game.dates().at(-1)))throw Error('终局记录没有对应的选择或时点');}
    else if(l.endingId!==null||l.nextGroupIndex!==i+1||!nextGroup.nodes.some(n=>n.id===l.nextNodeId)||l.settledDate!==G.Game.dates()[nextGroup.dateIndex])throw Error('场景组间的日期或导航不一致');
   }
   const last=s.choiceLog.at(-1),node=c.nodeMap[s.nodeId];
   if(s.phase==='choice'){
    if(s.choiceCount!==s.groupIndex||s.result!==null||s.pendingEnding!==null||s.ending!==null||s.nextNodeId!==null||s.nextGroupIndex!==null||cs.stage!==node.dateIndex||s.seenNodes.includes(node.id))throw Error('未结算场景状态损坏');
    if(last&&last.nextNodeId!==node.id)throw Error('翻页目的地不符');
   }else{
    if(s.choiceCount!==s.groupIndex+1||!last||last.nodeId!==node.id||last.settledDate!==cs.date)throw Error('已结算场景状态损坏');
    if(s.phase==='result'){
     const authoredChoice=node.choices.find(ch=>ch.id===last.choiceId);
     if(s.pendingEnding!==null&&!plain(s.pendingEnding))throw Error('结果页终局导航损坏');
     if(plain(s.result)&&s.result.text!==authoredChoice.result.text){const m=c.saveCompatibility?.resultText.find(m=>m.nodeId===node.id&&m.choiceId===last.choiceId&&m.from===s.result.text&&m.to===authoredChoice.result.text);if(m)s.result.text=m.to;}
     if(!plain(s.result)||s.result.id!==node.id+':'+last.choiceId+':'+s.choiceCount||s.result.nodeId!==node.id||s.result.choiceId!==last.choiceId||s.result.fromDate!==last.date||s.result.toDate!==cs.date||s.result.title!==(authoredChoice.result.title||'这次选择之后')||s.result.text!==authoredChoice.result.text||typeof s.result.terminal!=='boolean'||!Array.isArray(s.result.changes)||!Array.isArray(s.result.notices)||!Array.isArray(s.result.transactions)||s.ending!==null)throw Error('结果页损坏');
     if(s.result.changes.some(v=>!plain(v)||typeof v.label!=='string'||['before','after','delta'].some(k=>!finite(v[k]))||Math.abs(v.after-v.before-v.delta)>1e-7)||s.result.notices.some(v=>typeof v!=='string')||s.result.transactions.some(v=>!plain(v)||!['client','personal'].includes(v.account)||typeof v.date!=='string'||v.date<last.date||v.date>cs.date||!['buy','sell','dividend','split','cash_merger','cancel','expense'].includes(v.type)||v.company!==null&&typeof v.company!=='string'||Object.entries(v).some(([k,x])=>!['account','date','type','company','reason'].includes(k)&&x!==null&&!finite(x))))throw Error('结果流水损坏');
     if(!plain(s.result.performance)||['client','personal'].some(k=>!plain(s.result.performance[k])||s.result.performance[k].twr!==null&&!finite(s.result.performance[k].twr)||s.result.performance[k].reason!==null&&typeof s.result.performance[k].reason!=='string'))throw Error('结果投资口径损坏');
     if(s.pendingEnding){if(s.nextNodeId!==null||s.nextGroupIndex!==null||last.endingId!==s.pendingEnding.id||!s.result.terminal)throw Error('终局导航损坏');}
     else if(s.nextNodeId!==last.nextNodeId||s.nextGroupIndex!==s.groupIndex+1||s.nextGroupIndex!==last.nextGroupIndex||!c.groups[s.nextGroupIndex]?.nodes.some(n=>n.id===s.nextNodeId&&n.dateIndex===cs.stage)||s.result.terminal)throw Error('下一场景损坏');
    }else if(s.result!==null||s.pendingEnding!==null||s.nextNodeId!==null||s.nextGroupIndex!==null||!plain(s.ending)||s.ending.id!==last.endingId)throw Error('终局状态损坏');
   }
   const end=s.ending||s.pendingEnding;if(end){const authored=c.endingMap[end.id];if(authored&&end.text!==authored.text){const m=c.saveCompatibility?.endingText?.find(m=>m.endingId===end.id&&m.from===end.text&&m.to===authored.text);if(m)end.text=m.to;}if(!authored||end.title!==authored.title||end.text!==authored.text||end.kind!==(authored.kind||'life')||end.date!==cs.date||end.age!==cs.age)throw Error('终局内容损坏');if((end.kind==='death'||end.id.includes('death'))&&cs.date<'2020-07-01')throw Error('提前死亡终局无效');const probe=Object.create(Novel.prototype);probe.state=s;probe.core=Object.create(G.Game.prototype);probe.core.state=cs;if(probe._chooseEnding(node.choices.find(ch=>ch.id===last.choiceId).ending).id!==end.id)throw Error('终局前提与人生状态不符');}
   if(cs.review.length!==cs.stage||cs.review.some((r,i)=>r.from!==G.Game.dates()[i]||r.date!==G.Game.dates()[i+1]))throw Error('金融日期重复结算或遗漏');
   // RC1 compatibility only redirects an unchosen, explicitly listed scene.
   // The original save must pass every check above; no core effects are replayed.
   if(s.phase==='choice'||s.phase==='result'&&s.pendingEnding===null){
    const current=s.phase==='choice',id=current?s.nodeId:s.nextNodeId,index=current?s.groupIndex:s.nextGroupIndex;
    const migration=c.saveCompatibility?.sceneDestinations.find(m=>m.from===id);
    if(migration){const probe=Object.create(Novel.prototype);probe.state=s;probe.core=Object.create(G.Game.prototype);probe.core.state=cs;const selected=probe._selectNode(index).id;
     if(migration.to.includes(selected)){if(current)s.nodeId=selected;else s.nextNodeId=selected;if(last)last.nextNodeId=selected;}
    }
   }
   return ok({state:clone(s),coreState:clone(cs)});
  }catch(e){return fail('无法载入小说存档：'+e.message);}
 }
 static fromSave(raw){const v=Novel.validateSave(raw);if(!v.ok)throw Error(v.error);const n=Object.create(Novel.prototype);n.state=v.state;n.core=Object.create(G.Game.prototype);n.core.state=v.coreState;return n;}
}
G.Novel=Novel;if(typeof module!=='undefined'&&module.exports)module.exports=Novel;
})(globalThis);
