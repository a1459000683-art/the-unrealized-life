/* Small, conservative startup layer; runs before the data and game scripts. */
(function (w, d) {
  'use strict';
  if (!w.globalThis) w.globalThis = w;
  if (!Array.prototype.at) Object.defineProperty(Array.prototype, 'at', { configurable: true, writable: true, value: function (n) { var i = Math.trunc(Number(n) || 0); if (i < 0) i += this.length; return this[i]; } });
  if (!Object.fromEntries) Object.fromEntries = function (items) {
    var out = {}, row, step, i = 0, iterator = typeof Symbol !== 'undefined' && items && items[Symbol.iterator] ? items[Symbol.iterator]() : null;
    if (!iterator && (!items || typeof items.length !== 'number')) throw new TypeError('Expected entries');
    while (iterator ? !(step = iterator.next()).done : i < items.length) {
      row = iterator ? step.value : items[i++];
      if (!row || typeof row !== 'object') throw new TypeError('Invalid entry');
      Object.defineProperty(out, row[0], { value: row[1], enumerable: true, configurable: true, writable: true });
    }
    return out;
  };
  var ready = false, failed = false;
  function notice(message) {
    if (ready) return;
    var el = d.getElementById('boot-status');
    if (!el) return;
    el.hidden = false;
    var body = el.querySelector('[data-boot-message]');
    if (body) body.textContent = message;
    else el.textContent = message;
  }
  w.NOVEL_BOOT_READY = function () {
    ready = true;
    var el = d.getElementById('boot-status');
    if (el) el.hidden = true;
    d.documentElement.setAttribute('data-game-ready', 'true');
  };
  w.NOVEL_BOOT_FAIL = function (error) {
    failed = true;
    notice('游戏未能完成初始化。请用系统 Safari 或 Chrome 打开，或尝试下方连接检查。错误：' + String(error && error.message || error || '未知错误').slice(0, 180));
  };
  w.addEventListener('error', function (event) { if (event.message) w.NOVEL_BOOT_FAIL(event.message); });
  w.addEventListener('unhandledrejection', function (event) { w.NOVEL_BOOT_FAIL(event.reason || '初始化请求未完成'); });
  w.setTimeout(function () { if (!failed) notice('还在打开这段人生。如果长时间没有变化，请点下方“连接检查”，区分网络下载与浏览器运行问题。'); }, 12000);
}(window, document));
