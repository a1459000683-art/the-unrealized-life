/* 静态手写剧情。所有私人经历及海岬资产管理均为虚构。 */
globalThis.STORY = {
  "version": 1,
  "setting": "所有雇主、人物、对话与私人事件均为虚构；市场路径由独立历史数据库决定。",
  "characters": [
    {
      "id": "lin",
      "name": "林知远",
      "role": "资深研究员与研究导师",
      "goal": "把能被别人复核的研究方法留下，业余修复旧家具",
      "boundary": "不替任何人签自己没有读过的报告",
      "roleHistory": [
        {
          "from": "2000-01-01",
          "role": "资深研究员与研究导师"
        },
        {
          "from": "2010-01-01",
          "role": "退休研究员，旧家具修复爱好者"
        }
      ]
    },
    {
      "id": "mara",
      "name": "玛拉·韦斯",
      "role": "海岬资产管理组合主管",
      "goal": "让团队在集团的预算争夺中活下来，也争取自己的席位",
      "boundary": "不接受绕过委员会动用客户资金",
      "roleHistory": [
        {
          "from": "2000-01-01",
          "role": "海岬资产管理组合主管"
        }
      ]
    },
    {
      "id": "june",
      "name": "朱恩·赵",
      "role": "客户关系负责人",
      "goal": "让客户的实际用款日期进入投资决策，也为自己的生活留下稳定时间",
      "boundary": "拒绝用保本承诺换取续约",
      "roleHistory": [
        {
          "from": "2000-01-01",
          "role": "客户关系负责人"
        }
      ]
    },
    {
      "id": "elias",
      "name": "伊莱·洛佩斯",
      "role": "合规同事",
      "goal": "建立遇到压力仍可使用的记录制度",
      "boundary": "不能为朋友删除利益冲突记录",
      "roleHistory": [
        {
          "from": "2000-01-01",
          "role": "合规同事"
        },
        {
          "from": "2016-01-01",
          "role": "公益机构运营人员"
        }
      ]
    },
    {
      "id": "mei",
      "name": "梅·陈",
      "role": "博物馆藏品登记员",
      "goal": "完成自己的巡回展，在友情中保留独立生活",
      "boundary": "不无限等待没有日期的约定",
      "roleHistory": [
        {
          "from": "2000-01-01",
          "role": "博物馆藏品登记员"
        },
        {
          "from": "2011-01-01",
          "role": "展览项目主管"
        }
      ]
    },
    {
      "id": "sam",
      "name": "山姆·里德",
      "role": "年轻研究同事",
      "goal": "得到可署名的工作，兼顾父亲的日常照护",
      "boundary": "不再长期承担别人的紧急加班",
      "roleHistory": [
        {
          "from": "2000-01-01",
          "role": "年轻研究同事"
        },
        {
          "from": "2014-01-01",
          "role": "另一家机构的小团队负责人"
        }
      ]
    },
    {
      "id": "nora",
      "name": "诺拉·陈",
      "role": "姐姐，建筑绘图员",
      "goal": "开自己的小事务所，与家人平等分担照顾责任",
      "boundary": "不把自己的工作永远排在玩家工作后面",
      "roleHistory": [
        {
          "from": "2000-01-01",
          "role": "姐姐，建筑绘图员"
        },
        {
          "from": "2005-01-01",
          "role": "姐姐，独立建筑绘图事务所负责人"
        }
      ]
    },
    {
      "id": "darius",
      "name": "达里厄斯·科尔",
      "role": "社区图书馆成人教育协调员",
      "goal": "让夜校课程靠稳定预算运转，而非靠讲师的英雄主义",
      "boundary": "不接受以课程名义推销金融产品",
      "roleHistory": [
        {
          "from": "2000-01-01",
          "role": "社区图书馆成人教育协调员"
        }
      ]
    }
  ],
  "events": [
    {
      "id": "b00",
      "stage": 0,
      "kind": "base",
      "date": "2000-01-01",
      "endDate": "2000-06-30",
      "title": "你的名字在门口",
      "text": "海岬资产管理租在集团大楼的第十九层。你二十四岁，桌上有一部能接内线的电话、一摞上季度报告和一张尚未填好的覆盖名单。玛拉说明：研究员可以建议，获批之前不能动客户的账户。午休时，姐姐诺拉打来电话，问你星期日是否还有空。第一天还没有一分钱收益，但几张日历已经开始争抢同一个人。",
      "characters": [
        "mara",
        "nora"
      ],
      "choices": [
        {
          "label": "先把授权边界问清",
          "detail": "把第一次委员会准备留在日程上。",
          "effects": {
            "research": 4,
            "trust": 3,
            "flags": [
              "first_rules",
              "process_discipline"
            ]
          },
          "id": "b00_1",
          "cost": {},
          "delayed": []
        },
        {
          "label": "把星期日留给诺拉",
          "detail": "一项具体约定进入记忆账本。",
          "effects": {
            "freedom": 4,
            "relations": {
              "nora": 8
            },
            "flags": [
              "sunday_promised",
              "life_priority"
            ]
          },
          "delayed": [
            {
              "years": 5,
              "text": "诺拉仍留着你第一份工作的办公地址。她为新事务所找房时，把看房日期发给了你。",
              "effects": {
                "relations": {
                  "nora": 2
                }
              },
              "flag": "family_echo"
            }
          ],
          "id": "b00_2",
          "cost": {}
        },
        {
          "label": "请朱恩带你旁听客户电话",
          "detail": "学习客户需要的语言，占用首次资料整理时间。",
          "effects": {
            "communication": 5,
            "research": -1,
            "relations": {
              "june": 6
            },
            "flags": [
              "client_horizon"
            ]
          },
          "id": "b00_3",
          "cost": {
            "research": 1
          },
          "delayed": []
        }
      ],
      "key": false,
      "requires": {}
    },
    {
      "id": "c00",
      "stage": 0,
      "kind": "conditional",
      "date": "2000-01-01",
      "endDate": "2000-06-30",
      "title": "还款日的铅笔印",
      "text": "你的第一张工资单还没来，学生贷款的还款日已经到了。你把房租、电费和最低还款额写在便笺背面，发现所谓能承受波动，首先是月底还能不能买一张车票。诺拉说可以让你暂住，但她也需要书桌画图。玛拉没有追问你的私人数字，只提醒奖金从来不是合同中保证的工资。",
      "characters": [
        "nora",
        "mara"
      ],
      "choices": [
        {
          "label": "先偿还一小笔本金",
          "detail": "从个人现金支付，降低债务；不触碰客户账户。",
          "effects": {
            "personalCash": -1500,
            "debt": -1500,
            "stress": -4,
            "flags": [
              "debt_paid",
              "process_discipline"
            ]
          },
          "id": "c00_1",
          "cost": {
            "personalCash": 1500
          },
          "delayed": []
        },
        {
          "label": "保留应急现金",
          "detail": "接受利息成本，为失业或搬家保留余地。",
          "effects": {
            "freedom": 4,
            "stress": 2,
            "flags": [
              "cash_buffer",
              "life_priority"
            ]
          },
          "id": "c00_2",
          "cost": {},
          "delayed": []
        },
        {
          "label": "和姐姐约定三个月合住",
          "detail": "本期住房费用返还 $1,200 记入个人现金；承诺共同承担家务。",
          "effects": {
            "personalCash": 1200,
            "relations": {
              "nora": 6
            },
            "flags": [
              "sunday_promised",
              "shared_room"
            ]
          },
          "id": "c00_3",
          "cost": {},
          "delayed": []
        }
      ],
      "key": false,
      "requires": {
        "flagsAll": [
          "start_debt"
        ]
      },
      "chain": "family"
    },
    {
      "id": "b01",
      "stage": 1,
      "kind": "base",
      "date": "2000-07-01",
      "endDate": "2000-12-31",
      "title": "报告的最后一页",
      "text": "林知远把你的第一份备忘录退回来，最后一页只有两个圈：现金从哪里来，以及什么会证明你错。你以为需要把预测写得更精确，他却让你保留删去的那段反对意见。打印机吐出两份版本；一份适合放进会议夹，一份足以让几年后的自己想起，当初其实没有那么确定。",
      "characters": [
        "lin"
      ],
      "choices": [
        {
          "label": "把反对意见留进正式版本",
          "detail": "研究过程留下可复核记录。",
          "effects": {
            "research": 7,
            "trust": 3,
            "flags": [
              "archive_kept",
              "process_discipline"
            ]
          },
          "delayed": [
            {
              "years": 3,
              "text": "旧报告里保留的反对意见成为一次新审查的起点。林知远请你带原稿，而不是只带最新结论。",
              "effects": {
                "research": 2
              },
              "flag": "archive_echo"
            }
          ],
          "id": "b01_1",
          "cost": {}
        },
        {
          "label": "先交简短版本，另存原稿",
          "detail": "提高沟通效率，同时承诺保留底稿。",
          "effects": {
            "communication": 5,
            "research": 2,
            "flags": [
              "archive_kept",
              "brief_writer"
            ]
          },
          "id": "b01_2",
          "cost": {},
          "delayed": []
        },
        {
          "label": "删去异议，强调最有把握的判断",
          "detail": "更容易被会议听见，未解决问题留给以后。",
          "effects": {
            "reputation": 5,
            "research": -2,
            "stress": 2,
            "flags": [
              "clean_story"
            ]
          },
          "id": "b01_3",
          "cost": {
            "research": 2
          },
          "delayed": []
        }
      ],
      "key": false,
      "chain": "archive",
      "requires": {}
    },
    {
      "id": "c01",
      "stage": 1,
      "kind": "conditional",
      "date": "2000-07-01",
      "endDate": "2000-12-31",
      "title": "熟人的午餐桌",
      "text": "带你认识玛拉的老同学邀请你吃午饭。桌上还坐着两位从业多年的朋友，他们谈起的职位都比你的名片大。饭快吃完时，有人让你把小组尚未公开的组合意见发来，说只是看看。你确实因关系较容易走进这扇门，但能否留在里面，未必取决于提供更多内部材料。服务生递来账单，话题还在等你的回答。",
      "characters": [
        "mara",
        "elias"
      ],
      "choices": [
        {
          "label": "只分享公开的研究方法",
          "detail": "守住内部资料边界，关系不等于访问权。",
          "effects": {
            "trust": 6,
            "communication": 3,
            "relations": {
              "elias": 4
            },
            "flags": [
              "archive_kept",
              "network_boundary"
            ]
          },
          "id": "c01_1",
          "cost": {},
          "delayed": []
        },
        {
          "label": "请他们介绍不同岗位的工作内容",
          "detail": "把这次关系机会用于了解职业。",
          "effects": {
            "freedom": 6,
            "communication": 4,
            "flags": [
              "network_option",
              "archive_kept"
            ]
          },
          "id": "c01_2",
          "cost": {},
          "delayed": []
        },
        {
          "label": "答应回去确认可分享范围",
          "detail": "承诺占用后续沟通时间，尚不传出任何材料。",
          "effects": {
            "stress": 3,
            "trust": 2,
            "flags": [
              "network_review",
              "archive_kept"
            ]
          },
          "id": "c01_3",
          "cost": {},
          "delayed": []
        }
      ],
      "key": false,
      "requires": {
        "flagsAll": [
          "start_network"
        ]
      },
      "chain": "archive"
    },
    {
      "id": "b02",
      "stage": 2,
      "kind": "base",
      "date": "2001-01-01",
      "endDate": "2001-06-30",
      "title": "星期三的灯",
      "text": "你连续两周离开办公室时，走廊的灯已经熄了一半。电梯里，伊莱拿着游泳袋；他不是没有待办事项，只是把星期三写成了不能再借的时间。你回家发现冰箱里只剩酱油和一盒过期酸奶。明天的资料不会自己读完，但身体也不会因为月底才评价业绩，就把疲劳等到月底再计算。",
      "characters": [
        "elias"
      ],
      "choices": [
        {
          "label": "固定一个恢复的晚上",
          "detail": "持续边界成为后续健康选择的依据。",
          "effects": {
            "health": 7,
            "stress": -6,
            "research": -1,
            "flags": [
              "wednesday_kept",
              "boundaries_kept"
            ]
          },
          "delayed": [
            {
              "years": 4,
              "text": "你保留下来的星期三没有让工作消失，却使一项长期安排仍能继续。伊莱把新泳道的时间告诉了你。",
              "effects": {
                "health": 3
              },
              "flag": "health_echo"
            }
          ],
          "id": "b02_1",
          "cost": {
            "research": 1
          }
        },
        {
          "label": "先赶完报告，下周再说",
          "detail": "当期研究推进，恢复承诺尚未兑现。",
          "effects": {
            "research": 6,
            "health": -4,
            "stress": 6,
            "flags": [
              "overtime_habit"
            ]
          },
          "id": "b02_2",
          "cost": {
            "health": 4
          },
          "delayed": []
        },
        {
          "label": "请林知远帮你删减问题",
          "detail": "通过缩小研究范围腾出休息，不假装面面俱到。",
          "effects": {
            "communication": 4,
            "research": 3,
            "stress": -2,
            "relations": {
              "lin": 4
            },
            "flags": [
              "scope_discipline",
              "wednesday_kept"
            ]
          },
          "id": "b02_3",
          "cost": {},
          "delayed": []
        }
      ],
      "key": false,
      "chain": "health",
      "requires": {}
    },
    {
      "id": "c02",
      "stage": 2,
      "kind": "conditional",
      "date": "2001-01-01",
      "endDate": "2001-06-30",
      "title": "没有花完的缓冲",
      "text": "你的个人账户里有一笔足够应付数月生活的缓冲。一个同事劝你别让它闲着，你却发现，现金给你的第一种回报是敢于在会上说“我还没核对”。午后，林知远给出两个选项：跟着做一份跨行业资料索引，或者争取更快看见成果的短期项目。两者都占时间，资金宽裕没有消除选择本身。",
      "characters": [
        "lin"
      ],
      "choices": [
        {
          "label": "用缓冲换一段学习时间",
          "detail": "支付公开课程费用，每周预留恢复时间，不接短期加班项目。",
          "effects": {
            "personalCash": -1200,
            "research": 9,
            "freedom": 3,
            "flags": [
              "cross_training",
              "wednesday_kept"
            ]
          },
          "id": "c02_1",
          "cost": {
            "personalCash": 1200
          },
          "delayed": []
        },
        {
          "label": "保留现金，设置每周恢复时间",
          "detail": "把财务缓冲与生活边界同时保留。",
          "effects": {
            "health": 6,
            "stress": -5,
            "flags": [
              "cash_buffer",
              "boundaries_kept",
              "wednesday_kept"
            ]
          },
          "id": "c02_2",
          "cost": {},
          "delayed": []
        },
        {
          "label": "接短期项目，争取可见成绩",
          "detail": "增加职业曝光，也提高工作负荷。",
          "effects": {
            "reputation": 7,
            "stress": 6,
            "flags": [
              "sprint_record",
              "overtime_habit"
            ]
          },
          "id": "c02_3",
          "cost": {},
          "delayed": []
        }
      ],
      "key": false,
      "requires": {
        "flagsAll": [
          "start_buffer"
        ]
      },
      "chain": "health"
    },
    {
      "id": "b03",
      "stage": 3,
      "kind": "base",
      "date": "2001-07-01",
      "endDate": "2001-12-31",
      "title": "一封没有收益率的信",
      "text": "朱恩让你读一封客户来信。那是一家虚构地方基金会，信里没有问哪个行业会涨，只写明十八个月后要付屋顶维修款。组合报表上，客户与其他账户一样只是数字；信纸上，时间却具体到一个雨季。朱恩要把这笔钱的期限写进委托文件，会议有人担心现金比例过高会显得没有本事。",
      "characters": [
        "june",
        "mara"
      ],
      "choices": [
        {
          "label": "支持把用款日写入授权",
          "detail": "客户期限影响以后可承受的风险。",
          "effects": {
            "trust": 6,
            "communication": 4,
            "relations": {
              "june": 7
            },
            "flags": [
              "client_horizon"
            ]
          },
          "delayed": [
            {
              "years": 4,
              "text": "基金会再次来信时，朱恩找出了写有用款日期的旧附件。它成为讨论赎回顺序的依据。",
              "effects": {
                "trust": 3
              },
              "flag": "client_echo"
            }
          ],
          "id": "b03_1",
          "cost": {}
        },
        {
          "label": "先展示不同现金比例的代价",
          "detail": "增加准备工作，让客户选择能理解的路径。",
          "effects": {
            "research": 5,
            "communication": 5,
            "stress": 3,
            "flags": [
              "client_horizon",
              "scenario_writer"
            ]
          },
          "id": "b03_2",
          "cost": {},
          "delayed": []
        },
        {
          "label": "只提交标准组合材料",
          "detail": "节省沟通时间，未获得额外客户信任。",
          "effects": {
            "research": 3,
            "relations": {
              "june": -3
            },
            "flags": [
              "standard_service"
            ]
          },
          "id": "b03_3",
          "cost": {},
          "delayed": []
        }
      ],
      "key": false,
      "chain": "clients",
      "requires": {}
    },
    {
      "id": "c03",
      "stage": 3,
      "kind": "conditional",
      "date": "2001-07-01",
      "endDate": "2001-12-31",
      "title": "仍夹在档案里的电话条",
      "text": "你在报告底稿旁保存的反对意见引来第二次讨论。林知远没有表扬结论，而是让你把客户什么时候需要钱也写在同一张纸上。朱恩带来一张手写电话条：一位客户只能承受暂时亏损，不能承受付款日没有现金。过去那页纸证明了你愿意保留疑问，如今它还需要容纳别人的时间。",
      "characters": [
        "lin",
        "june"
      ],
      "choices": [
        {
          "label": "把证据与用款期限分栏记录",
          "detail": "研究判断与客户适配分别评价。",
          "effects": {
            "research": 5,
            "trust": 5,
            "flags": [
              "client_horizon",
              "risk_record"
            ]
          },
          "id": "c03_1",
          "cost": {},
          "delayed": []
        },
        {
          "label": "请朱恩向客户解释波动区间",
          "detail": "把沟通作为研究的一部分。",
          "effects": {
            "communication": 7,
            "relations": {
              "june": 6
            },
            "flags": [
              "client_horizon"
            ]
          },
          "id": "c03_2",
          "cost": {},
          "delayed": []
        },
        {
          "label": "先聚焦公司，期限交给客户团队",
          "detail": "专业分工较窄，仍保留研究底稿。",
          "effects": {
            "research": 7,
            "communication": -2,
            "flags": [
              "research_specialist"
            ]
          },
          "id": "c03_3",
          "cost": {},
          "delayed": []
        }
      ],
      "key": false,
      "requires": {
        "flagsAll": [
          "archive_kept"
        ]
      },
      "chain": "archive",
      "recall": {
        "flag": "archive_kept",
        "text": "你曾选择留下反对意见，旧稿因此仍在。"
      }
    },
    {
      "id": "b04",
      "stage": 4,
      "kind": "base",
      "date": "2002-01-01",
      "endDate": "2002-06-30",
      "title": "在下跌之前写完",
      "text": "委员会的新表格只有四栏：理由、风险、期限和承认判断失效的证据。玛拉说，填表不代表会批准交易，也不会因为股价跌了就认定一切错误。你却发现，写“持续观察”很容易，写清哪种事实会使你离开很难。窗外正在换一块广告牌，工人先拴好绳索，才拆下第一颗螺丝。",
      "characters": [
        "mara",
        "lin"
      ],
      "choices": [
        {
          "label": "给出可核验的失效证据",
          "detail": "把过程纪律与后来的价格结果分开。",
          "effects": {
            "research": 6,
            "trust": 4,
            "flags": [
              "risk_record",
              "process_discipline"
            ]
          },
          "delayed": [
            {
              "years": 4,
              "text": "一次争论中，你拿出当年的失效条件。记录不能保证结论正确，却让变更判断有了可追踪的理由。",
              "effects": {
                "trust": 3
              },
              "flag": "risk_echo"
            }
          ],
          "id": "b04_1",
          "cost": {}
        },
        {
          "label": "用宽泛理由争取灵活空间",
          "detail": "更容易持续持有，也更难复核承诺。",
          "effects": {
            "freedom": 4,
            "reputation": 3,
            "flags": [
              "elastic_thesis"
            ]
          },
          "id": "b04_2",
          "cost": {},
          "delayed": []
        },
        {
          "label": "申请继续研究，本期保持现金",
          "detail": "没有自动成交；研究工作继续。",
          "effects": {
            "research": 8,
            "stress": 2,
            "flags": [
              "risk_record",
              "patient_research"
            ]
          },
          "id": "b04_3",
          "cost": {},
          "delayed": []
        }
      ],
      "key": false,
      "chain": "risk",
      "requires": {}
    },
    {
      "id": "c04",
      "stage": 4,
      "kind": "conditional",
      "date": "2002-01-01",
      "endDate": "2002-06-30",
      "title": "电话那端的原话",
      "text": "客户电话即将结束，朱恩忽然又问了一遍：这笔钱如果明年要取，你是否仍能接受今天讨论的安排。对方沉默片刻，给出了比问卷保守得多的回答。你曾支持把期限写入文件，现在这份文件使一笔看似有吸引力的建议显得不再合适。没有人要求你预测市场，只需要承认，过去拿到的授权需要重新确认。",
      "characters": [
        "june"
      ],
      "choices": [
        {
          "label": "据新期限申请收紧授权",
          "detail": "明确放弃一部分配置空间，换取适配。",
          "effects": {
            "authority": -5,
            "trust": 8,
            "communication": 4,
            "flags": [
              "risk_record",
              "client_limit"
            ]
          },
          "id": "c04_1",
          "cost": {
            "authority": 5
          },
          "delayed": []
        },
        {
          "label": "准备两套方案等客户书面选择",
          "detail": "保持原有边界，花更多沟通时间。",
          "effects": {
            "communication": 7,
            "stress": 3,
            "flags": [
              "risk_record",
              "client_consent"
            ]
          },
          "id": "c04_2",
          "cost": {},
          "delayed": []
        },
        {
          "label": "撤回这次建议，继续覆盖研究",
          "detail": "研究不等于交易，客户暂不承担新暴露。",
          "effects": {
            "research": 6,
            "trust": 3,
            "flags": [
              "patient_research"
            ]
          },
          "id": "c04_3",
          "cost": {},
          "delayed": []
        }
      ],
      "key": false,
      "requires": {
        "flagsAll": [
          "client_horizon"
        ]
      },
      "chain": "clients",
      "recall": {
        "flag": "client_horizon",
        "text": "你曾支持把客户的实际期限写下来，现在它需要被认真对待。"
      }
    },
    {
      "id": "b05",
      "stage": 5,
      "kind": "base",
      "date": "2002-07-01",
      "endDate": "2002-12-31",
      "title": "纸箱上的铅笔字",
      "text": "梅请你帮忙把几箱旧展览目录搬上楼。她刚获得一次外地展览的工作机会，兴奋过后才发现合同只覆盖一年。你们坐在没有桌子的房间里吃面，谈的并不全是你的工作。临走时她递给你一把备用钥匙，说搬家那天需要有人接安装工，但她会提前确认日期，不会默认你随叫随到。",
      "characters": [
        "mei"
      ],
      "choices": [
        {
          "label": "约定一个能够兑现的半天",
          "detail": "具体约定比随口答应更多时间可靠。",
          "effects": {
            "freedom": 3,
            "relations": {
              "mei": 9
            },
            "flags": [
              "key_held",
              "life_priority"
            ]
          },
          "delayed": [
            {
              "years": 4,
              "text": "梅在一次搬迁前问你是否还能保管备用钥匙。她记得当年约好的半天确实有人到场。",
              "effects": {
                "relations": {
                  "mei": 3
                }
              },
              "flag": "friend_echo"
            }
          ],
          "id": "b05_1",
          "cost": {}
        },
        {
          "label": "说明本期忙，帮她找搬运服务",
          "detail": "支付明确费用，不作无法兑现的陪伴承诺。",
          "effects": {
            "personalCash": -180,
            "relations": {
              "mei": 4
            },
            "flags": [
              "honest_boundary"
            ]
          },
          "id": "b05_2",
          "cost": {
            "personalCash": 180
          },
          "delayed": []
        },
        {
          "label": "答应整天都来，却不调整日程",
          "detail": "获得暂时信任，同时留下待兑现承诺。",
          "effects": {
            "stress": 5,
            "relations": {
              "mei": 3
            },
            "flags": [
              "moving_promise",
              "overpromise"
            ]
          },
          "id": "b05_3",
          "cost": {},
          "delayed": []
        }
      ],
      "key": false,
      "chain": "friend",
      "requires": {}
    },
    {
      "id": "c05",
      "stage": 5,
      "kind": "conditional",
      "date": "2002-07-01",
      "endDate": "2002-12-31",
      "title": "写着星期三的日历",
      "text": "你的日历第一次出现了连续几个月相同的空白。梅想把一场小型展览安排在星期三晚上，问你是否愿意做第一个观众。她已经邀请了别的朋友，不会因为你缺席就取消。桌上还有一份可以再多核对一遍的材料，你发现边界并不只用来拒绝工作，也需要有人认真决定把留下来的时间给什么。",
      "characters": [
        "mei",
        "elias"
      ],
      "choices": [
        {
          "label": "去看展览，并听她讲自己的工作",
          "detail": "巩固陪伴，不把聚会变成自己的职场倾诉。",
          "effects": {
            "health": 3,
            "stress": -4,
            "relations": {
              "mei": 8
            },
            "flags": [
              "key_held",
              "life_priority"
            ]
          },
          "id": "c05_1",
          "cost": {},
          "delayed": []
        },
        {
          "label": "去游泳，把周末另留给朋友",
          "detail": "保留恢复安排，并作一个有限承诺。",
          "effects": {
            "health": 7,
            "relations": {
              "mei": 3
            },
            "flags": [
              "boundaries_kept",
              "weekend_friend"
            ]
          },
          "id": "c05_2",
          "cost": {},
          "delayed": []
        },
        {
          "label": "借出这一次晚上赶材料",
          "detail": "研究推进；是否形成习惯留待以后选择。",
          "effects": {
            "research": 6,
            "stress": 4,
            "health": -2,
            "flags": [
              "borrowed_evening"
            ]
          },
          "id": "c05_3",
          "cost": {
            "health": 2
          },
          "delayed": []
        }
      ],
      "key": false,
      "requires": {
        "flagsAll": [
          "wednesday_kept"
        ]
      },
      "chain": "health",
      "recall": {
        "flag": "wednesday_kept",
        "text": "你曾把星期三列为恢复时间，现在要决定如何使用它。"
      }
    },
    {
      "id": "b06",
      "stage": 6,
      "kind": "base",
      "date": "2003-01-01",
      "endDate": "2003-06-30",
      "title": "导师空着的一格",
      "text": "林知远要你独立主持一次研究例会。他仍坐在靠门的位置，却把主讲人的名字一栏留空，等你自己填。材料中有一处尚未核验的经营数字；用它，论证会更顺，用空缺，会议一定有人追问。你已经能读懂很多术语，但真正站到投影前，才知道一句“目前还不知道”也需要练习。",
      "characters": [
        "lin",
        "mara"
      ],
      "choices": [
        {
          "label": "保留空缺并说明验证计划",
          "detail": "未知不被包装成事实。",
          "effects": {
            "research": 6,
            "trust": 5,
            "authority": 5,
            "flags": [
              "evidence_boundary"
            ]
          },
          "id": "b06_1",
          "cost": {},
          "delayed": []
        },
        {
          "label": "用可核验的区间代替单点估算",
          "detail": "清楚标示假设，争取有限试行授权。",
          "effects": {
            "communication": 6,
            "trust": 3,
            "authority": 5,
            "flags": [
              "scenario_writer"
            ]
          },
          "id": "b06_2",
          "cost": {},
          "delayed": []
        },
        {
          "label": "暂缓推荐，先完成核验",
          "detail": "错过本次展示机会，保留过程信誉。",
          "effects": {
            "research": 8,
            "reputation": -2,
            "flags": [
              "patient_research"
            ]
          },
          "id": "b06_3",
          "cost": {
            "reputation": 2
          },
          "delayed": []
        }
      ],
      "key": false,
      "requires": {}
    },
    {
      "id": "c06",
      "stage": 6,
      "kind": "conditional",
      "date": "2003-01-01",
      "endDate": "2003-06-30",
      "title": "原稿上的订书钉",
      "text": "林知远让你带来三年前的第一份原稿。订书钉生了细小的锈，反对意见仍在最后一页。他要从中挑一份做新人的培训材料，也愿意把作者名字印上去。你可以删掉幼稚之处，使它像一篇从未犹豫的报告；也可以留下修改痕迹，让别人知道，一份有用的研究是怎样逐步长出来的。",
      "characters": [
        "lin",
        "sam"
      ],
      "choices": [
        {
          "label": "保留修改痕迹，接受署名",
          "detail": "把不确定性作为可传授的方法。",
          "effects": {
            "research": 6,
            "reputation": 5,
            "relations": {
              "lin": 7
            },
            "flags": [
              "archive_shared",
              "credit_record"
            ]
          },
          "id": "c06_1",
          "cost": {},
          "delayed": []
        },
        {
          "label": "请林知远共同署名并补注日期",
          "detail": "确认协作贡献，避免改写过去信息。",
          "effects": {
            "trust": 6,
            "communication": 4,
            "flags": [
              "archive_shared",
              "credit_record"
            ]
          },
          "id": "c06_2",
          "cost": {},
          "delayed": []
        },
        {
          "label": "只作匿名内部案例",
          "detail": "放弃曝光，但保留档案用途。",
          "effects": {
            "freedom": 3,
            "research": 5,
            "flags": [
              "archive_shared",
              "quiet_teacher"
            ]
          },
          "id": "c06_3",
          "cost": {},
          "delayed": []
        }
      ],
      "key": false,
      "requires": {
        "flagsAll": [
          "archive_kept"
        ]
      },
      "chain": "archive",
      "recall": {
        "flag": "archive_kept",
        "text": "这份原稿存在，是因为你曾选择保存反对意见。"
      }
    },
    {
      "id": "b07",
      "stage": 7,
      "kind": "base",
      "date": "2003-07-01",
      "endDate": "2003-12-31",
      "title": "雨季前的会议",
      "text": "客户会议安排在周五下午。朱恩把支出计划放在收益图前面，玛拉担心客户以为团队在逃避讨论业绩。你分到十分钟，既要说清公司为什么值得继续研究，也要解释为什么不是所有现金都必须马上投出去。会议室里没有人举着标准答案，只有不同的人在等待不同时间能用的钱。",
      "characters": [
        "june",
        "mara"
      ],
      "choices": [
        {
          "label": "先讲期限，再讲投资机会",
          "detail": "增进理解，但不会直接获得更高奖金。",
          "effects": {
            "communication": 8,
            "trust": 4,
            "flags": [
              "client_horizon",
              "client_listener"
            ]
          },
          "id": "b07_1",
          "cost": {},
          "delayed": []
        },
        {
          "label": "先展示研究证据及其局限",
          "detail": "巩固研究角色，明确无法承诺的结果。",
          "effects": {
            "research": 6,
            "communication": 3,
            "flags": [
              "evidence_boundary"
            ]
          },
          "id": "b07_2",
          "cost": {},
          "delayed": []
        },
        {
          "label": "让玛拉主讲，自己记录疑问",
          "detail": "内部关系改善，自主表达练习较少。",
          "effects": {
            "relations": {
              "mara": 6
            },
            "trust": 3,
            "flags": [
              "committee_support"
            ]
          },
          "id": "b07_3",
          "cost": {},
          "delayed": []
        }
      ],
      "key": false,
      "requires": {}
    },
    {
      "id": "c07",
      "stage": 7,
      "kind": "conditional",
      "date": "2003-07-01",
      "endDate": "2003-12-31",
      "title": "提前一年到的确认函",
      "text": "两年前写下的用款日期离现在已经很近。朱恩拿来确认函，客户要求把一部分账户保持为可用现金；这并不是对你研究能力的评判。你准备的公司材料还没有等到期待中的证据。把两件事放在同一张桌子上令人不舒服，却也使期限成为可执行的约束，而不是一段只在签约时出现的文字。",
      "characters": [
        "june",
        "mara"
      ],
      "choices": [
        {
          "label": "支持降低这部分委托的授权上限",
          "detail": "上限收紧；现有仓位仍须按交易规则处理。",
          "effects": {
            "authority": -5,
            "trust": 8,
            "flags": [
              "client_served",
              "client_limit"
            ]
          },
          "id": "c07_1",
          "cost": {
            "authority": 5
          },
          "delayed": []
        },
        {
          "label": "安排一次提前沟通，确认赎回节奏",
          "detail": "以额外沟通减少临近用款日的意外。",
          "effects": {
            "communication": 8,
            "stress": 3,
            "flags": [
              "client_served",
              "client_listener"
            ]
          },
          "id": "c07_2",
          "cost": {},
          "delayed": []
        },
        {
          "label": "将这笔客户转给更匹配的同事",
          "detail": "关系保持，个人职业曝光减少。",
          "effects": {
            "reputation": -3,
            "freedom": 4,
            "relations": {
              "june": 4
            },
            "flags": [
              "client_transferred"
            ]
          },
          "id": "c07_3",
          "cost": {
            "reputation": 3
          },
          "delayed": []
        }
      ],
      "key": false,
      "requires": {
        "flagsAll": [
          "client_horizon"
        ]
      },
      "chain": "clients",
      "recall": {
        "flag": "client_horizon",
        "text": "早年写下的客户期限如今进入执行阶段。"
      }
    },
    {
      "id": "b08",
      "stage": 8,
      "kind": "base",
      "date": "2004-01-01",
      "endDate": "2004-06-30",
      "title": "抽屉里的交易清单",
      "text": "伊莱在茶水间向大家发放个人交易申报表。今天讲的是海岬的内部政策：个人账户需要事前审批，接触未公开资料的人要回避相关交易。他特地把内部要求与当时的外部规定分开写，不用一句“法律要求”遮住所有细节。你抽屉里还有一张自己想研究的名单，申报会让原本方便的事情多一道步骤。",
      "characters": [
        "elias"
      ],
      "choices": [
        {
          "label": "完整申报并设置回避记录",
          "detail": "个人交易权限受审查；换取可审计的信任。",
          "effects": {
            "trust": 7,
            "communication": 2,
            "flags": [
              "ethics_record",
              "compliance_clear"
            ]
          },
          "delayed": [
            {
              "years": 6,
              "text": "旧申报表在一次资料迁移中被找到，日期与审批记录都完整。它减少了复核你个人交易的来回询问。",
              "effects": {
                "trust": 3
              },
              "flag": "ethics_echo"
            }
          ],
          "id": "b08_1",
          "cost": {}
        },
        {
          "label": "暂停私人交易，先熟悉政策",
          "detail": "保留现金，承诺不绕过审批。",
          "effects": {
            "freedom": -2,
            "research": 4,
            "trust": 4,
            "flags": [
              "personal_pause",
              "ethics_record"
            ]
          },
          "id": "b08_2",
          "delayed": [
            {
              "years": 1,
              "text": "你已完成个人交易政策的学习与申报复核，自愿暂停结束。后续个人买入仍须按当期机构政策审批。",
              "effects": {
                "removeFlags": [
                  "personal_pause"
                ]
              },
              "flag": "personal_policy_reviewed"
            }
          ],
          "cost": {
            "freedom": 2
          }
        },
        {
          "label": "要求书面澄清边界后再提交",
          "detail": "合规沟通增加，记录未被省略。",
          "effects": {
            "communication": 6,
            "stress": 2,
            "relations": {
              "elias": 3
            },
            "flags": [
              "ethics_record",
              "policy_reader"
            ]
          },
          "id": "b08_3",
          "cost": {},
          "delayed": []
        }
      ],
      "key": false,
      "chain": "ethics",
      "requires": {}
    },
    {
      "id": "c08",
      "stage": 8,
      "kind": "conditional",
      "date": "2004-01-01",
      "endDate": "2004-06-30",
      "title": "被借走的署名页",
      "text": "你的培训材料被放进一场集团汇报。邀请函上只有玛拉的名字，她说这是集团习惯，不是针对你。林知远建议先确认材料版本，山姆则盯着那一页作者栏看了很久。你先前曾选择让研究留下署名，现在要决定是安静收起原稿，还是把协作贡献变成一项具体的工作约定。",
      "characters": [
        "mara",
        "lin",
        "sam"
      ],
      "choices": [
        {
          "label": "私下请求补上团队贡献页",
          "detail": "维护署名记录，承担一次困难对话。",
          "effects": {
            "communication": 6,
            "stress": 3,
            "relations": {
              "mara": -2,
              "sam": 5
            },
            "flags": [
              "credit_defended"
            ]
          },
          "id": "c08_1",
          "delayed": [
            {
              "years": 8,
              "text": "八年前那次署名讨论的原邮件，在履历复核中成为可用的证据。它说明你实际承担过什么，也保留了其他人的贡献；并不保证获得新职位。",
              "effects": {
                "trust": 3,
                "reputation": 2
              },
              "flag": "credit_legacy"
            }
          ],
          "cost": {}
        },
        {
          "label": "允许这次使用，书面约定以后规则",
          "detail": "换取内部合作，也保留将来可引用的承诺。",
          "effects": {
            "trust": 4,
            "relations": {
              "mara": 4
            },
            "flags": [
              "credit_agreement"
            ]
          },
          "id": "c08_2",
          "delayed": [
            {
              "years": 8,
              "text": "八年前那次署名讨论的原邮件，在履历复核中成为可用的证据。它说明你实际承担过什么，也保留了其他人的贡献；并不保证获得新职位。",
              "effects": {
                "trust": 3,
                "reputation": 2
              },
              "flag": "credit_legacy"
            }
          ],
          "cost": {}
        },
        {
          "label": "把时间放回研究，保存原始邮件",
          "detail": "暂时不争取曝光，底稿仍可核验。",
          "effects": {
            "research": 6,
            "reputation": -2,
            "flags": [
              "credit_evidence"
            ]
          },
          "id": "c08_3",
          "delayed": [
            {
              "years": 8,
              "text": "八年前那次署名讨论的原邮件，在履历复核中成为可用的证据。它说明你实际承担过什么，也保留了其他人的贡献；并不保证获得新职位。",
              "effects": {
                "trust": 3,
                "reputation": 2
              },
              "flag": "credit_legacy"
            }
          ],
          "cost": {
            "reputation": 2
          }
        }
      ],
      "key": false,
      "requires": {
        "flagsAll": [
          "credit_record"
        ]
      },
      "chain": "credit",
      "recall": {
        "flag": "credit_record",
        "text": "你曾在培训材料中明确过作者和协作贡献。"
      }
    },
    {
      "id": "b09",
      "stage": 9,
      "kind": "base",
      "date": "2004-07-01",
      "endDate": "2004-12-31",
      "title": "第一次有条件的授权",
      "text": "玛拉递来一张试行授权书。允许的不是随意押注，而是在既定现金、集中度和研究记录约束内提交较大的配置；如果违反约束，授权会收回。工资条不会因为这张纸立刻改变。你可以接受、要求更窄的范围，或继续当研究员。门外有人等着开会，决定却没有必须赶在电梯到来前做完。",
      "characters": [
        "mara",
        "lin"
      ],
      "choices": [
        {
          "label": "接受有限试行授权",
          "detail": "得到更大操作空间与工作负担。",
          "effects": {
            "authority": 10,
            "stress": 5,
            "reputation": 4,
            "career": "manager",
            "flags": [
              "mandate_trial"
            ]
          },
          "id": "b09_1",
          "cost": {},
          "delayed": []
        },
        {
          "label": "要求较小额度与明确复核日期",
          "detail": "进展较慢，纪律和边界更清楚。",
          "effects": {
            "authority": 5,
            "trust": 6,
            "flags": [
              "mandate_trial",
              "process_discipline"
            ]
          },
          "id": "b09_2",
          "cost": {},
          "delayed": []
        },
        {
          "label": "继续做研究，暂不带组合",
          "detail": "保留研究深度和较多生活空间。",
          "effects": {
            "research": 8,
            "freedom": 5,
            "flags": [
              "research_specialist"
            ]
          },
          "id": "b09_3",
          "cost": {},
          "delayed": []
        }
      ],
      "key": false,
      "requires": {}
    },
    {
      "id": "c09",
      "stage": 9,
      "kind": "conditional",
      "date": "2004-07-01",
      "endDate": "2004-12-31",
      "title": "附在信封里的小字",
      "text": "先前关于署名的书面约定出现在晋升材料里。玛拉把你列为独立负责一段研究的人，同时要求你承担对客户解释结论的工作。那封邮件没有替你赢得所有人的支持，却让委员会能看见具体职责。你可以接受这一步，也可以选择不把每一次认可都换成更多管理任务。",
      "characters": [
        "mara",
        "june"
      ],
      "choices": [
        {
          "label": "接下职责，并保留团队署名规则",
          "detail": "职位机会与沟通责任一起增加。",
          "effects": {
            "authority": 10,
            "communication": 4,
            "stress": 4,
            "career": "manager",
            "flags": [
              "credit_honored",
              "mandate_trial"
            ]
          },
          "id": "c09_1",
          "cost": {},
          "delayed": []
        },
        {
          "label": "接受高级研究职责，不带更大组合",
          "detail": "增加专业认可，授权维持原状。",
          "effects": {
            "research": 8,
            "reputation": 6,
            "freedom": 2,
            "flags": [
              "credit_honored",
              "research_specialist"
            ]
          },
          "id": "c09_2",
          "cost": {},
          "delayed": []
        },
        {
          "label": "把这次展示机会让给共同作者",
          "detail": "帮助同事，也放慢自己的曝光。",
          "effects": {
            "trust": 7,
            "relations": {
              "sam": 7
            },
            "flags": [
              "shared_credit",
              "credit_honored"
            ]
          },
          "id": "c09_3",
          "cost": {},
          "delayed": []
        }
      ],
      "key": false,
      "requires": {
        "flagsAll": [
          "credit_agreement"
        ]
      },
      "chain": "credit",
      "recall": {
        "flag": "credit_agreement",
        "text": "此前的书面署名约定被正式引用，承诺有了兑现的机会。"
      }
    },
    {
      "id": "b10",
      "stage": 10,
      "kind": "base",
      "date": "2005-01-01",
      "endDate": "2005-06-30",
      "title": "图书馆的折叠椅",
      "text": "达里厄斯正在社区图书馆办一门读懂账单的夜课。他找到你，不是要一位预测市场的明星，而是缺一个能把利息、费用和风险说清楚的人。教室里只有十二把折叠椅，讲课没有报酬，也不允许推销产品。他希望你至少答应一个学期；一次热闹的分享会容易安排，连续六个周二却要真正挪动生活。",
      "characters": [
        "darius"
      ],
      "choices": [
        {
          "label": "接下一个学期，限制课程范围",
          "detail": "固定投入时间，学习向非专业者解释。",
          "effects": {
            "communication": 7,
            "freedom": -3,
            "stress": 2,
            "relations": {
              "darius": 8
            },
            "flags": [
              "teaching",
              "school_commitment"
            ]
          },
          "delayed": [
            {
              "years": 6,
              "text": "夜校要更新教材，达里厄斯找到了你当年留下的费用示例。他想知道你是否愿意回来修订。",
              "effects": {
                "communication": 3
              },
              "flag": "school_echo"
            }
          ],
          "id": "b10_1",
          "cost": {
            "freedom": 3
          }
        },
        {
          "label": "编一份可复用的讲义，请别人主讲",
          "detail": "付出当期研究时间，保留长期自由。",
          "effects": {
            "research": 4,
            "communication": 4,
            "relations": {
              "darius": 5
            },
            "flags": [
              "school_notes"
            ]
          },
          "id": "b10_2",
          "cost": {},
          "delayed": []
        },
        {
          "label": "坦白无法固定出席，提供书单",
          "detail": "不作长期承诺，保持有限联系。",
          "effects": {
            "freedom": 4,
            "trust": 2,
            "flags": [
              "school_contact"
            ]
          },
          "id": "b10_3",
          "cost": {},
          "delayed": []
        }
      ],
      "key": false,
      "chain": "school",
      "requires": {}
    },
    {
      "id": "c10",
      "stage": 10,
      "kind": "conditional",
      "date": "2005-01-01",
      "endDate": "2005-06-30",
      "title": "看房的星期日",
      "text": "诺拉终于找到一间能容纳两张制图桌的小办公室。她把看房安排在星期日，因为记得你刚入职时说过，那天可以留给家人。这不是一次紧急求助，她已经约好房东，也能自己签约；她只是想让你看一眼窗户朝向。周一的报告尚未完成，你需要决定当年那句具体的话，在五年后还值多少日历上的空间。",
      "characters": [
        "nora"
      ],
      "choices": [
        {
          "label": "按约去看房，晚上再整理材料",
          "detail": "履行早年的约定，工作负荷没有消失。",
          "effects": {
            "stress": 2,
            "relations": {
              "nora": 10
            },
            "flags": [
              "family_kept",
              "life_priority"
            ]
          },
          "id": "c10_1",
          "cost": {},
          "delayed": []
        },
        {
          "label": "提前说明无法到场，替她核对租约费用",
          "detail": "有限但可靠的支持，需要支付文件费用。",
          "effects": {
            "personalCash": -250,
            "communication": 3,
            "relations": {
              "nora": 5
            },
            "flags": [
              "family_supported"
            ]
          },
          "id": "c10_2",
          "cost": {
            "personalCash": 250
          },
          "delayed": []
        },
        {
          "label": "临时取消，把全部时间留给报告",
          "detail": "研究推进，具体失约被记录。",
          "effects": {
            "research": 8,
            "relations": {
              "nora": -10
            },
            "flags": [
              "family_missed",
              "career_first"
            ]
          },
          "id": "c10_3",
          "cost": {},
          "delayed": []
        }
      ],
      "key": false,
      "requires": {
        "flagsAll": [
          "sunday_promised"
        ]
      },
      "chain": "family",
      "recall": {
        "flag": "sunday_promised",
        "text": "这次邀请明确来自你早年关于星期日的承诺。"
      }
    },
    {
      "id": "b11",
      "stage": 11,
      "kind": "base",
      "date": "2005-07-01",
      "endDate": "2005-12-31",
      "title": "第二把椅子",
      "text": "山姆第一次跟你参加会议，抱着资料坐在离投影最远的位置。他核对出附表一个口径差异，却不敢中断讨论。散会后他问，这种发现该写在谁的工作记录上。你想起自己刚到这里时也有一把不属于任何人的椅子。帮助一个新人不只是说句鼓励的话，还包括把可见的工作和出错时的责任分给他。",
      "characters": [
        "sam",
        "mara"
      ],
      "choices": [
        {
          "label": "让山姆独立解释，并注明贡献",
          "detail": "花时间辅导，留下可兑现的协作承诺。",
          "effects": {
            "communication": 5,
            "stress": 2,
            "relations": {
              "sam": 9
            },
            "flags": [
              "sam_mentored",
              "shared_credit"
            ]
          },
          "delayed": [
            {
              "years": 3,
              "text": "山姆在自己的履历中保留了第一次署名的核验工作。他发来一封邮件，感谢你当时把发言时间让给他。",
              "effects": {
                "relations": {
                  "sam": 3
                }
              },
              "flag": "junior_echo"
            }
          ],
          "id": "b11_1",
          "cost": {}
        },
        {
          "label": "你替他报告，但把名字放进附注",
          "detail": "降低新人压力，成长较慢。",
          "effects": {
            "research": 4,
            "relations": {
              "sam": 4
            },
            "flags": [
              "sam_supported"
            ]
          },
          "id": "b11_2",
          "cost": {},
          "delayed": []
        },
        {
          "label": "先赶进度，约他以后再聊",
          "detail": "当前会议更省事，帮助尚未落实。",
          "effects": {
            "reputation": 3,
            "relations": {
              "sam": -3
            },
            "flags": [
              "sam_waited"
            ]
          },
          "id": "b11_3",
          "cost": {},
          "delayed": []
        }
      ],
      "key": false,
      "chain": "junior",
      "requires": {}
    },
    {
      "id": "c11",
      "stage": 11,
      "kind": "conditional",
      "date": "2005-07-01",
      "endDate": "2005-12-31",
      "title": "钥匙没有变",
      "text": "梅的展览结束，备用钥匙仍挂在同一圈金属环上。她这次要去另一座城市一年，给你看工作安排，而不是请你替她决定。临行前的聚会与一次可有可无的行业晚餐撞期。她知道你忙，也开始学会把“有空再见”理解成没有约定。钥匙可以还给她，关系也可以换一种更清楚的维护方式。",
      "characters": [
        "mei"
      ],
      "choices": [
        {
          "label": "去送行，并约定固定通话日期",
          "detail": "维护友谊，需要长期沟通投入。",
          "effects": {
            "relations": {
              "mei": 9
            },
            "communication": 3,
            "flags": [
              "friend_distance",
              "life_priority"
            ]
          },
          "id": "c11_1",
          "cost": {},
          "delayed": []
        },
        {
          "label": "交还钥匙，约定偶尔写信",
          "detail": "接受关系变疏，但不留下虚假的日程承诺。",
          "effects": {
            "freedom": 5,
            "relations": {
              "mei": 2
            },
            "flags": [
              "friend_letters"
            ]
          },
          "id": "c11_2",
          "cost": {},
          "delayed": []
        },
        {
          "label": "参加行业晚餐，临时发消息告别",
          "detail": "获得职业接触，朋友记得的是缺席。",
          "effects": {
            "reputation": 6,
            "relations": {
              "mei": -8
            },
            "flags": [
              "friend_missed",
              "career_first"
            ]
          },
          "id": "c11_3",
          "cost": {},
          "delayed": []
        }
      ],
      "key": false,
      "requires": {
        "flagsAll": [
          "key_held"
        ]
      },
      "chain": "friend",
      "recall": {
        "flag": "key_held",
        "text": "这把钥匙来自那次你兑现了的搬家约定。"
      }
    },
    {
      "id": "b12",
      "stage": 12,
      "kind": "base",
      "date": "2006-01-01",
      "endDate": "2006-06-30",
      "title": "纸面上的额度",
      "text": "年度授权评审不是一张排行榜。玛拉看过业绩，也看你是否在事前写过风险、有没有及时通知客户、是否违反既有约束。她提出扩大你的研究覆盖范围，额度可以另行讨论。你可以把更多权力当作终于到来的证明，也可以问清谁会承担与它一起到来的电话、会议与减仓决定。",
      "characters": [
        "mara",
        "june"
      ],
      "choices": [
        {
          "label": "扩大有限授权，同时接受复核",
          "detail": "更多决策空间，承担管理责任。",
          "effects": {
            "authority": 10,
            "stress": 5,
            "career": "manager",
            "flags": [
              "mandate_reviewed",
              "management_path"
            ]
          },
          "id": "b12_1",
          "cost": {},
          "delayed": []
        },
        {
          "label": "只扩大覆盖，不扩大资金权限",
          "detail": "培养研究能力，不自动改变客户仓位。",
          "effects": {
            "research": 8,
            "freedom": 2,
            "flags": [
              "research_specialist",
              "cross_training"
            ]
          },
          "id": "b12_2",
          "cost": {},
          "delayed": []
        },
        {
          "label": "保留原授权，把时间给客户沟通",
          "detail": "收益表现以外的服务进入履历。",
          "effects": {
            "communication": 7,
            "trust": 6,
            "flags": [
              "service_chosen",
              "client_listener"
            ]
          },
          "id": "b12_3",
          "cost": {},
          "delayed": []
        }
      ],
      "key": false,
      "requires": {}
    },
    {
      "id": "c12",
      "stage": 12,
      "kind": "conditional",
      "date": "2006-01-01",
      "endDate": "2006-06-30",
      "title": "失效条件的空白处",
      "text": "两年前写下的失效条件仍在底稿里。如今一项当时列为关键的事实尚未公开，价格变化却比报告更容易引起会议讨论。玛拉问你是否要改变判断。你可以修订假设，但必须说明是新证据、客户约束，还是自己对波动的耐心变了。原表格没有替你作决定，只使三种理由无法轻易混成一句话。",
      "characters": [
        "mara",
        "lin"
      ],
      "choices": [
        {
          "label": "逐项核对原条件，维持证据边界",
          "detail": "对未知保持未知，过程纪律被看见。",
          "effects": {
            "research": 7,
            "trust": 5,
            "flags": [
              "risk_honored",
              "process_discipline"
            ]
          },
          "id": "c12_1",
          "cost": {},
          "delayed": []
        },
        {
          "label": "修订判断并保存两个版本",
          "detail": "允许改变想法，记录改变的依据。",
          "effects": {
            "communication": 5,
            "research": 5,
            "flags": [
              "risk_honored",
              "versioned_thesis"
            ]
          },
          "id": "c12_2",
          "cost": {},
          "delayed": []
        },
        {
          "label": "先缩小申请额度，再继续研究",
          "detail": "减少承受压力；交易仍需自行提交。",
          "effects": {
            "authority": -5,
            "stress": -5,
            "research": 4,
            "flags": [
              "risk_honored",
              "patient_research"
            ]
          },
          "id": "c12_3",
          "cost": {
            "authority": 5
          },
          "delayed": []
        }
      ],
      "key": false,
      "requires": {
        "flagsAll": [
          "risk_record"
        ]
      },
      "chain": "risk",
      "recall": {
        "flag": "risk_record",
        "text": "你曾在价格结果到来之前留下可核验的失效条件。"
      }
    },
    {
      "id": "b13",
      "stage": 13,
      "kind": "base",
      "date": "2006-07-01",
      "endDate": "2006-12-31",
      "title": "一通过界的电话",
      "text": "一次普通工作电话忽然提到尚未公开的交易安排。对方没有提供文件，也没有让你保密，但你知道继续追问会改变自己所处的位置。伊莱的流程很具体：记录接触内容、停止相关个人交易、交由合规判断。相关研究可以暂时停下，市场不会因为你的回避而暂停。代价是机会，也可能是同事眼里多出来的一道麻烦。",
      "characters": [
        "elias",
        "mara"
      ],
      "choices": [
        {
          "label": "停止追问并上报，进入回避",
          "detail": "暂停私人交易；不会以未公开材料改变收益路径。",
          "effects": {
            "trust": 8,
            "freedom": -3,
            "relations": {
              "elias": 6
            },
            "flags": [
              "restricted_information",
              "personal_pause",
              "ethics_record"
            ]
          },
          "id": "b13_1",
          "delayed": [
            {
              "years": 1,
              "text": "海岬合规完成对当年信息接触的复核，确认回避期结束。个人交易仍须按当前机构政策审批；旧记录继续保留。",
              "effects": {
                "removeFlags": [
                  "personal_pause",
                  "restricted_information"
                ],
                "flags": [
                  "restriction_reviewed"
                ]
              },
              "flag": "restriction_reviewed"
            }
          ],
          "cost": {
            "freedom": 3
          }
        },
        {
          "label": "仅记录已听到的话，请合规定范围",
          "detail": "保留审计轨迹，等待明确指令。",
          "effects": {
            "communication": 6,
            "stress": 3,
            "trust": 5,
            "flags": [
              "restricted_information",
              "personal_pause",
              "ethics_record"
            ]
          },
          "id": "b13_2",
          "delayed": [
            {
              "years": 1,
              "text": "海岬合规完成对当年信息接触的复核，确认回避期结束。个人交易仍须按当前机构政策审批；旧记录继续保留。",
              "effects": {
                "removeFlags": [
                  "personal_pause",
                  "restricted_information"
                ],
                "flags": [
                  "restriction_reviewed"
                ]
              },
              "flag": "restriction_reviewed"
            }
          ],
          "cost": {}
        },
        {
          "label": "退出相关覆盖，申请别的公开研究",
          "detail": "付出转组成本，限制仍由正式审批解除。",
          "effects": {
            "research": -3,
            "freedom": 4,
            "stress": 2,
            "flags": [
              "restricted_information",
              "personal_pause",
              "cross_training"
            ]
          },
          "id": "b13_3",
          "delayed": [
            {
              "years": 1,
              "text": "海岬合规完成对当年信息接触的复核，确认回避期结束。个人交易仍须按当前机构政策审批；旧记录继续保留。",
              "effects": {
                "removeFlags": [
                  "personal_pause",
                  "restricted_information"
                ],
                "flags": [
                  "restriction_reviewed"
                ]
              },
              "flag": "restriction_reviewed"
            }
          ],
          "cost": {
            "research": 3
          }
        }
      ],
      "key": false,
      "chain": "ethics",
      "requires": {}
    },
    {
      "id": "c13",
      "stage": 13,
      "kind": "conditional",
      "date": "2006-07-01",
      "endDate": "2006-12-31",
      "title": "旧表格里的另一种用途",
      "text": "你提交过的个人交易清单让伊莱较容易划定这次回避范围。一次工作接触涉及未公开细节，他没有因为熟悉你就略去程序，也没有把全组所有工作一并停下。你现在需要决定是等合规复核，还是先转向不受限制的研究。表格原先像一道麻烦的门槛，如今也能防止一项限制无限扩张。",
      "characters": [
        "elias"
      ],
      "choices": [
        {
          "label": "按已确认范围回避并保留记录",
          "detail": "仍暂停个人交易，避免扩大信息接触。",
          "effects": {
            "trust": 7,
            "stress": -2,
            "flags": [
              "restricted_information",
              "personal_pause",
              "ethics_followed"
            ]
          },
          "id": "c13_1",
          "delayed": [
            {
              "years": 1,
              "text": "海岬合规完成对当年信息接触的复核，确认回避期结束。个人交易仍须按当前机构政策审批；旧记录继续保留。",
              "effects": {
                "removeFlags": [
                  "personal_pause",
                  "restricted_information"
                ],
                "flags": [
                  "restriction_reviewed"
                ]
              },
              "flag": "restriction_reviewed"
            }
          ],
          "cost": {}
        },
        {
          "label": "转向新覆盖并要求明确复核日期",
          "detail": "研究学习有成本，限制须正式解除。",
          "effects": {
            "research": -2,
            "communication": 6,
            "freedom": 3,
            "flags": [
              "restricted_information",
              "personal_pause",
              "cross_training",
              "ethics_followed"
            ]
          },
          "id": "c13_2",
          "delayed": [
            {
              "years": 1,
              "text": "海岬合规完成对当年信息接触的复核，确认回避期结束。个人交易仍须按当前机构政策审批；旧记录继续保留。",
              "effects": {
                "removeFlags": [
                  "personal_pause",
                  "restricted_information"
                ],
                "flags": [
                  "restriction_reviewed"
                ]
              },
              "flag": "restriction_reviewed"
            }
          ],
          "cost": {
            "research": 2
          }
        },
        {
          "label": "暂停相关职责，利用时间恢复",
          "detail": "接受短期职业曝光下降。",
          "effects": {
            "health": 7,
            "stress": -5,
            "reputation": -2,
            "flags": [
              "restricted_information",
              "personal_pause",
              "health_reset"
            ]
          },
          "id": "c13_3",
          "delayed": [
            {
              "years": 1,
              "text": "海岬合规完成对当年信息接触的复核，确认回避期结束。个人交易仍须按当前机构政策审批；旧记录继续保留。",
              "effects": {
                "removeFlags": [
                  "personal_pause",
                  "restricted_information"
                ],
                "flags": [
                  "restriction_reviewed"
                ]
              },
              "flag": "restriction_reviewed"
            }
          ],
          "cost": {
            "reputation": 2
          }
        }
      ],
      "key": false,
      "requires": {
        "flagsAll": [
          "ethics_record",
          "compliance_clear"
        ]
      },
      "chain": "ethics",
      "recall": {
        "flag": "ethics_record",
        "text": "先前完整的申报记录，使本次回避范围有据可查。"
      }
    },
    {
      "id": "b14",
      "stage": 14,
      "kind": "base",
      "date": "2007-01-01",
      "endDate": "2007-06-30",
      "title": "名片的背面",
      "text": "一位做过独立顾问的旧同事把电话写在名片背面。她说，离开大机构意味着自己找客户、支付账单、处理合同，不能把曾经管理过的规模当成自己的钱。你还没有决定离开，只是第一次认真计算需要多少生活缓冲。桌上另一份文件是更高职责的内部申请，两条路都不保证自由，也都不会只靠一份好报告就自动打开。",
      "characters": [
        "june",
        "mara"
      ],
      "choices": [
        {
          "label": "开始积累独立工作的准备资料",
          "detail": "当期花费学习合同和运营，不立即辞职。",
          "effects": {
            "personalCash": -600,
            "freedom": 6,
            "communication": 3,
            "flags": [
              "independence_plan",
              "autonomy_card"
            ]
          },
          "delayed": [
            {
              "years": 5,
              "text": "当年的名片仍可联系。对方发来一份独立业务的费用清单，提醒你把固定支出放进决定里。",
              "effects": {
                "freedom": 3
              },
              "flag": "autonomy_echo"
            }
          ],
          "id": "b14_1",
          "cost": {
            "personalCash": 600
          }
        },
        {
          "label": "申请内部管理路线",
          "detail": "把选择空间换成更清晰的组织内职责。",
          "effects": {
            "reputation": 6,
            "trust": 3,
            "stress": 4,
            "flags": [
              "management_path"
            ]
          },
          "id": "b14_2",
          "cost": {},
          "delayed": []
        },
        {
          "label": "先保留储蓄与现在的岗位",
          "detail": "不把观察职业出口当作必须立即行动。",
          "effects": {
            "freedom": 4,
            "stress": -3,
            "flags": [
              "cash_buffer",
              "patient_career"
            ]
          },
          "id": "b14_3",
          "cost": {},
          "delayed": []
        }
      ],
      "key": false,
      "chain": "autonomy",
      "requires": {}
    },
    {
      "id": "c14",
      "stage": 14,
      "kind": "conditional",
      "date": "2007-01-01",
      "endDate": "2007-06-30",
      "title": "异地寄来的明信片",
      "text": "梅寄来一张展馆的明信片，背面只有四行工作近况。你们约定的通话有几次被临时会议挤掉，她没有发脾气，而是把晚上的课程排进了原来的时段。她仍愿意聊，却不愿每天待命。你意识到友谊没有发生灾难，只是在没有明确决定的情况下，慢慢失去共同经历的素材。",
      "characters": [
        "mei"
      ],
      "choices": [
        {
          "label": "重新确认一个双方都方便的时间",
          "detail": "把承诺缩小到能够做到的范围。",
          "effects": {
            "communication": 4,
            "relations": {
              "mei": 8
            },
            "flags": [
              "friend_renewed",
              "life_priority"
            ]
          },
          "id": "c14_1",
          "cost": {},
          "delayed": []
        },
        {
          "label": "接受改成写信，寄去自己的近况",
          "detail": "尊重她的时间，关系换一种频率。",
          "effects": {
            "freedom": 4,
            "relations": {
              "mei": 5
            },
            "flags": [
              "friend_letters",
              "friend_renewed"
            ]
          },
          "id": "c14_2",
          "cost": {},
          "delayed": []
        },
        {
          "label": "保持偶尔联系，把精力留给工作",
          "detail": "并非断绝关系，但不再承诺稳定陪伴。",
          "effects": {
            "research": 5,
            "relations": {
              "mei": -5
            },
            "flags": [
              "friend_distant",
              "career_first"
            ]
          },
          "id": "c14_3",
          "cost": {},
          "delayed": []
        }
      ],
      "key": false,
      "requires": {
        "flagsAll": [
          "friend_distance"
        ]
      },
      "chain": "friend",
      "recall": {
        "flag": "friend_distance",
        "text": "早年送行时约定过的通话频率，如今需要双方重新确认。"
      }
    },
    {
      "id": "b15",
      "stage": 15,
      "kind": "base",
      "date": "2007-07-01",
      "endDate": "2007-12-31",
      "title": "客户把问题问了两遍",
      "text": "朱恩整理最近的电话记录，发现越来越多人把“需要多久才能取钱”问了两遍。她不把这些电话当作市场预测，只认为流动性安排值得提前说明。你准备的公司资料有许多长期理由，而客户最关心的日期却越来越近。把风险写清楚也许会失去一部分委托，不写则可能使未来的决定更仓促。",
      "characters": [
        "june"
      ],
      "choices": [
        {
          "label": "主动解释现金与退出规则",
          "detail": "沟通增强，机构收入不因此得到保证。",
          "effects": {
            "communication": 8,
            "trust": 5,
            "flags": [
              "liquidity_explained",
              "client_listener"
            ]
          },
          "id": "b15_1",
          "cost": {},
          "delayed": []
        },
        {
          "label": "复核仓位集中度与授权约束",
          "detail": "为压力时刻准备可执行的纪律。",
          "effects": {
            "research": 6,
            "trust": 4,
            "flags": [
              "liquidity_explained",
              "risk_record"
            ]
          },
          "id": "b15_2",
          "cost": {},
          "delayed": []
        },
        {
          "label": "维持标准沟通，优先完成研究",
          "detail": "当期证据覆盖增加，服务准备较少。",
          "effects": {
            "research": 8,
            "stress": 3,
            "flags": [
              "research_focus"
            ]
          },
          "id": "b15_3",
          "cost": {},
          "delayed": []
        }
      ],
      "key": false,
      "requires": {}
    },
    {
      "id": "c15",
      "stage": 15,
      "kind": "conditional",
      "date": "2007-07-01",
      "endDate": "2007-12-31",
      "title": "日历里的空白需要保卫",
      "text": "你曾固定留出的恢复时间开始被临时会议一格格借走。伊莱发现你把游泳袋当成了装文件的袋子，笑了笑，没有替你取消任何会议。他也正忙着家中的事，只愿意分享自己如何排优先级。连续疲劳没有变成戏剧性的急症，却让你在会议里更难听完别人的一句话。",
      "characters": [
        "elias"
      ],
      "choices": [
        {
          "label": "恢复固定边界，移交一项职责",
          "detail": "恢复能力增加，职业曝光稍降。",
          "effects": {
            "health": 9,
            "stress": -9,
            "reputation": -2,
            "flags": [
              "health_reset",
              "boundaries_kept"
            ]
          },
          "id": "c15_1",
          "cost": {
            "reputation": 2
          },
          "delayed": []
        },
        {
          "label": "只保留隔周恢复，明确截止日期",
          "detail": "在负荷与身体之间作有限妥协。",
          "effects": {
            "health": 4,
            "stress": -3,
            "flags": [
              "bounded_overtime"
            ]
          },
          "id": "c15_2",
          "cost": {},
          "delayed": []
        },
        {
          "label": "继续借出晚上，等评审结束",
          "detail": "研究推进，疲劳真实累积。",
          "effects": {
            "research": 7,
            "health": -7,
            "stress": 9,
            "flags": [
              "exhausted",
              "career_first"
            ]
          },
          "id": "c15_3",
          "cost": {
            "health": 7
          },
          "delayed": []
        }
      ],
      "key": false,
      "requires": {
        "flagsAll": [
          "wednesday_kept"
        ]
      },
      "chain": "health",
      "recall": {
        "flag": "wednesday_kept",
        "text": "这项被临时会议挤占的安排，是你在职业早期亲自留下的边界。"
      }
    },
    {
      "id": "b16",
      "stage": 16,
      "kind": "base",
      "date": "2008-01-01",
      "endDate": "2008-06-30",
      "title": "红色数字之外",
      "text": "本期报表的数字让会议室安静了一会儿。玛拉要求大家分别说明价格变化、经营证据和客户约束，不能把三件事都叫作“市场不好”。你有几页尚未读完的公开材料，也有几封尚未回的客户邮件。眼下没有一项行动能使历史重新开始，能做的是决定先处理哪一种不确定性，并承认其余部分仍然存在。",
      "characters": [
        "mara",
        "june"
      ],
      "choices": [
        {
          "label": "先核对证据，再解释已有风险",
          "detail": "提高研究与沟通质量，不改变市场。",
          "effects": {
            "research": 6,
            "communication": 4,
            "stress": 3,
            "flags": [
              "crisis_record",
              "process_discipline"
            ]
          },
          "id": "b16_1",
          "cost": {},
          "delayed": []
        },
        {
          "label": "先联系用款最紧的客户",
          "detail": "把期限放在前面，承担较多情绪劳动。",
          "effects": {
            "communication": 8,
            "stress": 5,
            "relations": {
              "june": 6
            },
            "flags": [
              "crisis_service",
              "service_chosen"
            ]
          },
          "id": "b16_2",
          "cost": {},
          "delayed": []
        },
        {
          "label": "申请收紧授权和工作范围",
          "detail": "主动降低可承担决策量，留出恢复空间。",
          "effects": {
            "authority": -10,
            "health": 5,
            "stress": -5,
            "flags": [
              "crisis_boundary",
              "boundaries_kept"
            ]
          },
          "id": "b16_3",
          "cost": {
            "authority": 10
          },
          "delayed": []
        }
      ],
      "key": false,
      "requires": {}
    },
    {
      "id": "c16",
      "stage": 16,
      "kind": "conditional",
      "date": "2008-01-01",
      "endDate": "2008-06-30",
      "title": "你写过的那一行",
      "text": "当年的失效条件出现在桌上，旁边是今天能够获得的公开材料。有些条件尚未触发，有些事实仍未核验；单纯的价格下跌并没有替你填完表。玛拉要求你给出当期行动建议，朱恩则提醒，用款期限可能先于公司逻辑兑现。过去的记录让你不能把所有理由都改写成自己早就知道。",
      "characters": [
        "mara",
        "june"
      ],
      "choices": [
        {
          "label": "按原条件区分证据与耐受力",
          "detail": "保持过程纪律，未来价格仍未知。",
          "effects": {
            "research": 7,
            "trust": 5,
            "flags": [
              "crisis_record",
              "risk_honored"
            ]
          },
          "id": "c16_1",
          "cost": {},
          "delayed": []
        },
        {
          "label": "因客户期限缩小申请，不伪称公司已坏",
          "detail": "明确承认制度约束与投资判断不同。",
          "effects": {
            "authority": -5,
            "communication": 7,
            "trust": 3,
            "flags": [
              "crisis_service",
              "service_chosen"
            ]
          },
          "id": "c16_2",
          "cost": {
            "authority": 5
          },
          "delayed": []
        },
        {
          "label": "修订原条件，保留修改时间",
          "detail": "承认判断改变，接受复核与短期质疑。",
          "effects": {
            "research": 5,
            "reputation": -3,
            "trust": 5,
            "flags": [
              "versioned_thesis",
              "crisis_record"
            ]
          },
          "id": "c16_3",
          "cost": {
            "reputation": 3
          },
          "delayed": []
        }
      ],
      "key": false,
      "requires": {
        "flagsAll": [
          "risk_honored"
        ]
      },
      "chain": "risk",
      "recall": {
        "flag": "risk_honored",
        "text": "你曾复核而没有抹去原始失效条件，今天仍能区分原判断与新约束。"
      }
    },
    {
      "id": "b17",
      "stage": 17,
      "kind": "base",
      "date": "2008-07-01",
      "endDate": "2008-12-31",
      "title": "纸箱先送到了走廊",
      "text": "集团缩减海岬的预算，走廊先出现了一叠平纸箱，随后才有正式会议。玛拉没有说市场损失都来自研究员，也没有承诺每个人都能留下。她把三个去向写在纸上：接受职责更窄的内部岗位，带着现有履历离开，或申请一段无薪休整后重新竞争位置。\n\n朱恩在隔壁继续接客户电话。那些账户属于客户，离职不会让管理规模变成你的离职金；未兑现的奖金也不能提前记进私人存款。你翻看自己的个人账本，第一次感到平时保留的现金是几个月具体的日子，而不仅是一行资产。门口有人问纸箱能不能先借一个，声音很轻。你还需要签一份交接清单，写清谁接走没有结束的工作。",
      "characters": [
        "mara",
        "june"
      ],
      "choices": [
        {
          "label": "接受降职责岗位，保留收入",
          "detail": "职位和授权下降，保留机构内工作。",
          "effects": {
            "career": "analyst",
            "authority": -15,
            "reputation": -4,
            "stress": 5,
            "flags": [
              "crisis_survivor",
              "mandate_cut"
            ],
            "removeFlags": [
              "unemployed_now"
            ]
          },
          "id": "b17_1",
          "cost": {
            "authority": 15,
            "reputation": 4
          },
          "delayed": []
        },
        {
          "label": "接受离职安排，开始求职",
          "detail": "此后先停止机构新交易，个人存款承担生活。",
          "effects": {
            "career": "unemployed",
            "authority": -100,
            "stress": 8,
            "freedom": 8,
            "flags": [
              "job_lost",
              "unemployed_now",
              "rebuild_started"
            ]
          },
          "delayed": [
            {
              "years": 2,
              "text": "那张交接清单仍在你的求职资料里。完整的交接记录让别人能理解你当年做过什么。",
              "effects": {
                "trust": 2
              },
              "flag": "repair_echo"
            }
          ],
          "id": "b17_2",
          "cost": {
            "authority": 100
          }
        },
        {
          "label": "主动离开金融岗位，寻找新方向",
          "detail": "进入职业外部路线；以后仍可依法管理个人资金。",
          "effects": {
            "career": "outside",
            "authority": -100,
            "freedom": 12,
            "stress": -5,
            "flags": [
              "left_industry",
              "life_priority"
            ],
            "removeFlags": [
              "unemployed_now"
            ]
          },
          "id": "b17_3",
          "cost": {
            "authority": 100
          },
          "delayed": []
        }
      ],
      "key": true,
      "chain": "repair",
      "requires": {}
    },
    {
      "id": "c17",
      "stage": 17,
      "kind": "conditional",
      "date": "2008-07-01",
      "endDate": "2008-12-31",
      "title": "第二把椅子也在名单上",
      "text": "裁减预算的通知发下来时，山姆正在替另一位同事核对附表。他的名字和你的名字都出现在需要重新安排的名单上。你曾把发言和署名分给他，现在他问的不是你能否保住自己，而是能否给他的求职材料写一段真实评价。玛拉说团队只能保留更窄的职责；多保住一个人并不意味着还有原来的授权。\n\n你们在楼下买了两杯普通咖啡。山姆先说，他父亲的照护安排不能再靠临时调班解决，即使留下也要改变工作方式。你不需要替他作决定，也不必为了表现义气承诺不存在的岗位。需要决定的是如何结束这一段共同工作：继续留在缩小后的团队、带着可复核的交接离开，或者把这次中断变成正式转行的起点。",
      "characters": [
        "sam",
        "mara"
      ],
      "choices": [
        {
          "label": "留下较窄岗位，为山姆写真实推荐",
          "detail": "保留收入并承担交接；不替他虚构业绩。",
          "effects": {
            "career": "analyst",
            "authority": -15,
            "communication": 4,
            "relations": {
              "sam": 10
            },
            "flags": [
              "sam_reference",
              "crisis_survivor"
            ],
            "removeFlags": [
              "unemployed_now"
            ]
          },
          "id": "c17_1",
          "cost": {
            "authority": 15
          },
          "delayed": []
        },
        {
          "label": "离职并交换各自的求职线索",
          "detail": "失业路线继续，友谊与帮助不保证录用。",
          "effects": {
            "career": "unemployed",
            "authority": -100,
            "freedom": 8,
            "stress": 7,
            "relations": {
              "sam": 8
            },
            "flags": [
              "sam_reference",
              "job_lost",
              "unemployed_now",
              "rebuild_started"
            ]
          },
          "id": "c17_2",
          "cost": {
            "authority": 100
          },
          "delayed": []
        },
        {
          "label": "转向外部行业，把研究交接完整",
          "detail": "退出原职业路线，保留同事关系。",
          "effects": {
            "career": "outside",
            "authority": -100,
            "freedom": 12,
            "relations": {
              "sam": 6
            },
            "flags": [
              "left_industry",
              "sam_reference",
              "life_priority"
            ],
            "removeFlags": [
              "unemployed_now"
            ]
          },
          "id": "c17_3",
          "cost": {
            "authority": 100
          },
          "delayed": []
        }
      ],
      "key": true,
      "requires": {
        "flagsAll": [
          "sam_mentored"
        ]
      },
      "chain": "junior",
      "recall": {
        "flag": "sam_mentored",
        "text": "你曾给山姆一次可署名的发言机会，如今他的履历里确实有这项工作。"
      }
    },
    {
      "id": "b18",
      "stage": 18,
      "kind": "base",
      "date": "2009-01-01",
      "endDate": "2009-06-30",
      "title": "新地址上的职业栏",
      "text": "年度表格要求更新职业和联系地址。你发现这比填上一年的投资结果更难：一个职位可以继续，工作内容却已经变了；一个人离开机构，也仍然保有学过的东西。诺拉带来事务所印错的一盒名片，让你拿背面打草稿。你可以申请内部的新职责，也可以为外部岗位整理自己的技能，或者用一段学习把选项重新打开。",
      "characters": [
        "nora",
        "june"
      ],
      "choices": [
        {
          "label": "整理可核验履历，申请研究岗位",
          "detail": "回到或继续机构研究，授权从有限额度开始。",
          "effects": {
            "career": "analyst",
            "authority": 5,
            "research": 5,
            "trust": 3,
            "flags": [
              "rebuilt",
              "employed_again"
            ],
            "removeFlags": [
              "unemployed_now",
              "outside_now"
            ]
          },
          "id": "b18_1",
          "cost": {},
          "delayed": []
        },
        {
          "label": "把研究技能用于外部行业",
          "detail": "收入规则改为外部岗位；退出客户新交易。",
          "effects": {
            "career": "outside",
            "authority": -100,
            "freedom": 7,
            "communication": 3,
            "flags": [
              "left_industry",
              "outside_committed"
            ],
            "removeFlags": [
              "unemployed_now"
            ]
          },
          "id": "b18_2",
          "cost": {
            "authority": 100
          },
          "delayed": []
        },
        {
          "label": "支付一门公开课程的费用",
          "detail": "有计划地扩展技能，保留当前职业状态。",
          "effects": {
            "personalCash": -700,
            "research": 7,
            "freedom": 4,
            "flags": [
              "cross_training"
            ]
          },
          "id": "b18_3",
          "cost": {
            "personalCash": 700
          },
          "delayed": []
        }
      ],
      "key": false,
      "requires": {}
    },
    {
      "id": "c18",
      "stage": 18,
      "kind": "conditional",
      "date": "2009-01-01",
      "endDate": "2009-06-30",
      "title": "没有工牌的星期一",
      "text": "你已经不需要在九点前刷工牌。个人账户里的生活支出照常发生，简历发出去也不等于工作已经回来。朱恩愿意介绍一家虚构的小型机构，但只能保证你有一次面谈，不能保证职位或薪酬。诺拉把空着的制图桌借给你一周，说晚上六点她要用房间上课。失业使日历松开，也让每一天都必须自己安排。",
      "characters": [
        "june",
        "nora"
      ],
      "choices": [
        {
          "label": "接受小机构的研究试用职位",
          "detail": "重建路线：授权有限、从新履历开始。",
          "effects": {
            "career": "analyst",
            "authority": 5,
            "reputation": 3,
            "stress": -4,
            "relations": {
              "june": 6
            },
            "flags": [
              "rebuilt",
              "employed_again"
            ],
            "removeFlags": [
              "unemployed_now"
            ]
          },
          "id": "c18_1",
          "cost": {},
          "delayed": []
        },
        {
          "label": "应聘外部业务分析职位",
          "detail": "实际转行，研究技能仍保留。",
          "effects": {
            "career": "outside",
            "authority": -100,
            "freedom": 8,
            "stress": -5,
            "flags": [
              "left_industry",
              "outside_committed",
              "rebuilt"
            ],
            "removeFlags": [
              "unemployed_now"
            ]
          },
          "id": "c18_2",
          "cost": {
            "authority": 100
          },
          "delayed": []
        },
        {
          "label": "接公开资料咨询，建立独立工作起点",
          "detail": "独立收入不等于管理客户的钱，付出启动费用。",
          "effects": {
            "personalCash": -1000,
            "career": "independent",
            "authority": 5,
            "communication": 4,
            "freedom": 8,
            "flags": [
              "founded",
              "rebuilt",
              "independence_plan"
            ],
            "removeFlags": [
              "unemployed_now"
            ]
          },
          "id": "c18_3",
          "cost": {
            "personalCash": 1000
          },
          "delayed": []
        }
      ],
      "key": false,
      "requires": {
        "flagsAll": [
          "unemployed_now"
        ]
      },
      "chain": "repair",
      "recall": {
        "flag": "job_lost",
        "text": "你的工牌已在此前离职时交回，这里的工作机会并非自动晋升。"
      }
    },
    {
      "id": "b19",
      "stage": 19,
      "kind": "base",
      "date": "2009-07-01",
      "endDate": "2009-12-31",
      "title": "奖金之外的一行收入",
      "text": "你在个人账本里把劳动收入和投资变化分成两栏。朱恩发来近况：她所在团队有客户赎回，即使公司研究后来被证明有价值，资金也未必等得到那个时候。你不需要为过去没能控制的事编一个胜利故事。眼前能处理的是本期固定支出、下一份工作的边界，以及是否继续把不确定奖金当作确定的钱花掉。",
      "characters": [
        "june"
      ],
      "choices": [
        {
          "label": "重新按固定收入安排生活",
          "detail": "保留现金缓冲，不自动把客户成绩当收入。",
          "effects": {
            "stress": -5,
            "freedom": 4,
            "flags": [
              "cash_buffer",
              "salary_budget"
            ]
          },
          "id": "b19_1",
          "cost": {},
          "delayed": []
        },
        {
          "label": "投入时间争取更高职责",
          "detail": "增加职业曝光与压力，奖金仍按系统结算。",
          "effects": {
            "reputation": 7,
            "stress": 7,
            "flags": [
              "management_path",
              "career_first"
            ]
          },
          "id": "b19_2",
          "cost": {},
          "delayed": []
        },
        {
          "label": "把一个晚上留给旧同事",
          "detail": "维持职业之外的支持网络。",
          "effects": {
            "communication": 4,
            "relations": {
              "june": 5,
              "sam": 4
            },
            "flags": [
              "service_chosen"
            ]
          },
          "id": "b19_3",
          "cost": {},
          "delayed": []
        }
      ],
      "key": false,
      "requires": {}
    },
    {
      "id": "c19",
      "stage": 19,
      "kind": "conditional",
      "date": "2009-07-01",
      "endDate": "2009-12-31",
      "title": "到期的屋顶账单",
      "text": "多年前写在信里的屋顶支出，后来确实成了客户账上的付款。朱恩把一份已做完的服务记录寄给你，无论你现在在哪个岗位，她都认为应当让曾参与的人看到结果。记录里有主动保留的现金，也有因为期限不得不结束的研究暴露。她没有把这份服务写成选股成功，而是在最后注明：钱按约定到了该到的地方。",
      "characters": [
        "june"
      ],
      "choices": [
        {
          "label": "保留服务记录，解释实际与反事实",
          "detail": "过去退出不自动等于研究错误，也不重复扣机会成本。",
          "effects": {
            "communication": 7,
            "trust": 6,
            "flags": [
              "client_cycle_closed",
              "service_chosen"
            ]
          },
          "id": "c19_1",
          "cost": {},
          "delayed": []
        },
        {
          "label": "请朱恩同意将匿名流程用作培训",
          "detail": "得到许可后传播过程，不带出客户身份。",
          "effects": {
            "research": 4,
            "communication": 5,
            "flags": [
              "client_cycle_closed",
              "quiet_teacher"
            ]
          },
          "id": "c19_2",
          "cost": {},
          "delayed": []
        },
        {
          "label": "只在私人记忆账本里写下这一页",
          "detail": "不把客户的用款故事变成营销素材。",
          "effects": {
            "freedom": 4,
            "relations": {
              "june": 7
            },
            "flags": [
              "client_cycle_closed",
              "life_priority"
            ]
          },
          "id": "c19_3",
          "cost": {},
          "delayed": []
        }
      ],
      "key": false,
      "requires": {
        "flagsAll": [
          "client_served"
        ]
      },
      "chain": "clients",
      "recall": {
        "flag": "client_served",
        "text": "你确实在较早阶段支持过这笔委托的期限安排，才会收到这份服务回访。"
      }
    },
    {
      "id": "b20",
      "stage": 20,
      "kind": "base",
      "date": "2010-01-01",
      "endDate": "2010-06-30",
      "title": "退休宴没有投影",
      "text": "林知远的退休聚餐订在一家普通餐馆，没有投影仪。有人问他最满意哪次投资，他却开始说一把修到一半的旧椅子，木榫还缺一块合适的料。你收到一箱他不想带回家的公开资料，里面有过时的预测，也有至今仍可使用的方法。他说你可以留下，也可以交给需要的人，条件只有一个：不要把旧日期抹掉。",
      "characters": [
        "lin",
        "sam"
      ],
      "choices": [
        {
          "label": "整理资料并保留原日期",
          "detail": "付出档案工作，积累可传承的方法。",
          "effects": {
            "research": 7,
            "stress": 2,
            "relations": {
              "lin": 7
            },
            "flags": [
              "mentor_archive",
              "quiet_teacher"
            ]
          },
          "id": "b20_1",
          "cost": {},
          "delayed": []
        },
        {
          "label": "帮他搬箱子，把晚上留给聊天",
          "detail": "关系不必通过职业成绩来维系。",
          "effects": {
            "health": 3,
            "stress": -3,
            "relations": {
              "lin": 9
            },
            "flags": [
              "mentor_friend",
              "life_priority"
            ]
          },
          "id": "b20_2",
          "cost": {},
          "delayed": []
        },
        {
          "label": "把资料转交愿意整理的同事",
          "detail": "完成有边界的交接，保留自由时间。",
          "effects": {
            "trust": 4,
            "freedom": 5,
            "flags": [
              "archive_transferred"
            ]
          },
          "id": "b20_3",
          "cost": {},
          "delayed": []
        }
      ],
      "key": false,
      "requires": {}
    },
    {
      "id": "c20",
      "stage": 20,
      "kind": "conditional",
      "date": "2010-01-01",
      "endDate": "2010-06-30",
      "title": "新封皮下的旧日期",
      "text": "退休前，林知远把你参与的旧培训材料重新装订。最前面仍是那份保留修改痕迹的报告，后面夹着几个新人不同的理解。他没有让你替整个体系背书，只问这套东西以后由谁维护。你可以把它变成个人名声的一部分，也可以建立一个让别人容易纠错的版本记录。那几颗生锈的订书钉已经取下，纸上留下了洞。",
      "characters": [
        "lin",
        "sam"
      ],
      "choices": [
        {
          "label": "承诺维护开放的修改记录",
          "detail": "长期承担方法传承，保留他人贡献。",
          "effects": {
            "research": 6,
            "trust": 6,
            "relations": {
              "lin": 8
            },
            "flags": [
              "mentor_archive",
              "archive_custodian",
              "teaching"
            ]
          },
          "id": "c20_1",
          "cost": {},
          "delayed": []
        },
        {
          "label": "和山姆共同维护，各自分工",
          "detail": "他也获得责任，不只是替你整理材料。",
          "effects": {
            "communication": 6,
            "relations": {
              "sam": 7
            },
            "flags": [
              "archive_custodian",
              "shared_credit",
              "mentor_archive"
            ]
          },
          "id": "c20_2",
          "cost": {},
          "delayed": []
        },
        {
          "label": "谢绝长期维护，完成一次完整交接",
          "detail": "诚实保留边界，未承诺无限劳动。",
          "effects": {
            "freedom": 6,
            "trust": 4,
            "flags": [
              "archive_transferred",
              "boundaries_kept"
            ]
          },
          "id": "c20_3",
          "cost": {},
          "delayed": []
        }
      ],
      "key": false,
      "requires": {
        "flagsAll": [
          "archive_shared"
        ]
      },
      "chain": "archive",
      "recall": {
        "flag": "archive_shared",
        "text": "这套材料起源于你允许保留修改痕迹的早期报告。"
      }
    },
    {
      "id": "b21",
      "stage": 21,
      "kind": "base",
      "date": "2010-07-01",
      "endDate": "2010-12-31",
      "title": "免费建议的价格",
      "text": "达里厄斯在社区活动后截住你，问能否帮课程设计一个不用推荐具体产品的练习。活动中的另一位来宾想赞助，但希望印上自己的获客二维码。达里厄斯不愿意把学员变成名单，你也发现一次免费建议可能附带很多没有说出的用途。要拒绝的不是钱本身，而是这份钱要求你在课堂上扮演的角色。",
      "characters": [
        "darius"
      ],
      "choices": [
        {
          "label": "设计费用比较练习，拒绝推销环节",
          "detail": "增加公共沟通能力，投入个人时间。",
          "effects": {
            "communication": 7,
            "trust": 4,
            "relations": {
              "darius": 7
            },
            "flags": [
              "teaching",
              "school_commitment"
            ]
          },
          "id": "b21_1",
          "cost": {},
          "delayed": []
        },
        {
          "label": "协助寻找无附带推销条件的赞助",
          "detail": "增加组织工作，不承诺一定找到。",
          "effects": {
            "communication": 5,
            "stress": 3,
            "flags": [
              "school_partner"
            ]
          },
          "id": "b21_2",
          "cost": {},
          "delayed": []
        },
        {
          "label": "说明自己无法持续参与",
          "detail": "守住时间边界，不把暂时帮助许成长期岗位。",
          "effects": {
            "freedom": 5,
            "trust": 2,
            "flags": [
              "honest_boundary"
            ]
          },
          "id": "b21_3",
          "cost": {},
          "delayed": []
        }
      ],
      "key": false,
      "requires": {}
    },
    {
      "id": "c21",
      "stage": 21,
      "kind": "conditional",
      "date": "2010-07-01",
      "endDate": "2010-12-31",
      "title": "讲义上的咖啡渍",
      "text": "达里厄斯拿出五年前的讲义，边角有一圈咖啡渍。学员的问题变了：有人想知道一次失业怎样影响还款，有人分不清账户增加是工资还是投资收益。他希望重写例题，而不是把往年的数字机械更新。你曾答应一个学期，后来并没有欠图书馆一生的义务；这次是否回来，需要重新决定。",
      "characters": [
        "darius"
      ],
      "choices": [
        {
          "label": "重写例题并培养一位接班讲师",
          "detail": "教学方式能在你缺席时继续。",
          "effects": {
            "communication": 8,
            "research": 3,
            "relations": {
              "darius": 8
            },
            "flags": [
              "teaching_return",
              "school_successor"
            ]
          },
          "id": "c21_1",
          "cost": {},
          "delayed": []
        },
        {
          "label": "回来讲两次，明确结束日期",
          "detail": "兑现有限承诺，保留恢复与其他关系。",
          "effects": {
            "communication": 5,
            "freedom": 2,
            "flags": [
              "teaching_return",
              "boundaries_kept"
            ]
          },
          "id": "c21_2",
          "cost": {},
          "delayed": []
        },
        {
          "label": "交出可编辑讲义，暂不授课",
          "detail": "作品继续被用，人不必始终在场。",
          "effects": {
            "research": 4,
            "freedom": 5,
            "flags": [
              "school_notes",
              "school_successor"
            ]
          },
          "id": "c21_3",
          "cost": {},
          "delayed": []
        }
      ],
      "key": false,
      "requires": {
        "flagsAll": [
          "teaching",
          "school_commitment"
        ]
      },
      "chain": "school",
      "recall": {
        "flag": "teaching",
        "text": "旧讲义来自你确实参加过的课堂，因此达里厄斯知道该向谁询问。"
      }
    },
    {
      "id": "b22",
      "stage": 22,
      "kind": "base",
      "date": "2011-01-01",
      "endDate": "2011-06-30",
      "title": "桌上多了一张椅子",
      "text": "诺拉的事务所请到第一位长期合作者，房间里多了一张椅子。她谈起新项目时很快，抱怨客户改图时也不避讳。你发现自己若只问她还需不需要钱，就会错过她最想说的部分。晚饭后她要继续工作，既不需要你留下整夜，也不愿意每次见面都变成关于你职业的简报。",
      "characters": [
        "nora"
      ],
      "choices": [
        {
          "label": "听她讲完项目，并分担一次日常事务",
          "detail": "家人的工作获得真正关注。",
          "effects": {
            "relations": {
              "nora": 8
            },
            "communication": 3,
            "flags": [
              "family_supported",
              "life_priority"
            ]
          },
          "id": "b22_1",
          "cost": {},
          "delayed": []
        },
        {
          "label": "请她明确需要哪一种帮助",
          "detail": "用具体约定替代无限兜底。",
          "effects": {
            "freedom": 3,
            "relations": {
              "nora": 5
            },
            "flags": [
              "family_agreement",
              "boundaries_kept"
            ]
          },
          "id": "b22_2",
          "cost": {},
          "delayed": []
        },
        {
          "label": "匆匆吃完，回去处理自己的材料",
          "detail": "当期研究推进，关系不是自动维持。",
          "effects": {
            "research": 6,
            "relations": {
              "nora": -5
            },
            "flags": [
              "family_distant",
              "career_first"
            ]
          },
          "id": "b22_3",
          "cost": {},
          "delayed": []
        }
      ],
      "key": false,
      "requires": {}
    },
    {
      "id": "c22",
      "stage": 22,
      "kind": "conditional",
      "date": "2011-01-01",
      "endDate": "2011-06-30",
      "title": "晚点列车里的座位",
      "text": "梅来附近城市布展，列车晚了四十分钟。她在短信里说，如果你已经安排了别的事，可以下次再见。你们曾重新商量过联系频率，所以这句话不是试探。见面时，她拿出一本展览工作日志，里面有许多与你无关的人和地方。时间把朋友的生活展开了，也让你看见自己究竟愿意花多少心思继续认识她。",
      "characters": [
        "mei"
      ],
      "choices": [
        {
          "label": "调整当晚安排，认真听她的近况",
          "detail": "友谊继续生长，不索取无条件陪伴。",
          "effects": {
            "stress": -4,
            "relations": {
              "mei": 10
            },
            "flags": [
              "friend_reunion",
              "life_priority"
            ]
          },
          "id": "c22_1",
          "cost": {},
          "delayed": []
        },
        {
          "label": "约短暂早餐，尊重双方工作时间",
          "detail": "维持可靠而有限的联系。",
          "effects": {
            "freedom": 4,
            "relations": {
              "mei": 6
            },
            "flags": [
              "friend_reunion",
              "boundaries_kept"
            ]
          },
          "id": "c22_2",
          "cost": {},
          "delayed": []
        },
        {
          "label": "如实说明无法见面，寄一封长信",
          "detail": "联系仍在，错过一次共同经历。",
          "effects": {
            "communication": 4,
            "relations": {
              "mei": 2
            },
            "flags": [
              "friend_letters"
            ]
          },
          "id": "c22_3",
          "cost": {},
          "delayed": []
        }
      ],
      "key": false,
      "requires": {
        "flagsAll": [
          "friend_renewed"
        ]
      },
      "chain": "friend",
      "recall": {
        "flag": "friend_renewed",
        "text": "你们曾共同调整过异地联系的约定，因此无需把这次迟到理解成失信。"
      }
    },
    {
      "id": "b23",
      "stage": 23,
      "kind": "base",
      "date": "2011-07-01",
      "endDate": "2011-12-31",
      "title": "推荐信应当写什么",
      "text": "山姆为一个新职位准备材料，请你证明他实际做过的工作。你们的职业道路未必仍在一处，手头也没有所有时期的资料。推荐信模板里有很多方便的形容词，真正可以核对的却是一次次具体分工。给他帮助并不需要把自己不知道的业绩写成事实；拒绝虚夸也不等于拒绝一个老同事。",
      "characters": [
        "sam"
      ],
      "choices": [
        {
          "label": "只写亲见的贡献，标明时间",
          "detail": "推荐可核验，关系因坦诚而稳定。",
          "effects": {
            "trust": 6,
            "communication": 5,
            "relations": {
              "sam": 7
            },
            "flags": [
              "sam_reference",
              "credit_defended"
            ]
          },
          "id": "b23_1",
          "cost": {},
          "delayed": []
        },
        {
          "label": "提供原始署名材料，让他自行说明",
          "detail": "交还成果所有权，少作无法验证的判断。",
          "effects": {
            "research": 4,
            "relations": {
              "sam": 5
            },
            "flags": [
              "shared_credit",
              "credit_evidence"
            ]
          },
          "id": "b23_2",
          "cost": {},
          "delayed": []
        },
        {
          "label": "请更熟悉近期工作的人推荐",
          "detail": "承认认知边界，保留职业信誉。",
          "effects": {
            "trust": 5,
            "freedom": 3,
            "flags": [
              "evidence_boundary"
            ]
          },
          "id": "b23_3",
          "cost": {},
          "delayed": []
        }
      ],
      "key": false,
      "requires": {}
    },
    {
      "id": "c23",
      "stage": 23,
      "kind": "conditional",
      "date": "2011-07-01",
      "endDate": "2011-12-31",
      "title": "被留下的审批日期",
      "text": "伊莱准备一次内部流程复核，请你核对自己当年留下的申报与回避日期。复核不是重新裁判投资结果，而是确认谁在什么时候知道什么、做过什么。记录完整并不保证没有麻烦，却使你无需靠记忆拼出一套无懈可击的故事。他已经在考虑另一份职业，希望离开前把流程交给能继续使用它的人。",
      "characters": [
        "elias"
      ],
      "choices": [
        {
          "label": "核对原件并指出仍不明确的部分",
          "detail": "保留认知边界，帮助完成合规交接。",
          "effects": {
            "trust": 8,
            "research": 3,
            "flags": [
              "ethics_honored",
              "compliance_clear"
            ]
          },
          "id": "c23_1",
          "cost": {},
          "delayed": []
        },
        {
          "label": "把流程改写成易懂的说明",
          "detail": "让制度能被新同事使用，而不是只靠熟人。",
          "effects": {
            "communication": 7,
            "trust": 5,
            "flags": [
              "ethics_honored",
              "policy_teacher"
            ]
          },
          "id": "c23_2",
          "cost": {},
          "delayed": []
        },
        {
          "label": "完成个人部分，谢绝额外职责",
          "detail": "不抹去记录，也不承担无限维护工作。",
          "effects": {
            "trust": 4,
            "freedom": 5,
            "flags": [
              "ethics_honored",
              "boundaries_kept"
            ]
          },
          "id": "c23_3",
          "cost": {},
          "delayed": []
        }
      ],
      "key": false,
      "requires": {
        "flagsAll": [
          "ethics_record",
          "ethics_followed"
        ]
      },
      "chain": "ethics",
      "recall": {
        "flag": "ethics_record",
        "text": "当年的申报和回避确实被记录，复核才有原件可用。"
      }
    },
    {
      "id": "b24",
      "stage": 24,
      "kind": "base",
      "date": "2012-01-01",
      "endDate": "2012-06-30",
      "title": "从头写一份预算",
      "text": "你给自己写了三份下一年的预算：继续在机构内工作、成立规模很小的独立研究与管理业务、或者到金融之外使用这些技能。三份纸上的房租一样，工作关系和收入稳定性却不同。独立业务需要真实的启动支出，过往管理规模不能拿来付款；外部岗位也不是一座没有压力的岛。你不再二十四岁，但仍有需要从头学习的地方。",
      "characters": [
        "june",
        "nora",
        "mara"
      ],
      "choices": [
        {
          "label": "留在机构，争取清楚的管理职责",
          "detail": "职业转为组合管理，授权增加须接受边界。",
          "effects": {
            "career": "manager",
            "authority": 10,
            "stress": 4,
            "flags": [
              "management_path",
              "institution_renewed"
            ],
            "removeFlags": [
              "unemployed_now"
            ]
          },
          "id": "b24_1",
          "cost": {},
          "delayed": []
        },
        {
          "label": "支付启动费，成立独立业务",
          "detail": "个人支付启动成本；客户钱仍有独立账户。",
          "effects": {
            "personalCash": -2500,
            "career": "independent",
            "authority": 10,
            "freedom": 10,
            "stress": 6,
            "flags": [
              "founded",
              "independence_plan"
            ],
            "removeFlags": [
              "unemployed_now"
            ]
          },
          "id": "b24_2",
          "cost": {
            "personalCash": 2500
          },
          "delayed": []
        },
        {
          "label": "接受外部行业岗位，正式转行",
          "detail": "退出机构交易授权，个人账户和历史继续。",
          "effects": {
            "career": "outside",
            "authority": -100,
            "freedom": 9,
            "stress": -5,
            "flags": [
              "left_industry",
              "outside_committed",
              "life_priority"
            ],
            "removeFlags": [
              "unemployed_now"
            ]
          },
          "id": "b24_3",
          "cost": {
            "authority": 100
          },
          "delayed": []
        }
      ],
      "key": false,
      "chain": "autonomy",
      "requires": {}
    },
    {
      "id": "c24",
      "stage": 24,
      "kind": "conditional",
      "date": "2012-01-01",
      "endDate": "2012-06-30",
      "title": "名片上的电话还接得通",
      "text": "你拨通五年前写在名片背面的号码，对方换了办公地址，电话仍然接得通。她先问你能承受多久没有客户，再问你是否愿意亲自催合同和账单。桌上的计划不再只有投资理念，还有生活缓冲、服务范围和最坏情况下回去求职的费用。一个出口经过多年准备，终于成为可选择的门，但门后没有预先写好的成功。",
      "characters": [
        "june",
        "nora"
      ],
      "choices": [
        {
          "label": "按预算成立小型独立业务",
          "detail": "支付准备充分后的启动费；接受收入波动。",
          "effects": {
            "personalCash": -2000,
            "career": "independent",
            "authority": 10,
            "freedom": 12,
            "stress": 4,
            "flags": [
              "founded",
              "prepared_founder"
            ],
            "removeFlags": [
              "unemployed_now"
            ]
          },
          "id": "c24_1",
          "cost": {
            "personalCash": 2000
          },
          "delayed": []
        },
        {
          "label": "保留计划，暂留机构管理岗位",
          "detail": "出口存在，不代表今年必须走出去。",
          "effects": {
            "career": "manager",
            "authority": 5,
            "trust": 4,
            "flags": [
              "management_path",
              "institution_renewed",
              "patient_career"
            ],
            "removeFlags": [
              "unemployed_now"
            ]
          },
          "id": "c24_2",
          "cost": {},
          "delayed": []
        },
        {
          "label": "把独立计划改成外部行业服务",
          "detail": "正式转行，退出客户组合决策权。",
          "effects": {
            "career": "outside",
            "authority": -100,
            "freedom": 10,
            "communication": 4,
            "flags": [
              "left_industry",
              "outside_committed"
            ],
            "removeFlags": [
              "unemployed_now"
            ]
          },
          "id": "c24_3",
          "cost": {
            "authority": 100
          },
          "delayed": []
        }
      ],
      "key": false,
      "requires": {
        "flagsAll": [
          "autonomy_card",
          "independence_plan"
        ]
      },
      "chain": "autonomy",
      "recall": {
        "flag": "autonomy_card",
        "text": "这份预算建立在多年前开始的准备上，电话号码不是临时出现的捷径。"
      }
    },
    {
      "id": "b25",
      "stage": 25,
      "kind": "base",
      "date": "2012-07-01",
      "endDate": "2012-12-31",
      "title": "谁来接最后一个电话",
      "text": "朱恩要把每周某个晚上的客户电话交给轮值同事。她的孩子开始上学，家里的时间也需要明确安排。她问你是否愿意帮助设计交接标准，免得每一个人都因为“最熟悉客户”而永远不能下班。你们未必仍属于同一机构，但这种问题在任何工作里都认得出来：人可靠，不应当意味着制度只能依赖他一直在场。",
      "characters": [
        "june"
      ],
      "choices": [
        {
          "label": "帮助建立交接记录与轮值边界",
          "detail": "沟通能力变成制度，不以牺牲一人完成。",
          "effects": {
            "communication": 7,
            "trust": 5,
            "relations": {
              "june": 7
            },
            "flags": [
              "service_chosen",
              "service_system"
            ]
          },
          "id": "b25_1",
          "cost": {},
          "delayed": []
        },
        {
          "label": "只承担明确的短期培训",
          "detail": "提供有限协助，守住自己的日历。",
          "effects": {
            "communication": 4,
            "freedom": 3,
            "flags": [
              "boundaries_kept",
              "service_system"
            ]
          },
          "id": "b25_2",
          "cost": {},
          "delayed": []
        },
        {
          "label": "婉拒额外任务，整理自己的研究",
          "detail": "研究推进，关系帮助没有发生。",
          "effects": {
            "research": 7,
            "flags": [
              "research_specialist"
            ]
          },
          "id": "b25_3",
          "cost": {},
          "delayed": []
        }
      ],
      "key": false,
      "requires": {}
    },
    {
      "id": "c25",
      "stage": 25,
      "kind": "conditional",
      "date": "2012-07-01",
      "endDate": "2012-12-31",
      "title": "第一份合同的删改线",
      "text": "独立业务的第一份拟议合同回来了。客户要求你写进“任何年份都要超过某个目标”的承诺，律师的批注在旁边画了长线。朱恩提醒，争取一笔委托与争取一份你能履行的委托不是一回事。空着的办公桌仍要付费，你也需要收入，但一份不能诚实解释的承诺会持续限制后面的每一次决定。",
      "characters": [
        "june",
        "elias"
      ],
      "choices": [
        {
          "label": "删去保证收益，写清期限与风险",
          "detail": "可能失去合同；信任规则形成长期约束。",
          "effects": {
            "trust": 8,
            "communication": 6,
            "stress": 3,
            "flags": [
              "client_rules",
              "independent_renewed"
            ]
          },
          "id": "c25_1",
          "cost": {},
          "delayed": []
        },
        {
          "label": "缩小业务范围，先做公开研究服务",
          "detail": "授权减少，换取更清晰可履行的交付。",
          "effects": {
            "authority": -5,
            "freedom": 4,
            "trust": 5,
            "flags": [
              "client_rules",
              "research_service",
              "independent_renewed"
            ]
          },
          "id": "c25_2",
          "cost": {
            "authority": 5
          },
          "delayed": []
        },
        {
          "label": "支付专业审阅费后再谈合同",
          "detail": "个人启动支出增加，不自动获得委托。",
          "effects": {
            "personalCash": -500,
            "research": 3,
            "trust": 6,
            "flags": [
              "client_rules",
              "prepared_founder"
            ]
          },
          "id": "c25_3",
          "cost": {
            "personalCash": 500
          },
          "delayed": []
        }
      ],
      "key": false,
      "requires": {
        "flagsAll": [
          "founded"
        ],
        "career": "independent"
      },
      "chain": "autonomy",
      "recall": {
        "flag": "founded",
        "text": "你已实际承担独立业务的启动费用，这份合同属于新事业的现实压力。"
      }
    },
    {
      "id": "b26",
      "stage": 26,
      "kind": "base",
      "date": "2013-01-01",
      "endDate": "2013-06-30",
      "title": "照护不是一张空白支票",
      "text": "诺拉拿来一份家庭日历。年长亲属需要有人定期陪同办事，安排并不紧急，却会持续很久。她已经填好自己能够承担的日期，剩下的空白不能默认由谁无限补上。你可以付一部分交通和服务费用，也可以固定出时间，或者请大家重新商量更小的任务。每一种帮助都需要边界，钱与陪伴不能在表格里互相伪装。",
      "characters": [
        "nora"
      ],
      "choices": [
        {
          "label": "固定每月半天，由其他人分担其余部分",
          "detail": "长期约定具体可执行。",
          "effects": {
            "freedom": -2,
            "relations": {
              "nora": 8
            },
            "flags": [
              "family_agreement",
              "life_priority"
            ]
          },
          "id": "b26_1",
          "cost": {
            "freedom": 2
          },
          "delayed": []
        },
        {
          "label": "分担明确的交通服务费用",
          "detail": "个人现金支付，不把付款当作所有义务已完成。",
          "effects": {
            "personalCash": -600,
            "relations": {
              "nora": 5
            },
            "flags": [
              "family_supported"
            ]
          },
          "id": "b26_2",
          "cost": {
            "personalCash": 600
          },
          "delayed": []
        },
        {
          "label": "说明目前负荷，只接一项短期任务",
          "detail": "支持有限且明确，不许下无法兑现的长期承诺。",
          "effects": {
            "stress": -3,
            "relations": {
              "nora": 2
            },
            "flags": [
              "honest_boundary",
              "boundaries_kept"
            ]
          },
          "id": "b26_3",
          "cost": {},
          "delayed": []
        }
      ],
      "key": false,
      "requires": {}
    },
    {
      "id": "c26",
      "stage": 26,
      "kind": "conditional",
      "date": "2013-01-01",
      "endDate": "2013-06-30",
      "title": "恢复不再是奖励",
      "text": "你曾在压力升高时移交过一项职责，现在复核那段日历，发现工作没有因此自动消失，但你更容易在会议结束后停止继续争辩。伊莱问是否愿意和几位朋友共同保留一个固定活动时段。他们各有负担，也会缺席；没人打算把健康变成另一种绩效比赛。你要选择的是以后如何维护这种安排。",
      "characters": [
        "elias"
      ],
      "choices": [
        {
          "label": "固定安排，允许合理缺席并及时说明",
          "detail": "把恢复变成可持续的日常。",
          "effects": {
            "health": 8,
            "stress": -7,
            "flags": [
              "health_sustained",
              "boundaries_kept"
            ]
          },
          "id": "c26_1",
          "cost": {},
          "delayed": []
        },
        {
          "label": "减少频率，保留独处恢复时间",
          "detail": "不依赖集体安排也能维护边界。",
          "effects": {
            "health": 6,
            "freedom": 5,
            "flags": [
              "health_sustained",
              "quiet_life"
            ]
          },
          "id": "c26_2",
          "cost": {},
          "delayed": []
        },
        {
          "label": "暂停安排，接下额外工作",
          "detail": "增加研究与职业投入，疲劳风险回升。",
          "effects": {
            "research": 7,
            "health": -6,
            "stress": 7,
            "flags": [
              "exhausted",
              "career_first"
            ]
          },
          "id": "c26_3",
          "cost": {
            "health": 6
          },
          "delayed": []
        }
      ],
      "key": false,
      "requires": {
        "flagsAll": [
          "health_reset"
        ]
      },
      "chain": "health",
      "recall": {
        "flag": "health_reset",
        "text": "你曾真实减少过负荷，这次是在维护已有改变，而非凭空获得康复。"
      }
    },
    {
      "id": "b27",
      "stage": 27,
      "kind": "base",
      "date": "2013-07-01",
      "endDate": "2013-12-31",
      "title": "不用证明那一年",
      "text": "一次旧同事聚会谈起低谷时的去向。有人留下，有人离开，有人直到现在也不愿总结。玛拉带来一张老照片，没有把任何人裁掉；山姆则说自己换工作主要是为了照顾父亲，不是什么精准的职业判断。轮到你开口时，过去不必被整理成一条毫无弯路的胜利路线，但也可以说清哪些决定确实由你承担过。",
      "characters": [
        "mara",
        "sam"
      ],
      "choices": [
        {
          "label": "讲具体约束，也承认运气",
          "detail": "将结果和过程分开，避免夸大个人控制力。",
          "effects": {
            "trust": 6,
            "communication": 4,
            "flags": [
              "honest_history"
            ]
          },
          "id": "b27_1",
          "cost": {},
          "delayed": []
        },
        {
          "label": "少谈职业，听别人把近况说完",
          "detail": "关系获得时间，不把聚会变成路演。",
          "effects": {
            "relations": {
              "mara": 4,
              "sam": 6
            },
            "stress": -3,
            "flags": [
              "life_priority"
            ]
          },
          "id": "b27_2",
          "cost": {},
          "delayed": []
        },
        {
          "label": "展示自己的成绩，争取新机会",
          "detail": "职业曝光增加，也提高未来期待。",
          "effects": {
            "reputation": 7,
            "stress": 4,
            "flags": [
              "management_path",
              "career_first"
            ]
          },
          "id": "b27_3",
          "cost": {},
          "delayed": []
        }
      ],
      "key": false,
      "requires": {}
    },
    {
      "id": "c27",
      "stage": 27,
      "kind": "conditional",
      "date": "2013-07-01",
      "endDate": "2013-12-31",
      "title": "旧工牌留在抽屉里",
      "text": "你已经重新有了工作方式和收入来源，那张失效工牌却一直放在抽屉深处。一个正在求职的人来问当年的经历，希望得到一句“很快就会好”的保证。你知道真实过程没有那样整齐：帮助来自具体的人，储蓄买到了一些时间，新的职位也没有完全复原旧的身份。是否讲出这些细节，本身是一种选择。",
      "characters": [
        "june",
        "nora"
      ],
      "choices": [
        {
          "label": "分享真实步骤，不承诺相同结果",
          "detail": "把重建经验变成有边界的帮助。",
          "effects": {
            "communication": 7,
            "trust": 5,
            "flags": [
              "rebuild_shared",
              "service_chosen"
            ]
          },
          "id": "c27_1",
          "cost": {},
          "delayed": []
        },
        {
          "label": "介绍公开求职资源，保留个人细节",
          "detail": "保护私人边界，同时提供实际信息。",
          "effects": {
            "freedom": 4,
            "communication": 4,
            "flags": [
              "rebuild_shared",
              "boundaries_kept"
            ]
          },
          "id": "c27_2",
          "cost": {},
          "delayed": []
        },
        {
          "label": "婉拒采访，继续自己的生活",
          "detail": "经历不必变成永久的职业身份。",
          "effects": {
            "stress": -4,
            "freedom": 5,
            "flags": [
              "quiet_life"
            ]
          },
          "id": "c27_3",
          "cost": {},
          "delayed": []
        }
      ],
      "key": false,
      "requires": {
        "flagsAll": [
          "job_lost",
          "rebuilt"
        ]
      },
      "chain": "repair",
      "recall": {
        "flag": "job_lost",
        "text": "失效工牌来自已经发生的离职；重建也已经在此前开始。"
      }
    },
    {
      "id": "b28",
      "stage": 28,
      "kind": "base",
      "date": "2014-01-01",
      "endDate": "2014-06-30",
      "title": "十年前的表格再打开",
      "text": "新的资料系统要迁移旧记录。你打开几份多年以前的表格，发现当时使用的口径有些已经不用，有些字段从来就缺失。把今天知道的内容填回旧表会使它整齐，却会破坏当时的信息边界。你决定如何保留这些档案，也是在决定多年后别人能否真正复核你曾经做过的判断，而不是只读到一份后来重写的聪明。",
      "characters": [
        "elias",
        "lin"
      ],
      "choices": [
        {
          "label": "保留原版，给更正单独标日期",
          "detail": "当时所知与后来所知清楚分离。",
          "effects": {
            "research": 7,
            "trust": 6,
            "flags": [
              "dated_archive",
              "process_discipline"
            ]
          },
          "id": "b28_1",
          "cost": {},
          "delayed": []
        },
        {
          "label": "只迁移重要档案，记录缺失范围",
          "detail": "减少维护量，明确证据的局限。",
          "effects": {
            "freedom": 4,
            "research": 4,
            "flags": [
              "dated_archive",
              "scope_discipline"
            ]
          },
          "id": "b28_2",
          "cost": {},
          "delayed": []
        },
        {
          "label": "请专业同事整理，自己抽样复核",
          "detail": "承担明确的个人资料整理费用。",
          "effects": {
            "personalCash": -350,
            "trust": 4,
            "flags": [
              "dated_archive"
            ]
          },
          "id": "b28_3",
          "cost": {
            "personalCash": 350
          },
          "delayed": []
        }
      ],
      "key": false,
      "requires": {}
    },
    {
      "id": "c28",
      "stage": 28,
      "kind": "conditional",
      "date": "2014-01-01",
      "endDate": "2014-06-30",
      "title": "结果并没有替你答题",
      "text": "旧记录里有一个后来结果很好的判断，当时的论据却很薄；另一个写得扎实的判断没有等来合适结果。你保留的危机笔记让两者都无法被轻易包装。林知远如今已退休，只在邮件里说，档案应允许作者显得不那么聪明。你可以为这两份记录写不同评价，却不应让收益数字替过程把所有题都答完。",
      "characters": [
        "lin"
      ],
      "choices": [
        {
          "label": "分别评价证据质量与投资结果",
          "detail": "保持过程纪律，不给运气编造精确占比。",
          "effects": {
            "research": 8,
            "trust": 5,
            "flags": [
              "dated_archive",
              "process_honored"
            ]
          },
          "id": "c28_1",
          "cost": {},
          "delayed": []
        },
        {
          "label": "把其中一份用作反面教学案例",
          "detail": "承认不漂亮的部分，提升沟通能力。",
          "effects": {
            "communication": 7,
            "reputation": -2,
            "trust": 5,
            "flags": [
              "process_honored",
              "teaching"
            ]
          },
          "id": "c28_2",
          "cost": {
            "reputation": 2
          },
          "delayed": []
        },
        {
          "label": "仅在个人档案中记录，不公开展示",
          "detail": "诚实复核不必成为营销材料。",
          "effects": {
            "research": 5,
            "freedom": 4,
            "flags": [
              "process_honored",
              "quiet_life"
            ]
          },
          "id": "c28_3",
          "cost": {},
          "delayed": []
        }
      ],
      "key": false,
      "requires": {
        "flagsAll": [
          "crisis_record"
        ]
      },
      "chain": "risk",
      "recall": {
        "flag": "crisis_record",
        "text": "你当年留下的危机记录，使这次复核有事前证据而非只有事后记忆。"
      }
    },
    {
      "id": "b29",
      "stage": 29,
      "kind": "base",
      "date": "2014-07-01",
      "endDate": "2014-12-31",
      "title": "更年轻的人也会离开",
      "text": "一位年轻同事准备换工作，请你替他读一遍交接说明。你有些不舍，也知道当初学来的方法不应把人永远绑在原处。山姆说，他现在招人时会先谈职责和边界，再谈忠诚。你可以投入时间帮这位新人把工作交清楚，也可以明确自己只能看一部分；无论如何，别人有权选择与你不同的职业速度。",
      "characters": [
        "sam"
      ],
      "choices": [
        {
          "label": "帮助完成交接，并确认贡献归属",
          "detail": "制度能在人员离开后继续。",
          "effects": {
            "communication": 6,
            "trust": 6,
            "flags": [
              "succession_practice",
              "shared_credit"
            ]
          },
          "id": "b29_1",
          "cost": {},
          "delayed": []
        },
        {
          "label": "只复核风险最大的部分",
          "detail": "聚焦实际责任，避免无限投入。",
          "effects": {
            "research": 5,
            "freedom": 3,
            "flags": [
              "scope_discipline",
              "succession_practice"
            ]
          },
          "id": "b29_2",
          "cost": {},
          "delayed": []
        },
        {
          "label": "把任务转给更熟悉项目的人",
          "detail": "不以旧资历垄断角色，保留个人精力。",
          "effects": {
            "freedom": 5,
            "trust": 2,
            "flags": [
              "quiet_life"
            ]
          },
          "id": "b29_3",
          "cost": {},
          "delayed": []
        }
      ],
      "key": false,
      "requires": {}
    },
    {
      "id": "c29",
      "stage": 29,
      "kind": "conditional",
      "date": "2014-07-01",
      "endDate": "2014-12-31",
      "title": "工作记录里的一封回信",
      "text": "山姆已经在另一家机构负责小团队。他寄来一封不是求助的信，邀请你交换培训办法；你以前给予的具体帮助还保存在他的工作记录里。他的父亲需要规律的照护，团队排班因此更加固定。山姆并没有复制你的生活，他想知道哪些规则值得留下，哪些应当从一开始就做得不同。",
      "characters": [
        "sam"
      ],
      "choices": [
        {
          "label": "共同制定署名与交接规则",
          "detail": "长期协作回收为实际制度。",
          "effects": {
            "communication": 7,
            "trust": 5,
            "relations": {
              "sam": 9
            },
            "flags": [
              "sam_partner",
              "succession_practice"
            ]
          },
          "id": "c29_1",
          "cost": {},
          "delayed": []
        },
        {
          "label": "向他学习排班，减少自己随时在线的责任",
          "detail": "接受后辈也能改变你的方法。",
          "effects": {
            "health": 5,
            "stress": -4,
            "relations": {
              "sam": 6
            },
            "flags": [
              "sam_partner",
              "boundaries_kept"
            ]
          },
          "id": "c29_2",
          "cost": {},
          "delayed": []
        },
        {
          "label": "接受一次交流，不承诺持续合作",
          "detail": "关系保持，避免把感谢变成无限义务。",
          "effects": {
            "freedom": 5,
            "relations": {
              "sam": 4
            },
            "flags": [
              "sam_peer"
            ]
          },
          "id": "c29_3",
          "cost": {},
          "delayed": []
        }
      ],
      "key": false,
      "requires": {
        "flagsAll": [
          "sam_reference"
        ]
      },
      "chain": "junior",
      "recall": {
        "flag": "sam_reference",
        "text": "你曾写过真实推荐或完成相互帮助，这封回信有具体来由。"
      }
    },
    {
      "id": "b30",
      "stage": 30,
      "kind": "base",
      "date": "2015-01-01",
      "endDate": "2015-06-30",
      "title": "技能清单没有职位名",
      "text": "你把现在会做的事写在纸上：核对资料、解释不确定性、与意见不同的人完成工作。职位名被放到第二页，第一页因此显得陌生。达里厄斯说图书馆正在找能管理项目的人，但这不是对金融职业的道德评判，只是另一份同样需要预算和耐心的工作。你可以试着了解，也可以决定现有道路仍值得继续。",
      "characters": [
        "darius",
        "nora"
      ],
      "choices": [
        {
          "label": "用有限时间探索外部机会",
          "detail": "增加选择空间，不自动辞职。",
          "effects": {
            "freedom": 7,
            "communication": 3,
            "flags": [
              "career_options",
              "school_contact"
            ]
          },
          "id": "b30_1",
          "cost": {},
          "delayed": []
        },
        {
          "label": "明确继续目前职业，收窄目标",
          "detail": "减少为了比较而增加的焦虑。",
          "effects": {
            "trust": 4,
            "stress": -3,
            "flags": [
              "career_deliberate"
            ]
          },
          "id": "b30_2",
          "cost": {},
          "delayed": []
        },
        {
          "label": "接一个短期公共教育项目",
          "detail": "付出时间，让技能在不同场景中工作。",
          "effects": {
            "communication": 6,
            "stress": 2,
            "relations": {
              "darius": 5
            },
            "flags": [
              "teaching",
              "school_commitment"
            ]
          },
          "id": "b30_3",
          "cost": {},
          "delayed": []
        }
      ],
      "key": false,
      "requires": {}
    },
    {
      "id": "c30",
      "stage": 30,
      "kind": "conditional",
      "date": "2015-01-01",
      "endDate": "2015-06-30",
      "title": "六年后的工作证明",
      "text": "重建后的履历已经足够长，离职不再是第一页上唯一显眼的事。朱恩请你协助一项新工作，明确说她看重的是近年的交付，而不是补偿当年的遗憾。你仍记得没有工牌的星期一，也知道帮助并非靠欠人情维持一生。接受这项工作可以继续累积服务经验，拒绝也不等于辜负曾经帮过你的人。",
      "characters": [
        "june"
      ],
      "choices": [
        {
          "label": "接下有明确边界的服务职责",
          "detail": "重建成为持续工作方式，不是一次幸运录用。",
          "effects": {
            "communication": 7,
            "trust": 6,
            "flags": [
              "rebuild_completed",
              "service_chosen"
            ]
          },
          "id": "c30_1",
          "cost": {},
          "delayed": []
        },
        {
          "label": "接受研究部分，请别人负责营销",
          "detail": "保留专业定位，按新分工继续成长。",
          "effects": {
            "research": 8,
            "trust": 3,
            "flags": [
              "rebuild_completed",
              "research_specialist"
            ]
          },
          "id": "c30_2",
          "cost": {},
          "delayed": []
        },
        {
          "label": "谢绝这次任务，保持已经稳定的生活",
          "detail": "承认恢复本身有价值，关系不以服从偿还。",
          "effects": {
            "freedom": 7,
            "stress": -4,
            "flags": [
              "rebuild_completed",
              "life_priority"
            ]
          },
          "id": "c30_3",
          "cost": {},
          "delayed": []
        }
      ],
      "key": false,
      "requires": {
        "flagsAll": [
          "job_lost",
          "rebuilt"
        ]
      },
      "chain": "repair",
      "recall": {
        "flag": "rebuilt",
        "text": "这份工作证明建立在离职后已持续进行的重建上。"
      }
    },
    {
      "id": "b31",
      "stage": 31,
      "kind": "base",
      "date": "2015-07-01",
      "endDate": "2015-12-31",
      "title": "舞台上空出来的十分钟",
      "text": "一个行业活动邀请你分享经验，组织者希望标题更有吸引力，最好保证听众学会一招就能改善结果。你手里有具体记录，却没有一条适用于所有时期的捷径。山姆说，台下也许有人只想知道遇到未知怎么办。十分钟可以换来名声，也可以被用来清楚说明方法的适用范围；两种讲法未必获得同样的掌声。",
      "characters": [
        "sam"
      ],
      "choices": [
        {
          "label": "讲一个有局限的过程案例",
          "detail": "明确证据与假设，名声增长较慢。",
          "effects": {
            "communication": 7,
            "trust": 5,
            "flags": [
              "process_public",
              "evidence_boundary"
            ]
          },
          "id": "b31_1",
          "cost": {},
          "delayed": []
        },
        {
          "label": "改为小组讨论，让参与者自己权衡",
          "detail": "牺牲曝光，换取较深入的交流。",
          "effects": {
            "research": 4,
            "communication": 5,
            "flags": [
              "teaching",
              "quiet_teacher"
            ]
          },
          "id": "b31_2",
          "cost": {},
          "delayed": []
        },
        {
          "label": "谢绝活动，把时间留给私人安排",
          "detail": "放弃一次曝光，维护恢复和关系。",
          "effects": {
            "health": 5,
            "stress": -4,
            "freedom": 4,
            "flags": [
              "life_priority",
              "boundaries_kept"
            ]
          },
          "id": "b31_3",
          "cost": {},
          "delayed": []
        }
      ],
      "key": false,
      "requires": {}
    },
    {
      "id": "c31",
      "stage": 31,
      "kind": "conditional",
      "date": "2015-07-01",
      "endDate": "2015-12-31",
      "title": "新行业没有请你预测市场",
      "text": "你所在的新行业遇到预算争议，同事请你帮忙整理假设和现金支出时间。他们没有问曾经管过多少资金，也不在意你是否仍关注股票。你发现以前练过的方法还能工作，旧职位却不必永远坐在你的肩上。与此同时，一份重返金融的邀请到来，薪酬可能更高，也意味着重新接受那套授权和考核。",
      "characters": [
        "nora",
        "darius"
      ],
      "choices": [
        {
          "label": "留在新行业，把工作做深",
          "detail": "主动转行得到持续确认。",
          "effects": {
            "freedom": 6,
            "communication": 6,
            "flags": [
              "outside_confirmed",
              "meaningful_work"
            ]
          },
          "id": "c31_1",
          "cost": {},
          "delayed": []
        },
        {
          "label": "保持外部主业，承担有限教学",
          "detail": "以新的身份保留旧技能。",
          "effects": {
            "communication": 7,
            "stress": 2,
            "flags": [
              "outside_confirmed",
              "teaching"
            ]
          },
          "id": "c31_2",
          "cost": {},
          "delayed": []
        },
        {
          "label": "接受研究岗位邀请，重新进入机构",
          "detail": "真实改变职业和授权，不抹去外部经历。",
          "effects": {
            "career": "analyst",
            "authority": 5,
            "research": 5,
            "stress": 4,
            "flags": [
              "returned_finance",
              "rebuilt"
            ],
            "removeFlags": [
              "outside_now"
            ]
          },
          "id": "c31_3",
          "cost": {},
          "delayed": []
        }
      ],
      "key": false,
      "requires": {
        "flagsAll": [
          "left_industry",
          "outside_committed"
        ],
        "career": "outside"
      },
      "chain": "repair",
      "recall": {
        "flag": "outside_committed",
        "text": "你已在此前正式选择外部职业，今天才会有新行业的工作积累。"
      }
    },
    {
      "id": "b32",
      "stage": 32,
      "kind": "base",
      "date": "2016-01-01",
      "endDate": "2016-06-30",
      "title": "日历上的空白并不多",
      "text": "诺拉发来下半年的日历，几项家庭事务仍需要分工；朱恩也在调整自己的工作时段。你发现大家不再像刚入职时那样把空白视为随时可以加上的工作。林知远约朋友帮忙修椅子，梅正在准备自己的展览。每个人都在安排一种有限的生活，你要决定本期把可用的时间留给哪一项具体的事。",
      "characters": [
        "nora",
        "june",
        "lin",
        "mei"
      ],
      "choices": [
        {
          "label": "确认一个长期家庭分工",
          "detail": "具体时间被承诺，关系获得连续性。",
          "effects": {
            "relations": {
              "nora": 7
            },
            "freedom": -2,
            "flags": [
              "family_agreement",
              "life_priority"
            ]
          },
          "id": "b32_1",
          "cost": {
            "freedom": 2
          },
          "delayed": []
        },
        {
          "label": "投入研究，把其他承诺缩小并提前说明",
          "detail": "职业深度增加，不许下无法完成的陪伴。",
          "effects": {
            "research": 8,
            "communication": 2,
            "stress": 4,
            "flags": [
              "research_specialist",
              "honest_boundary"
            ]
          },
          "id": "b32_2",
          "cost": {},
          "delayed": []
        },
        {
          "label": "为自己保留恢复与独处时间",
          "detail": "生活价值也包括不被任何职责占满的空间。",
          "effects": {
            "health": 7,
            "stress": -6,
            "freedom": 5,
            "flags": [
              "health_reset",
              "boundaries_kept",
              "quiet_life"
            ]
          },
          "id": "b32_3",
          "cost": {},
          "delayed": []
        }
      ],
      "key": false,
      "requires": {}
    },
    {
      "id": "c32",
      "stage": 32,
      "kind": "conditional",
      "date": "2016-01-01",
      "endDate": "2016-06-30",
      "title": "第二间办公室的窗户",
      "text": "诺拉的事务所准备搬到更合适的地方。她说起多年前第一次看房，记得你确实出现在那个星期日，还认真问过窗户的朝向。这次她已能独立作大多数决定，邀请你不是因为没有别人可找。她想把旧办公室那张略微摇晃的椅子送给你，像是给一段各自忙碌却没有完全失去联系的年月找个安放之处。",
      "characters": [
        "nora"
      ],
      "choices": [
        {
          "label": "去看新房间，商量未来可持续的分工",
          "detail": "早年承诺在多年后成为稳定关系。",
          "effects": {
            "relations": {
              "nora": 10
            },
            "health": 3,
            "flags": [
              "family_cycle_closed",
              "life_priority"
            ]
          },
          "id": "c32_1",
          "cost": {},
          "delayed": []
        },
        {
          "label": "收下椅子，帮助核对搬迁预算",
          "detail": "以实际技能支持她自己的事业。",
          "effects": {
            "communication": 4,
            "relations": {
              "nora": 7
            },
            "flags": [
              "family_cycle_closed",
              "family_supported"
            ]
          },
          "id": "c32_2",
          "cost": {},
          "delayed": []
        },
        {
          "label": "说明无法到场，寄去亲笔祝贺",
          "detail": "保持联系，承认这次没有共同经历。",
          "effects": {
            "relations": {
              "nora": 3
            },
            "freedom": 3,
            "flags": [
              "family_supported"
            ]
          },
          "id": "c32_3",
          "cost": {},
          "delayed": []
        }
      ],
      "key": false,
      "requires": {
        "flagsAll": [
          "family_kept"
        ]
      },
      "chain": "family",
      "recall": {
        "flag": "family_kept",
        "text": "她记得那次看房，是因为你确实兑现过早年的星期日约定。"
      }
    },
    {
      "id": "b33",
      "stage": 33,
      "kind": "base",
      "date": "2016-07-01",
      "endDate": "2016-12-31",
      "title": "一个总想追上别人的账户",
      "text": "朱恩转来一个经过匿名处理的沟通案例：客户看到朋友近期赚得更多，希望立刻提高风险。资料里没有任何人永远正确的证据，只有不同起点、现金流和期限。你可以帮她比较约束，也可以拒绝为完全不了解的账户给具体建议。相同的市场不会替每个人提供相同的承受能力，解释这一点比展示一张漂亮图更费耐心。",
      "characters": [
        "june"
      ],
      "choices": [
        {
          "label": "先核对期限与承受力，再谈配置",
          "detail": "服务和沟通能力增加，不追逐未经授权的风险。",
          "effects": {
            "communication": 8,
            "trust": 5,
            "flags": [
              "client_listener",
              "service_chosen"
            ]
          },
          "id": "b33_1",
          "cost": {},
          "delayed": []
        },
        {
          "label": "说明缺少资料，只提供问题清单",
          "detail": "证据不足时保持边界。",
          "effects": {
            "research": 5,
            "trust": 5,
            "flags": [
              "evidence_boundary",
              "process_discipline"
            ]
          },
          "id": "b33_2",
          "cost": {},
          "delayed": []
        },
        {
          "label": "建议由当前顾问完整评估，退出讨论",
          "detail": "不因旧关系越过责任范围。",
          "effects": {
            "freedom": 5,
            "trust": 3,
            "flags": [
              "boundaries_kept"
            ]
          },
          "id": "b33_3",
          "cost": {},
          "delayed": []
        }
      ],
      "key": false,
      "requires": {}
    },
    {
      "id": "c33",
      "stage": 33,
      "kind": "conditional",
      "date": "2016-07-01",
      "endDate": "2016-12-31",
      "title": "用款记录成为新的起点",
      "text": "朱恩再次请你看客户服务流程，附上的旧案例正是当年那笔屋顶支出。她没有用它证明现金永远最好，而是希望新人理解，已知用途的钱需要怎样的安排。有人问，如果当时继续持有后来表现更好的证券，会不会赚得更多。这个问题可以计算一条财务路径，却不能把已经支付的屋顶、或者今天的客户关系重新倒回去。",
      "characters": [
        "june"
      ],
      "choices": [
        {
          "label": "把实际结果与反事实分栏解释",
          "detail": "明确机会成本不会再次从账本扣款。",
          "effects": {
            "communication": 8,
            "trust": 6,
            "flags": [
              "client_legacy",
              "steady_service"
            ]
          },
          "id": "c33_1",
          "cost": {},
          "delayed": []
        },
        {
          "label": "让新人先写客户期限，再看结果",
          "detail": "把约束顺序放进培训。",
          "effects": {
            "research": 4,
            "communication": 6,
            "flags": [
              "client_legacy",
              "teaching",
              "process_honored"
            ]
          },
          "id": "c33_2",
          "cost": {},
          "delayed": []
        },
        {
          "label": "只保留匿名流程，谢绝宣传使用",
          "detail": "服务经验仍在，不变成自己的广告。",
          "effects": {
            "freedom": 4,
            "relations": {
              "june": 7
            },
            "flags": [
              "client_legacy",
              "life_priority"
            ]
          },
          "id": "c33_3",
          "cost": {},
          "delayed": []
        }
      ],
      "key": false,
      "requires": {
        "flagsAll": [
          "client_cycle_closed"
        ]
      },
      "chain": "clients",
      "recall": {
        "flag": "client_cycle_closed",
        "text": "旧案例的实际付款和服务回访已经发生，本次只重新解释它的意义。"
      }
    },
    {
      "id": "b34",
      "stage": 34,
      "kind": "base",
      "date": "2017-01-01",
      "endDate": "2017-06-30",
      "title": "旧档案不是第二个账户",
      "text": "整理投资记录时，你看见一些已经结束的判断，还有一些至今仍未兑现的期待。价格之后怎么走，可以在今天已知的范围内再看；实际卖出的资金去了哪里，也有自己的记录。你不必把后来错过的上涨叫作第二次亏损，更不能从今天的现金再扣一遍。档案能帮助你了解自己的选择，却没有另一段完整人生可以拿来精确对照。",
      "characters": [
        "lin"
      ],
      "choices": [
        {
          "label": "先看实际现金流，再看可定义的比较",
          "detail": "用可复核记录区分实际与机会成本。",
          "effects": {
            "research": 7,
            "trust": 4,
            "flags": [
              "counterfactual_clear",
              "process_honored"
            ]
          },
          "id": "b34_1",
          "cost": {},
          "delayed": []
        },
        {
          "label": "只复核决策时的证据与约束",
          "detail": "不让后来的价格抹去当时的边界。",
          "effects": {
            "research": 6,
            "stress": -3,
            "flags": [
              "process_honored",
              "evidence_boundary"
            ]
          },
          "id": "b34_2",
          "cost": {},
          "delayed": []
        },
        {
          "label": "结束本次复盘，把一个晚上还给生活",
          "detail": "反思也需要停止，历史记录继续保留。",
          "effects": {
            "health": 5,
            "stress": -5,
            "freedom": 4,
            "flags": [
              "life_priority",
              "boundaries_kept"
            ]
          },
          "id": "b34_3",
          "cost": {},
          "delayed": []
        }
      ],
      "key": false,
      "requires": {}
    },
    {
      "id": "c34",
      "stage": 34,
      "kind": "conditional",
      "date": "2017-01-01",
      "endDate": "2017-06-30",
      "title": "同一个条件的第三次版本",
      "text": "你再次打开那套保留版本的失效条件。最早的语言生硬，中间的版本带着危机时期的焦急，今天的你会写得更短。档案没有证明你的每次坚持都正确，也没有证明每次退出都懦弱。它只是留下了一个人怎样在具体信息和具体责任下改变判断。你要决定这套记录之后如何使用，而不是给过去颁发一个统一的分数。",
      "characters": [
        "lin",
        "sam"
      ],
      "choices": [
        {
          "label": "保留全部版本，用于过程复核",
          "detail": "跨阶段的纪律继续发挥作用。",
          "effects": {
            "research": 7,
            "trust": 6,
            "flags": [
              "process_honored",
              "dated_archive"
            ]
          },
          "id": "c34_1",
          "cost": {},
          "delayed": []
        },
        {
          "label": "与山姆交换方法，承认各自局限",
          "detail": "合作双方都可以改进，不垄断正确。",
          "effects": {
            "communication": 7,
            "relations": {
              "sam": 5
            },
            "flags": [
              "process_honored",
              "shared_credit"
            ]
          },
          "id": "c34_2",
          "cost": {},
          "delayed": []
        },
        {
          "label": "封存原件，写一页给自己的说明",
          "detail": "保留记忆，不让复盘无限占用当下。",
          "effects": {
            "freedom": 5,
            "stress": -4,
            "flags": [
              "process_honored",
              "quiet_life"
            ]
          },
          "id": "c34_3",
          "cost": {},
          "delayed": []
        }
      ],
      "key": false,
      "requires": {
        "flagsAll": [
          "risk_honored"
        ]
      },
      "chain": "risk",
      "recall": {
        "flag": "risk_honored",
        "text": "原始条件与修订版本一直被你保留，因此三个时期可以被真实比较。"
      }
    },
    {
      "id": "b35",
      "stage": 35,
      "kind": "base",
      "date": "2017-07-01",
      "endDate": "2017-12-31",
      "title": "更大的门牌",
      "text": "玛拉转来一份团队负责人的职位说明，来自虚构的合作机构。即使你现在已在别处工作，邀请仍然是一份需要重新权衡的工作：更多授权、更多人事责任，也有更多别人临时找你的晚上。她没有把它称作必然晋升。你读到最后一页，发现待遇写得很细，日历该如何分配却只用了“视业务需要”几个字。",
      "characters": [
        "mara",
        "june"
      ],
      "choices": [
        {
          "label": "接受负责人岗位，承担更高职责",
          "detail": "明确进入管理职业；组织边界仍约束交易。",
          "effects": {
            "career": "manager",
            "authority": 15,
            "reputation": 8,
            "stress": 9,
            "freedom": -6,
            "flags": [
              "leadership_accepted",
              "management_path"
            ],
            "removeFlags": [
              "unemployed_now"
            ]
          },
          "id": "b35_1",
          "cost": {
            "freedom": 6
          },
          "delayed": []
        },
        {
          "label": "只有写清职责与退出机制才接受",
          "detail": "进入管理职业，同时为生活保留制度边界。",
          "effects": {
            "career": "manager",
            "authority": 10,
            "trust": 6,
            "stress": 3,
            "flags": [
              "leadership_bounded",
              "management_path",
              "boundaries_kept"
            ],
            "removeFlags": [
              "unemployed_now"
            ]
          },
          "id": "b35_2",
          "cost": {},
          "delayed": []
        },
        {
          "label": "谢绝职位，维持自己的工作方式",
          "detail": "放弃可见的头衔，保留既有道路。",
          "effects": {
            "freedom": 8,
            "health": 3,
            "flags": [
              "career_deliberate",
              "life_priority"
            ]
          },
          "id": "b35_3",
          "cost": {},
          "delayed": []
        }
      ],
      "key": false,
      "requires": {}
    },
    {
      "id": "c35",
      "stage": 35,
      "kind": "conditional",
      "date": "2017-07-01",
      "endDate": "2017-12-31",
      "title": "是否把自己的名字印得更大",
      "text": "独立业务走到可以重新选择规模的阶段。有人愿意带来客户，也希望你把所有空余时间都交给增长。账本能够显示收入、费用和客户资金，却不能告诉你该不该把自己的名字印得更大。朱恩提醒，选择保持小规模同样需要把服务做完；一旦停止扩张，工作不会自动变成假期。\n\n你拿出最早的启动预算。那些费用确实由个人支付，后来的收入也按各自来源记入；没有哪一笔客户资产悄悄变成你的储蓄。如今的难题不是证明当初离开是否正确，而是决定下一段工作应该允许谁下班、允许什么样的客户拒绝你，以及你是否仍愿意亲自处理那些不体面的账单和合同。窗台上的名片盒还剩一半，不换名字也可以继续用。",
      "characters": [
        "june",
        "elias"
      ],
      "choices": [
        {
          "label": "维持小规模，重申客户规则",
          "detail": "独立路线持续，以有限服务换取更多自主。",
          "effects": {
            "freedom": 8,
            "trust": 7,
            "stress": -3,
            "flags": [
              "independent_renewed",
              "client_rules",
              "small_practice"
            ]
          },
          "id": "c35_1",
          "cost": {},
          "delayed": []
        },
        {
          "label": "扩大业务，但给团队建立轮值制度",
          "detail": "扩大工作负荷，同时承担组织责任。",
          "effects": {
            "authority": 10,
            "reputation": 7,
            "stress": 5,
            "communication": 4,
            "flags": [
              "independent_renewed",
              "client_rules",
              "service_system"
            ]
          },
          "id": "c35_2",
          "cost": {},
          "delayed": []
        },
        {
          "label": "结束扩张，逐步转向外部行业",
          "detail": "正式退出客户新交易；既有账本仍保留。",
          "effects": {
            "career": "outside",
            "authority": -100,
            "freedom": 10,
            "flags": [
              "left_industry",
              "outside_committed",
              "outside_confirmed"
            ],
            "removeFlags": [
              "unemployed_now"
            ]
          },
          "id": "c35_3",
          "cost": {
            "authority": 100
          },
          "delayed": []
        }
      ],
      "key": true,
      "requires": {
        "flagsAll": [
          "founded"
        ],
        "career": "independent"
      },
      "chain": "autonomy",
      "recall": {
        "flag": "founded",
        "text": "这份最早的预算对应你已经支付过的独立业务启动成本。"
      }
    },
    {
      "id": "b36",
      "stage": 36,
      "kind": "base",
      "date": "2018-01-01",
      "endDate": "2018-06-30",
      "title": "你不在时该由谁决定",
      "text": "一次需要你签字的工作因为你休息而停了两天。回来后，你没有发现整个世界崩塌，只看见几个人多等了一轮邮件。山姆建议把能授权给别人的判断写清，不必把经验全部锁在一个人的日程里。你可以继续成为不可替代的人，也可以投入一段时间，使事情在你不在场时仍然得到有记录的决定。",
      "characters": [
        "sam"
      ],
      "choices": [
        {
          "label": "建立清楚的交接与复核权限",
          "detail": "当期额外工作，为以后释放空间。",
          "effects": {
            "communication": 7,
            "trust": 6,
            "stress": 2,
            "flags": [
              "succession_practice",
              "service_system"
            ]
          },
          "id": "b36_1",
          "cost": {},
          "delayed": []
        },
        {
          "label": "保留核心职责，只移交常规任务",
          "detail": "平衡控制与负荷，形成有限替代。",
          "effects": {
            "research": 4,
            "freedom": 3,
            "flags": [
              "scope_discipline"
            ]
          },
          "id": "b36_2",
          "cost": {},
          "delayed": []
        },
        {
          "label": "继续全部亲自决定",
          "detail": "短期曝光更高，疲劳和依赖积累。",
          "effects": {
            "reputation": 6,
            "stress": 8,
            "health": -4,
            "flags": [
              "indispensable",
              "career_first"
            ]
          },
          "id": "b36_3",
          "cost": {
            "health": 4
          },
          "delayed": []
        }
      ],
      "key": false,
      "requires": {}
    },
    {
      "id": "c36",
      "stage": 36,
      "kind": "conditional",
      "date": "2018-01-01",
      "endDate": "2018-06-30",
      "title": "档案柜有了第二把钥匙",
      "text": "你维护多年的研究档案要交给下一位保管人。林知远的旧报告、你留下的修订记录和山姆补写的说明都在里面，没有一个人的名字能概括全部工作。新保管人问是否可以改分类方式，你发现自己也会对熟悉的抽屉顺序生出占有欲。把方法传下去，或许还包括允许它不再完全照着自己的习惯继续。",
      "characters": [
        "lin",
        "sam"
      ],
      "choices": [
        {
          "label": "交出维护权，要求保留来源与版本",
          "detail": "完成跨代传承，不垄断档案。",
          "effects": {
            "trust": 7,
            "freedom": 5,
            "relations": {
              "lin": 5,
              "sam": 5
            },
            "flags": [
              "archive_legacy",
              "teaching_legacy"
            ]
          },
          "id": "c36_1",
          "cost": {},
          "delayed": []
        },
        {
          "label": "设一个过渡期，共同核对重要材料",
          "detail": "花时间确保交接可执行。",
          "effects": {
            "research": 5,
            "communication": 5,
            "flags": [
              "archive_legacy",
              "succession_practice"
            ]
          },
          "id": "c36_2",
          "cost": {},
          "delayed": []
        },
        {
          "label": "保留个人副本，将公共部分交出",
          "detail": "明确私人记忆与团队资产边界。",
          "effects": {
            "freedom": 5,
            "trust": 5,
            "flags": [
              "archive_legacy",
              "dated_archive"
            ]
          },
          "id": "c36_3",
          "cost": {},
          "delayed": []
        }
      ],
      "key": false,
      "requires": {
        "flagsAll": [
          "archive_custodian"
        ]
      },
      "chain": "archive",
      "recall": {
        "flag": "archive_custodian",
        "text": "你曾正式接下维护这套材料的职责，如今才能交出这把钥匙。"
      }
    },
    {
      "id": "b37",
      "stage": 37,
      "kind": "base",
      "date": "2018-07-01",
      "endDate": "2018-12-31",
      "title": "一场不需要你的会议",
      "text": "梅邀请你参加展览结束后的普通聚餐。她已经能独立处理复杂项目，桌边的人谈论运输、灯光与一件迟到的展品，没有谁需要你的投资意见。你起初有些不知道该做什么，后来发现不必在每张桌子上提供专业价值。手机里仍有工作消息，是否马上回复，是一个不会立刻出现在收益图上的决定。",
      "characters": [
        "mei"
      ],
      "choices": [
        {
          "label": "把手机收起来，完成这顿饭",
          "detail": "陪伴发生在当下，不只是态度声明。",
          "effects": {
            "health": 3,
            "stress": -4,
            "relations": {
              "mei": 7
            },
            "flags": [
              "life_priority",
              "friend_present"
            ]
          },
          "id": "b37_1",
          "cost": {},
          "delayed": []
        },
        {
          "label": "说明需要处理十分钟工作，再回来",
          "detail": "为临时工作设置具体边界。",
          "effects": {
            "communication": 4,
            "relations": {
              "mei": 3
            },
            "flags": [
              "boundaries_kept",
              "honest_boundary"
            ]
          },
          "id": "b37_2",
          "cost": {},
          "delayed": []
        },
        {
          "label": "提前离开，完成手上的任务",
          "detail": "当期工作推进，错过聚会的后半段。",
          "effects": {
            "research": 6,
            "relations": {
              "mei": -5
            },
            "flags": [
              "career_first",
              "friend_distant"
            ]
          },
          "id": "b37_3",
          "cost": {},
          "delayed": []
        }
      ],
      "key": false,
      "requires": {}
    },
    {
      "id": "c37",
      "stage": 37,
      "kind": "conditional",
      "date": "2018-07-01",
      "endDate": "2018-12-31",
      "title": "备用钥匙已换了几次",
      "text": "梅把旧钥匙放在聚餐桌上，笑说它早已打不开任何一扇现在的门。你们曾在异地重新确认联系，又在晚点列车后见过面；这些小事没有阻止她去别处工作，也没有使你们每一年都亲密无间。她想把钥匙留作展览工作之外的一件私人纪念，问你是否还记得当时楼梯转角那箱特别重的目录。",
      "characters": [
        "mei"
      ],
      "choices": [
        {
          "label": "一起写下各自记得的细节",
          "detail": "允许两个人的记忆不完全相同。",
          "effects": {
            "relations": {
              "mei": 10
            },
            "stress": -4,
            "flags": [
              "friend_cycle_closed",
              "life_priority"
            ]
          },
          "id": "c37_1",
          "cost": {},
          "delayed": []
        },
        {
          "label": "把钥匙交回，约下一次具体见面",
          "detail": "物件可以归还，关系需要新的时间。",
          "effects": {
            "communication": 4,
            "relations": {
              "mei": 7
            },
            "flags": [
              "friend_cycle_closed",
              "boundaries_kept"
            ]
          },
          "id": "c37_2",
          "cost": {},
          "delayed": []
        },
        {
          "label": "承认很多细节已忘，认真听她说",
          "detail": "不虚构共同记忆来制造亲密。",
          "effects": {
            "trust": 4,
            "relations": {
              "mei": 6
            },
            "flags": [
              "friend_cycle_closed",
              "honest_history"
            ]
          },
          "id": "c37_3",
          "cost": {},
          "delayed": []
        }
      ],
      "key": false,
      "requires": {
        "flagsAll": [
          "friend_reunion",
          "key_held"
        ]
      },
      "chain": "friend",
      "recall": {
        "flag": "friend_reunion",
        "text": "备用钥匙与异地重逢都在该存档真实发生过，人物只引用这些共同经历。"
      }
    },
    {
      "id": "b38",
      "stage": 38,
      "kind": "base",
      "date": "2019-01-01",
      "endDate": "2019-06-30",
      "title": "取消的不是整个人生",
      "text": "你翻看近几个月的安排，发现很多事项都写着必须由你完成。没有突如其来的灾难，也没有医生替你给出一份标准人生方案；只是睡眠变浅、耐心变短，恢复越来越像欠下的账。诺拉提醒，调整职责可以是一项具体的工作决定，不必等到身体用更响亮的方式替你宣布。你需要选出一件真正愿意放下的事。",
      "characters": [
        "nora",
        "elias"
      ],
      "choices": [
        {
          "label": "移交一项职责，固定恢复时段",
          "detail": "降低授权和曝光，恢复真实发生。",
          "effects": {
            "authority": -5,
            "health": 10,
            "stress": -12,
            "reputation": -2,
            "flags": [
              "health_reset",
              "health_sustained",
              "boundaries_kept"
            ]
          },
          "id": "b38_1",
          "cost": {
            "authority": 5,
            "reputation": 2
          },
          "delayed": []
        },
        {
          "label": "收窄研究范围，保留当前岗位",
          "detail": "用专业边界减少负荷。",
          "effects": {
            "research": 3,
            "health": 5,
            "stress": -6,
            "flags": [
              "scope_discipline",
              "health_sustained"
            ]
          },
          "id": "b38_2",
          "cost": {},
          "delayed": []
        },
        {
          "label": "继续当前负荷，完成重要项目",
          "detail": "能力与曝光增加，身体代价记入状态。",
          "effects": {
            "research": 8,
            "reputation": 5,
            "health": -8,
            "stress": 10,
            "flags": [
              "exhausted",
              "career_first"
            ]
          },
          "id": "b38_3",
          "cost": {
            "health": 8
          },
          "delayed": []
        }
      ],
      "key": false,
      "requires": {}
    },
    {
      "id": "c38",
      "stage": 38,
      "kind": "conditional",
      "date": "2019-01-01",
      "endDate": "2019-06-30",
      "title": "后辈替你把会议改了时间",
      "text": "山姆看见你又把晚间会议排得很满，发来他们团队使用的轮值表。他没有说你当年怎样对他，因此现在必须接受帮助；只是说明哪一项可以转交、哪里还需要你本人决定。多年前你曾把署名和机会给过他，如今他带来的也不是感恩宣言，而是一份可以直接改动日历的办法。",
      "characters": [
        "sam"
      ],
      "choices": [
        {
          "label": "采用轮值，真实移交一项职责",
          "detail": "关系帮助落在可执行的恢复安排。",
          "effects": {
            "health": 9,
            "stress": -10,
            "communication": 4,
            "relations": {
              "sam": 8
            },
            "flags": [
              "health_reset",
              "health_sustained",
              "boundaries_kept",
              "junior_cycle_closed"
            ]
          },
          "id": "c38_1",
          "cost": {},
          "delayed": []
        },
        {
          "label": "借用方法，自己安排有限的交接",
          "detail": "保留自主，同时接受他人经验。",
          "effects": {
            "health": 5,
            "stress": -6,
            "research": 3,
            "flags": [
              "junior_cycle_closed",
              "succession_practice"
            ]
          },
          "id": "c38_2",
          "cost": {},
          "delayed": []
        },
        {
          "label": "感谢帮助，本期仍承担全部工作",
          "detail": "关系未被抹去，疲劳不会因感谢消失。",
          "effects": {
            "reputation": 5,
            "health": -6,
            "stress": 8,
            "relations": {
              "sam": 2
            },
            "flags": [
              "junior_cycle_closed",
              "career_first",
              "exhausted"
            ]
          },
          "id": "c38_3",
          "cost": {
            "health": 6
          },
          "delayed": []
        }
      ],
      "key": false,
      "requires": {
        "flagsAll": [
          "sam_partner",
          "sam_mentored"
        ]
      },
      "chain": "junior",
      "recall": {
        "flag": "sam_partner",
        "text": "你与山姆已经建立过平等的后续协作，因此他了解你的工作方式。"
      }
    },
    {
      "id": "b39",
      "stage": 39,
      "kind": "base",
      "date": "2019-07-01",
      "endDate": "2019-12-31",
      "title": "一份可以署名的说明",
      "text": "有人请你写一页关于长期工作的说明，希望少一点公式，多一点可执行的经验。你想到的却是一张张很普通的纸：申请、交接、日历与修改稿。它们没有使你避开所有错误，只让某些决定在多年后仍能被别人理解。你可以选择公开哪一部分，也可以保留私人经历；一份诚实说明不必把所有关系变成可展示的案例。",
      "characters": [
        "darius",
        "elias"
      ],
      "choices": [
        {
          "label": "公开方法与局限，征得相关人的同意",
          "detail": "尊重隐私与共同贡献。",
          "effects": {
            "communication": 7,
            "trust": 6,
            "flags": [
              "public_record",
              "honest_history"
            ]
          },
          "id": "b39_1",
          "cost": {},
          "delayed": []
        },
        {
          "label": "只整理给后辈的工作清单",
          "detail": "把经验留下，不追求更大曝光。",
          "effects": {
            "research": 5,
            "communication": 4,
            "flags": [
              "quiet_teacher",
              "teaching_legacy"
            ]
          },
          "id": "b39_2",
          "cost": {},
          "delayed": []
        },
        {
          "label": "不发表，完成个人记忆账本",
          "detail": "职业经验不必占据全部生活。",
          "effects": {
            "freedom": 6,
            "stress": -4,
            "flags": [
              "quiet_life",
              "life_priority"
            ]
          },
          "id": "b39_3",
          "cost": {},
          "delayed": []
        }
      ],
      "key": false,
      "requires": {}
    },
    {
      "id": "c39",
      "stage": 39,
      "kind": "conditional",
      "date": "2019-07-01",
      "endDate": "2019-12-31",
      "title": "伊莱的新工作邮箱",
      "text": "伊莱已转到一家虚构公益机构负责运营。他从新邮箱写信，想借用经过匿名化的流程图，帮助同事理解利益冲突需要怎样记录。你们曾核对过旧审批日期，他知道资料可以追溯，也知道你会问用途。规则离开金融楼层后仍有普通的含义：朋友不能因此获得删除记录的特权，程序也不该只剩吓人的术语。",
      "characters": [
        "elias",
        "darius"
      ],
      "choices": [
        {
          "label": "核对用途后分享无私人信息的流程",
          "detail": "伦理记录跨职业场景继续发挥作用。",
          "effects": {
            "trust": 8,
            "communication": 5,
            "relations": {
              "elias": 7
            },
            "flags": [
              "ethics_legacy",
              "public_record"
            ]
          },
          "id": "c39_1",
          "cost": {},
          "delayed": []
        },
        {
          "label": "协助改写为普通人能使用的说明",
          "detail": "付出沟通工作，使制度减少对熟人的依赖。",
          "effects": {
            "communication": 8,
            "trust": 5,
            "flags": [
              "ethics_legacy",
              "teaching_legacy"
            ]
          },
          "id": "c39_2",
          "cost": {},
          "delayed": []
        },
        {
          "label": "只提供原则，不传出原始资料",
          "detail": "保守处理资料权限，帮助保持有限。",
          "effects": {
            "trust": 6,
            "freedom": 3,
            "flags": [
              "ethics_legacy",
              "boundaries_kept"
            ]
          },
          "id": "c39_3",
          "cost": {},
          "delayed": []
        }
      ],
      "key": false,
      "requires": {
        "flagsAll": [
          "ethics_honored"
        ]
      },
      "chain": "ethics",
      "recall": {
        "flag": "ethics_honored",
        "text": "你们曾认真完成原记录的复核，所以本次知道哪些内容可以被使用。"
      }
    },
    {
      "id": "b40",
      "stage": 40,
      "kind": "base",
      "date": "2020-01-01",
      "endDate": "2020-06-30",
      "title": "四十四岁的第一张日历",
      "text": "你把新日历翻开，写下年龄：四十四。二十年前的许多问题并没有消失，只是金额、职位和需要商量的人变了。诺拉忙着自己的项目，梅仍在安排展览，林知远发来修好椅子的照片。你可以先为今年留下某种边界，也可以继续扩大正在做的事。没有人把这一年预先标成结局，它仍然需要按一个个具体日子过下去。",
      "characters": [
        "nora",
        "mei",
        "lin"
      ],
      "choices": [
        {
          "label": "为关系与恢复先留出具体日期",
          "detail": "长期边界延续，选择空间仍属于自己。",
          "effects": {
            "health": 5,
            "freedom": 5,
            "relations": {
              "nora": 3,
              "mei": 3
            },
            "flags": [
              "life_priority",
              "boundaries_kept"
            ]
          },
          "id": "b40_1",
          "cost": {},
          "delayed": []
        },
        {
          "label": "写清最后一阶段的工作目标与交接",
          "detail": "保留职业责任，不把自己设置为唯一答案。",
          "effects": {
            "research": 5,
            "communication": 4,
            "trust": 4,
            "flags": [
              "succession_practice"
            ]
          },
          "id": "b40_2",
          "cost": {},
          "delayed": []
        },
        {
          "label": "继续扩大工作承诺",
          "detail": "更多声望机会，也有真实的压力成本。",
          "effects": {
            "reputation": 7,
            "stress": 7,
            "health": -3,
            "flags": [
              "career_first"
            ]
          },
          "id": "b40_3",
          "cost": {
            "health": 3
          },
          "delayed": []
        }
      ],
      "key": false,
      "requires": {}
    },
    {
      "id": "c40",
      "stage": 40,
      "kind": "conditional",
      "date": "2020-01-01",
      "endDate": "2020-06-30",
      "title": "两张日历放在一起",
      "text": "诺拉把她的新日历放到桌上，你的那一本摊在旁边。她没有要求你为往年补上所有缺席，只想确认已经持续多年的联系是否需要调整方式。以前看房时问过的窗户，如今已经换到另一间办公室；那次守约并没有冻结关系，而是使你们遇到变化时较愿意直接开口。四十四岁的你仍需要练习重新作一个合适的承诺。",
      "characters": [
        "nora"
      ],
      "choices": [
        {
          "label": "按双方现状重新确认分工",
          "detail": "关系延续依靠更新承诺。",
          "effects": {
            "relations": {
              "nora": 8
            },
            "freedom": 3,
            "flags": [
              "family_renewed",
              "life_priority"
            ]
          },
          "id": "c40_1",
          "cost": {},
          "delayed": []
        },
        {
          "label": "缩小自己的部分，并承担明确费用",
          "detail": "有限支持仍需实际个人支出。",
          "effects": {
            "personalCash": -400,
            "relations": {
              "nora": 5
            },
            "flags": [
              "family_renewed",
              "family_supported"
            ]
          },
          "id": "c40_2",
          "cost": {
            "personalCash": 400
          },
          "delayed": []
        },
        {
          "label": "保留原分工，同时减少一项工作",
          "detail": "改变负荷而非要求家人无限等待。",
          "effects": {
            "authority": -5,
            "health": 6,
            "stress": -5,
            "relations": {
              "nora": 6
            },
            "flags": [
              "family_renewed",
              "boundaries_kept"
            ]
          },
          "id": "c40_3",
          "cost": {
            "authority": 5
          },
          "delayed": []
        }
      ],
      "key": false,
      "requires": {
        "flagsAll": [
          "family_cycle_closed"
        ]
      },
      "chain": "family",
      "recall": {
        "flag": "family_cycle_closed",
        "text": "你们曾在第二次办公室搬迁时维持过具体的联系与支持，今天是在更新关系。"
      }
    },
    {
      "id": "b41",
      "stage": 41,
      "kind": "base",
      "date": "2020-07-01",
      "endDate": "2020-12-31",
      "title": "屏幕关上以后",
      "text": "这次年度整理通过视频完成。小格子里的房间各不相同：朱恩身后的门偶尔打开，玛拉的桌上堆着纸，林知远连接了两次才让声音出来。你把投资记录、劳动收入和个人支出分开看，又把那些与钱没有直接关系的决定放到另一页。\n\n有些判断赚到了钱，有些没有；有些得到过信任，却未必带来晋升。人们各自讲近况，没有谁等着给你的二十年打一个统一分数。会议结束前，你需要完成最后一轮具体交接，决定哪些材料可留给别人、哪些属于私人记忆，以及什么安排仍值得带到明年。\n\n屏幕关上后，桌面露出来。生涯记录会保留实际走过的路径，历史档案也会揭开匿名公司的身份。至于没有发生的那一段人生，它没有一份可靠账本，不必被编造成一定更幸福或一定更富有的答案。",
      "characters": [
        "june",
        "mara",
        "lin",
        "nora",
        "mei",
        "sam",
        "elias",
        "darius"
      ],
      "choices": [
        {
          "label": "完成可复核的工作交接",
          "detail": "保持职业责任，结局由多年累积状态决定。",
          "effects": {
            "trust": 4,
            "communication": 3,
            "flags": [
              "final_handover"
            ]
          },
          "id": "b41_1",
          "cost": {},
          "delayed": []
        },
        {
          "label": "给重要的人写一封具体的信",
          "detail": "只引用记忆账本里真实发生的事。",
          "effects": {
            "relations": {
              "nora": 3,
              "mei": 3,
              "sam": 3,
              "lin": 3
            },
            "freedom": 3,
            "flags": [
              "final_letters"
            ]
          },
          "id": "b41_2",
          "cost": {},
          "delayed": []
        },
        {
          "label": "留一个安静的晚上，封存本期账本",
          "detail": "恢复和独处也有价值，不改变已发生的资金流。",
          "effects": {
            "health": 4,
            "stress": -5,
            "flags": [
              "final_quiet"
            ]
          },
          "id": "b41_3",
          "cost": {},
          "delayed": []
        }
      ],
      "key": true,
      "requires": {}
    },
    {
      "id": "c41",
      "stage": 41,
      "kind": "conditional",
      "date": "2020-07-01",
      "endDate": "2020-12-31",
      "title": "折叠椅换成了小窗口",
      "text": "达里厄斯把夜校搬到视频窗口里，请你参加一次学期结业。他让每位学员讲一个自己学会核对的问题，而不是报出投资成绩。有的人终于分清工资流入与账户收益，有的人决定下次先问费用。屏幕的另一端很安静，那十二把旧折叠椅并不在场，但课程仍然有一个能够继续的顺序。\n\n你想起最早答应的一个学期，也想起后来重新修订教材时的咖啡渍。那些晚上占用了真实的时间，没有自动使你在市场上更聪明；它们改变的是你如何把有限的知识说给别人，以及在不知道的时候能否停下来。\n\n结业前，达里厄斯问下一位讲师该接走哪些材料。你可以继续有限参与，也可以完成一次诚实交接。多年承诺已经在记忆账本里留下兑现的记录，这道选择只安排下一步，不负责抹平过去所有取舍。",
      "characters": [
        "darius"
      ],
      "choices": [
        {
          "label": "交出完整讲义与修订方法",
          "detail": "公共工作有后继，不依赖一个人永远到场。",
          "effects": {
            "communication": 5,
            "trust": 4,
            "flags": [
              "teaching_legacy",
              "school_successor",
              "final_handover"
            ]
          },
          "id": "c41_1",
          "cost": {},
          "delayed": []
        },
        {
          "label": "继续有限授课，给出明确时段",
          "detail": "关系与职责都有可持续边界。",
          "effects": {
            "communication": 4,
            "freedom": 2,
            "flags": [
              "teaching_legacy",
              "boundaries_kept",
              "final_letters"
            ]
          },
          "id": "c41_2",
          "cost": {},
          "delayed": []
        },
        {
          "label": "结束固定授课，完成资料交接",
          "detail": "主动结束也是一种兑现，不取消既有贡献。",
          "effects": {
            "freedom": 6,
            "health": 3,
            "flags": [
              "teaching_legacy",
              "school_successor",
              "final_quiet"
            ]
          },
          "id": "c41_3",
          "cost": {},
          "delayed": []
        }
      ],
      "key": true,
      "requires": {
        "flagsAll": [
          "teaching",
          "teaching_return"
        ]
      },
      "chain": "school",
      "recall": {
        "flag": "teaching_return",
        "text": "你曾回到课堂修订或继续教学，所以这场结业会有你真正参与的材料。"
      }
    }
  ],
  "endings": [
    {
      "id": "institution_solitude",
      "title": "门牌变大，日历变窄",
      "text": "你走到需要为更多人签字的位置。职业档案里有清楚的职责，也有主动增加的工作承诺。这个位置并非只由选股结果决定；沟通、制度和时机都参与其中。私人时间曾被一次次借出，哪些关系仍在，关系账本会分别说明。名片是真的，代价也没有从记忆中消失。",
      "requires": {
        "career": [
          "manager",
          "head",
          "partner"
        ],
        "flagsAll": [
          "leadership_accepted",
          "career_first"
        ]
      }
    },
    {
      "id": "independent_practice",
      "title": "名片盒还剩一半",
      "text": "你实际支付过启动费用，也在合同与规模之间重新选择过边界。独立工作没有把客户的钱变成自己的财富，更没有免去账单与责任；它让你能够决定用什么条件继续。窗台上的名片未必用完，个人资产与机构成绩将分别列出，这段生涯的自由来自付过的代价和承担的工作。",
      "requires": {
        "career": "independent",
        "flagsAll": [
          "founded",
          "independent_renewed",
          "client_rules"
        ]
      }
    },
    {
      "id": "outside_profession",
      "title": "职业栏里的新名字",
      "text": "你正式离开过原来的职业，又在新的工作中决定继续。研究、核对和解释不确定性的能力没有随旧工牌失效，但它们不再只服务于投资。转行的收入和生活变化都有各自记录，旧组合的历史也仍可复盘。你不需要证明所有留下的人都错，才能承认这条道路是自己的选择。",
      "requires": {
        "career": "outside",
        "flagsAll": [
          "left_industry",
          "outside_committed",
          "outside_confirmed"
        ]
      }
    },
    {
      "id": "rebuilt_career",
      "title": "失效工牌之后",
      "text": "失业没有替你结束故事。个人缓冲、他人介绍、自己的学习和后来的工作共同组成重建，账本里也保留了中断的成本。多年以后，你接受或谢绝新职责时已能说明边界。旧工牌还可以留着，却不再是履历的全部；这段结局属于确实经历过失去工作，又逐步建立持续生活的人。",
      "requires": {
        "flagsAll": [
          "job_lost",
          "rebuilt",
          "rebuild_completed"
        ]
      }
    },
    {
      "id": "quiet_wholeness",
      "title": "两张日历",
      "text": "早年的星期日和后来办公室的窗户，在这份存档里都有真实来由。你多次给关系和生活留出具体位置，也接受它们需要重新商量。财富不必因此更高，职业也未必停滞；这些数字会单独展示。两张日历放在一起，没有一张要求另一张永远空白。",
      "requires": {
        "flagsAll": [
          "life_priority",
          "family_cycle_closed"
        ],
        "min": {
          "health": 40
        }
      }
    },
    {
      "id": "steady_steward",
      "title": "按约定到达的钱",
      "text": "你保留过客户期限，复核过实际服务结果，也把研究过程与后来价格分开评价。你未必抓住每一段上涨，但在可以说明的约束里承担过责任。机构时间加权业绩、私人资产和机会成本分别列出；它们不会被合并成一个道德分数。朱恩保存的那份记录，最后一行仍是钱何时到达用途。",
      "requires": {
        "flagsAll": [
          "client_cycle_closed",
          "process_honored",
          "client_legacy"
        ]
      }
    },
    {
      "id": "shared_method",
      "title": "灯可以由别人来关",
      "text": "你曾走进课堂或接下传承工作，又在后来实际回来修订和交接。方法经过别人的问题变得不同，贡献也有了不只一个名字。教学没有保证投资成功，却留下了一种面对未知的语言。最后的材料能够被别人继续使用，你可以留下，也可以准时回家。",
      "requires": {
        "flagsAll": [
          "teaching",
          "teaching_return",
          "teaching_legacy"
        ]
      }
    },
    {
      "id": "recovered_boundary",
      "title": "星期三仍是星期三",
      "text": "你不止一次在负荷升高时作了实际调整，也把恢复延续下来。这不意味着所有损失都被弥补，或身体成为永远不会变化的资产；只是日历上终于有几格不再等待工作剩余的时间。职业和财富仍有各自结果，生活的这一部分由你曾移交的职责和保留的边界支撑。",
      "requires": {
        "flagsAll": [
          "health_reset",
          "health_sustained",
          "boundaries_kept"
        ],
        "min": {
          "health": 45
        }
      }
    },
    {
      "id": "open_ledger",
      "title": "仍有空白的一页",
      "text": "你的道路没有落进一个整齐的类别。已经发生的交易、收入、决定和关系会留在各自的账本里，没有兑现的期待也仍然可以被命名。你走过了完整的二十年；真实公司现在揭晓，过去的信息边界仍可复核。余下的空白既不是亏损，也不是自动获利的机会，它只是尚未写下的生活。",
      "requires": {}
    }
  ],
  "chains": [
    {
      "id": "archive",
      "title": "黄纸档案",
      "nodes": [
        {
          "event": "b01",
          "flag": "archive_kept",
          "year": 2000
        },
        {
          "event": "c06",
          "flag": "archive_shared",
          "year": 2003
        },
        {
          "event": "c20",
          "flag": "archive_custodian",
          "year": 2010
        },
        {
          "event": "c36",
          "flag": "archive_legacy",
          "year": 2018
        }
      ]
    },
    {
      "id": "family",
      "title": "星期日与窗户",
      "nodes": [
        {
          "event": "b00",
          "flag": "sunday_promised",
          "year": 2000
        },
        {
          "event": "c10",
          "flag": "family_kept",
          "year": 2005
        },
        {
          "event": "c32",
          "flag": "family_cycle_closed",
          "year": 2016
        },
        {
          "event": "c40",
          "flag": "family_renewed",
          "year": 2020
        }
      ]
    },
    {
      "id": "credit",
      "title": "报告署名",
      "nodes": [
        {
          "event": "c06",
          "flag": "credit_record",
          "year": 2003
        },
        {
          "event": "c08",
          "flag": "credit_agreement",
          "year": 2004
        },
        {
          "event": "c09",
          "flag": "credit_honored",
          "year": 2004
        },
        {
          "event": "c08",
          "type": "delayed",
          "flag": "credit_legacy",
          "year": 2012
        }
      ]
    },
    {
      "id": "clients",
      "title": "客户的时间",
      "nodes": [
        {
          "event": "b03",
          "flag": "client_horizon",
          "year": 2001
        },
        {
          "event": "c07",
          "flag": "client_served",
          "year": 2003
        },
        {
          "event": "c19",
          "flag": "client_cycle_closed",
          "year": 2009
        },
        {
          "event": "c33",
          "flag": "client_legacy",
          "year": 2016
        }
      ]
    },
    {
      "id": "ethics",
      "title": "抽屉里的清单",
      "nodes": [
        {
          "event": "b08",
          "flag": "ethics_record",
          "year": 2004
        },
        {
          "event": "c13",
          "flag": "ethics_followed",
          "year": 2006
        },
        {
          "event": "c23",
          "flag": "ethics_honored",
          "year": 2011
        },
        {
          "event": "c39",
          "flag": "ethics_legacy",
          "year": 2019
        }
      ]
    },
    {
      "id": "friend",
      "title": "海边的钥匙",
      "nodes": [
        {
          "event": "b05",
          "flag": "key_held",
          "year": 2002
        },
        {
          "event": "c11",
          "flag": "friend_distance",
          "year": 2005
        },
        {
          "event": "c14",
          "flag": "friend_renewed",
          "year": 2007
        },
        {
          "event": "c22",
          "flag": "friend_reunion",
          "year": 2011
        },
        {
          "event": "c37",
          "flag": "friend_cycle_closed",
          "year": 2018
        }
      ]
    },
    {
      "id": "junior",
      "title": "第二把椅子",
      "nodes": [
        {
          "event": "b11",
          "flag": "sam_mentored",
          "year": 2005
        },
        {
          "event": "c17",
          "flag": "sam_reference",
          "year": 2008
        },
        {
          "event": "c29",
          "flag": "sam_partner",
          "year": 2014
        },
        {
          "event": "c38",
          "flag": "junior_cycle_closed",
          "year": 2019
        }
      ]
    },
    {
      "id": "risk",
      "title": "先写下退出条件",
      "nodes": [
        {
          "event": "b04",
          "flag": "risk_record",
          "year": 2002
        },
        {
          "event": "c12",
          "flag": "risk_honored",
          "year": 2006
        },
        {
          "event": "c16",
          "flag": "crisis_record",
          "year": 2008
        },
        {
          "event": "c28",
          "flag": "process_honored",
          "year": 2014
        },
        {
          "event": "c34",
          "flag": "process_honored",
          "year": 2017
        }
      ]
    },
    {
      "id": "repair",
      "title": "失效工牌",
      "nodes": [
        {
          "event": "b17",
          "flag": "job_lost",
          "year": 2008
        },
        {
          "event": "c18",
          "flag": "rebuilt",
          "year": 2009
        },
        {
          "event": "c27",
          "flag": "rebuild_shared",
          "year": 2013
        },
        {
          "event": "c30",
          "flag": "rebuild_completed",
          "year": 2015
        }
      ]
    },
    {
      "id": "school",
      "title": "夜校的灯",
      "nodes": [
        {
          "event": "b10",
          "flag": "teaching",
          "year": 2005
        },
        {
          "event": "c21",
          "flag": "teaching_return",
          "year": 2010
        },
        {
          "event": "c41",
          "flag": "teaching_legacy",
          "year": 2020
        }
      ]
    },
    {
      "id": "autonomy",
      "title": "名片的背面",
      "nodes": [
        {
          "event": "b14",
          "flag": "independence_plan",
          "year": 2007
        },
        {
          "event": "c24",
          "flag": "founded",
          "year": 2012
        },
        {
          "event": "c25",
          "flag": "client_rules",
          "year": 2012
        },
        {
          "event": "c35",
          "flag": "independent_renewed",
          "year": 2017
        }
      ]
    },
    {
      "id": "health",
      "title": "周三晚上",
      "nodes": [
        {
          "event": "b02",
          "flag": "wednesday_kept",
          "year": 2001
        },
        {
          "event": "c15",
          "flag": "health_reset",
          "year": 2007
        },
        {
          "event": "c26",
          "flag": "health_sustained",
          "year": 2013
        },
        {
          "event": "b38",
          "flag": "health_sustained",
          "year": 2019
        }
      ]
    }
  ]
};
