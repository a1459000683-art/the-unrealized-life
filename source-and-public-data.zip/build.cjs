'use strict';
const fs=require('node:fs');
const path=require('node:path');
const escape=s=>s.replace(/<\/script/gi,'<\\/script');
function build(){
 const data=fs.readFileSync('data/market.json','utf8');
 const js=['src/finance.js','src/story.js','src/game.js','src/ui.js'].map(p=>fs.readFileSync(p,'utf8')).join('\n;\n');
 const css=fs.readFileSync('src/style.css','utf8');
 let html=fs.readFileSync('src/shell.html','utf8');
 html=html.replace('<!--STYLE-->',()=>css).replace('<!--SCRIPTS-->',()=> 'globalThis.MARKET='+escape(data)+';\n'+escape(js)+'\n;UI.mount();');
 if(/<!--(?:STYLE|SCRIPTS)-->/g.test(html))throw Error('Unreplaced build marker');
 for(const dir of ['dist','site/dist']){fs.mkdirSync(dir,{recursive:true});fs.writeFileSync(path.join(dir,'index.html'),html);}
 fs.writeFileSync('index.html',html);
 console.log(JSON.stringify({built:true,bytes:Buffer.byteLength(html),outputs:['index.html','dist/index.html','site/dist/index.html']}));
}
build();
