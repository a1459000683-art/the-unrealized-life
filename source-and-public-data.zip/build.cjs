'use strict';
const fs=require('node:fs');
const path=require('node:path');
const vm=require('node:vm');
const {execFileSync}=require('node:child_process');
const escape=s=>s.replace(/<\/script/gi,'<\\/script');
const preview=process.argv.includes('--preview');
const storyContext={};
vm.runInNewContext(fs.readFileSync('src/novel-story.js','utf8'),storyContext);
if(storyContext.NOVEL_STORY?.draft&&!preview)throw Error('Story is still an authoring draft; use --preview for an isolated local preview.');
// Rebuild the compatible legacy edition; the exact v1.1 snapshot remains a separate file.
execFileSync(process.execPath,['build-legacy.cjs'],{stdio:'inherit'});
const data=JSON.stringify(JSON.parse(fs.readFileSync('data/market.json','utf8')));
const read=p=>fs.readFileSync(p,'utf8');
const code=[read('src/finance.js'),read('src/novel-story.js'),
 'globalThis.STORY={characters:globalThis.NOVEL_STORY.characters,events:[],endings:[]};',
 read('src/game.js'),read('src/novel.js'),read('src/fflate.js'),read('src/novel-ui.js')].join('\n;\n');
const script="try { globalThis.MARKET=JSON.parse(document.getElementById('market-data').textContent);\n"+code+"\n;NovelUI.mount(); } catch(error) { if(globalThis.NOVEL_BOOT_FAIL)globalThis.NOVEL_BOOT_FAIL(error); console.error(error); }";
let html=read('src/novel-shell.html')
 .replace('<!--STYLE-->',()=>'<style>'+read('src/novel-style.css')+'</style>')
 .replace('<!--BOOTSTRAP-->',()=>'<script>'+escape(read('src/novel-bootstrap.js'))+'</script>')
 .replace('<!--DATA-->',()=>'<script id="market-data" type="application/json">'+escape(data)+'</script>')
 .replace('<!--SCRIPTS-->',()=>'<script>'+escape(script)+'</script>');
if(/<!--(?:STYLE|BOOTSTRAP|DATA|SCRIPTS)-->/g.test(html))throw Error('Unreplaced build marker');
const dirs=preview?['output/preview']:['dist','site/dist'];
for(const dir of dirs){
 fs.mkdirSync(dir,{recursive:true});fs.writeFileSync(path.join(dir,'index.html'),html);
 fs.copyFileSync('connection-check.html',path.join(dir,'connection-check.html'));
 fs.copyFileSync('legacy-v1.1.html',path.join(dir,'legacy-v1.1.html'));
 if(preview)fs.copyFileSync('legacy.html',path.join(dir,'legacy.html'));
}
if(!preview)fs.writeFileSync('index.html',html);
console.log(JSON.stringify({built:true,experience:'novel',preview,bytes:Buffer.byteLength(html),outputs:preview?['output/preview/index.html']:['index.html','dist/index.html','site/dist/index.html'],legacy:'legacy.html'}));
