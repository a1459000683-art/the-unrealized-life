# 《未实现的人生》需求覆盖与独立验收矩阵

依据：用户原始附件 `requirements/wall_street_life_game_prompt(1).md`（274 行，29,986 字节）。独立验收人员于 2026-10-02 通过当前 Library `read` 完整读取，结果 `start_line=1`、`end_line=274`、`has_more=false`。原文件不改动。该矩阵是验收工作底稿，不能代替原始需求。

状态含义：**待实现/待核验**＝没有执行证据；**部分**＝存在实现但仍有具体缺口；**通过**＝实现与真实执行的证据均已记录；**限制**＝未实现或无法实测，必须在最终交付中披露。本次核验以源码审计、受控机制回归、真实行情完整生涯和实际浏览器操作分别记录；不把其中一种当作另一种。主证据索引见本文末尾。

## 1. 产品、历史与数据

| ID | 附件节 | 必须满足的验收事实 | 实现/数据定位 | 执行证据 | 当前状态 |
|---|---:|---|---|---|---|
| P01 | 1,18 | 可独立游玩并通关的全中文投资人生游戏；不是策划案/演示 | src/game.js、src/story.js、src/ui.js | 51 生涯报告、剧情覆盖报告、浏览器离线通关 | 通过 |
| P02 | 1 | 2000—2020 主线，开场 24 岁；若调整须至少 15 年并披露 | src/game.js、src/story.js、src/ui.js | 51 生涯报告、剧情覆盖报告、浏览器离线通关 | 通过 |
| P03 | 1 | 雇主、人物、金额及私人经历均虚构；未读取用户私人资料 | src/game.js、src/story.js、src/ui.js | 51 生涯报告、剧情覆盖报告、浏览器离线通关 | 通过 |
| P04 | 1,13 | 财富、职业、诚信、关系、自由分立，没有人生总分或唯一标准结局 | src/game.js、src/story.js、src/ui.js | 51 生涯报告、剧情覆盖报告、浏览器离线通关 | 通过 |
| I01 | 2 | 中型投行集团下独立资管团队，有研究、投委会、组合、客户与合规职能 | src/game.js：权限/研究/职业/三账；src/story.js | 集成回归、51 生涯报告、剧情覆盖报告 | 通过 |
| I02 | 2 | 初级研究员不能无授权动客户资金；研究与提交不等于成交 | src/game.js：权限/研究/职业/三账；src/story.js | 集成回归、51 生涯报告、剧情覆盖报告 | 通过 |
| I03 | 2 | 初始覆盖方向改变候选、研究难点、导师/机会；转组付实际成本 | src/game.js：权限/研究/职业/三账；src/story.js | 集成回归、51 生涯报告、剧情覆盖报告 | 通过 |
| I04 | 2 | 客户组合、机构收入、个人现金三账分开；薪酬、奖金、递延、离职损失可追踪 | src/game.js：权限/研究/职业/三账；src/story.js | 集成回归、51 生涯报告、剧情覆盖报告 | 通过 |
| I05 | 2 | 个人交易审批/限制有机制；法律、虚构政策、玩法简化分明 | src/game.js：权限/研究/职业/三账；src/story.js | 集成回归、51 生涯报告、剧情覆盖报告 | 通过 |
| D01 | 3 | 至少 16 家完整真实美股普通股，至少 8 种生意 | data/market.json、data/SOURCE-MANIFEST.json、src/game.js：company | 17 家/17 生意；16 家各 53 真报价；PIR 为额外 3 报价有限窗口，见 SOURCES.md | 通过 |
| D02 | 3 | 排除微软/英伟达/英特尔/苹果/亚马逊/Alphabet/Meta/特斯拉/伯克希尔；避免安然/雷曼等明显答案 | data/market.json、data/SOURCE-MANIFEST.json、src/game.js：company | docs/data-audit.json 76/76、docs/SOURCES.md、公开日期回归 | 通过 |
| D03 | 3 | 成长、周期、估值透支、债务危机、衰退、重组/清算等路径均有真实样本 | data/market.json、data/SOURCE-MANIFEST.json、src/game.js：company | 真实增长/周期/长期衰退及 PIR 旧股注销；具体样本与限制见 SOURCES.md | 通过 |
| D04 | 3,5 | 每家公司可交易期间、上市状态与规模适配均核验；不能仅有名称/编造年回报 | docs/SOURCES.md；data/market.json：窗口/真报价 | 17/17 actualListingDate 为 null；listed 仅本包开放日；没有逐年市值/规模序列。16 家各 53 真报价，PIR 另 3 点有限窗口 | 部分：规模及精确 IPO 日期不完整 |
| D05 | 4 | 默认稳定匿名身份，无真名/代码/Logo/名人或结局暗示 | data/market.json、data/SOURCE-MANIFEST.json、src/game.js：company | company 投影隐藏真名与来源；浏览器匿名 UI 检查。源码可查阅，非保密系统 | 通过 |
| D06 | 4 | 真名与来源终局揭晓；提前揭晓有警告并永久记剧透标记 | data/market.json、data/SOURCE-MANIFEST.json、src/game.js：company | docs/data-audit.json 76/76、docs/SOURCES.md、公开日期回归 | 通过 |
| D07 | 4 | 不声称客户端保密；开局/随机种子不修改历史价格 | data/market.json、data/SOURCE-MANIFEST.json、src/game.js：company | docs/data-audit.json 76/76、docs/SOURCES.md、公开日期回归 | 通过 |
| D08 | 5 | 财务所属期、事件发生日、公开日分开；每一关键值/价格/行动有来源、口径、核验状态 | data/market.json、data/SOURCE-MANIFEST.json、src/game.js：company | docs/data-audit.json 76/76、docs/SOURCES.md、公开日期回归 | 通过 |
| D09 | 5 | 拆并股、分红、并购、停牌退市、旧股注销按具体权益；品牌不等于原普通股 | src/finance.js：action；data/market.json：actions | 真实分红、拆股、PIR 旧股注销已集成；现金并购仅机制单元测试，没有以真实样本覆盖所有分拆/合并类型 | 部分：真实公司行动样本范围有限 |
| D10 | 5 | 缺失字段显式未核验；无可靠中间价不得交易或画假曲线；模拟数据隔离 | data/market.json、data/SOURCE-MANIFEST.json、src/game.js：company | docs/data-audit.json 76/76、docs/SOURCES.md、公开日期回归 | 通过 |
| D11 | 5 | 不编造真实公司违法；指控/调查/已确认区分且按当时公开日出现 | data/market.json、data/SOURCE-MANIFEST.json、src/game.js：company | docs/data-audit.json 76/76、docs/SOURCES.md、公开日期回归 | 通过 |
| D12 | 5,14 | 所有可见页面/提示/搜索/图表/复盘统一 asOfDate；后来更正不覆盖此前披露 | data/market.json、data/SOURCE-MANIFEST.json、src/game.js：company | docs/data-audit.json 76/76、docs/SOURCES.md、公开日期回归 | 通过 |

## 2. 核心循环、职业与人生

| ID | 附件节 | 必须满足的验收事实 | 实现/数据定位 | 执行证据 | 当前状态 |
|---|---:|---|---|---|---|
| G01 | 6 | 当期 3—5 重点候选；仍能管理原持仓；不强迫定期交易 | src/game.js、src/ui.js | 浏览器研究→判断→审批→买卖→推进→终章；51 生涯报告 | 通过 |
| G02 | 6 | 摘要→有限时间→证据→结构化判断→授权配置→推进→回顾完整 | src/game.js、src/ui.js | 浏览器研究→判断→审批→买卖→推进→终章；51 生涯报告 | 通过 |
| G03 | 6 | 买入理由、主要风险、预期时长、失效证据四项判断；文本只作记录 | src/game.js、src/ui.js | 浏览器研究→判断→审批→买卖→推进→终章；51 生涯报告 | 通过 |
| G04 | 6 | 研究、等待、持有、加/减仓、清仓均真实可用；订单前见现金/费用/集中度/权限/持仓 | src/game.js、src/ui.js | 浏览器研究→判断→审批→买卖→推进→终章；51 生涯报告 | 通过 |
| G05 | 6 | 时间增量明确；危机、赎回、公司行动前有合理反应节点 | src/game.js、src/ui.js | 浏览器研究→判断→审批→买卖→推进→终章；51 生涯报告 | 通过 |
| G06 | 6 | 跨期持仓、现金等待；不年底机械清仓 | src/game.js、src/ui.js | 浏览器研究→判断→审批→买卖→推进→终章；51 生涯报告 | 通过 |
| R01 | 7 | 公司档案三层：生意、财务/经营指标、原始证据及反驳 | src/ui.js：公司三层档案；data/market.json | 三层 UI 已实现；早年利润表/现金流等缺项明确未核验；不把空值算完整财报 | 部分：早期财务字段缺口 |
| R02 | 7 | 保守/中性/乐观估值有可见假设，不当作未来真值 | src/game.js：company/researchCompany/setThesis；src/ui.js | EPS 情景及研究主题回归、浏览器档案三级 | 通过 |
| R03 | 7 | 研究有具体对象、成本、证据覆盖与不确定性；不能买未来答案 | src/game.js：company/researchCompany/setThesis；src/ui.js | EPS 情景及研究主题回归、浏览器档案三级 | 通过 |
| R04 | 7 | 重要候选同时有吸引力和疑点；不同年份信息更新 | data/market.json：早期生意/风险/事实；src/game.js：公开日期 | 有正反业务线索；v1.1新增174个同期原报快照，16家2000—2008各公开年度连续，原报与更正分开按日期可见，未核验字段仍null | 通过：早期年度信息连续；专属经营指标仍不齐全 |
| R05 | 7,10 | 研究/沟通/恢复/陪伴共享有限机会，形成实际代价 | src/game.js：company/researchCompany/setThesis；src/ui.js | EPS 情景及研究主题回归、浏览器档案三级 | 通过 |
| M01 | 8 | 市场预先固定且不受按钮/研究/人生随机流影响 | src/game.js、src/finance.js、data/market.json | 确定性/无杠杆/注销回归；51 生涯报告 | 通过 |
| M02 | 8 | 人生随机种子及流状态存档；浏览/刷新/读档不重骰 | src/game.js、src/finance.js、data/market.json | 确定性/无杠杆/注销回归；51 生涯报告 | 通过 |
| M03 | 8 | 普通股无杠杆不生成额外无限债务；单股损失不抹掉其他资产/已收现金 | src/game.js、src/finance.js、data/market.json | 确定性/无杠杆/注销回归；51 生涯报告 | 通过 |
| M04 | 8 | 策略得失来自历史和人生约束，没有橡皮筋改价或全局万能奖励 | src/game.js、src/finance.js、data/market.json | 确定性/无杠杆/注销回归；51 生涯报告 | 通过 |
| C01 | 9 | 职业可分支；研究员→管理/负责人/合伙或其他去向，不按年份必升 | src/game.js：permissions/_setCareer/advance；src/story.js | 集成回归、三核心生涯、剧情自然到达报告 | 通过 |
| C02 | 9 | 业绩、研究质量、纪律、沟通、信任和关系分开影响评价 | src/game.js：permissions/_setCareer/advance；src/story.js | 集成回归、三核心生涯、剧情自然到达报告 | 通过 |
| C03 | 9 | 赎回、短期跑输压奖金、上司归功、揭问题影响不同人、侥幸扩大权限有功能事件 | src/game.js：permissions/_setCareer/advance；src/story.js | 集成回归、三核心生涯、剧情自然到达报告 | 通过 |
| C04 | 9 | 可见授权、基准、集中上限、风险预算、赎回约束；变化真实改变动作 | src/game.js：permissions/_setCareer/advance；src/story.js | 集成回归、三核心生涯、剧情自然到达报告 | 通过 |
| C05 | 9 | 失业后可凭储蓄/口碑/技能/关系继续；重建/转业/休整/创业 | src/game.js：permissions/_setCareer/advance；src/story.js | 集成回归、三核心生涯、剧情自然到达报告 | 通过 |
| L01 | 10 | 现金、债务、健康/压力、关系、信誉、职业选择空间和长期事件均跟踪 | src/story.js、src/game.js：memory/pending/relations | docs/STORY_COVERAGE.md、13 定向生涯 + 1 重播 | 通过 |
| L02 | 10 | 重要选择留下具体记忆/承诺，即时→延迟→关键节点兑现 | src/story.js、src/game.js：memory/pending/relations | docs/STORY_COVERAGE.md、13 定向生涯 + 1 重播 | 通过 |
| L03 | 10 | ≥12 条两年以上后续链，≥6 跨主要阶段；无伪关联 | src/story.js、src/game.js：memory/pending/relations | docs/STORY_COVERAGE.md、13 定向生涯 + 1 重播 | 通过 |
| L04 | 10,11 | ≥8 主要人物独立目标、脾气、边界、关系和弧线；恋爱非强制 | src/story.js、src/game.js：memory/pending/relations | docs/STORY_COVERAGE.md、13 定向生涯 + 1 重播 | 通过 |
| L05 | 10,11 | 不以不陪伴强制灾难/诚实必致富；人物间变化不全围绕玩家 | src/story.js、src/game.js：memory/pending/relations | docs/STORY_COVERAGE.md、13 定向生涯 + 1 重播 | 通过 |
| L06 | 10 | 记忆账本含日期、处境、选择、承诺、人物、已兑现/未解决；不引用未发生经历 | src/story.js、src/game.js：memory/pending/relations | docs/STORY_COVERAGE.md、13 定向生涯 + 1 重播 | 通过 |
| N01 | 11 | 克制现实主义、年代一致；物件/邮件/重逢回收 | src/story.js | 剧情作者全文人工审阅；独立检查关键回忆条件。文学质量不等同自动断言 | 通过 |
| N02 | 11,16 | 普通 100—220 字、关键 250—450 字为目标；节点独立功能非换名模板 | src/story.js | docs/STORY_COVERAGE.md：84 独立手写节点/长度核查/因果修订 | 通过 |

## 3. 金融计算与复盘

| ID | 附件节 | 必须满足的验收事实 | 实现/数据定位 | 执行证据 | 当前状态 |
|---|---:|---|---|---|---|
| F01 | 12 | 统一引擎和可复核账本驱动页面；所有财富变动有来源，无剧情直接改最终财富 | src/finance.js、src/game.js、src/ui.js | output/qa/unit-tests.txt；独立集成回归；真实持仓生涯 | 通过 |
| F02 | 12 | 行情原始价/复权价/总回报口径明确；分红拆股不重复；基准同口径 | src/finance.js、src/game.js、src/ui.js | output/qa/unit-tests.txt；独立集成回归；真实持仓生涯 | 通过 |
| F03 | 12,17 | 不投入无持仓、不能超现金买入/超量卖出；金额数量合法 | src/finance.js、src/game.js、src/ui.js | output/qa/unit-tests.txt；独立集成回归；真实持仓生涯 | 通过 |
| F04 | 2,12,17 | 未获授权、未上市、停牌、注销、终局等不成交 | src/finance.js、src/game.js、src/ui.js | output/qa/unit-tests.txt；独立集成回归；真实持仓生涯 | 通过 |
| F05 | 12,17 | 拆并股数量与单股成本反向调整，总权益保持；具体零碎股口径 | src/finance.js、src/game.js、src/ui.js | output/qa/unit-tests.txt；独立集成回归；真实持仓生涯 | 通过 |
| F06 | 12,17 | 分红现金权益正确且幂等；重载/重复推进不再派发 | src/finance.js、src/game.js、src/ui.js | output/qa/unit-tests.txt；独立集成回归；真实持仓生涯 | 通过 |
| F07 | 12,17 | 多次买入/部分卖出/清仓；成交日期数量价格费用和成本规则确定 | src/finance.js、src/game.js、src/ui.js | output/qa/unit-tests.txt；独立集成回归；真实持仓生涯 | 通过 |
| F08 | 12,17 | 机构 TWR 剔除客户申赎；工资储蓄不是收益；机构收入不入客户/个人账 | src/finance.js、src/game.js、src/ui.js | output/qa/unit-tests.txt；独立集成回归；真实持仓生涯 | 通过 |
| F09 | 12,17 | 停牌估值、赎回到账、强退与旧股注销不混同 | src/finance.js、src/game.js、src/ui.js | output/qa/unit-tests.txt；独立集成回归；真实持仓生涯 | 通过 |
| F10 | 12,17 | 不规则流用验证过的资金加权收益；不能平均年化或误用 CAGR | src/finance.js、src/game.js、src/ui.js | output/qa/unit-tests.txt；独立集成回归；真实持仓生涯 | 通过 |
| F11 | 12 | 复盘列投入退出、剩余、持有时长、实现/未实现损益、分红、费用、回报、适用年化、最大回撤、同期间基准 | src/finance.js、src/game.js、src/ui.js | Finance 收益字段回归、浏览器持仓/终章检查；区间端点为真实已核验采样点 | 通过 |
| F12 | 12 | 回撤注明采样频率；没有日内数据不称真实日内回撤 | src/finance.js、src/game.js、src/ui.js | output/qa/unit-tests.txt；独立集成回归；真实持仓生涯 | 通过 |
| F13 | 12 | 卖后档案回访；实际损益/错过上涨/躲过下跌/再投资分明；反事实不扣现金 | src/finance.js、src/game.js、src/ui.js | output/qa/unit-tests.txt；独立集成回归；真实持仓生涯 | 通过 |
| F14 | 12 | 财务变化、职业评价、人生余波分别展示 | src/finance.js、src/game.js、src/ui.js | output/qa/unit-tests.txt；独立集成回归；真实持仓生涯 | 通过 |

## 4. 结局、界面、存档和交付

| ID | 附件节 | 必须满足的验收事实 | 实现/数据定位 | 执行证据 | 当前状态 |
|---|---:|---|---|---|---|
| E01 | 13,16 | ≥8 实质不同可达结局，依据累计状态/关键事件，不由最后一题指定 | src/story.js：endings；src/ui.js：ending | 9/9 自然终局见证；浏览器终章与揭晓 | 通过 |
| E02 | 13 | 终局含年表、机构业绩、个人资产来源、投资得失、关系、早期回声、真实公司/来源 | src/story.js：endings；src/ui.js：ending | 9/9 自然终局见证；浏览器终章与揭晓 | 通过 |
| E03 | 13 | 过程、结果、运气分开，无伪精确运气比例 | src/story.js：endings；src/ui.js：ending | 9/9 自然终局见证；浏览器终章与揭晓 | 通过 |
| E04 | 13 | ≥3 开局改变资源与剧情，不改行情；独立浏览器独立进度 | src/story.js：endings；src/ui.js：ending | 9/9 自然终局见证；浏览器终章与揭晓 | 通过 |
| U01 | 14 | 档案/研究终端/人生手记视觉，深蓝灰白，文字符号表达盈亏 | src/style.css、src/ui.js、src/shell.html | docs/BROWSER_QA.md；桌面/手机截图与实际操作 | 通过 |
| U02 | 14 | 必备页面和导航：开始/继续、处境、研究、档案、交易/组合、职业/关系、事件/记忆、复盘、结局 | src/style.css、src/ui.js、src/shell.html | docs/BROWSER_QA.md；桌面/手机截图与实际操作 | 通过 |
| U03 | 14 | 手机任务分层，触控按钮、弹窗关闭、键盘焦点、禁用原因 | src/style.css、src/ui.js、src/shell.html | docs/BROWSER_QA.md；桌面/手机截图与实际操作 | 通过 |
| U04 | 14 | 第一轮操作引导、按需术语、损失/离职/清仓/长期跳时确认 | src/style.css、src/ui.js、src/shell.html | docs/BROWSER_QA.md；桌面/手机截图与实际操作 | 通过 |
| U05 | 14 | 字号/对比可读、减少动画选项 | src/style.css、src/ui.js、src/shell.html | docs/BROWSER_QA.md；桌面/手机截图与实际操作 | 通过 |
| U06 | 14 | 组合/基准、持仓构成、生涯时间线三可视化；不显示未来/伪数据 | src/style.css、src/ui.js、src/shell.html | docs/BROWSER_QA.md；桌面/手机截图与实际操作 | 通过 |
| S01 | 15,17 | 自动与多槽存档、导入/导出、生涯摘要导出 | src/game.js：validateSave；src/finance.js：validateAccount；src/ui.js：storage | 独立回归、51 生涯往返、docs/BROWSER_QA.md | 通过 |
| S02 | 15 | 存储 getter/setItem 全面捕获；不可用/满额提示与可导出降级；明确 file 限制 | src/game.js：validateSave；src/finance.js：validateAccount；src/ui.js：storage | 独立回归、51 生涯往返、docs/BROWSER_QA.md | 通过：Chrome 实际故障注入与导出 |
| S03 | 15 | 存档含版本、日期、三账、组合、授权、职业、关系、历史、待兑现、随机流 | src/game.js：validateSave；src/finance.js：validateAccount；src/ui.js：storage | 独立回归、51 生涯往返、docs/BROWSER_QA.md | 通过 |
| S04 | 15 | 导入验证结构、版本、金额、状态；畸形/注入内容不能破坏页面 | src/game.js：validateSave；src/finance.js：validateAccount；src/ui.js：storage | 独立回归、51 生涯往返、docs/BROWSER_QA.md | 通过 |
| S05 | 15,17 | 加载不重复派发工资奖金分红/事件；同状态种子复现 | src/game.js：validateSave；src/finance.js：validateAccount；src/ui.js：storage | 独立回归、51 生涯往返、docs/BROWSER_QA.md | 通过 |
| S06 | 5,17 | 未上市不可交易，未来信息不可见，刷新不变行情 | src/game.js：validateSave；src/finance.js：validateAccount；src/ui.js：storage | 独立回归、51 生涯往返、docs/BROWSER_QA.md | 通过 |
| S07 | 17 | 终局后不能交易/结算/修改资金 | src/game.js：validateSave；src/finance.js：validateAccount；src/ui.js：storage | 独立回归、51 生涯往返、docs/BROWSER_QA.md | 通过 |
| S08 | 17 | 日期单调、账户守恒、事件互斥、终局可达、页面数字一致 | src/game.js：validateSave；src/finance.js：validateAccount；src/ui.js：storage | 独立回归、51 生涯往返、docs/BROWSER_QA.md | 通过 |
| A01 | 16 | 数据、公开信息、事件、角色、金融、职业生活、UI、存档职责分离 | src/finance.js、src/game.js、src/story.js、src/ui.js、data/market.json | 代码审计、24/24 独立回归、84 节点/42 选择/9 终局覆盖 | 通过 |
| A02 | 16 | 事件 ID/时间/条件/人物/文本/选项/成本/即时/延迟/回收齐全 | src/finance.js、src/game.js、src/story.js、src/ui.js、data/market.json | 代码审计、24/24 独立回归、84 节点/42 选择/9 终局覆盖 | 通过 |
| A03 | 16 | 固定推进顺序，不能看到未来价后回填旧价订单 | src/finance.js、src/game.js、src/story.js、src/ui.js、data/market.json | 代码审计、24/24 独立回归、84 节点/42 选择/9 终局覆盖 | 通过 |
| A04 | 16 | ≥80 有独立功能手写节点，单局约 40—70 重要选择，无空白年代 | src/finance.js、src/game.js、src/story.js、src/ui.js、data/market.json | 代码审计、24/24 独立回归、84 节点/42 选择/9 终局覆盖 | 通过 |
| A05 | 16 | 分支可达报告；无 TODO/装饰按钮/未来解锁承诺 | src/finance.js、src/game.js、src/story.js、src/ui.js、data/market.json | 代码审计、24/24 独立回归、84 节点/42 选择/9 终局覆盖 | 通过 |
| T01 | 17 | 谨慎现金、集中高波动、生活与职业调整三局完整走通 | tests/career-simulation.cjs、tests/story-reachability.cjs、Playwright 操作 | output/qa/career-paths-51.json；docs/BROWSER_QA.md | 通过 |
| T02 | 17 | 明确覆盖失业继续、部分卖出、真实公司行动、重大损失、跨年关系回收 | tests/career-simulation.cjs、tests/story-reachability.cjs、Playwright 操作 | output/qa/career-paths-51.json；docs/BROWSER_QA.md | 通过 |
| T03 | 17 | 桌面手机、键盘、长文、导入导出、坏存储、file 离线与通关实际浏览器测试 | tests/career-simulation.cjs、tests/story-reachability.cjs、Playwright 操作 | output/qa/career-paths-51.json；docs/BROWSER_QA.md | 通过：Chrome 实际故障注入与导出 |
| X01 | 15,18 | 单文件 index.html 内嵌 CSS/JS/数据，断网可直接打开，无 CDN/API/远程字体依赖 | index.html、build.cjs、src | 最终 HTML 语法/内联资源断言；file: Chrome 断网经 53 日期通关 | 通过 |
| X02 | 15 | 无账号、收费、个人信息采集、排行榜、联机、交易接口 | index.html、build.cjs、src | tests/build.test.cjs；浏览器 file: + offline 通关 | 通过 |
| X03 | 15,18 | 真实本地文件、部署包、公开网址状态分开；公开站必须实测 | Sites public 发布；离线 index.html 分开交付 | docs/BROWSER_QA.md：全新无登录 Chrome context HTTP200、可开始并选择；父任务无Cookie curl校验 | 通过 |
| X04 | 18 | index.html、完整源码数据 ZIP、README、来源口径、实际测试报告齐备 | 根任务交付/发布流程 | output/qa/package-verification.json：实际解压、清单校验、HTML与数据重建一致、109/109包内测试通过 | 通过 |
| X05 | 委托补充 | 新独立作品，不覆盖时光仓；结果保存 Library 并返回确认 ID | 独立目录、独立 Site；delivery-receipt.json | 回执 5/5 status=succeeded 且 metadataApplied=true：index.html、源码数据 ZIP、README、SOURCES、TEST_REPORT；各 library_file_id 已记录 | 通过：5 份 Library 文件已确认 |

## 5. 验收路径规范

- **E2E-CASH**：现金缓冲开局；先研究再提交，授权后小额配置；跨年持仓；一次部分卖出；比较机构 TWR 与个人工资来源；最终通关。
- **E2E-RISK**：集中/高波动组合；不绕过真实集中度与权限；经历真实大跌或永久权益损失；有反应机会且分散资金/已收分红仍在；最终通关。
- **E2E-LIFE**：有限行动中选择陪伴/恢复；职业调整或失业；失业期间依靠储蓄与关系继续；至少一个两年以上承诺被有条件回收；最终通关。
- **终局覆盖**：每种结局应有一条从正常开局、通过合法选项到终局的执行记录。单独构造临界状态可以测试判定函数，但不能据此宣称结局自然可达。
- **叙事覆盖**：按事件稳定 ID 记录实际可达节点；80 节点数量断言不等于 80 节点文风/功能合格。模板相似度与人工检查共同记录。
- **真实公司行动**：引擎合成拆股/分红/注销测试检验算法；另外至少一个来源核实、真实数据中存在的行动检验集成，二者不可互相冒充。
- **公开访问**：本机 localhost、带身份的编辑预览、Library 文件下载链接都不计公开站；发布权限与匿名可访问结果由发布人员记录。

## 6. 数据证据闸门

公司入池前须记录真实身份、匿名 ID、行业/生意、上市及可交易窗口、行情来源与查询参数、原始/调整口径、行动列表、可见事实及 `publishedAt`、财务缺口、核验状态。若无法建立可靠行情，先更换候选或缩短其交易窗口；不能用报告内经营增长或两点插值冒充真实可交易价格。

来源 `R1`—`R5` 仅为附件研究起点。`R1` 不证明价格回报，`R2/R3` 不自动证明所有旧股在申报日归零，`R4` 不把每项机构内部限制变成法律，`R5` 不保证任一浏览器永久支持 file 存档。具体市场来源审计由数据交付文档承担；规则与存储来源见 `RULES.md`。

## 7. 更新纪律

测试执行前不写“通过”。每次独立审计应记录产物版本/摘要、日期、命令或浏览器操作、实际断言计数及失败项。已写测试但未执行记“待核验”；仅静态检查不计浏览器实测；修复后重跑有关测试并保留修复说明。最终仍待核验/部分/限制项必须汇总到测试报告，不能在交付文案中隐去。

## 8. 已执行证据索引（2026-10-02）

- `output/qa/career-paths-51.json`：正常开局、合法命令 51 完整生涯；116,741 项断言，84/84 节点、8 具名结局。三核心每局 42 选择、53 市场日期，含失业继续、部分卖出、真实分红/拆股/PIR 注销及 -100% 个股损失。此为最后债务流水字段与三条叙事前因增强之前的广覆盖报告；最终三核心与叙事定向重跑另列，不能把两份版本混为同一遍执行。
- `tests/story-reachability-results.json`：最终叙事版本的 13 定向完整生涯 + 1 完整重播，5,250 过程断言并检查三个覆盖集合，84/84 事件、9/9 结局、12/12 完整因果链。见证从正常开局产生，没有注入终局状态。
- `output/qa/independent-regression.txt`：独立集成 22 项 + 构建 2 项，24/24 通过；根任务全套结果见 `output/qa/unit-tests.txt`。
- `docs/data-audit.json`：数据转换与来源映射 76/76 通过；不代替金融和浏览器验收。
- `docs/BROWSER_QA.md`：真实 Chrome 的桌面/390px 手机视口、研究审批交易、存档、注入文本、完整断网生涯等实际操作。
- 公开地址及匿名可玩已独立浏览器验证；ZIP 解压重建与包内测试见 `output/qa/package-verification.json`；5 份 Library 保存确认见 `delivery-receipt.json`。后续网络地区性检查以根任务最新部署说明为准。

限制：手机测试为 Chrome 视口模拟，未在实体手机或 Safari/Firefox 实测；行情取 53 个已核验节点，曲线不代表日内路径，不对无报价日期开放交易；初期财务缺口和 PIR 有限窗口明确披露。匿名不提供客户端反作弊/保密保证。

最终构建补证：`output/qa/career-paths-final-3.json` 的三核心生涯 6,869 断言全部通过；最终 `ee844ee...` 单文件再次实际断网从开局 UI 通关，42 选择/53 日期/44 岁；SecurityError 与 QuotaExceededError、新存档 schema 往返、公开站匿名浏览器测试均通过，详见 `BROWSER_QA.md`。

## 9. 最后只读核对：资料缺口与篇幅口径

本节最初为交付复核，已更新至v1.1追加研究、实际测试与公开发布结果。

- **2000—2008 财务缺口已按同期年报补齐年度覆盖**：v1.1新增174快照，每家公司各公开年度连续；180份源哈希与披露日期核验通过。1392字段槽中1297非空，剩余95项为空：FAST四年纯capex、43份GPC/THO/SCHL/HRB的EPS与shares、CBU五年shares。行业专属指标、完整债务到期表和精确IPO日期仍不足，不称完整商业数据库。
- **IPO 与规模缺口**：全部 17 家的 `actualListingDate` 均为 `null`；16 家的 `listed=2000-01-03` 与 PIR 的 `listed=2019-07-31` 仅表示游戏开放交易窗口。已有开局前 SEC 年报与真实交易日证据，不等于已核验各自精确 IPO 日、完整上市沿革和 2000—2020 逐年市值规模。本包没有这些完整规模序列。
- **行情没有合成或插值**：16 × 53 = 848 条核心报价按同日 Yahoo 归档响应与真实拆股比例还原，PIR 另 3 条分别有 SEC/当日新闻来源；无报价不交易，旧价展示标记陈旧。SPY 使用真实同日调整收盘序列。故事、工资、费用属于明确虚构规则，不能误称这些人生参数也是真实市场数据。逐点来源变换可复现，不代表每点已由第二家行情商独立认证。
- **84 事件精确篇幅**：正文按 Unicode 字符计数，不计标题、选项、提示与另行追加的回收。79 个普通正文共 10,199 字符，每段 115–143；5 个关键正文原始共 1,406 字符（含 14 个空白/换行），去空白共 1,392，每段分别 `b17=253`、`c17=267`、`c35=270`、`b41=300`、`c41=302`。全部正文原始合计 **11,605**，去空白且保留标点合计 **11,591**。原始字符串关键段范围 255–306；两种口径不能混写。篇幅达到附件目标，独立功能与文风另依人工内容审核，不由字数单独证明。
- **文件交付**：网页、源码数据包、README、来源、测试报告与本矩阵均按各自既有Library身份维护；最新版本以任务最终回执为准。公开源码不包含内部Library文件标识。

2026-10-02用户追加明确授权后，已创建公开 GitHub 仓库 https://github.com/a1459000683-art/the-unrealized-life 并启用免费 Pages：https://a1459000683-art.github.io/the-unrealized-life/ 。首次v1发布run37020255828的build/deploy均success；本机默认curl与显式--noproxy '*'均HTTP200且SHA相同，全新未登录Chrome真实开局与选择结算成功。仅证明本机当前网络，不是全国各运营商保障。原Sites站保留备用，没有购买付费服务、创建token/OAuth或改系统网络。Cloudflare登录页未继续操作。
