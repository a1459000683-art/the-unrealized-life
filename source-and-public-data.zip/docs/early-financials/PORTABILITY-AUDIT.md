# v1.1 可移植性与分发隐私预审

本次按 `scripts/package_release.py` 的选择规则检查文件，没有运行打包器、修改产品/市场数据或执行发布。扫描时选择207份文件，其中198份可读文本；研究原年报全文不在分发选择中。

## 实际验证

- 所有研究脚本的项目根目录均由脚本位置推导，未发现硬编码的个人工作区；本轮无需修改脚本。
- 在独立临时目录中复制拟分发文件，确认不存在 `data/raw/*.txt` 或 `data/raw/early/` 原件目录，再运行 `python3 scripts/build_market.py`：成功。市场数据重建前后逐字节相同，SHA256均为 `bf7feeae0fa6f6391631f79e787f917f56a0e65310b4b22011e306cdbc61d75f`；17家公司、404条事实、1218项公司行动。
- 同一目录运行 `python3 scripts/audit_market.py`：76项通过，0失败。
- 同一目录运行 `node --test tests/early-financials.test.cjs`：21项通过，0失败。所需 `output/playwright/final-browser-save.json`、`quota-save.json`、`securityerror-save.json` 均存在、被分发规则包含，并实际通过旧存档加载测试。
- 全文模式的研究提取/原件哈希审计脚本仍需要从所列来源恢复研究原件；这是重新提取原始证据的依赖，不是市场数值重建、游戏运行或上述测试的依赖。未将这些原件脚本冒充随包无需原件可执行的流程。

## 隐私检查结果

未发现密钥/token形态、私钥、个人邮箱或脚本硬编码用户目录。BusinessWire链接中的 `/home/` 为公开网站路径；`research@example.com` 为研究脚本占位联系地址，均不是本机路径或个人邮箱。

预审发现并向主任务报告了三项清理位置，不记录其内部标识或实际路径：

1. `docs/cash-rebuild-audit.json` 的旧临时目录日志：主任务已清理，本轮复查无命中。
2. `docs/REQUIREMENTS.md` 中旧交付的5个内部Library标识：主任务已清理，本轮复查0个内部文件标识。
3. `output/qa/browser-results.json` 中一条本机 `file:` 测试地址：主任务已清理，本轮复查0个用户路径。

三份文件清理后的定向复查：内部Library标识、用户路径和临时目录均为0命中。结论：本轮发现项已清理，数值包重建与新增测试通过。本报告是预审，不表示已经制作或发布新的ZIP；实际归档仍须由主任务最终验包。
