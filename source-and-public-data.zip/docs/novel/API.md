# Novel wrapper contract v1

`src/novel.js` exports `globalThis.Novel` and CommonJS `module.exports`. Load Finance, MARKET, a minimal old STORY with eight characters and empty events/endings, Game, NOVEL_STORY, then Novel. Game and Finance retain their APIs and receive only the integrated QA safety fixes documented in FINANCIAL-INTEGRATION.md. Historical prices/actions and the old save schema are unchanged.

- `new Novel(start = 'buffer', seed = 2000)`; starts: `debt`, `buffer`, `network`.
- `view()` is a lightweight projection: `{phase,date,age,chapter,node,result,ending,people,summary,progress,revision}`. It does not call the expensive Game.view.
- `node`: `{id,title,text,choices:[{id,choiceId,label,detail,available,reason}],dateIndex,slot}`. **choice.id is an opaque revision-bound token**; pass it unchanged to `choose(choice.id)`. `choiceId` is the authored local ID. Optional expectedNodeId/revision arguments provide extra stale-input checks. Raw authored IDs require both matching expectedNodeId and revision. A consumed or stale token is rejected, even if a later node reuses the local choice ID.
- `choose(token, expectedNodeId?, expectedRevision?) -> {ok,error?,result?}` atomically consumes one choice, applies its effects and strategy, and advances through every intermediate real market date exactly once to prepare the next scene. The settled result is stored. Failure restores all state.
- `next() -> {ok,error?}` only consumes a result and navigates to the prepared node/ending. **No salary, expense, fee, corporate action or trade occurs in next().** Calling it outside result phase fails.
- `audit()` lazily calculates full account statistics, current-date research views and ledgers. UI must not read MARKET or calculate money.
- `summary()` returns a plain-text career export.
- `exportSave()` returns a JSON string. `Novel.validateSave(raw)` returns `{ok,error?,...}`; `Novel.fromSave(raw)` throws on invalid input. Exact envelope game ID `unrealized-life-novel` and `schemaVersion:1` are mandatory; old Game saves and bare states are rejected.
- `Novel.STORAGE_PREFIX = 'unrealized-life-novel:v1:'`; UI owns slots and storage fallback. Do not read/write legacy keys.

## Authored content

`NOVEL_STORY={version:1,characters,chapters,nodes,endings}`. Characters retain IDs `lin,mara,june,elias,mei,sam,nora,darius`.

Nodes: `{id,dateIndex:0..52,slot:0|1,chapter,title,text,requires?,priority?,choices}`. Nodes sharing dateIndex+slot are mutually exclusive alternatives; select the highest-priority eligible alternative. Each group needs an unconditional fallback. The planned schedule is 53 main slots plus 24 second slots (77 decisions), with >=20 additional authored alternatives. No node/choice may jump groups in v1.

Choices: `{id,label,detail?,requires?,effects?,strategy?,result:{title?,text},ending?}`. Each node contains 2–4 choices. `ending` is an optional explicit ending ID for the late, carefully foreshadowed fictional terminal branch; low health never automatically means death.

Conditions: `flagsAll`, `flagsNone`, `flagsAny`; `career` (string/array), `start` (string/array); `min`/`max` maps. Numeric keys include the eight Game stats, `relations.ID`, `authority`, `debt`, `personalCash`, `wealth`, `age`, `choices`, `dateIndex`, `unemployedMonths`. Flags, relationships, research and career affect the actual eligibility and transaction policy.

Effects: the eight stats as flat numeric deltas; `relations:{id:delta}`, `flags`, `removeFlags`, `career`, `authority`, `personalCash`, `debt`. **Global research skill is numeric `research`; specific dossier work is `researchCompany:[{companyId,topic}]`**, with Game research time cost and topics `cashflow/debt/customers/valuation/challenge`. Story-specific positive/negative cash effects are one-time external personal flows with narrative reasons, never taken from the client account. Scheduled work salary/bonus remains the Game's firm-to-person accounting.

Strategy: `{type:'invest'|'hold'|'reduce'|'exit'|'repay',companyId?,account?:'client'|'personal',targetPercent?,thesis?}`. `targetPercent` for invest/reduce is target percentage of that account's NAV, not percentage of shares. `exit` sells the full affected holding; `hold` performs no trade. For repay, targetPercent is percentage of current personal cash (default100), capped at outstanding personal debt, without forced asset sale. Invest requires dossier research and a recorded pre-trade thesis; it seeks actual committee approval for client assets, obeys concentration/risk/cash/trading-window rules, and records partial execution or refusal transparently. Effects may include current dossier research before that same authored investment decision. No margin, no arbitrary deposit command.

A normal route reaches2020 through all77groups. A forced ending remains in Novel state; core.ending is not falsified to bypass the legacy date validator. Result screens are saved after settlement and never replayed on reload.

## Read-only UI objects

- `chapter`: `{id,title,subtitle?}`.
- `people`: `{id,name,role,relationship,status}[]`; role histories are filtered by the current date.
- `summary` in `view`: `{career,clientNav,personalNav,personalNetWorth,debt,health,stress,choiceCount,salaryTotal,bonusTotal,livingTotal}`. NAV changes are not labelled investment profit.
- `progress`: `{choiceCount,totalGroups,groupIndex,dateIndex,totalDates}`.
- `result`: `{id,nodeId,choiceId,title,text,fromDate,toDate,changes,notices,transactions,performance,terminal}`. `changes` rows contain `{label,before,after,delta}`; `transactions` rows contain `{account,date,type,company,...}` where company is the stable anonymous alias. Corporate-action rows include the actual quantityBefore/quantityAfter/perShare/ratio where available. No raw action source metadata is projected into these rows.
- `performance`: `{client:{twr,reason},personal:{twr,reason}}`. Period TWR is the ratio of end/start account TWR factors minus one, neutral to external contributions and withdrawals, including trading/management costs. A zero starting factor yields `twr:null` and an explicit reason. Use these values, never NAV differences, for investment percentages. Personal net-worth changes also include employment income, consumption and debt.
- `ending`: `{id,title,text,kind,date,age,reveal:[{alias,name,ticker,business}]}` or null. Only an ending reveals company identity; death is authored, late and conditional, not inferred from a health number.
- `audit()`: `{date,clientStats,personalStats,positions,companies,permissions,clientHistory,benchmark,oldFiles,ledgers:{client,personal,firm,debt},firm,summary}`. Company dossier facts retain the Game's current-date/research gates; client/personal ledger rows use aliases. Internal company IDs are keys, never display names. UI does not render raw source/action JSON; source links are available only after the ending reveal.

Additional condition statistics supported: `personalNav`, `clientNav`, `clientTwr`, `personalTwr`, `careerMonths`, `choiceCount`; TWR thresholds are decimal values, e.g. `0.5` means 50%. Unknown numeric condition/effect keys are rejected as content errors rather than silently making a branch impossible.
