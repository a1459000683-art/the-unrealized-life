# 实际浏览器验收

执行日：2026-10-02。使用独立 Playwright CLI 会话 `unrealized-audit` 驱动真实 Chrome 154.0.8037.95；没有操作用户登录窗口或其他项目。桌面视口 1440 × 1000，手机视口 390 × 844。手机是浏览器视口模拟，未声称实体手机或 Safari/Firefox 验证。

最终离线文件：`index.html`，1,976,053 字节，SHA-256 `ee844ee254761023fac8e34f9dc7bc2fd26bf57700715c0e29130ab9657872d9`。最终测试通过后文件未更改。

## 操作与结果

| 实际操作 | 观察结果 | 证据 / 版本范围 |
|---|---|---|
| 本地文件直接打开、新开局 | 中文标题、24 岁、2000-01-03；可进入研究桌，3 选项、4 公司候选 | `desktop-desk.png`；最终版本另 fresh load |
| 打开湖岸航材档案→研究现金流→填写四项事前判断→提交委员会 | 行动点 3→2；授权 8%；研究和提交均未成交；客户现金仍 1,000,000、无持仓 | 开发期完整 UI 流；随后产品仅补债务流水及叙事前因 |
| 交易预览买 100 股→确认；再预览卖 40 股→确认 | 剩余 60 股，成本 1,265.01356982，客户现金 998,733.30143042，个人现金仍 90,000，金融对账误差 0；预览费用/所得/剩余股数可见 | `mobile-portfolio.png`；真实 Game / Finance / 历史报价，不注入资产 |
| 手机组合账本、长文、终章 | 390px 页面无整页横向溢出，表格内部可横向滚动；正文及按钮可读 | 人工查看 `mobile-portfolio.png`、`mobile-ending.png` |
| 两个手动存档、设置、真实下载 | slot1 / slot2 均保留开局；减少动画和大字号类生效，无手机溢出；JSON 成功下载 | `browser-save.json`；后续最终新 schema 再下载 `final-browser-save.json` |
| 格式非法的导入 | 把客户现金改成字符串，UI 显示「导入失败：无法载入：账户损坏」；原持仓 60 股不变，没有导入确认弹窗 | `malformed-save.json`；最终版又以 `final-malformed-save.json` 实测相同拒绝 |
| 合法导入及键盘取消 | 导入前有内容摘要及确认；Escape 关闭后未替换；重新导入确认恢复原账本 | 最终新债务流水 schema 也实际下载→上传→确认，`Game.validateSave` 返回 true |
| 恶意样式便笺 | 写入 `<img src=x onerror=window.__qaInjected=true>` 的便笺并保存、导入，标记始终 false，没有执行为 HTML | 该字符串保存在开发期导出 JSON；UI 对文本统一 escape |
| 初始访问 localStorage 抛 SecurityError | 页面正常开始，明确提示内存暂存及导出；可保存会话槽并实际下载合法 JSON；捕获页面脚本错误数为 0 | **最终构建**；`securityerror-save.json`、`final-storage-fallback.png` |
| Storage.setItem 抛 QuotaExceededError | 推进到 2000-06-30、覆盖并读取手动槽后仍是新日期；磁盘旧槽仍为 2000-01-03，没有覆盖新内存结果；导出可用且合法 | **最终构建**；`quota-save.json` |
| file: 设置网络 offline 后刷新 | 最终游戏仍打开；仅记录本地 index 文件请求，无 HTTP/CDN/API 请求；0 新页面脚本错误 | **最终构建**；可见 `debtLedger` 新字段 |
| 完整离线人生 | 开发期持有 60 股的路径走到 2020-12-31、44 岁、42 次重要选择、53 日期，终局「按约定到达的钱」；股票持有跨年并收到真实权益 | `mobile-ending.png`；全部通过 UI 选择/确认按钮，非终局注入 |
| 最终版本再次完整离线人生 | 从正常开局，通过全部 UI 选择和推进到同一终点，42 次选择；终局真实公司揭晓、存档验证 true，并实际下载生涯摘要 | **最终构建**；`final-desktop-ending.png`、`final-career-summary.txt` |
| 公开站手机和键盘 | 8 人物卡可见，记忆手记含刚才选择；弹窗首焦点为关闭；推进对话框 Tab 到「再想一会儿」显示 3px solid 焦点，Enter 取消且日期不变；Escape 可关闭；390px 无整页溢出 | **最终公开构建**；`public-mobile-desk.png` |

以上截图路径均相对于 `output/playwright/`。JSON 文件是测试员通过浏览器操作生成的虚构游戏存档，非用户私人资料。

## 公开网址验证

生产网址：<https://the-unrealized-life-2000.a1459000683.chatgpt.site/>。

根任务发布服务确认 `succeeded` 和 `access_mode=public` 后，独立验收另建没有既有 Cookie、没有登录记录的 Chrome browser context 访问。观察到 HTTP **200**、标题「未实现的人生 · The Unrealized Life」、没有登录墙；点击「开始这段人生」并完成第 1 个选择，状态为 2000-01-03、24 岁、choices=1，最终债务流水字段存在。页面脚本错误列表为空。桌面截图 `public-desktop-desk.png` 已保存，手机截图 `public-mobile-desk.png` 已人工查看。

生产环境额外请求了同源 `/cdn-cgi/challenge-platform/...`，托管服务设置了 2 个 Cookie。这是公开托管层的反机器人代码，不在离线包内。不能把「离线包无运行时依赖」扩写成「生产站没有任何额外脚本或 Cookie」。未使用用户凭证访问该网址。

## 测试发现与修复

- 最初打包使用字符串作为 `String.replace` 的 replacement，源码中的 `$'` 被错误解释，产生无效脚本和可见源代码。独立浏览器启动发现该阻断问题；根任务改成 replacement 回调。随后构建语法、重新加载、UI 通关都通过。`tests/build.test.cjs` 防止复发。
- 桌面与手机财务字段、费用合计文字和有效净值采样在审计后修正；最终报告明确离散采样及陈旧估值排除，不称每日/日内回撤。
- 最初有头 Chrome 的截图调用等待超时，切换同一独立会话的 headless 模式后成功。一次自动化读取存档忘记确认框，下载等待超时；随后按实际确认按钮继续，验证成功。这两项为测试工具/脚本问题，不列为游戏缺陷，也没有将超时记作通过。

本次没有穷举每个页面和 252 个选择的全部组合。金融边界和全分支证据分别由单元、集成、51 生涯、最终 3 生涯、13 定向叙事生涯报告承担，不能用某一张截图替代它们。
