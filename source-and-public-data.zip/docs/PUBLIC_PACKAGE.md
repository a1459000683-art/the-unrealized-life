# 公共包范围与可移植性

本包使用明确文件白名单。完整游戏源码、行情和SEC数值JSON、已核验的早期财务快照、源链接和哈希、构建脚本及默认Node测试均保留。它不包含需求附件、账号配置、上传凭据、开发者私人目录或本机QA日志。

## 省略项目

- `data/raw`下的年报TXT/HTML全文及`data/raw/early`研究原件不重复分发。原件可按快照中的来源链接自行取得；这不影响离线游戏、数值数据重建或默认Node测试。
- `tests/independent-early-financials-audit.py`和`tests/audit-early-hrb.py`依赖这些原件全文/研究中间表，公共包省略。已核验短数字证据和每项定位仍随早期财务JSON保留。
- 只保留 `scripts/build_market.py`、`scripts/audit_market.py` 和本打包器。首次抓取/解析原报告、作者本地发布和研究杂项脚本不属于离线重建链，故省略。
- 不复制根目录QA报告、浏览器截图、发布日志、原要求或开发进度。`tests`里的小型JSON见证/测试结果是测试资料，不能代替使用者自己运行当前版本。

## 默认测试之外的入口

`tests/novel-browser-faults.cjs`、`tests/novel-browser-final-career.cjs`是接收已有Playwright Page对象的浏览器测试函数，保留供开发者复用；单独执行Node不会自动建立浏览器会话，也不应把这种执行称作浏览器测试通过。真实浏览器测试需要自行准备环境，它不是离线游玩的依赖。

默认 `node --test tests/*.test.cjs` 不需要Playwright、账号、网络、Git历史或完整原年报。RC1/RC2压缩源码夹具保持原字节与哈希，三份旧版存档供结构和账本兼容性测试。`output/qa/.gitkeep`只创建测试输出目录，不包含开发者QA记录。

## 安全检查边界

打包器扫描公开文件、生成说明以及解压后的gzip测试夹具，检查本机用户目录、临时绝对路径、附件标识、常见密钥格式和带密码URL；只报告文件名和规则类别，不回显匹配内容。白名单、人工范围和模式扫描共同限制公开面，扫描没有命中不是对所有可能秘密格式的数学证明。

## 重新打包

先运行 `node build.cjs`，再运行 `python3 scripts/package_public.py`。程序先确认嵌入源码与数据一致、v1.1冻结哈希未变、所有文件扫描无命中，最后准备七个上传文件；不触发构建、浏览器、网络或部署。相同输入生成相同ZIP字节。可以使用 `--output output/public-package-check`隔离演练，或 `--check-only`只检查而不生成文件。
