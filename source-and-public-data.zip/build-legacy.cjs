'use strict';
const fs=require('node:fs');
const path=require('node:path');
const escape=s=>s.replace(/<\/script/gi,'<\\/script');
function build(){
 const data=JSON.stringify(JSON.parse(fs.readFileSync('data/market.json','utf8')));
 const js=['src/finance.js','src/story.js','src/game.js','src/ui.js'].map(p=>fs.readFileSync(p,'utf8')).join('\n;\n');
 const css=fs.readFileSync('src/style.css','utf8');
 let html=fs.readFileSync('src/shell.html','utf8');
 html=html.replace('<!--STYLE-->',()=>css)
  .replace('<!--BOOT-->',()=>escape(fs.readFileSync('src/boot.js','utf8')))
  .replace('<!--SCRIPTS-->',()=> 'globalThis.MARKET='+escape(data)+';\n'+escape(js)+'\n;UI.mount();window.__lifeReady();');
 if(/<!--(?:STYLE|BOOT|SCRIPTS)-->/g.test(html))throw Error('Unreplaced build marker');
 for(const dir of ['dist','site/dist']){fs.mkdirSync(dir,{recursive:true});fs.writeFileSync(path.join(dir,'legacy.html'),html);}
 fs.writeFileSync('legacy.html',html);
 console.log(JSON.stringify({built:true,bytes:Buffer.byteLength(html),outputs:['legacy.html','dist/legacy.html','site/dist/legacy.html']}));
}
build();
